// This file is generated.
export const version = '1.49.2'
