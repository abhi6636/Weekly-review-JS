(function(_) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    var da, fa, ia, ja, ma, sa, ua, xa, Ba, Aa, Ca, Da, Ea, Fa, Ga, Ia, Ja, Pa, Qa, Ra, Sa, Ta, Ua, Va, Wa, Ya, Xa, Za, $a, ab, bb, gb, hb, jb, lb, ob, qb, yb, Ab, Gb, Jb, Ob, Rb, Tb, Wb, Yb, fc, hc, bc, jc, kc, lc, mc, nc, oc, pc, qc, rc, sc, tc, wc, yc, xc, zc, Bc, Cc, Dc, Ec, Ic, Mc, Lc, Kc, Oc, Qc, Rc, Tc, Uc, Xc, Yc, Zc, $c, dd, gd, kd, md, pd, td, qd, wd, ud, vd, xd, Bd, yd, Sc, Dd, Ed, Hd, Ld, Od, Id, Jd, Sd, Td, Ud, Vd, Qd, Rd, Wd, ae, be, de, ee, fe, ie, je, ke, qe, re, te, ue, we, xe, ye, Be, De, Fe, Xe, Oe, Ze, bf, df, ef, gf, lf, mf, nf, qf, rf, uf, zf, vf, Hf, If, Lf, Mf, Sf, Qf, Pf, Of, Xf, gg, hg, ig, vg, Cg, Ag, Bg, Hg, Lg, Mg, Wg, $g, Yg, eh, jh, kh, mh, nh, rh, sh, th, ph, qh, uh, vh, Bh, zh, Eh, Jh, Lh, Mh, Nh, Uh, Yh, H, Zh, ei, ci, pi, ti, vi, wi, yi, zi, Vi, Xi, $i, cj, ej, ij, gj, jj, qj, rj, sj, tj, kj, uj, lj, wj, yj, zj, Bj, Aj, Gj, Ej, Hj, Qj, Tj, Lj, Mj, Uj, Vj, Xj, Yj, Zj, ak, ek, kk, gk, ck, rk, pk, qk, sk, tk, uk, wk, Ik, Jk, Lk, Ok, Qk, Sk, Tk, Uk, Vk, Xk, Zk, $k, al, dl, cl, bl, ll, ol, wl, xl, zl, Al, El, Gl, Kl, Ql, Sl, Ul, Vl, hm, jm, mm, om, qm, rm, tm, vm, wm, um, wa, zm, Am, Cm, Em, Fm, Gm, Im, Nm, Rm, Sm, Wm, Xm, Ym, $m, an, bn, cn, fn, dn, gn, jn, kn, ln, mn, nn, qn, rn, tn, xn, vn, zn, An, Gn, Hn, Jn, On, Pn, Rn, Yn, ao, Zn, $n, mo, po, no, oo, ro, Bo, zo, Co, Fo, so, Oo, Po, So, To, Uo, ap, cp, dp, fp, gp, hp, ip, lp, np, up, op, pp, kp, yp, zp, Cp, Sp, aq, bq, dq, jq, mq, nq, oq, tq, vq, wq, Bq, Cq, Hq, Iq, Lq, Nq, Oq, Gr, Jr, Kr, Lr, Tr, Vr, Xr, $r, as, bs, cs, es, fs, gs, hs, is, js, ks, rs, ss, ts, Cb, Eb, Fb, vs, ys, ws, xs, zs, As, Is, za, qa, ra, Ks, Os, hf;
    da = function(a) {
        return function() {
            return _.ba[a].apply(this, arguments)
        }
    };
    fa = function(a) {
        return a ? a.passive && ea() ? a : a.capture || !1 : !1
    };
    ia = function(a, b) {
        b = _.ha(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    };
    ja = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    ma = function(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    };
    sa = function(a) {
        for (var b = 0, c = 0, d = {}; c < a.length;) {
            var e = a[c++],
                f = _.pa(e) ? "o" + (Object.prototype.hasOwnProperty.call(e, qa) && e[qa] || (e[qa] = ++ra)) : (typeof e).charAt(0) + e;
            Object.prototype.hasOwnProperty.call(d, f) || (d[f] = !0, a[b++] = e)
        }
        a.length = b
    };
    ua = function(a, b) {
        a.sort(b || _.ta)
    };
    xa = function(a) {
        for (var b = wa, c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
            index: d,
            value: a[d]
        };
        var e = b || _.ta;
        ua(c, function(f, g) {
            return e(f.value, g.value) || f.index - g.index
        });
        for (b = 0; b < a.length; b++) a[b] = c[b].value
    };
    Ba = function(a, b) {
        if (!za(a) || !za(b) || a.length != b.length) return !1;
        for (var c = a.length, d = Aa, e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    };
    _.ta = function(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    };
    Aa = function(a, b) {
        return a === b
    };
    Ca = function(a, b) {
        for (var c = {}, d = 0; d < a.length; d++) {
            var e = a[d],
                f = b.call(void 0, e, d, a);
            void 0 !== f && (c[f] || (c[f] = [])).push(e)
        }
        return c
    };
    Da = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192)
                    for (var f = Da.apply(null, ma(d, e, e + 8192)), g = 0; g < f.length; g++) b.push(f[g]);
            else b.push(d)
        }
        return b
    };
    Ea = function(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    Fa = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    Ga = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return c
    };
    Ia = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Ha.length; f++) c = Ha[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    Ja = function() {
        var a = _.q.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    Pa = function(a) {
        return La ? Ma ? Ma.brands.some(function(b) {
            return (b = b.brand) && Na(b, a)
        }) : !1 : !1
    };
    Qa = function(a) {
        return Na(Ja(), a)
    };
    Ra = function(a) {
        for (var b = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g"), c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
        return c
    };
    Sa = function() {
        return La ? !!Ma && 0 < Ma.brands.length : !1
    };
    Ta = function() {
        return Sa() ? !1 : Qa("Opera")
    };
    Ua = function() {
        return Sa() ? !1 : Qa("Trident") || Qa("MSIE")
    };
    Va = function() {
        return Sa() ? Pa("Microsoft Edge") : Qa("Edg/")
    };
    Wa = function() {
        return Qa("Firefox") || Qa("FxiOS")
    };
    Ya = function() {
        return Qa("Safari") && !(Xa() || (Sa() ? 0 : Qa("Coast")) || Ta() || (Sa() ? 0 : Qa("Edge")) || Va() || (Sa() ? Pa("Opera") : Qa("OPR")) || Wa() || Qa("Silk") || Qa("Android"))
    };
    Xa = function() {
        return Sa() ? Pa("Chromium") : (Qa("Chrome") || Qa("CriOS")) && !(Sa() ? 0 : Qa("Edge")) || Qa("Silk")
    };
    Za = function(a) {
        var b = {};
        a.forEach(function(c) {
            b[c[0]] = c[1]
        });
        return function(c) {
            return b[_.u(c, "find").call(c, function(d) {
                return d in b
            })] || ""
        }
    };
    $a = function() {
        var a = Ja();
        if (Ua()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        a = Ra(a);
        b = Za(a);
        return Ta() ? b(["Version", "Opera"]) : (Sa() ? 0 : Qa("Edge")) ? b(["Edge"]) : Va() ? b(["Edg"]) : Qa("Silk") ? b(["Silk"]) : Xa() ? b(["Chrome", "CriOS", "HeadlessChrome"]) : (a = a[2]) && a[1] || ""
    };
    ab = function() {
        var a = Ra(Ja());
        Za(a);
        return Wa() ? (a = a[2]) && a[1] || "" : ""
    };
    bb = function() {
        if (Sa()) {
            var a = _.u(Ma.brands, "find").call(Ma.brands, function(b) {
                return "Firefox" === b.brand
            });
            if (!a || !a.version) return NaN;
            a = a.version.split(".")
        } else {
            a = ab();
            if ("" === a) return NaN;
            a = a.split(".")
        }
        return 0 === a.length ? NaN : Number(a[0])
    };
    _.fb = function(a) {
        if (a instanceof _.cb) a = _.db(a);
        else {
            b: if (eb) {
                try {
                    var b = new URL(a)
                } catch (c) {
                    b = "https:";
                    break b
                }
                b = b.protocol
            } else c: {
                b = document.createElement("a");
                try {
                    b.href = a
                } catch (c) {
                    b = void 0;
                    break c
                }
                b = b.protocol;b = ":" === b || "" === b ? "https:" : b
            }
            a = "javascript:" !== b ? a : void 0
        }
        return a
    };
    gb = function(a) {
        throw Error("unexpected value " + a + "!");
    };
    hb = function(a) {
        var b, c, d = null == (c = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : c.call(b, "script[nonce]");
        (b = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };
    jb = function(a, b) {
        a.textContent = _.ib(b);
        hb(a)
    };
    lb = function(a, b) {
        a.src = _.kb(b);
        hb(a)
    };
    ob = function(a, b) {
        a.write(_.nb(b))
    };
    qb = function(a) {
        return new pb(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    };
    _.wb = function(a) {
        var b = void 0 === b ? rb : b;
        a: {
            b = void 0 === b ? rb : b;
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof pb && d.eh(a)) {
                    a = ub(a);
                    break a
                }
            }
            a = void 0
        }
        return a || _.vb
    };
    yb = function(a) {
        for (var b = _.xb.apply(1, arguments), c = [a[0]], d = 0; d < b.length; d++) c.push(String(b[d])), c.push(a[d + 1]);
        return ub(c.join(""))
    };
    Ab = function(a) {
        var b = window,
            c = !0;
        c = void 0 === c ? !1 : c;
        new _.v.Promise(function(d, e) {
            function f() {
                g.onload = null;
                g.onerror = null;
                var h;
                null == (h = g.parentElement) || h.removeChild(g)
            }
            var g = b.document.createElement("script");
            g.onload = function() {
                f();
                d()
            };
            g.onerror = function() {
                f();
                e(void 0)
            };
            g.type = "text/javascript";
            lb(g, a);
            c && "complete" !== b.document.readyState ? _.zb(b, "load", function() {
                b.document.body.appendChild(g)
            }) : b.document.body.appendChild(g)
        })
    };
    Gb = function(a) {
        var b, c, d, e, f, g;
        return _.Bb(function(h) {
            switch (h.j) {
                case 1:
                    return b = "https://pagead2.googlesyndication.com/getconfig/sodar?sv=200&tid=" + a.j + ("&tv=" + a.o + "&st=") + a.Qb, c = void 0, h.m = 2, Cb(h, Db(b), 4);
                case 4:
                    c = h.o;
                    Eb(h, 3);
                    break;
                case 2:
                    Fb(h);
                case 3:
                    if (!c) return h.return(void 0);
                    d = a.uc || c.sodar_query_id;
                    e = void 0 !== c.rc_enable && a.m ? c.rc_enable : "n";
                    f = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms;
                    g = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
                    return d && c.bg_hash_basename && c.bg_binary ? h.return({
                        context: a.H,
                        gg: c.bg_hash_basename,
                        fg: c.bg_binary,
                        kh: a.j + "_" + a.o,
                        uc: d,
                        Qb: a.Qb,
                        kd: e,
                        Ed: f,
                        jd: g
                    }) : h.return(void 0)
            }
        })
    };
    Jb = function(a) {
        var b;
        return _.Bb(function(c) {
            if (1 == c.j) return Cb(c, Gb(a), 2);
            if (b = c.o) {
                var d = "sodar2";
                d = void 0 === d ? "sodar2" : d;
                var e = window,
                    f = e.GoogleGcLKhOms;
                f && "function" === typeof f.push || (f = e.GoogleGcLKhOms = []);
                var g = {};
                f.push((g._ctx_ = b.context, g._bgv_ = b.gg, g._bgp_ = b.fg, g._li_ = b.kh, g._jk_ = b.uc, g._st_ = b.Qb, g._rc_ = b.kd, g._dl_ = b.Ed, g._g2_ = b.jd, g));
                if (f = e.GoogleDX5YKUSk) e.GoogleDX5YKUSk = void 0, f[1]();
                d = Hb(Ib, {
                    basename: d
                });
                Ab(d)
            }
            return c.return(b)
        })
    };
    Ob = function(a) {
        var b = !1;
        b = void 0 === b ? !1 : b;
        if (Lb) {
            if (b && /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a)) throw Error("Found an unpaired surrogate");
            a = (Nb || (Nb = new TextEncoder)).encode(a)
        } else {
            for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                var f = a.charCodeAt(e);
                if (128 > f) d[c++] = f;
                else {
                    if (2048 > f) d[c++] = f >> 6 | 192;
                    else {
                        if (55296 <= f && 57343 >= f) {
                            if (56319 >= f && e < a.length) {
                                var g = a.charCodeAt(++e);
                                if (56320 <= g && 57343 >= g) {
                                    f = 1024 * (f - 55296) + g - 56320 + 65536;
                                    d[c++] = f >> 18 | 240;
                                    d[c++] = f >> 12 & 63 | 128;
                                    d[c++] = f >> 6 & 63 | 128;
                                    d[c++] = f & 63 | 128;
                                    continue
                                } else e--
                            }
                            if (b) throw Error("Found an unpaired surrogate");
                            f = 65533
                        }
                        d[c++] = f >> 12 | 224;
                        d[c++] = f >> 6 & 63 | 128
                    }
                    d[c++] = f & 63 | 128
                }
            }
            a = c === d.length ? d : d.subarray(0, c)
        }
        return a
    };
    Rb = function(a) {
        if (!Pb) return Qb(a);
        for (var b = ""; 10240 < a.length;) b += String.fromCharCode.apply(null, a.subarray(0, 10240)), a = a.subarray(10240);
        b += String.fromCharCode.apply(null, a);
        return btoa(b)
    };
    Tb = function(a) {
        return Sb[a] || ""
    };
    Wb = function(a) {
        return Vb && null != a && a instanceof Uint8Array
    };
    Yb = function(a) {
        if (a !== Xb) throw Error("illegal external caller");
    };
    fc = function(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = _.x(bc(c, a)), b = c.next().value, a = c.next().value, c = b);
        cc = c >>> 0;
        ec = a >>> 0
    };
    hc = function(a) {
        if (16 > a.length) fc(Number(a));
        else if (gc) a = BigInt(a), cc = Number(a & BigInt(4294967295)) >>> 0, ec = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +("-" === a[0]);
            ec = cc = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), ec *= 1E6, cc = 1E6 * cc + d, 4294967296 <= cc && (ec += cc / 4294967296 | 0, cc %= 4294967296);
            b && (b = _.x(bc(cc, ec)), a = b.next().value, b = b.next().value, cc = a, ec = b)
        }
    };
    bc = function(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    jc = function(a, b) {
        if (ic) return a[ic] |= b;
        if (void 0 !== a.Ua) return a.Ua |= b;
        Object.defineProperties(a, {
            Ua: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return b
    };
    kc = function(a, b) {
        ic ? a[ic] && (a[ic] &= ~b) : void 0 !== a.Ua && (a.Ua &= ~b)
    };
    lc = function(a) {
        var b;
        ic ? b = a[ic] : b = a.Ua;
        return null == b ? 0 : b
    };
    mc = function(a, b) {
        ic ? a[ic] = b : void 0 !== a.Ua ? a.Ua = b : Object.defineProperties(a, {
            Ua: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return a
    };
    nc = function(a) {
        jc(a, 1);
        return a
    };
    oc = function(a) {
        return !!(lc(a) & 2)
    };
    pc = function(a) {
        jc(a, 18);
        return a
    };
    qc = function(a) {
        jc(a, 16);
        return a
    };
    rc = function(a, b) {
        mc(b, (a | 0) & -51)
    };
    sc = function(a, b) {
        mc(b, (a | 18) & -41)
    };
    tc = function(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    };
    wc = function(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new uc(a, Xb) : vc();
            else if (a.constructor !== uc)
            if (Wb(a)) {
                var d;
                c ? d = 0 == a.length ? vc() : new uc(a, Xb) : d = a.length ? new uc(new Uint8Array(a), Xb) : vc();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    };
    yc = function(a) {
        xc(lc(a.fa))
    };
    xc = function(a) {
        if (a & 2) throw Error();
    };
    zc = function(a) {
        var b = a.length;
        (b = b ? a[b - 1] : void 0) && tc(b) ? b.g = 1 : (b = {}, a.push((b.g = 1, b)))
    };
    _.Ac = function(a) {
        if (null != a && "number" !== typeof a) throw Error("Value of float/double field must be a number|null|undefined, found " + typeof a + ": " + a);
        return a
    };
    Bc = function(a) {
        if (null == a) return a;
        switch (typeof a) {
            case "string":
                return +a;
            case "number":
                return a
        }
    };
    Cc = function(a) {
        return a
    };
    Dc = function(a) {
        return a
    };
    Ec = function(a) {
        return a
    };
    _.Fc = function(a) {
        return a
    };
    Ic = function(a) {
        return a
    };
    Mc = function(a, b, c, d) {
        var e = !1;
        if (null != a && "object" === typeof a && !(e = Array.isArray(a)) && a.se === Jc) return a;
        if (!e) return c ? d & 2 ? Kc(b) : new b : void 0;
        Lc(a, d);
        return new b(a)
    };
    Lc = function(a, b) {
        var c = lc(a),
            d = c;
        0 === d && (d |= b & 16);
        d |= b & 2;
        d !== c && mc(a, d)
    };
    Kc = function(a) {
        var b = a[Nc];
        if (b) return b;
        b = new a;
        pc(b.fa);
        return a[Nc] = b
    };
    Oc = function(a) {
        return a
    };
    Qc = function(a) {
        return a
    };
    Rc = function(a, b) {
        a = "" + a;
        b = "" + b;
        return a > b ? 1 : a < b ? -1 : 0
    };
    Tc = function(a, b, c, d, e, f) {
        a = Mc(a, d, c, f);
        e && (a = Sc(a));
        return a
    };
    Uc = function(a) {
        return a
    };
    Xc = function(a, b, c, d, e) {
        var f = y(a, b, d);
        Array.isArray(f) || (f = Vc);
        var g = lc(f);
        g & 1 || nc(f);
        if (e) g & 2 || pc(f), c & 1 || Object.freeze(f);
        else {
            e = !(c & 2);
            var h = g & 2;
            c & 1 || !h ? e && g & 16 && !h && kc(f, 16) : (f = nc(Array.prototype.slice.call(f)), Wc(a, b, f, d))
        }
        return f
    };
    Yc = function(a, b, c, d, e) {
        var f = oc(a.fa),
            g = Xc(a, b, e || 1, d, f),
            h = lc(g);
        if (!(h & 4)) {
            Object.isFrozen(g) && (g = nc(g.slice()), Wc(a, b, g, d));
            for (var k = 0, l = 0; k < g.length; k++) {
                var m = c(g[k]);
                null != m && (g[l++] = m)
            }
            l < k && (g.length = l);
            h |= 5;
            f && (h |= 18);
            mc(g, h);
            h & 2 && Object.freeze(g)
        }
        if (2 === e) return g;
        !f && (h & 2 || Object.isFrozen(g)) && (g = Array.prototype.slice.call(g), jc(g, 5), Wc(a, b, g, d));
        return g
    };
    Zc = function(a) {
        return wc(a, !0, !0)
    };
    $c = function(a) {
        return wc(a, !0, !1)
    };
    dd = function(a, b, c) {
        var d = !1;
        if (null == b) {
            if (c) return ad || (ad = new bd(pc([])));
            b = []
        } else if (b.constructor === bd) {
            if (0 == (b.m & 2) || c) return b;
            b = cd(b)
        } else Array.isArray(b) ? d = oc(b) : b = [];
        if (c) {
            if (!b.length) return ad || (ad = new bd(pc([])));
            d || (d = !0, pc(b))
        } else if (d)
            for (d = !1, b = Array.prototype.slice.call(b), c = 0; c < b.length; c++) {
                var e = b[c] = Array.prototype.slice.call(b[c]);
                Array.isArray(e[1]) && (e[1] = pc(e[1]))
            }
        d || (lc(b) & 32 ? kc(b, 16) : lc(a.fa) & 16 && qc(b));
        d = new bd(b, void 0, Qc, Qc);
        Wc(a, 26, d, !1);
        return d
    };
    _.ed = function(a, b, c, d) {
        if (null == c) return _.z(a, b, Vc);
        var e = lc(c);
        if (!(e & 4)) {
            if (e & 2 || Object.isFrozen(c)) c = Array.prototype.slice.call(c);
            for (var f = 0; f < c.length; f++) c[f] = d(c[f]);
            mc(c, e | 5)
        }
        return _.z(a, b, c)
    };
    _.fd = function(a, b, c, d) {
        yc(a);
        c !== d ? Wc(a, b, c) : Wc(a, b, void 0, !1);
        return a
    };
    gd = function(a, b, c, d, e) {
        var f = !!(e & 2);
        a.j || (a.j = {});
        var g = a.j[c],
            h = Xc(a, c, 3, void 0, f);
        if (!g) {
            var k = h;
            g = [];
            f = !!(e & 2);
            h = !!(lc(k) & 2);
            var l = k;
            !f && h && (k = Array.prototype.slice.call(k));
            var m = e | (h ? 2 : 0);
            e = h;
            for (var n = 0; n < k.length; n++) {
                var p = k[n];
                var r = b;
                Array.isArray(p) ? (Lc(p, m), p = new r(p)) : p = void 0;
                void 0 !== p && (e = e || !!(2 & lc(p.fa)), g.push(p))
            }
            a.j[c] = g;
            m = lc(k);
            b = m | 33;
            b = e ? b & -9 : b | 8;
            m != b && (e = k, Object.isFrozen(e) && (e = Array.prototype.slice.call(e)), mc(e, b), k = e);
            l !== k && Wc(a, c, k);
            (f || 1 === d && h) && pc(g);
            (f || 1 === d) && Object.freeze(g);
            return g
        }
        if (3 === d) return g;
        f || ((f = Object.isFrozen(g), 1 !== d || f) ? 2 === d && f && (g = Array.prototype.slice.call(g), a.j[c] = g) : Object.freeze(g));
        return g
    };
    _.hd = function(a, b, c) {
        return _.fd(a, b, null == c ? c : !!c, !1)
    };
    _.id = function(a, b, c) {
        return _.fd(a, b, c, 0)
    };
    _.jd = function(a, b, c) {
        return _.fd(a, b, c, "")
    };
    kd = function(a, b) {
        return null == a ? b : a
    };
    md = function(a, b) {
        ld = b;
        a = new a(b);
        ld = void 0;
        return a
    };
    pd = function(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (0 !== (lc(a) & 128)) return a = Array.prototype.slice.call(a), zc(a), a
                    } else {
                        if (Wb(a)) return Rb(a);
                        if (a instanceof uc) return nd(a);
                        if (a instanceof bd) return od(a)
                    }
        }
        return a
    };
    td = function(a, b, c, d, e) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && lc(a) & 1 ? void 0 : qd(a, b, c, void 0 !== d, e);
            else if (tc(a)) {
                var f = {},
                    g;
                for (g in a) Object.prototype.hasOwnProperty.call(a, g) && (f[g] = td(a[g], b, c, d, e));
                a = f
            } else a = b(a, d);
            return a
        }
    };
    qd = function(a, b, c, d, e) {
        var f = lc(a);
        d = d ? !!(f & 16) : void 0;
        a = Array.prototype.slice.call(a);
        for (var g = 0; g < a.length; g++) a[g] = td(a[g], b, c, d, e);
        c(f, a);
        return a
    };
    wd = function(a) {
        return td(a, ud, vd, void 0, !1)
    };
    ud = function(a) {
        return a.se === Jc ? a.toJSON() : a instanceof bd ? od(a, wd) : pd(a)
    };
    vd = function(a, b) {
        a & 128 && zc(b)
    };
    xd = function(a, b, c) {
        c = void 0 === c ? sc : c;
        if (null != a) {
            if (Vb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = lc(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return mc(a, d | 18), a;
                a = qd(a, xd, d & 4 ? sc : c, !0, !1);
                b = lc(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            a.se === Jc ? a = yd(a) : a instanceof bd && (b = pc(cd(a, xd)), a = new bd(b, a.o, a.H, a.B));
            return a
        }
    };
    Bd = function(a, b, c, d, e, f, g) {
        (a = a.j && a.j[c]) ? (d = lc(a), d & 2 ? d = a : (f = _.zd(a, yd), sc(d, f), Object.freeze(f), d = f), _.Ad(b, c, d, e)) : _.z(b, c, xd(d, f, g), e)
    };
    yd = function(a) {
        if (oc(a.fa)) return a;
        a = _.Cd(a, !0);
        pc(a.fa);
        return a
    };
    _.Cd = function(a, b) {
        var c = a.fa,
            d = qc([]),
            e = a.constructor.messageId;
        e && d.push(e);
        e = a.Qa;
        if (e) {
            d.length = c.length;
            var f = {};
            d[d.length - 1] = f
        }
        0 !== (lc(c) & 128) && zc(d);
        b = b || oc(a.fa) ? sc : rc;
        d = md(a.constructor, d);
        a.oe && (d.oe = a.oe.slice());
        f = !!(lc(c) & 16);
        for (var g = e ? c.length - 1 : c.length, h = 0; h < g; h++) Bd(a, d, h - a.rb, c[h], !1, f, b);
        if (e)
            for (var k in e) Bd(a, d, +k, e[k], !0, f, b);
        return d
    };
    Sc = function(a) {
        if (!oc(a.fa)) return a;
        var b = _.Cd(a, !1);
        b.B = a;
        return b
    };
    Dd = function(a, b) {
        if (Array.isArray(a)) {
            var c = lc(a),
                d = 1;
            !b || c & 2 || (d |= 16);
            (c & d) !== d && mc(a, c | d)
        }
    };
    Ed = function(a, b) {
        return pd(b)
    };
    Hd = function(a, b) {
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        var c = lc(b);
        if (0 !== c) throw Error();
        mc(b, c | 64);
        return md(a, qc(b))
    };
    Ld = function(a, b, c) {
        if (c) {
            var d = {},
                e;
            for (e in c) {
                if (Object.prototype.hasOwnProperty.call(c, e)) {
                    var f = c[e],
                        g = f.ji;
                    g || (d.Wb = f.vj || f.Dj.Gd, f.dg ? (d.Ld = Id(f.dg), g = function(h) {
                        return function(k, l, m) {
                            return h.Wb(k, l, m, h.Ld)
                        }
                    }(d)) : f.lh ? (d.Kd = Jd(f.Bg.Ze, f.lh), g = function(h) {
                        return function(k, l, m) {
                            return h.Wb(k, l, m, h.Kd)
                        }
                    }(d)) : g = d.Wb, f.ji = g);
                    g(b, a, f.Bg)
                }
                d = {
                    Wb: d.Wb,
                    Ld: d.Ld,
                    Kd: d.Kd
                }
            }
        }
        Kd(b, a)
    };
    Od = function(a, b) {
        var c = a[b];
        "function" == typeof c && 0 === c.length && (c = c(), a[b] = c);
        return Array.isArray(c) && (Md in c || Nd in c || 0 < c.length && "function" == typeof c[0]) ? c : void 0
    };
    Id = function(a) {
        var b = a[Pd];
        if (!b) {
            var c = Qd(a);
            b = function(d, e) {
                return Rd(d, e, c)
            };
            a[Pd] = b
        }
        return b
    };
    Jd = function(a, b) {
        var c = a[Pd];
        c || (c = function(d, e) {
            return Ld(d, e, b)
        }, a[Pd] = c);
        return c
    };
    Sd = function(a, b) {
        a.push(b)
    };
    Td = function(a, b, c) {
        a.push(b, c.Gd)
    };
    Ud = function(a, b, c, d) {
        var e = Id(d),
            f = Qd(d).Ze,
            g = c.Gd;
        a.push(b, function(h, k, l) {
            return g(h, k, l, f, e)
        })
    };
    Vd = function(a, b, c, d, e, f) {
        var g = Jd(d, f),
            h = c.Gd;
        a.push(b, function(k, l, m) {
            return h(k, l, m, d, g)
        })
    };
    Qd = function(a) {
        var b = a[Nd];
        if (b) return b;
        b = a[Nd] = [];
        var c = Sd,
            d = Td,
            e = Ud,
            f = Vd;
        b.Ze = a[0];
        var g = 1;
        if (a.length > g && "number" !== typeof a[g]) {
            var h = a[g++];
            c(b, h)
        }
        for (; g < a.length;) {
            c = a[g++];
            for (var k = g + 1; k < a.length && "number" !== typeof a[k];) k++;
            h = a[g++];
            k -= g;
            switch (k) {
                case 0:
                    d(b, c, h);
                    break;
                case 1:
                    (k = Od(a, g)) ? (g++, e(b, c, h, k)) : d(b, c, h, a[g++]);
                    break;
                case 2:
                    k = b;
                    var l = g++;
                    l = Od(a, l);
                    e(k, c, h, l, a[g++]);
                    break;
                case 3:
                    f(b, c, h, a[g++], a[g++], a[g++]);
                    break;
                case 4:
                    f(b, c, h, a[g++], a[g++], a[g++], a[g++]);
                    break;
                default:
                    throw Error("unexpected number of binary field arguments: " + k);
            }
        }
        Md in a && Nd in a && (a.length = 0);
        return b
    };
    Rd = function(a, b, c) {
        for (var d = c.length, e = 1 == d % 2, f = e ? 1 : 0; f < d; f += 2)(0, c[f + 1])(b, a, c[f]);
        Ld(a, b, e ? c[0] : void 0)
    };
    Wd = function(a, b) {
        return {
            Cj: a,
            Gd: b
        }
    };
    ae = function(a, b, c) {
        b = y(b, c);
        null != b && ("string" === typeof b && Yd(b), null != b && (Zd(a.j, 8 * c), "number" === typeof b ? (a = a.j, fc(b), $d(a, cc, ec)) : (c = Yd(b), $d(a.j, c.o, c.j))))
    };
    be = function(a) {
        return a
    };
    de = function(a, b) {
        var c = ce;
        ce = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    };
    ee = function(a, b, c) {
        de(a, b, c);
        return a
    };
    fe = function(a, b, c) {
        b = ce;
        ce = void 0;
        if (!a) {
            if (b) throw Error(b());
            if (c && 0 < c.length) throw Error("[" + c.map(String).join(",") + "]");
            throw Error(String(a));
        }
    };
    ie = function(a) {
        return function() {
            var b = new ge;
            Rd(this, b, Qd(a));
            he(b, b.j.end());
            for (var c = new Uint8Array(b.o), d = b.m, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            b.m = [c];
            return c
        }
    };
    je = function(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = md(a, qc(b))
            }
            return b
        }
    };
    ke = function(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    };
    qe = function(a, b, c, d) {
        d = void 0 === d ? [] : d;
        var e = new a.MutationObserver(function(f) {
            f = _.x(f);
            for (var g = f.next(); !g.done; g = f.next()) {
                g = _.x(g.value.removedNodes);
                for (var h = g.next(); !h.done; h = g.next())
                    if (h = h.value, d && (h === b || le(h, b))) {
                        f = _.x(d);
                        for (g = f.next(); !g.done; g = f.next()) g.value.disconnect();
                        d.length = 0;
                        c();
                        return
                    }
            }
        });
        d.push(e);
        e.observe(a.document.documentElement, {
            childList: !0,
            subtree: !0
        });
        ne(function(f) {
            if (!f.parent || !_.oe(f.parent)) return !1;
            for (var g = f.parent.document.getElementsByTagName("iframe"), h = 0; h < g.length; h++) try {
                if (pe(g[h]) == f) {
                    qe(f.parent, g[h], c, d);
                    break
                }
            } catch (k) {}
            return !1
        }, !1, !1, a)
    };
    re = function(a) {
        a = void 0 === a ? _.q : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return (null == (c = b) ? 0 : c.pageViewId) && (null == (d = b) ? 0 : d.canonicalUrl) ? b : null
    };
    _.A = function(a) {
        var b = _.xb.apply(1, arguments);
        if (0 === b.length) return se(a[0]);
        for (var c = [a[0]], d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
        return se(c.join(""))
    };
    te = function(a, b) {
        var c = _.kb(a).toString();
        if (/#/.test(c)) throw Error("");
        var d = /\?/.test(c) ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return se(c)
    };
    ue = function(a) {
        return JSON.stringify([a.map(function(b) {
            var c = {};
            return [(c[b.Ke] = b.message.toJSON(), c)]
        })])
    };
    we = function(a) {
        a.Ge.apply(a, _.ve(_.xb.apply(1, arguments).map(function(b) {
            return {
                Ke: 2,
                message: b
            }
        })))
    };
    xe = function(a) {
        a.Ge.apply(a, _.ve(_.xb.apply(1, arguments).map(function(b) {
            return {
                Ke: 5,
                message: b
            }
        })))
    };
    ye = function(a) {
        a && "function" == typeof a.Da && a.Da()
    };
    Be = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = _.ze("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                d && ia(a.google_image_requests, f);
                _.Ae(f, "load", g);
                _.Ae(f, "error", g)
            };
            _.zb(f, "load", g);
            _.zb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    };
    De = function() {
        var a = Ce;
        return (0, B.me)(function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }, function() {
            return "unknown enum"
        })
    };
    Fe = function() {
        var a = Ee;
        return (0, B.me)(function(b) {
            return b instanceof a
        }, function() {
            var b = a.name;
            b || (b = (b = /function\s+([^\(]+)/m.exec(String(a))) ? b[1] : "(Anonymous)");
            return b
        })
    };
    Xe = function(a, b) {
        var c;
        a: {
            try {
                if (a) {
                    var d = a.getItem("google_experiment_mod");
                    break a
                }
            } catch (g) {}
            d = null
        }
        d = null != (c = d) ? c : "";
        try {
            var e = Ge(d);
            if (d) {
                var f = Ge(d);
                He(f, Le(Me(1), -1));
                Ne(f)
            }
        } catch (g) {
            Oe(d), e = new Pe
        }
        if (c = (_.C = Qe(e, Re, 1), _.u(_.C, "find")).call(_.C, function(g) {
                return _.Se(g, 1, 0) === b
            }))
            if (f = Te(c, 2), null === f || isNaN(f)) Oe(d);
            else return f;
        d = (0, _.Ue)() ? null : Math.floor(1E3 * _.Ve());
        if (null === d) return null;
        c ? Le(c, d) : He(e, Le(Me(b), d));
        return We(a, Ne(e)) ? d : null
    };
    Oe = function(a) {
        .01 > Math.random() && Ye({
            data: a
        }, "ls_tamp")
    };
    Ze = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Ce: b.__uspapiReturn.callId
        }
    };
    bf = function(a) {
        a = $e(a.data.__fciReturn);
        return {
            payload: a,
            Ce: _.af(a, 1)
        }
    };
    df = function(a, b) {
        b = void 0 === b ? window : b;
        if (cf(a)) try {
            return b.localStorage
        } catch (c) {}
        return null
    };
    ef = function(a) {
        return "null" !== a.origin
    };
    gf = function(a, b, c) {
        b = cf(b) && ef(c) ? c.document.cookie : null;
        return null === b ? null : (new ff({
            cookie: b
        })).get(a) || ""
    };
    _.jf = function(a) {
        a = void 0 === a ? _.q : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : hf()
    };
    _.kf = function(a) {
        a = void 0 === a ? _.q : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    lf = function(a, b) {
        b = void 0 === b ? _.q : b;
        var c, d;
        return (null == (c = b.performance) ? void 0 : null == (d = c.timing) ? void 0 : d[a]) || 0
    };
    mf = function(a) {
        a = void 0 === a ? _.q : a;
        var b = Math.min(lf("domLoading", a) || Infinity, lf("domInteractive", a) || Infinity);
        return Infinity === b ? Math.max(lf("responseEnd", a), lf("navigationStart", a)) : b
    };
    nf = function(a, b, c) {
        return b[a] || c
    };
    qf = function(a) {
        _.of(pf).H(a)
    };
    rf = function(a) {
        return _.of(pf).m(a)
    };
    uf = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? {} : d;
        var e = sf.j();
        0 === e.j && (e.j = .001 > Math.random() ? 2 : 1);
        2 === e.j && (e = {}, Ye(_.u(Object, "assign").call(Object, {}, (e.c = String(a), e.pc = String(tf(window)), e.em = c, e.lid = b, e.eids = _.of(pf).j().join(), e), d), "esp"))
    };
    zf = function(a, b, c, d) {
        uf(18, a);
        try {
            var e = _.jf();
            return c().then(function(f) {
                uf(29, a, null, {
                    delta: String(_.jf() - e)
                });
                if (null == f) return uf(41, a), vf(b, 111, d), b;
                null != f && ("string" !== typeof f ? uf(21, a) : f.length || uf(20, a));
                wf(_.z(b, 2, f), 10);
                xf().set(b, d) && uf(27, a);
                return b
            }).catch(function(f) {
                vf(b, 106, d);
                uf(28, a, yf(f));
                return b
            })
        } catch (f) {
            return vf(b, 107, d), uf(1, a, yf(f)), _.v.Promise.resolve(b)
        }
    };
    vf = function(a, b, c) {
        var d;
        a.Ha(Af(null != (d = Bf(a, Cf, 10)) ? d : new Cf, b));
        xf().set(a, c)
    };
    Hf = function() {
        var a = window;
        var b = void 0 === b ? function() {} : b;
        return new _.v.Promise(function(c) {
            var d = function() {
                c(b());
                _.Ae(a, "load", d)
            };
            _.zb(a, "load", d)
        })
    };
    If = function(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$");
        try {
            for (var d = 0; d < a.length; d++) {
                var e = (c.exec(a.key(d)) || [])[1];
                e && b.push(e)
            }
        } catch (f) {}
        return b
    };
    _.E = function(a) {
        return _.of(Jf).j(a.j, a.defaultValue)
    };
    _.Kf = function(a) {
        return _.of(Jf).o(a.j, a.defaultValue)
    };
    Lf = function(a) {
        return _.of(Jf).m(a.j, a.defaultValue)
    };
    Mf = function(a) {
        return _.of(Jf).H(a.j, a.defaultValue)
    };
    Sf = function(a, b, c, d, e, f) {
        var g = new Nf;
        f = null != f ? f : Of(c, b);
        var h = _.u(f, "flatMap").call(f, function(k) {
            return k.m()
        }).map(function(k) {
            return k.m()
        });
        Pf(g, a, b, h, e);
        Qf(g, f.concat(null != d ? d : []), c, b, a);
        if (!Qe(g, Rf, 2).length) return null;
        uf(50, "");
        return Qb(g.m(), 3)
    };
    Qf = function(a, b, c, d, e) {
        if (d && c && b && "function" === typeof c.getUserIdsAsEidBySource) {
            if ("function" === typeof c.getUserIdsAsEids) try {
                for (var f = _.x(c.getUserIdsAsEids()), g = f.next(); !g.done; g = f.next()) {
                    var h = g.value;
                    "string" === typeof h.source && uf(52, h.source)
                }
            } catch (n) {
                var k;
                uf(45, "", null == (k = n) ? void 0 : k.message)
            }
            b = _.x(b);
            for (f = b.next(); !f.done; f = b.next())
                if (f = f.value, String(_.Tf(f, 1)) === d)
                    for (f = _.x(f.m()), g = f.next(); !g.done; g = f.next())
                        if (g = g.value, _.Uf(g, Vf(g, Wf, 3)) && (g = g.m(), !Xf(a, g))) {
                            h = null;
                            try {
                                var l = k = void 0,
                                    m = void 0;
                                h = null == (k = c.getUserIdsAsEidBySource(g)) ? void 0 : null == (l = k.uids) ? void 0 : null == (m = l[0]) ? void 0 : m.id
                            } catch (n) {
                                k = void 0, uf(45, g, null == (k = n) ? void 0 : k.message)
                            }
                            h ? 300 < h.length ? (k = {}, uf(12, g, null, (k.sl = String(h.length), k.fp = "1", k))) : (k = Yf(g), k = _.z(k, 2, h), k = _.z(k, 11, !0), _.Zf(a, 2, Rf, k), k = {}, uf(19, g, null, (k.fp = "1", k.hs = h ? "1" : "0", k))) : (k = h = void 0, e && (null == (h = xf().get(g, e).pb) ? 0 : null == (k = y(h, 2)) ? 0 : k.length) && uf(51, g))
                        }
        }
    };
    Pf = function(a, b, c, d, e) {
        if (b)
            for (var f = _.x(If(b)), g = f.next(); !g.done; g = f.next()) {
                g = g.value;
                var h = void 0;
                if (null == (h = d) || !_.u(h, "includes").call(h, g))
                    if (h = xf().get(g, b).pb) {
                        var k = $f(h);
                        if (2 !== k && 3 !== k) {
                            k = !1;
                            if (c) {
                                var l = void 0,
                                    m = null == (l = e) ? void 0 : l.get(c);
                                if (m && !m.has(g)) continue;
                                if ((l = /^(\d+)$/.exec(g)) && !(k = _.u(c.split(","), "includes").call(c.split(","), l[1]))) continue
                            }
                            _.z(h, 9, k);
                            l = y(h, 2);
                            _.E(ag) || (k = k ? 1E3 : 300, 0 <= k && l && l.length > k && (k = {}, uf(12, g, null, (k.sl = String(l.length), k)), vf(h, 108, b), wf(h, 2)));
                            _.Zf(a, 2, Rf, h);
                            h = {};
                            uf(19, g, null, (h.hs = l ? "1" : "0", h))
                        }
                    }
            }
    };
    Of = function(a, b) {
        if (!b || "function" !== typeof(null == a ? void 0 : a.getUserIdsAsEidBySource)) return [];
        a = [];
        for (var c = _.x(Mf(bg)), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = null;
            try {
                e = cg(d)
            } catch (f) {
                d = void 0;
                uf(44, "UNKNOWN_ID", null == (d = f) ? void 0 : d.message);
                continue
            }
            _.Tf(e, 1) === b && a.push(e)
        }
        return a
    };
    Xf = function(a, b) {
        return Qe(a, Rf, 2).some(function(c) {
            return y(c, 1) === b && _.dg(c, 2)
        })
    };
    gg = function(a, b, c) {
        var d, e, f, g, h, k;
        return _.Bb(function(l) {
            if (1 == l.j) return d = c ? a.filter(function(m) {
                return !m.qb
            }) : a, Cb(l, _.v.Promise.all(d.map(function(m) {
                return m.Ya.promise
            })), 2);
            if (4 != l.j) {
                if (a.length === d.length) return l.return(0);
                e = a.filter(function(m) {
                    return m.qb
                });
                f = _.jf();
                if (_.E(eg)) {
                    g = _.x(b);
                    for (h = g.next(); !h.done; h = g.next()) k = h.value, fg(k);
                    return Cb(l, _.v.Promise.all(e.map(function(m) {
                        return m.Ya.promise
                    })), 4)
                }
                return Cb(l, _.v.Promise.race([_.v.Promise.all(e.map(function(m) {
                    return m.Ya.promise
                })), new _.v.Promise(function(m) {
                    return void setTimeout(m, c)
                })]), 4)
            }
            return l.return(_.jf() - f)
        })
    };
    hg = function(a) {
        var b = function(c) {
            var d = {};
            uf(c, (0, B.K)(y(a, 1)), null, (d.tic = String(Math.round((Date.now() - (0, B.K)(y(a, 3))) / 6E4)), d))
        };
        switch ($f(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                break;
            case 2:
                b(26);
                break;
            case 3:
                uf(9, (0, B.K)(y(a, 1)));
                break;
            case 4:
                b(23)
        }
    };
    ig = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    vg = function(a, b, c, d, e) {
        var f, g, h, k, l, m, n, p, r, t, w;
        return _.Bb(function(D) {
            f = new jg;
            g = new kg(a, c, d, e);
            h = new lg(g.A, c, d, e);
            k = new mg(g.l, e);
            m = l = null;
            _.E(ag) ? (n = new ng(k.l, e), G(f, n), l = n.A, p = new og(b, n.l, e), G(f, p), G(f, new lg(p.l, c, d, e)), r = new pg(p.A, p.G, 300, 1E3, e), G(f, r), G(f, new lg(r.l, c, d, e)), m = function() {
                var F, I, S;
                return _.Bb(function(M) {
                    return 1 == M.j ? (S = a, Cb(M, r.l.promise, 2)) : M.return({
                        id: S,
                        collectorGeneratedData: null != (I = null == (F = M.o) ? void 0 : qg(F, 2)) ? I : null
                    })
                })
            }) : (t = new rg(b, k.l, c, d, e), G(f, t), l = t.G, m = function() {
                var F;
                return _.Bb(function(I) {
                    return 1 == I.j ? Cb(I, t.l.promise, 2) : I.return(null != (F = I.o) ? F : {
                        id: a,
                        collectorGeneratedData: null
                    })
                })
            });
            w = new sg(b, l, c, d, e);
            tg(f, [g, h, k, w]);
            ug(f);
            return D.return(m())
        })
    };
    Cg = function(a, b, c) {
        var d = {
            Le: _.E(wg)
        };
        d = void 0 === d ? xg : d;
        b ? yg() !== zg(window) ? uf(16, "") : Ag(a, "encryptedSignalProviders", c) && Ag(a, "secureSignalProviders", c) || (uf(38, ""), Bg(a, "encryptedSignalProviders", b, c, d), Bg(a, "secureSignalProviders", b, c, d)) : uf(15, "")
    };
    Ag = function(a, b, c) {
        if (void 0 === a[b] || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    };
    Bg = function(a, b, c, d, e) {
        var f, g = new Dg(null != (f = a[b]) ? f : [], c, "secureSignalProviders" === b, e);
        a[b] = new Eg(g);
        g.addErrorHandler(d)
    };
    Hg = function(a, b) {
        var c = new jg,
            d = new Fg(b);
        a = new Gg(d.C, a, b);
        tg(c, [d, a]);
        ug(c)
    };
    Lg = function(a, b, c, d, e) {
        if (!c) return null;
        var f = b.toString();
        if (Ig.has(f)) return null;
        Ig.add(f);
        f = new jg;
        a = new kg(a, c, d, e);
        var g = new lg(a.A, c, d, e),
            h = new Jg(a.l, e),
            k = new mg(h.l, e);
        b = new Kg(k.l, b, e);
        c = new lg(b.l, c, d, e);
        tg(f, [a, g, h, k, b, c]);
        ug(f);
        return f
    };
    Mg = function(a, b) {
        b = void 0 === b ? document : b;
        var c;
        return !(null == (c = b.featurePolicy) || !(_.C = c.allowedFeatures(), _.u(_.C, "includes")).call(_.C, a))
    };
    Wg = function(a) {
        _.of(Vg).j(a)
    };
    $g = function() {
        if (void 0 === b) {
            var a = void 0 === a ? _.q : a;
            var b = a.ggeac || (a.ggeac = {})
        }
        a = b;
        Xg(_.of(pf), a);
        Yg(b);
        Zg(_.of(Vg), b);
        _.of(Jf).B()
    };
    Yg = function(a) {
        var b = _.of(Jf);
        b.j = function(c, d) {
            return nf(5, a, function() {
                return !1
            })(c, d, 2)
        };
        b.o = function(c, d) {
            return nf(6, a, function() {
                return 0
            })(c, d, 2)
        };
        b.m = function(c, d) {
            return nf(7, a, function() {
                return ""
            })(c, d, 2)
        };
        b.H = function(c, d) {
            return nf(8, a, function() {
                return []
            })(c, d, 2)
        };
        b.B = function() {
            nf(15, a, function() {})(2)
        }
    };
    eh = function(a) {
        var b = void 0 === b ? ah : b;
        var c = _.u(Object, "assign").call(Object, {}, a),
            d = a.id,
            e = a.style;
        a = a.data;
        c = (delete c.id, delete c.style, delete c.data, c);
        if (_.u(Object, "keys").call(Object, c).length) throw Error("Invalid attribute(s): " + _.u(Object, "keys").call(Object, c));
        d = {
            id: d,
            style: e ? e : void 0
        };
        if (a)
            for (e = _.x(_.u(a, "entries").call(a)), a = e.next(); !a.done; a = e.next()) c = _.x(a.value), a = c.next().value, c = c.next().value, (0, B.yf)(bh.test(a)), d[a] = c;
        _.ch("div");
        return _.dh("div", d, b)
    };
    jh = function(a) {
        fh();
        var b = gh.googleToken[5] || 0;
        a && (0 != b || hh[3] >= hf() ? ih.Re(a) : (ih.dd().push(a), ih.Bf()));
        hh[3] >= hf() && hh[2] >= hf() || ih.Bf()
    };
    kh = function(a) {
        a = _.zd(a.split(/\s+/), function(b) {
            return (b = /^(-?\d+)(px|%)$/.exec(b)) ? {
                value: parseFloat(b[1]),
                type: b[2]
            } : {
                value: 0,
                type: "px"
            }
        });
        a[1] = a[1] || a[0];
        a[2] = a[2] || a[0];
        a[3] = a[3] || a[1];
        return a
    };
    mh = function(a) {
        if (!a) return [0];
        a = "number" === typeof a ? [a] : a;
        a = _.lh(a, function(b) {
            return "number" === typeof b && 0 <= b && 1 >= b ? !0 : !1
        });
        sa(a);
        ua(a, function(b, c) {
            return b - c
        });
        return a
    };
    nh = function(a) {
        try {
            var b = a.getBoundingClientRect()
        } catch (c) {}
        return b ? {
            top: b.top,
            right: b.right,
            bottom: b.bottom,
            left: b.left,
            width: b.width || b.right - b.left,
            height: b.height || b.bottom - b.top
        } : {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            width: 0,
            height: 0
        }
    };
    rh = function(a, b, c, d) {
        var e = new _.oh,
            f = "",
            g = function(k) {
                try {
                    var l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (_.Ae(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (m) {}
            },
            h = ph(a);
        return h ? (_.zb(a, "message", g), f = c(h), e.promise) : (c = qh(a)) ? (f = String(Math.floor(2147483647 * _.Ve())), _.zb(a, "message", g), b(c, f), e.promise) : null
    };
    sh = function(a) {
        return rh(a, function(b, c) {
            var d, e;
            return void(null == (d = null != (e = b.getGmaQueryInfo) ? e : b.getGmaSig) ? void 0 : d.postMessage(c))
        }, function(b) {
            return b.getQueryInfo()
        }, function(b) {
            return b.signal
        })
    };
    th = function(a) {
        return !!ph(a) || !!qh(a)
    };
    ph = function(a) {
        var b;
        if ("function" === typeof(null == (b = a.gmaSdk) ? void 0 : b.getQueryInfo)) return a.gmaSdk
    };
    qh = function(a) {
        var b, c, d, e, f, g;
        if ("function" === typeof(null == (b = a.webkit) ? void 0 : null == (c = b.messageHandlers) ? void 0 : null == (d = c.getGmaQueryInfo) ? void 0 : d.postMessage) || "function" === typeof(null == (e = a.webkit) ? void 0 : null == (f = e.messageHandlers) ? void 0 : null == (g = f.getGmaSig) ? void 0 : g.postMessage)) return a.webkit.messageHandlers
    };
    uh = function(a) {
        var b, c;
        return null != (c = (_.C = ["pbjs"].concat(null != (b = a._pbjsGlobals) ? b : []).map(function(d) {
            return a[d]
        }), _.u(_.C, "find")).call(_.C, function(d) {
            return Array.isArray(null == d ? void 0 : d.que)
        })) ? c : null
    };
    vh = function(a, b, c, d) {
        try {
            if (a.setAttribute("data-google-query-id", c), !d) {
                null != b.googletag || (b.googletag = {
                    cmd: []
                });
                var e, f = null != (e = b.googletag.queryIds) ? e : [];
                f.push(c);
                500 < f.length && f.shift();
                b.googletag.queryIds = f
            }
        } catch (g) {}
    };
    _.Dh = function(a) {
        var b = a.ta,
            c = a.te,
            d = a.pd,
            e = a.Te,
            f = a.Ga;
        a = a.jg;
        var g = 0;
        try {
            g |= b != b.top ? 512 : 0;
            var h = Math.min(b.screen.width || 0, b.screen.height || 0);
            g |= h ? 320 > h ? 8192 : 0 : 2048;
            var k;
            if (k = b.navigator) {
                var l = b.navigator.userAgent;
                k = /Android 2/.test(l) || /iPhone OS [34]_/.test(l) || /Windows Phone (?:OS )?[67]/.test(l) || /MSIE.*Windows NT/.test(l) || /Windows NT.*Trident/.test(l)
            }
            g |= k ? 1048576 : 0;
            g = c ? g | (b.innerHeight >= c ? 0 : 1024) : g | (_.wh(b) ? 0 : 8);
            g |= xh(b, d);
            g |= yh(b)
        } catch (m) {
            g |= 32
        }
        switch (e) {
            case 2:
                c = f;
                c = void 0 === c ? null : c;
                d = zh(b.innerWidth, 3, 0, Math.min(Math.round(b.innerWidth / 320 * 50), Ah) + 15, 3);
                null != Bh(b, d, void 0 === c ? null : c) && (g |= 16777216);
                break;
            case 1:
                c = f, c = void 0 === c ? null : c, d = b.innerWidth, e = b.innerHeight, h = Math.min(Math.round(b.innerWidth / 320 * 50), Ah) + 15, k = zh(d, 3, e - h, e, 3), 25 < h && k.push({
                    x: d - 25,
                    y: e - 25
                }), null != Bh(b, k, void 0 === c ? null : c) && (g |= 16777216)
        }
        a && null != _.Ch(b, void 0 === f ? null : f) && (g |= 16777216);
        return g
    };
    _.Ch = function(a, b) {
        b = void 0 === b ? null : b;
        var c = a.innerHeight;
        c = zh(a.innerWidth, 10, c - 45, c, 10);
        return Bh(a, c, b)
    };
    Bh = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = _.x(b);
        for (var d = b.next(); !d.done; d = b.next()) {
            var e = a,
                f = d.value;
            d = c;
            d = void 0 === d ? null : d;
            var g = e.document;
            var h = f.x,
                k = f.y;
            g.hasOwnProperty("_goog_efp_called_") || (g._goog_efp_called_ = g.elementFromPoint(h, k));
            if (g = g.elementFromPoint(h, k)) {
                if (!(h = Eh(g, e, f, d))) a: {
                    d = void 0 === d ? null : d;h = e.document;
                    for (g = g.offsetParent; g && g !== h.body; g = g.offsetParent)
                        if (k = Eh(g, e, f, d)) {
                            h = k;
                            break a
                        }
                    h = null
                }
                d = h || null
            } else d = null;
            if (d) return d
        }
        return null
    };
    zh = function(a, b, c, d, e) {
        for (var f = [], g = 0; g < e; g++)
            for (var h = 0; h < b; h++) {
                var k = f,
                    l = b - 1,
                    m = e - 1;
                k.push.call(k, {
                    x: (0 === l ? 0 : h / l) * a,
                    y: c + (0 === m ? 0 : g / m) * (d - c)
                })
            }
        return f
    };
    Eh = function(a, b, c, d) {
        d = void 0 === d ? null : d;
        if ("fixed" !== Fh(a, "position")) return null;
        var e = "GoogleActiveViewInnerContainer" === a.getAttribute("class") || 1 >= _.Gh(_.Hh, a).width && 1 >= _.Gh(_.Hh, a).height ? !0 : !1;
        if (d) {
            var f, g;
            _.Ih(d, "ach_evt", {
                tn: a.tagName,
                id: null != (f = a.getAttribute("id")) ? f : "",
                cls: null != (g = a.getAttribute("class")) ? g : "",
                ign: String(e),
                pw: b.innerWidth,
                ph: b.innerHeight,
                x: c.x,
                y: c.y
            }, !0, 1)
        }
        return e ? null : a
    };
    Jh = function(a, b) {
        b = void 0 === b ? [] : b;
        var c = Date.now();
        return _.lh(b, function(d) {
            return c - d < 1E3 * a
        })
    };
    Lh = function(a, b) {
        try {
            var c = a.getItem("__lsv__");
            if (!c) return [];
            try {
                var d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || _.Kh(d, function(e) {
                    return !_.u(Number, "isInteger").call(Number, e)
                })) return a.removeItem("__lsv__"), [];
            d = Jh(b, d);
            d.length || null == a || a.removeItem("__lsv__");
            return d
        } catch (e) {
            return null
        }
    };
    Mh = function(a, b) {
        .001 > _.Ve() && Ye({
            c: a,
            s: b
        }, "gpt_whirs")
    };
    Nh = function(a) {
        var b = a.split("/");
        return "/" === a.charAt(0) && 2 <= b.length ? b[1] : "/" !== a.charAt(0) && 1 <= b.length ? b[0] : ""
    };
    _.Qh = function(a) {
        _.of(Oh).j = !0;
        return Ph[a]
    };
    Uh = function(a) {
        var b = new Rh;
        b = _.id(b, 1, Date.now());
        b = _.id(b, 2, a.pvsid);
        b = _.jd(b, 3, a.bb || a.Na);
        var c = _.of(pf).j();
        b = _.ed(b, 4, c, Cc);
        b = _.id(b, 5, a.jh);
        a = _.jd(b, 12, a.tg);
        var d;
        if (b = null == (d = _.v.globalThis.performance) ? void 0 : d.memory) {
            d = new Sh;
            try {
                _.id(d, 1, b.jsHeapSizeLimit)
            } catch (e) {}
            try {
                _.id(d, 2, b.totalJSHeapSize)
            } catch (e) {}
            try {
                _.id(d, 3, b.usedJSHeapSize)
            } catch (e) {}
        } else d = void 0;
        d && _.Th(a, 10, d);
        return a
    };
    Yh = function(a) {
        var b = mf();
        if (a.Dc) {
            var c = a.Eb;
            a = Uh(a);
            var d = new Vh;
            b = _.id(d, 2, b);
            b = _.Wh(a, 6, Xh, b);
            xe(c, b)
        }
    };
    H = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        return function() {
            var e = _.xb.apply(0, arguments),
                f = Zh(a, b, c, d).apply(this, e);
            try {
                var g = e.length;
                if (a.Dc && a.Mh) {
                    var h = a.Eb,
                        k = Uh(a);
                    var l = _.id(k, 5, a.ih);
                    var m = new $h;
                    var n = _.fd(m, 1, b, 0);
                    var p = _.fd(n, 2, g, 0);
                    var r = _.Wh(l, 9, Xh, p);
                    xe(h, r)
                }
            } catch (t) {}
            return f
        }
    };
    Zh = function(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return function() {
            var e = _.xb.apply(0, arguments),
                f = void 0,
                g = !1,
                h = null,
                k = _.of(ai);
            try {
                var l = _.E(bi);
                l && k && (h = k.start(b.toString(), 3));
                f = c.apply(this, e);
                g = !0;
                l && k && k.end(h)
            } catch (m) {
                try {
                    if (g) ci.call(this, a, 110, m);
                    else if (ci.call(this, a, b, m), !d) throw m;
                } catch (n) {
                    if (_.di(h), !g && !d) throw m;
                }
            }
            return f
        }
    };
    ei = function(a, b, c, d) {
        return Zh(a, b, c, void 0 === d ? !1 : d)()
    };
    ci = function(a, b, c) {
        if (a.Jf) {
            c = c.error && c.meta && c.id ? c.error : c;
            var d = new fi,
                e = new gi;
            try {
                var f = tf(window);
                _.id(e, 1, f)
            } catch (p) {}
            try {
                var g = _.of(pf).j();
                _.ed(e, 2, g, Cc)
            } catch (p) {}
            try {
                _.jd(e, 3, window.document.URL)
            } catch (p) {}
            f = _.Th(d, 2, e);
            g = new hi;
            b = _.fd(g, 1, b, 0);
            try {
                var h = ii(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                _.jd(b, 2, h)
            } catch (p) {}
            try {
                var k = ii(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                _.jd(b, 3, k)
            } catch (p) {}
            try {
                var l = ii(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && _.ed(b, 4, l.split(/\n\s*/), _.Fc)
            } catch (p) {}
            h = _.Th(f, 1, b);
            k = new ji;
            try {
                _.jd(k, 1, a.bb || a.Na)
            } catch (p) {}
            try {
                var m = ki();
                _.fd(k, 2, m, 0)
            } catch (p) {}
            try {
                var n = [].concat(_.ve(_.u(li, "keys").call(li)));
                _.ed(k, 3, n, _.Fc)
            } catch (p) {}
            _.Wh(h, 4, mi, k);
            _.id(h, 5, a.bf);
            we(a.Eb, h)
        }
    };
    pi = function(a, b) {
        var c, d;
        return null != (d = null == (c = _.u(a, "find").call(a, function(e) {
            e = (0, B.K)(Bf(e, ni, 1));
            return oi(e, 1) <= oi(b, 1) && oi(e, 2) <= oi(b, 2)
        })) ? void 0 : Qe(c, ni, 2)) ? d : null
    };
    ti = function(a, b, c) {
        return "number" === typeof b && "number" === typeof c && Qe(a, qi, 6).length ? pi(Qe(a, qi, 6), ri(si(new ni, b), c)) : Qe(a, ni, 5)
    };
    vi = function(a) {
        var b = void 0 === b ? window : b;
        var c = null;
        b.top === b && (b = ui(!1, b), c = ti(a, b.width, b.height));
        null != c || (c = ti(a));
        return null == c ? [] : c.map(function(d) {
            return J(d, 3) ? "fluid" : [(0, B.ua)(oi(d, 1)), (0, B.ua)(oi(d, 2))]
        })
    };
    wi = function(a) {
        var b = [],
            c = !1;
        a = _.x(vi(a));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, Array.isArray(d) ? b.push(d.join("x")) : "fluid" === d ? c = !0 : b.push(d);
        c && b.unshift("320x50");
        return b.join("|")
    };
    yi = function(a, b) {
        b = void 0 === b ? null : b;
        var c = [];
        a && (c.push(y(a, 1)), c.push(wi(a)), c.push(y(a, 2)));
        if (b) {
            a = [];
            for (var d = 0; b && 25 > d; b = b.parentNode, ++d) 9 === b.nodeType ? a.push("") : a.push(b.id);
            (b = a.join()) && c.push(b)
        }
        return c.length ? _.xi(c.join(":")).toString() : "0"
    };
    zi = function(a) {
        return 0 !== a && 1 !== a
    };
    Vi = function(a, b) {
        var c;
        return !(null != (c = Ui(b, 22)) ? !c : !J(a, 15))
    };
    Xi = function(a) {
        var b = a.document;
        return Wi(a) ? b.URL : b.referrer
    };
    $i = function(a) {
        try {
            return Yi(a, window.top)
        } catch (b) {
            return new _.Zi(-12245933, -12245933)
        }
    };
    cj = function(a) {
        if (!a) return null;
        var b, c;
        a.getBoundingClientRect ? (a = _.Gh(aj, a), a = new _.bj(a.right - a.left, a.bottom - a.top)) : a = null;
        return null != (c = null == (b = a) ? void 0 : b.floor()) ? c : null
    };
    ej = function(a, b) {
        for (var c = {}, d = _.x(_.u(Object, "keys").call(Object, b)), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = _.Cd(b[e], !1),
                g = _.of(dj),
                h = g.j.get(e);
            null == h ? h = ++_.of(ai).m : g.j.delete(e);
            _.z(f, 20, h);
            c[e] = f
        }
        return {
            T: _.Cd(a, !1),
            U: c
        }
    };
    ij = function() {
        switch (_.Kf(fj)) {
            case 1:
                return gj();
            case 2:
                return "9901b501132b9fabe59d89fcfe6bb421";
            default:
                return hj()
        }
    };
    gj = function() {
        for (var a = "", b = _.x(jj()), c = b.next(); !c.done; c = b.next()) c = c.value, 15 >= c && (a += "0"), a += c.toString(16);
        return a
    };
    jj = function() {
        var a;
        if ("function" === typeof(null == (a = window.crypto) ? void 0 : a.getRandomValues)) return a = new Uint8Array(16), window.crypto.getRandomValues(a), a;
        a = window;
        var b;
        if ("function" === typeof(null == (b = a.msCrypto) ? void 0 : b.getRandomValues)) return b = new Uint8Array(16), a.msCrypto.getRandomValues(b), b;
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(255 * Math.random());
        return a
    };
    qj = function(a, b, c, d) {
        var e = kj(b, a) || lj(b, a);
        if (!e) return null;
        var f = $i(e),
            g = e === lj(b, a),
            h = mj(function() {
                var p = g ? lj(b, a) : e;
                return p && nj(p, window)
            }),
            k = function(p) {
                var r;
                return null == (r = h()) ? void 0 : r.getPropertyValue(p)
            };
        c = vi(c)[0];
        var l = !1;
        Array.isArray(c) && (l = d ? g : 0 === f.x && "center" === k("text-align"));
        l && (f.x += Math.round(Math.max(0, (g ? e.clientWidth : e.parentElement.clientWidth) - Number(c[0])) / 2));
        if (g) {
            var m;
            f.y += Math.round(Math.min(null != (m = oj(k("padding-top"))) ? m : 0, e.clientHeight));
            if (!l) {
                d = e.clientWidth;
                var n;
                f.x += Math.round(Math.min(null != (n = oj(k("padding-left"))) ? n : 0, d))
            }
        }
        return f && pj(e) ? f : new _.Zi(-12245933, -12245933)
    };
    rj = function(a, b, c, d) {
        var e = lj(a, c),
            f = "none" === (null == e ? void 0 : e.style.display);
        f && (e.style.display = "block");
        a = qj(c, a, b, d);
        f && (e.style.display = "none");
        return a
    };
    sj = function(a) {
        return "google_ads_iframe_" + a.toString()
    };
    tj = function(a) {
        return sj(a) + "__container__"
    };
    kj = function(a, b) {
        var c;
        return (null == (c = lj(a, b)) ? void 0 : c.querySelector('[id="' + tj(a) + '"]')) || null
    };
    uj = function(a, b) {
        var c, d;
        return null != (d = null == (c = kj(a, b)) ? void 0 : c.querySelector('iframe[id="' + sj(a) + '"]')) ? d : null
    };
    lj = function(a, b) {
        b = void 0 === b ? document : b;
        return vj().m.get(a) || b.getElementById(a.getDomId())
    };
    wj = function(a) {
        return Math.round(Number(oj(a)))
    };
    yj = function(a, b, c) {
        for (var d = 100; a && a !== b && --d;) _.xj(a, c), a = a.parentElement
    };
    zj = function(a, b, c, d, e) {
        _.xj(a, {
            "margin-left": "0px",
            "margin-right": "0px"
        });
        var f = {},
            g = "rtl" === d.direction,
            h = ((e && -12245933 !== e.width ? e.width : b.innerWidth) - c) / 2;
        d = function() {
            var k = a.getBoundingClientRect().left;
            return g ? h - k : k - h
        };
        b = d();
        return 0 !== b ? (c = function(k) {
            g ? f["margin-right"] = k + "px" : f["margin-left"] = k + "px"
        }, c(-b), _.xj(a, f), d = d(), 0 !== d && b !== d && (c(b / (d - b) * b), _.xj(a, f)), !0) : !1
    };
    Bj = function(a, b, c, d, e, f, g, h, k) {
        var l = wi(d);
        _.q.setTimeout(Zh(a, 459, function() {
            return void Aj(a, b, c, e, f, g, l, h, k)
        }), 500)
    };
    Aj = function(a, b, c, d, e, f, g, h, k) {
        if (_.q.IntersectionObserver) {
            var l = null,
                m, n = null != (m = uj(c, b)) ? m : lj(c, b);
            m = Zh(a, 459, function(p) {
                if (p = p && p[0]) {
                    var r = p.boundingClientRect,
                        t = window.innerWidth,
                        w = Math.round(r.left),
                        D = Math.round(r.right),
                        F = 0 > w + 2,
                        I = 0 < D - (t + 2);
                    if (p.intersectionRatio >= 1 - ((0 <= Math.round(r.left) ? 0 : 2) + (Math.round(r.right) <= window.innerWidth ? 0 : 2)) / e || F || I) Cj(h, function(S) {
                        if (F || I) {
                            var M = new Dj;
                            M.set(8);
                            Ej(n) && M.set(10);
                            M = Fj(M)
                        } else M = Gj(b, c);
                        var R = Hj(c, n, f),
                            T = R.ah;
                        R = R.bh;
                        Ij(S, a);
                        K(S, "qid", k);
                        K(S, "iu", c.getAdUnitPath());
                        K(S, "e", String(M));
                        F && K(S, "ofl", String(w));
                        I && K(S, "ofr", String(D - t));
                        K(S, "ret", e + "x" + f);
                        K(S, "req", g);
                        K(S, "bm", String(d));
                        K(S, "efh", Number(T));
                        K(S, "stk", Number(R));
                        K(S, "ifi", Jj(window))
                    }, _.Kf(Kj)), l && l.unobserve((0, B.K)(n))
                }
            });
            n && (l = new _.q.IntersectionObserver(m, {
                threshold: [1]
            }), (0, B.K)(l).observe(n))
        }
    };
    Gj = function(a, b) {
        var c = uj(b, a) || lj(b, a),
            d = new Dj;
        try {
            var e = c.getBoundingClientRect(),
                f = e.left,
                g = e.top,
                h = e.width,
                k = e.height,
                l = lj(b, a),
                m = (0, B.K)(nj(l, window));
            if ("hidden" === m.visibility || "none" === m.display) return Fj(d);
            var n = wj(m.getPropertyValue("border-top-width") || 0) + 1;
            b = f + h;
            k = g + k;
            var p = a.elementsFromPoint(f + n + 2, g + n);
            var r = a.elementsFromPoint(b - n - 2, g + n);
            var t = a.elementsFromPoint(b - n - 2, k - n);
            var w = a.elementsFromPoint(f + n + 2, k - n);
            var D = a.elementsFromPoint(b / 2, k - n)
        } catch (I) {
            return d.set(1), Fj(d)
        }
        if (!(p && p.length && r && r.length && t && t.length && w && w.length && D && D.length)) return d.set(7), Fj(d);
        a = function(I, S) {
            for (var M = !1, R = 0; R < I.length; R++) {
                var T = I[R];
                if (M) {
                    var X = nj(T, window);
                    if ("hidden" !== X.visibility && !Lj(T) && !F(c, T)) {
                        d.set(S);
                        "absolute" === X.position && d.set(11);
                        break
                    }
                } else c === T && (M = !0)
            }
        };
        Mj(c) && d.set(9);
        var F = function(I, S) {
            return Nj(I, S) || Nj(S, I)
        };
        f = p[0];
        c === f || F(c, f) || Lj(f) || d.set(2);
        f = r[0];
        c === f || F(c, f) || Lj(f) || d.set(3);
        f = t[0];
        c === f || F(c, f) || Lj(f) || d.set(4);
        f = w[0];
        c === f || F(c, f) || Lj(f) || d.set(5);
        if (Lj(c)) return Fj(d);
        a(p, 12);
        a(r, 13);
        a(t, 14);
        a(w, 15);
        a(D, 6);
        return Fj(d)
    };
    Ej = function(a) {
        var b = !1,
            c = !1;
        return Oj(a, function(d) {
            c = c || "scroll" === d.overflowX || "auto" === d.overflowX;
            return (b = b || "flex" === d.display) && c
        })
    };
    Hj = function(a, b, c) {
        var d = (a = lj(a)) && nj(a, window),
            e = d ? "absolute" !== d.position : !0,
            f = !1,
            g = a && a.parentElement,
            h = !1;
        Pj(b, function(k) {
            var l = k.style;
            if (e)
                if (h || (h = k === g)) e = Qj(k, _.q, -1, -1);
                else {
                    l = l && l.height;
                    var m = (l && _.u(l, "endsWith").call(l, "px") ? wj(l) : 0) >= c;
                    !l || m || "string" === typeof l && _.u(Rj, "includes").call(Rj, l) || (e = !1)
                }
            f || (k = nj(k, _.q), "sticky" !== k.position && "fixed" !== k.position) || (f = !0);
            return !(f && !e)
        }, 100);
        return {
            ah: e,
            bh: f
        }
    };
    Qj = function(a, b, c, d) {
        var e = a.style;
        return (null == e ? 0 : e.height) && !_.u(Rj, "includes").call(Rj, e.height) || (null == e ? 0 : e.maxHeight) && !_.u(Sj, "includes").call(Sj, e.maxHeight) || Tj(a, b.document, function(f) {
            var g = f.style.height;
            f = f.style.getPropertyValue("max-height");
            return !!g && !_.u(Rj, "includes").call(Rj, g) || !!f && !_.u(Sj, "includes").call(Sj, f)
        }, c, d) ? !1 : !0
    };
    Tj = function(a, b, c, d, e) {
        b = b.styleSheets;
        if (!b) return !1;
        var f = a.matches || a.msMatchesSelector;
        d = -1 === d ? Infinity : d;
        e = -1 === e ? Infinity : e;
        for (var g = 0; g < Math.min(b.length, d); ++g) {
            var h = null;
            try {
                var k = b[g],
                    l = null;
                try {
                    l = k.cssRules || k.rules
                } catch (S) {
                    if (15 == S.code) throw S.styleSheet = k, S;
                }
                h = l
            } catch (S) {
                continue
            }
            l = void 0;
            if (null != (l = h) && l.length)
                for (l = 0; l < Math.min(h.length, e); ++l) try {
                    var m = h[l],
                        n, p = c;
                    if (!(n = f.call(a, m.selectorText) && p(m))) a: {
                        var r = void 0;p = a;
                        var t = c,
                            w = e,
                            D = null != (r = m.cssRules) ? r : [];
                        for (r = 0; r < Math.min(D.length, w); r++) {
                            var F = D[r],
                                I = t;
                            if (f.call(p, F.selectorText) && I(F)) {
                                n = !0;
                                break a
                            }
                        }
                        n = !1
                    }
                    if (n) return !0
                } catch (S) {}
        }
        return !1
    };
    Lj = function(a) {
        return Oj(a, function(b) {
            return "fixed" === b.position || "sticky" === b.position
        })
    };
    Mj = function(a) {
        return Oj(a, function(b) {
            var c;
            return (_.C = ["left", "right"], _.u(_.C, "includes")).call(_.C, null != (c = b["float"]) ? c : b.cssFloat)
        })
    };
    Uj = function(a) {
        return "number" === typeof a || "string" === typeof a
    };
    Vj = function(a, b) {
        /^(uuid-in-package|urn:uuid):[0-9a-fA-F-]*$/.test(b) && (b = se(b), a.src = _.kb(b).toString())
    };
    Xj = function(a, b, c) {
        c = void 0 === c ? Wj : c;
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? c(a, b) : _.zb(a, "load", function() {
            return void c(a, b)
        }))
    };
    Yj = function(a) {
        try {
            var b, c;
            return (null != (c = null == (b = a.top) ? void 0 : b.frames) ? c : {}).google_ads_top_frame
        } catch (d) {}
        return null
    };
    Zj = function(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    };
    ak = function(a) {
        if (a === a.top || _.oe(a.top)) return _.v.Promise.resolve({
            status: 4
        });
        var b = Yj(a);
        if (!b) return _.v.Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && Zj(a.document.referrer)) return _.v.Promise.resolve({
            status: 3
        });
        var c = new _.oh;
        a = new MessageChannel;
        a.port1.onmessage = function(d) {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                Wc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    ek = function(a) {
        var b = void 0 === b ? bk : b;
        var c = ck(a);
        return c.messageChannelSendRequestFn ? _.v.Promise.resolve(c.messageChannelSendRequestFn) : new _.v.Promise(function(d) {
            function e(k) {
                return h.j(k).then(function(l) {
                    return l.data
                })
            }
            var f = _.ze("IFRAME");
            f.style.display = "none";
            f.name = "goog_topics_frame";
            f.src = _.kb(b).toString();
            var g = (new URL(b.toString())).origin,
                h = dk({
                    destination: a,
                    hd: f,
                    origin: g,
                    Sa: "goog:gRpYw:doubleclick"
                });
            h.j("goog:topics:frame:handshake:ack").then(function(k) {
                "goog:topics:frame:handshake:ack" === k.data && d(e)
            });
            c.messageChannelSendRequestFn = e;
            a.document.documentElement.appendChild(f)
        })
    };
    kk = function(a, b, c, d) {
        var e = _.E(fk);
        e = void 0 === e ? !1 : e;
        var f = gk(d),
            g = f.Rc,
            h = f.Qc;
        b = ck(b);
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e
        }).then(function(k) {
            var l = h;
            if (k instanceof Uint8Array) l || (l = !(g instanceof Uint8Array && Ba(k, g)));
            else if (De()(k)) l || (l = k !== g);
            else return c.Nb(989, Error(JSON.stringify(k))), 7;
            if (l && d) try {
                var m = new hk;
                var n = _.z(m, 2, _.jf());
                k instanceof Uint8Array ? ik(n, 1, jk, wc(k, !1, !1)) : ik(n, 3, jk, k);
                d.setItem("goog:cached:topics", Ne(n))
            } catch (p) {}
            return k
        }), b.getTopicsPromise = (0, B.ua)(a));
        return g && !h ? _.v.Promise.resolve(g) : b.getTopicsPromise
    };
    gk = function(a) {
        if (!a) return {
            Rc: null,
            Qc: !0
        };
        try {
            var b = a.getItem("goog:cached:topics");
            if (!b) return {
                Rc: null,
                Qc: !0
            };
            var c = lk(b),
                d = mk(c, jk);
            switch (d) {
                case 0:
                    var e = null;
                    break;
                case 1:
                    var f = Vf(c, jk, 1),
                        g = y(c, f),
                        h = wc(g, !0, !!(lc(c.fa) & 18));
                    null != h && h !== g && Wc(c, f, h);
                    var k = null == h ? vc() : h;
                    var l = nk(k);
                    e = l ? new Uint8Array(l) : ok || (ok = new Uint8Array(0));
                    break;
                case 3:
                    e = _.Se(c, Vf(c, jk, 3), 0);
                    break;
                default:
                    gb(d)
            }
            var m = _.af(c, 2) + 6048E5 < _.jf();
            return {
                Rc: e,
                Qc: m
            }
        } catch (n) {
            return {
                Rc: null,
                Qc: !0
            }
        }
    };
    ck = function(a) {
        var b;
        return null != (b = a.google_tag_topics_state) ? b : a.google_tag_topics_state = {}
    };
    rk = function(a) {
        if (Xa()) {
            var b = a.document.documentElement.lang;
            pk(a) ? qk(tf(a), !0, "", b) : (new MutationObserver(function(c, d) {
                pk(a) && (qk(tf(a), !1, b, a.document.documentElement.lang), d.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    };
    pk = function(a) {
        var b, c;
        a = null == (b = a.document) ? void 0 : null == (c = b.documentElement) ? void 0 : c.classList;
        return !!((null == a ? 0 : a.contains("translated-rtl")) || (null == a ? 0 : a.contains("translated-ltr")))
    };
    qk = function(a, b, c, d) {
        Ye({
            ptt: "17",
            pvsid: "" + a,
            ibatl: String(b),
            pl: c,
            nl: d
        }, "translate-event")
    };
    sk = function(a) {
        var b = "";
        ne(function(c) {
            if (c === c.top) return !0;
            var d;
            if (null == (d = c.document) ? 0 : d.referrer) b = c.document.referrer;
            return !1
        }, !1, !1, a);
        return b
    };
    tk = function(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    };
    uk = function(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    };
    wk = function() {
        var a = window;
        if (!uk(a)) return null;
        var b = tk(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(vk).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    };
    Ik = function(a) {
        var b;
        return xk(yk(zk(Ak(Bk(Ck(Dk(Ek(Fk(new Gk, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new Hk;
            d = _.z(d, 1, c.brand);
            return _.z(d, 2, c.version)
        })) || []), a.wow64 || !1)
    };
    Jk = function() {
        var a, b;
        return null != (b = null == (a = wk()) ? void 0 : a.then(function(c) {
            return Ik(c)
        })) ? b : null
    };
    Lk = function(a) {
        a = (_.oe(a.top) ? a.top : a).AMP;
        return "object" === typeof a && !!Kk(a, function(b, c) {
            return !/^inabox/i.test(c)
        })
    };
    Ok = function(a, b) {
        var c = Mk.get(a);
        c || (b = c = b(), Nk.set(b, a), Mk.set(a, b));
        return c
    };
    Qk = function(a, b) {
        return (0, B.ua)(Ok(b, function() {
            return new Pk(a, b)
        }))
    };
    Sk = function(a) {
        return function() {
            return new Rk(a, [].concat(_.ve(_.xb.apply(0, arguments))))
        }
    };
    Tk = function(a) {
        return "[" + a.map(function(b) {
            return "string" === typeof b ? "'" + b + "'" : Array.isArray(b) ? Tk(b) : String(b)
        }).join(", ") + "]"
    };
    Uk = function(a, b) {
        b = Tk(b);
        b = b.substring(1, b.length - 1);
        return new Rk(96, [a, b])
    };
    Vk = function(a) {
        return (_.C = "rewardedSlotReady rewardedSlotGranted rewardedSlotClosed slotAdded slotRequested slotResponseReceived slotRenderEnded slotOnload slotVisibilityChanged impressionViewable".split(" "), _.u(_.C, "includes")).call(_.C, a) ? a : null
    };
    Xk = function(a, b, c) {
        return Ok(c, function() {
            return new Wk(a, b, c)
        })
    };
    Zk = function(a, b, c) {
        return Ok(c, function() {
            return new Yk(a, b, c)
        })
    };
    $k = function() {
        var a;
        return null != (a = _.q.googletag) ? a : _.q.googletag = {
            cmd: []
        }
    };
    al = function() {
        var a = $k();
        a.hasOwnProperty("pubadsReady") || (a.pubadsReady = !0)
    };
    dl = function(a) {
        var b = window;
        "complete" === _.q.document.readyState ? ei(a, 94, function() {
            $k()._pubconsole_disable_ || null !== bl(b) && cl(a, b)
        }) : _.zb(_.q, "load", Zh(a, 94, function() {
            $k()._pubconsole_disable_ || null !== bl(b) && cl(a, b)
        }))
    };
    cl = function(a, b) {
        b = void 0 === b ? _.q : b;
        if (!el) {
            var c = new fl("gpt_pubconsole_loaded");
            Ij(c, a);
            K(c, "param", String(bl(b)));
            K(c, "api", String(gl));
            hl(c);
            il(b.document, jl);
            el = !0
        }
    };
    bl = function(a) {
        var b = Xi(a),
            c;
        return null != (c = (_.C = ["google_debug", "dfpdeb", "google_console", "google_force_console", "googfc"], _.u(_.C, "find")).call(_.C, function(d) {
            return null !== kl(b, d)
        })) ? c : null
    };
    ll = function() {
        $k()._pubconsole_disable_ = !0
    };
    ol = function() {
        ml && ((0, B.K)($k().console).openConsole(nl), nl = void 0, ml = !1)
    };
    wl = function(a, b, c, d, e) {
        if ("string" !== typeof c || pl(c)) ql(e, Uk("Slot.setTargeting", [c, d]), a);
        else {
            var f = [];
            Array.isArray(d) ? f = d : za(d) ? f = _.u(Array, "from").call(Array, d) : d && (f = [d]);
            f = f.map(String);
            (d = (_.C = rl(b), _.u(_.C, "find")).call(_.C, function(g) {
                return y(g, 1) === c
            })) ? sl(d, f): (d = sl(tl(new ul, c), f), _.Zf(b, 9, ul, d));
            e.info(vl(c, f.join(), (0, B.K)(b.getAdUnitPath())), a)
        }
    };
    xl = function(a, b, c, d) {
        if (null != c && "object" === typeof c)
            for (var e = _.x(_.u(Object, "keys").call(Object, c)), f = e.next(); !f.done; f = e.next()) f = f.value, wl(a, b, f, c[f], d);
        else d.error(Uk("Slot.updateTargetingFromMap", [c]), a)
    };
    zl = function(a, b, c) {
        return Ok(c, function() {
            return new yl(a, b, c, c.j)
        })
    };
    Al = function(a) {
        return _.u(Object, "assign").call(Object, {}, a, _.u(Object, "fromEntries").call(Object, _.u(Object, "entries").call(Object, a).map(function(b) {
            b = _.x(b);
            var c = b.next().value;
            return [b.next().value, c]
        })))
    };
    El = function() {
        var a = {},
            b = Al(Bl);
        a.OutOfPageFormat = b;
        b = Al(Cl);
        a.TrafficSource = b;
        b = Al(Dl);
        a.Taxonomy = b;
        return a
    };
    Gl = function() {
        for (var a = Lf(Fl) || "0-0-0", b = a.split("-").map(function(e) {
                return Number(e)
            }), c = ["1", "0", "40"].map(function(e) {
                return Number(e)
            }), d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "1-0-40"
    };
    Kl = function() {
        if (Hl) return Hl;
        for (var a = Mf(Il), b = [], c = 0; c < a.length; c += 2) Jl(a[c], a[c + 1], b);
        return Hl = b.join("&")
    };
    Ql = function(a, b) {
        if (!b || !_.pa(b)) return null;
        var c = !1,
            d = new Ll;
        _.Ml(b, function(e, f) {
            var g = !1;
            switch (f) {
                case "allowOverlayExpansion":
                    "boolean" === typeof e ? _.z(d, 1, b.allowOverlayExpansion) : c = g = !0;
                    break;
                case "allowPushExpansion":
                    "boolean" === typeof e ? _.z(d, 2, b.allowPushExpansion) : c = g = !0;
                    break;
                case "sandbox":
                    !0 === e ? _.z(d, 3, b.sandbox) : c = g = !0;
                    break;
                case "useUniqueDomain":
                    Nl();
                    return;
                default:
                    g = !0
            }
            g && a.error(Ol("setSafeFrameConfig", Pl(b), f, Pl(e)))
        });
        return c ? null : d
    };
    Sl = function(a) {
        var b = new Ll;
        a = _.x(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value) Rl(c, 1) && _.z(b, 1, J(c, 1)), Rl(c, 2) && _.z(b, 2, J(c, 2)), Rl(c, 3) && _.z(b, 3, J(c, 3)), Rl(c, 4) && _.z(b, 4, J(c, 4));
        return b
    };
    Ul = function() {
        var a, b, c;
        return "pagead2.googlesyndication.com" === (null != (c = Tl.exec(null != (b = null == (a = _.Qh(172)) ? void 0 : a.src) ? b : "")) ? c : [])[1]
    };
    Vl = function(a) {
        return a + 'Correlator has been deprecated. Please see the Google Ad Manager help page on "Pageviews in GPT" for more information: https://support.google.com/admanager/answer/183281?hl=en'
    };
    hm = function(a, b) {
        var c = b.m;
        return a.map(function(d) {
            return _.u(c, "find").call(c, function(e) {
                return e.j === d
            })
        }).filter(Fe())
    };
    jm = function(a, b) {
        var c = [];
        a = _.x(a);
        for (var d = a.next(); !d.done; d = a.next()) {
            d = d.value;
            b.H = d;
            var e = rf(9);
            1 === e.length && (c.push(d), c.push(d + "-" + e[0]))
        }
        return c
    };
    mm = function(a, b, c, d, e, f) {
        var g = km(f, a, b, d, e, void 0, !0);
        f = g.slotId;
        g = g.fb;
        if (!f || !g) return ql(b, Uk("PubAdsService.definePassback", [d, e])), null;
        _.z(g, 17, !0);
        c.slotAdded(f, g);
        return {
            xf: zl(a, b, new lm(a, f, c)),
            fb: g
        }
    };
    om = function(a, b, c, d, e) {
        return Ok(c, function() {
            return new nm(a, b, c, d, e)
        })
    };
    qm = function(a) {
        return Array.isArray(a) && 2 === a.length ? a.every(pm) : "fluid" === a
    };
    rm = function(a) {
        return Array.isArray(a) && 2 === a.length && pm(a[0]) && pm(a[1])
    };
    tm = function(a) {
        return Array.isArray(a) ? ri(si(new ni, (0, B.ua)(a[0])), (0, B.ua)(a[1])) : sm()
    };
    vm = function(a) {
        var b = [];
        if (um(a)) b.push(tm((0, B.K)(a)));
        else if (Array.isArray(a)) {
            a = _.x(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, um(c) ? b.push(tm((0, B.K)(c))) : Ba(c, ["fluid"]) && b.push(sm())
        }
        return b
    };
    wm = function(a) {
        var b = void 0 === b ? window : b;
        if (!a) return [];
        if (!a.length) {
            var c, d;
            null == (c = b.console) || null == (d = c.warn) || d.call(c, "Invalid GPT fixed size specification: " + JSON.stringify(a))
        }
        return vm(a)
    };
    um = function(a) {
        return _.E(xm) ? Array.isArray(a) && 2 === a.length ? a.every(ym) : "fluid" === a : Array.isArray(a) && 1 < a.length ? "number" === typeof a[0] && "number" === typeof a[1] : "fluid" === a
    };
    wa = function(a, b) {
        a: {
            b = (0, B.ua)(b[0]);a = (0, B.ua)(a[0]);
            for (var c = _.ta, d = Math.min(b.length, a.length), e = 0; e < d; e++) {
                var f = c(b[e], a[e]);
                if (0 != f) {
                    b = f;
                    break a
                }
            }
            b = _.ta(b.length, a.length)
        }
        return b
    };
    zm = function(a) {
        return Array.isArray(a) && 2 === a.length && "number" === typeof a[0] && _.u(a, "includes").call(a, 0)
    };
    Am = function(a) {
        return zm(a) ? [] : Array.isArray(a) && 0 < a.length && "number" !== typeof a[0] ? a.filter(function(b) {
            return !zm(b)
        }) : a
    };
    Cm = function(a) {
        if (!Array.isArray(a) || 2 !== a.length) throw new Bm("Each mapping entry must be an array of size 2");
        var b = a[0];
        if (!rm(b)) throw new Bm("Size must be an array of two non-negative integers");
        b = ri(si(new ni, b[0]), b[1]);
        if (Array.isArray(a[1]) && 0 === a[1].length) a = [];
        else if (a = vm(a[1]), 0 === a.length) throw new Bm("At least one slot size must be present");
        var c = new qi;
        b = _.Th(c, 1, b);
        return _.Ad(b, 2, a)
    };
    Em = function(a, b, c) {
        return Ok(c, function() {
            return new Dm(a, b, c)
        })
    };
    Fm = function(a, b) {
        for (var c = new Dj, d = 0; d < a.length; d++) c.set(a.length - d - 1, b(a[d]));
        return Fj(c)
    };
    Gm = function(a, b, c) {
        c = void 0 === c ? {} : c;
        var d = void 0 === c.lc ? "" : c.lc;
        c = void 0 === c.oa ? "," : c.oa;
        var e = !1;
        a = a.map(function(f) {
            f = b(f);
            e || (e = !!f);
            return String(f || d)
        });
        return e ? a.join(c) : null
    };
    Im = function(a, b, c, d) {
        for (var e = _.x(_.u(Object, "entries").call(Object, Hm)), f = e.next(); !f.done; f = e.next()) {
            var g = _.x(f.value);
            f = g.next().value;
            g = g.next().value;
            b & f && ql(a, g(c, d))
        }
    };
    Nm = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = (void 0 === b ? 0 : b) ? 604800 : -1;
        if (!(0 < b) || c && cf(c)) {
            c = c ? df(c) : null;
            var d = 0;
            try {
                d |= a != a.top ? 512 : 0;
                var e;
                (e = !a.navigator) || (e = !1);
                d |= e || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
                d |= xh(a, 2500);
                if (_.E(Jm)) {
                    var f = _.Km(a).clientHeight;
                    d |= f ? 320 > f ? 2097152 : 0 : 1073741824
                }
                d |= yh(a);
                0 < b && !_.Lm(_.Mm(c, b)) && (d |= 134217728)
            } catch (g) {
                d |= 32
            }
            a = d
        } else a = 4194304;
        return a
    };
    Rm = function(a, b, c, d, e, f) {
        d = Om(d);
        if (5 !== d) return !1;
        var g = Nm(e, !Pm(c), f);
        if (g &= -134217729) Cj("gpt_int_ns", function(h) {
            K(h, "nsr", g);
            Ij(h, a)
        }, _.Kf(Qm)), Im(b, g, d, c.getAdUnitPath());
        return !!g
    };
    Sm = function(a) {
        switch (a) {
            case 4:
                return 11;
            case 2:
                return 2;
            case 3:
                return 1;
            case 5:
                return 8;
            case 6:
                return 42
        }
    };
    Wm = function(a, b) {
        a = Sm(a);
        if (!a) return null;
        var c = 0;
        if (11 !== a) {
            c |= _.q != _.q.top ? 512 : 0;
            var d = _.Tm(_.q);
            d = 26 !== a && 27 !== a && 40 !== a && 41 !== a && 10 !== a && d.adCount ? 1 == a || 2 == a ? !(!d.adCount[1] && !d.adCount[2]) : (d = d.adCount[a]) ? 1 <= d : !1 : !1;
            d && (c |= 64);
            if (c) return c
        }
        2 === a || 1 === a ? (b = {
            ta: _.q,
            pd: _.Um,
            Te: b ? a : void 0
        }, 0 === (0, _.Vm)() && (b.pd = 3E3, b.te = 650), c |= _.Dh(b)) : 8 === a ? c |= Nm(_.q) : 11 !== a && 42 !== a && (c |= 32);
        c || (b = _.Tm(_.q), b.adCount = b.adCount || {}, b.adCount[a] = b.adCount[a] + 1 || 1);
        return c
    };
    Xm = function(a, b, c, d) {
        var e = _.ze("DIV");
        e.id = b;
        e.name = b;
        b = e.style;
        b.border = "0pt none";
        c && (b.margin = "auto", b.textAlign = "center");
        d && (c = Array.isArray(d), b.width = c ? d[0] + "px" : "100%", b.height = c ? d[1] + "px" : "0%");
        a.appendChild(e);
        return e
    };
    Ym = function(a) {
        return "sticky" === (null == a ? void 0 : a.position) || "fixed" === (null == a ? void 0 : a.position)
    };
    $m = function(a, b, c, d) {
        try {
            var e;
            if (!(e = !b)) {
                var f;
                if (!(f = !Zm(b, c, d))) {
                    a: {
                        do {
                            var g = nj(b, c);
                            if (g && "fixed" == g.position) {
                                var h = !1;
                                break a
                            }
                        } while (b = b.parentElement);h = !0
                    }
                    f = !h
                }
                e = f
            }
            e && (a.height = -1)
        } catch (k) {
            a.width = -1, a.height = -1
        }
    };
    an = function(a) {
        if (61440 >= a.length) return {
            url: a,
            Se: 0
        };
        var b = a;
        61440 < b.length && (b = b.substring(0, 61432), b = b.replace(/%\w?$/, ""), b = b.replace(/&[^=]*=?$/, ""), b += "&trunc=1");
        return {
            url: b,
            Se: a.length - b.length + 8
        }
    };
    bn = function(a, b) {
        b = void 0 === b ? window : b;
        return b.location ? b.URLSearchParams ? (a = (new URLSearchParams(b.location.search)).get(a), (null == a ? 0 : a.length) ? a : null) : (a = (new RegExp("[?&]" + a + "=([^&]*)")).exec(b.location.search)) ? decodeURIComponent(a[1]) : null : null
    };
    cn = function(a, b) {
        b = void 0 === b ? window : b;
        return !!bn(a, b)
    };
    fn = function(a, b) {
        var c = b.U;
        return Gm(a, function(d) {
            return dn(c[d.getDomId()]).join("&")
        }, en)
    };
    dn = function(a) {
        a = gn(a);
        var b = [];
        _.Ml(a, function(c, d) {
            c.length && (c = c.map(encodeURIComponent), d = encodeURIComponent(d), b.push(d + "=" + c.join()))
        });
        return b
    };
    gn = function(a) {
        for (var b = {}, c = _.x(rl(a)), d = c.next(); !d.done; d = c.next()) d = d.value, b[(0, B.K)(y(d, 1))] = _.hn(d, 2);
        a = _.hn(a, 8);
        a.length && (null != b.excl_cat || (b.excl_cat = a));
        return b
    };
    jn = function(a) {
        var b = !1,
            c = Qe(a, ul, 2).map(function(d) {
                var e = (0, B.K)(y(d, 1));
                b = "excl_cat" === e;
                d = _.hn(d, 2);
                return encodeURIComponent(e) + "=" + encodeURIComponent(d.join())
            });
        a = _.hn(a, 3);
        !b && a.length && c.push(encodeURIComponent("excl_cat") + "=" + encodeURIComponent(a.join()));
        return c
    };
    kn = function(a) {
        var b, c;
        return null != (c = null == (b = _.u(a, "find").call(a, function(d) {
            return "page_url" === y(d, 1)
        })) ? void 0 : _.hn(b, 2)[0]) ? c : null
    };
    ln = function(a) {
        var b = a.indexOf("google_preview=", a.lastIndexOf("?")),
            c = a.indexOf("&", b); - 1 === c && (c = a.length - 1, --b);
        return a.substring(0, b) + a.substring(c + 1, a.length)
    };
    mn = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        ne(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    nn = function(a, b) {
        var c = b.U;
        return !!kn(b.T.wa()) || a.some(function(d) {
            return null !== kn(c[d.getDomId()].wa())
        })
    };
    qn = function(a, b, c) {
        var d = null;
        try {
            var e = on(b.top.document, b.top).y;
            d = a.map(function(f) {
                var g = c.T,
                    h = c.U[f.getDomId()],
                    k;
                f = null == (k = rj(f, h, b.document, Vi(g, h))) ? void 0 : k.y;
                k = ui(!0, b).height;
                return void 0 === f || -12245933 === f || -12245933 === k ? -1 : f < e + k ? 0 : ++pn
            })
        } catch (f) {}
        return d
    };
    rn = function(a) {
        return J(a, 8) ? "loc gpic cookie ms ppid top etu uule video_doc_id adsid".split(" ") : []
    };
    tn = function() {
        var a = void 0 === a ? window : a;
        sn = _.jf(a)
    };
    xn = function(a) {
        if (null == a || !a.aa.Y.length) return "";
        for (var b = new _.v.Map, c = _.x(un), d = c.next(); !d.done; d = c.next()) d = d.value, d(a, b);
        c = "https://" + (vn(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
        b = _.x(b);
        for (d = b.next(); !d.done; d = b.next()) {
            var e = _.x(d.value);
            d = e.next().value;
            var f = e.next().value;
            e = f.value;
            f = void 0 === f.options ? {} : f.options;
            (new RegExp("[?&]" + d + "=")).test(c);
            var g = a,
                h = new _.v.Set(Mf(wn));
            g = _.x(rn(g.da.V));
            for (var k = g.next(); !k.done; k = g.next()) h.add(k.value);
            !h.has(d) && null != e && (h = f, f = void 0 === h.oa ? "," : h.oa, h = void 0 === h.ya ? !1 : h.ya, e = "object" !== typeof e ? null == e || !h && 0 === e ? null : encodeURIComponent(e) : Array.isArray(e) && e.length ? encodeURIComponent(e.join(f)) : null) && ("?" !== c[c.length - 1] && (c += "&"), c += d + "=" + e)
        }
        return c
    };
    vn = function(a) {
        var b = a.da.V,
            c, d;
        a = null != (d = null == (c = yn(a.aa.O.T)) ? void 0 : J(c, 9)) ? d : !1;
        c = J(b, 8);
        return a || c || !cf(b)
    };
    zn = function(a, b) {
        var c;
        return !(null != (c = Ui(a, 11)) ? !c : !J(b, 10))
    };
    An = function(a, b, c, d) {
        if (a = lj(a, b)) {
            var e;
            if (c = null != (e = Ui(c, 24)) ? e : J(d, 30)) c = a.getBoundingClientRect(), d = c.top, e = c.bottom, 0 === c.height ? c = !1 : (c = _.q.innerHeight, c = 0 < e && e < c || 0 < d && d < c);
            c || (a.style.display = "none")
        }
    };
    Gn = function(a, b, c, d, e, f, g) {
        var h = new jg,
            k = new Bn(a, d);
        G(h, k);
        f = new Cn(a, e, f);
        G(h, f);
        f = new Dn(a, b, e, g, k.hb);
        G(h, f);
        b = new En(a, b, c, e, d, g, k.hb);
        G(h, b);
        a = new Fn(a, k.hb, b.l, f.l);
        G(h, a);
        ug(h);
        return {
            hb: a.C,
            nc: h
        }
    };
    Hn = function(a) {
        var b = a.match(/\/?([0-9]+)(?:,[0-9]+)?((?:\/.+?)+?)(?:\/*)$/);
        return 3 !== (null == b ? void 0 : b.length) ? a : "/" + b[1] + b[2]
    };
    Jn = function(a, b) {
        var c, d;
        return null != (d = null != (c = null == b ? void 0 : b.get(_.E(In) ? Hn(a) : a)) ? c : null == b ? void 0 : b.get(_.xi(a))) ? d : 0
    };
    On = function(a, b, c, d, e) {
        if (null != b && b.size) {
            var f, g;
            e = null != (g = null != (f = null == e ? void 0 : e.adUnits) ? f : null == a ? void 0 : a.adUnits) ? g : [];
            a = {};
            f = _.x(e);
            for (g = f.next(); !g.done; a = {
                    Kc: a.Kc
                }, g = f.next()) {
                e = g.value;
                g = e.code;
                var h = e.bids;
                e = void 0;
                if (g && null != (e = h) && e.length && (g = Jn(g, b), a.Kc = g / 1E6, !(0 >= g))) {
                    var k = void 0;
                    e = {};
                    h = _.x(null != (k = h) ? k : []);
                    for (k = h.next(); !k.done; e = {
                            Xa: e.Xa,
                            Hd: e.Hd
                        }, k = h.next()) k = k.value, e.Hd = "function" === typeof k.getFloor ? k.getFloor : void 0, e.Xa = Kn(Ln(Mn(new Nn, 4), g), c), k.getFloor = function(l, m) {
                        return function(n) {
                            4 === _.Se(l.Xa, 1, 0) && Mn(l.Xa, 1);
                            var p, r = null == (p = l.Hd) ? void 0 : p.apply(this, [n]);
                            n = c ? r || {} : {
                                currency: "USD",
                                floor: m.Kc
                            };
                            return null != r && r.floor ? (null == r ? 0 : r.currency) && "USD" !== r.currency ? (1 === _.Se(l.Xa, 1, 0) && (n = Ln(Mn(l.Xa, 6), 1E6 * r.floor), _.z(n, 3, r.currency)), r) : (r.floor || 0) > m.Kc ? (1 === _.Se(l.Xa, 1, 0) && Ln(Mn(l.Xa, 5), 1E6 * r.floor), r) : n : n
                        }
                    }(e, a), d.set(k.getFloor, e.Xa)
                }
            }
        }
    };
    Pn = function(a, b) {
        var c = a.que,
            d = function() {
                var e;
                null == a || null == (e = a.requestBids) || e.before.call(b, function(f, g) {
                    return $k().pbjs_hooks.push({
                        context: b,
                        nextFunction: f,
                        requestBidsConfig: g
                    })
                }, 0)
            };
        (null == c ? 0 : c.hasOwnProperty("push")) ? null == c || c.push(d): null == c || c.unshift(d)
    };
    Rn = function(a, b) {
        return (0, B.ua)(Ok(b, function() {
            return new Qn(a, b)
        }))
    };
    Yn = function(a, b, c) {
        var d = window,
            e = new jg;
        d = _.E(Sn) ? new Tn(d) : new Un(d);
        _.Vn(e, d);
        c = new Wn(a, d, c);
        G(e, c);
        a = new Xn(a, d, b, c.Lb);
        G(e, a);
        ug(e);
        return {
            Lb: c.Lb,
            gf: a.l,
            nc: e
        }
    };
    ao = function(a) {
        return Zn(a) && $n(a)
    };
    Zn = function(a) {
        var b, c = null == (b = window.top) ? void 0 : b.location.href;
        if (!c) return !1;
        var d = _.xi(c),
            e;
        return null == (e = Qe(a, bo, 1)) ? void 0 : e.some(function(f) {
            switch (mk(f, co)) {
                case 1:
                    f = (0, B.K)(eo(f, fo, 1, co));
                    if (null != go(f, 1) && null != go(f, 2)) {
                        var g = (0, B.K)(Te(f, 1));
                        f = 0 >= g || g > c.length ? !1 : (0, B.K)(Te(f, 2)) === _.xi(c.substring(0, g))
                    } else f = !1;
                    return f;
                case 2:
                    return (0, B.K)(Te(f, Vf(f, co, 2))) === d;
                default:
                    return !1
            }
        })
    };
    $n = function(a) {
        var b;
        return null == (b = ho(a, 2)) ? void 0 : b.some(function(c) {
            switch (c) {
                case 0:
                    return !1;
                case 1:
                    return !0;
                case 2:
                    return 0 === (0, _.Vm)();
                case 4:
                    return 2 === (0, _.Vm)();
                case 3:
                    return 1 === (0, _.Vm)();
                default:
                    return !1
            }
        })
    };
    mo = function(a, b, c, d, e) {
        var f = [];
        c = _.x(Qe(c, io, 3));
        for (var g = c.next(); !g.done; g = c.next())
            if (g = g.value, _.dg(g, 1) && _.dg(g, 2) && null != go(g, 3) && null != go(g, 4)) {
                var h = a.querySelector(_.Tf(g, 1)),
                    k = void 0;
                if (null != (k = h) && k.parentElement) {
                    k = g.getAdUnitPath();
                    var l = "gpt_opp_" + k;
                    if (!a.getElementById(l)) {
                        var m = a.createElement("div");
                        m.id = l;
                        h.insertAdjacentElement("beforebegin", m);
                        if (g = b.defineSlot(k, [g.getWidth(), g.getHeight()], l)) g.addService(b.pubads()), h = jo(vj(), g.getSlotElementId()), e && (k = void 0, null == (k = h) || ko(k, e)), f.push(g)
                    }
                }
            }
        f.length && lo(a, function() {
            for (var n = _.x(f), p = n.next(); !p.done; p = n.next()) b.display(p.value);
            J(d, 4) && b.pubads().refresh(f)
        })
    };
    po = function(a, b, c, d) {
        var e = d.be,
            f = d.adUnitPath;
        d = void 0 === d.jb ? !1 : d.jb;
        return "string" === typeof f && f.length && (null == e || "string" === typeof e || "number" === typeof e && no(e)) ? oo(a, b, f, c, {
            ib: "string" === typeof e ? e : void 0,
            format: "number" === typeof e ? e : 1,
            jb: d
        }) : (b.error(Uk("googletag.defineOutOfPageSlot", [f, e])), null)
    };
    no = function(a) {
        return !!Kk(Bl, function(b) {
            return b === a
        }) || 6 === a
    };
    oo = function(a, b, c, d, e) {
        var f = e.format;
        b = d.add(a, b, c, [1, 1], {
            ib: e.ib,
            format: f,
            jb: e.jb
        });
        a = b.slotId;
        b = b.fb;
        a && b && (_.z(b, 15, f), _.qo(a, function() {
            var g = window,
                h = Sm((0, B.K)(f));
            if (h) {
                g = _.Tm(g);
                var k = g.adCount && g.adCount[h];
                k && (g.adCount[h] = k - 1)
            }
        }));
        return null != a ? a : null
    };
    ro = function(a) {
        switch (Number(a)) {
            case 2:
            case 3:
                return "Anchor";
            case 5:
                return "Interstitial";
            case 6:
                return "Shoppit";
            default:
                return "Out-of-page creative"
        }
    };
    Bo = function(a, b, c, d, e) {
        var f = e.getBidResponsesForAdUnitCode;
        if (f) {
            var g, h, k, l = null != (k = null == (g = f(b.getDomId())) ? void 0 : g.bids) ? k : null == (h = f(b.getAdUnitPath())) ? void 0 : h.bids;
            if (null != l && l.length && (g = l.filter(function(p) {
                    var r = p.adId;
                    return p.auctionId !== c && d.some(function(t) {
                        return (_.C = _.hn(t, 2), _.u(_.C, "includes")).call(_.C, r)
                    })
                }), g.length)) {
                var m, n;
                f = null == (m = e.adUnits) ? void 0 : null == (n = _.u(m, "find").call(m, function(p) {
                    p = p.code;
                    return p === b.getAdUnitPath() || p === b.getDomId()
                })) ? void 0 : n.mediaTypes;
                m = _.x(g);
                for (n = m.next(); !n.done; n = m.next()) n = n.value, g = so(n, d, f), g = to(a, uo(_.z(vo(wo(new xo, n.bidder), 1), 6, !0), g)), _.E(yo) && zo(n.bidder, e, g), "number" === typeof n.timeToRespond && Ao(g, n.timeToRespond)
            }
        }
    };
    zo = function(a, b, c) {
        for (var d = []; a && !_.u(d, "includes").call(d, a);) {
            d.unshift(a);
            var e = void 0,
                f = void 0;
            a = null == (e = b) ? void 0 : null == (f = e.aliasRegistry) ? void 0 : f[a]
        }
        _.ed(c, 10, d, _.Fc)
    };
    Co = function(a, b, c) {
        null != y(a, 3) || (c === b.getAdUnitPath() ? _.z(a, 3, 1) : c === b.getDomId() && _.z(a, 3, 2))
    };
    Fo = function(a, b, c, d, e, f, g) {
        f = f.get(null != g ? g : function() {
            return null
        });
        1 !== (null == f ? void 0 : _.Se(f, 1, 0)) && _.Th(b, 5, f);
        Do(a, Nn, 5) || (f ? 1 === _.Se(f, 1, 0) ? Eo(a, f) : Eo(a, Ln(Mn(Kn(new Nn, e), 1), Jn(c, d))) : Eo(a, Mn(Kn(new Nn, e), Jn(c, d) ? 2 : 3)))
    };
    so = function(a, b, c) {
        var d = a.cpm,
            e = a.originalCpm,
            f = a.currency,
            g = a.originalCurrency,
            h = a.dealId,
            k = a.adserverTargeting,
            l = a.bidder,
            m = a.adUnitCode,
            n = a.adId,
            p = a.mediaType,
            r = a.height;
        a = a.width;
        var t = new Go;
        "number" === typeof d && (_.z(t, 2, Math.round(1E6 * d)), g && g !== f || (d = Math.round(1E6 * Number(e)), isNaN(d) || d === _.af(t, 2) || _.z(t, 8, d)));
        "string" === typeof f && _.z(t, 3, f);
        "string" === typeof h && Ho(t, Io(h));
        if ("object" === typeof k)
            for (b = _.u(Object, "fromEntries").call(Object, b.map(function(F) {
                    return [y(F, 1), _.hn(F, 2)]
                })), f = _.x(["", "_" + l]), h = f.next(); !h.done; h = f.next()) {
                h = h.value;
                d = [];
                e = _.x(_.u(Object, "entries").call(Object, k));
                for (g = e.next(); !g.done; g = e.next()) {
                    g = _.x(g.value);
                    var w = g.next().value;
                    g = g.next().value;
                    w = (w + h).slice(0, 20);
                    var D = void 0;
                    if (null != (D = b[w]) && D.length)
                        if (b[w][0] === String(g)) d.push(w);
                        else {
                            d = [];
                            break
                        }
                }
                Jo(t, _.hn(t, 4).concat(d))
            }
        switch (p || "banner") {
            case "banner":
                _.z(t, 5, 1);
                break;
            case "native":
                _.z(t, 5, 2);
                Cj("hbyg_nat", function(F) {
                    K(F, "pub_url", document.URL);
                    K(F, "b", l);
                    K(F, "auc", null != m ? m : "");
                    K(F, "hmt", Number(!!c));
                    var I;
                    K(F, "hat", Number(!!(null == c ? 0 : null == (I = c.native) ? 0 : I.adTemplate)))
                }, _.Kf(Ko));
                break;
            case "video":
                _.z(t, 5, 3)
        }
        "number" === typeof r && "number" === typeof a && Lo(t, Mo(No(a), r));
        "string" === typeof n && _.z(t, 1, n);
        return t
    };
    Oo = function(a, b) {
        var c = new _.v.Map,
            d = function(k) {
                var l = c.get(k);
                l || (l = {}, c.set(k, l));
                return l
            },
            e = [];
        a = _.x(a);
        for (var f = a.next(); !f.done; f = a.next()) {
            f = f.value;
            var g = f.args,
                h = f.eventType;
            f = f.elapsedTime;
            "bidTimeout" === h && e.push.apply(e, _.ve(g));
            switch (h) {
                case "bidRequested":
                    if (g.auctionId !== b) continue;
                    if (!Array.isArray(g.bids)) continue;
                    g = _.x(g.bids);
                    for (h = g.next(); !h.done; h = g.next())
                        if (h = h.value.bidId) d(h).requestTime = f;
                    break;
                case "noBid":
                    g.auctionId === b && g.bidId && (d(g.bidId).Hh = f)
            }
        }
        d = new _.v.Map;
        a = _.x(_.u(c, "entries").call(c));
        for (f = a.next(); !f.done; f = a.next()) g = _.x(f.value), f = g.next().value, h = g.next().value, g = h.requestTime, h = h.Hh, g && h && d.set(f, {
            latency: h - g,
            nf: !1
        });
        e = _.x(e);
        for (a = e.next(); !a.done; a = e.next())
            if (f = a.value, a = f.bidId, f = f.auctionId, a && f === b && (a = d.get(a))) a.nf = !0;
        return d
    };
    Po = function(a) {
        var b = {};
        a = _.x(a);
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[y(c, 1)] = y(c, 2);
        return b
    };
    So = function(a, b, c) {
        return new Qo(c, a, Ro, function(d) {
            d = d.detail.data;
            try {
                var e = JSON.parse(d);
                if ("rewarded" === e.type && e.message === b) return e
            } catch (f) {}
            return null
        })
    };
    To = function(a) {
        var b = a.Xd,
            c = a.Md,
            d = void 0 === a.lg ? [] : a.lg,
            e = void 0 === a.Of ? !1 : a.Of,
            f = e ? "https://securepubads.g.doubleclick.net" : "https://pubads.g.doubleclick.net",
            g = e ? "https://securepubads.g.doubleclick.net/td/sjs" : "https://pubads.g.doubleclick.net/td/sjs",
            h;
        a = {
            seller: f,
            decisionLogicUrl: g,
            trustedScoringSignalsUrl: e ? "https://securepubads.g.doubleclick.net/td/sts" : "https://pubads.g.doubleclick.net/td/sts",
            interestGroupBuyers: null != (h = a.interestGroupBuyers) ? h : ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"],
            sellerExperimentGroupId: 0,
            auctionSignals: b.auctionSignals.promise,
            sellerSignals: b.j.promise,
            sellerTimeout: 50,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: b.perBuyerSignals.promise,
            perBuyerTimeouts: b.perBuyerTimeouts.promise
        };
        return {
            seller: f,
            decisionLogicUrl: g,
            interestGroupBuyers: [],
            auctionSignals: {},
            sellerExperimentGroupId: 0,
            sellerSignals: b.topLevelSellerSignals.promise,
            sellerTimeout: 50,
            signal: c.signal,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: {},
            perBuyerTimeouts: {},
            componentAuctions: [a].concat(_.ve(d))
        }
    };
    Uo = function(a, b) {
        b.topLevelSellerSignals.resolve(a.sellerSignals);
        var c;
        if (a = null == (c = a.componentAuctions) ? void 0 : _.u(c, "find").call(c, function(e) {
                return (_.C = ["https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"], _.u(_.C, "includes")).call(_.C, e.seller)
            })) {
            b.auctionSignals.resolve(a.auctionSignals);
            b.j.resolve(a.sellerSignals);
            b.perBuyerSignals.resolve(a.perBuyerSignals);
            var d;
            b.perBuyerTimeouts.resolve(null != (d = a.perBuyerTimeouts) ? d : {})
        } else b.auctionSignals.resolve(void 0), b.j.resolve(void 0), b.perBuyerSignals.resolve({}), b.perBuyerTimeouts.resolve({})
    };
    ap = function(a, b) {
        var c, d, e, f, g, h, k, l, m, n, p, r;
        return _.Bb(function(t) {
            if (1 == t.j) return _.u(a, "startsWith").call(a, "urn:") && Vo.deprecatedURNToURL && Vo.deprecatedReplaceInURN ? Cb(t, Vo.deprecatedURNToURL(a), 2) : t.return();
            c = t.o;
            d = {};
            e = b.gdprApplies || "";
            (null != (f = c.match(Wo)) ? f : []).forEach(function(w) {
                d[w] = e
            });
            g = b.hf || "";
            (null != (h = c.match(Xo)) ? h : []).forEach(function(w) {
                d[w] = g
            });
            k = b.Ne || "";
            (null != (l = c.match(Yo)) ? l : []).forEach(function(w) {
                d[w] = k
            });
            m = b.Xf || "";
            (null != (n = c.match(Zo)) ? n : []).forEach(function(w) {
                d[w] = m
            });
            p = b.Vf || "";
            (null != (r = c.match($o)) ? r : []).forEach(function(w) {
                d[w] = p
            });
            return Cb(t, Vo.deprecatedReplaceInURN(a, d), 0)
        })
    };
    cp = function(a, b, c) {
        var d = "https://googleads.g.doubleclick.net/td/auctionwinner?status=nowinner",
            e = _.Uf(c, 18),
            f = _.Uf(c, 7);
        if (f || e) d += "&isContextualWinner=1";
        f && (d += "&hasXfpAds=1");
        e = c.getEscapedQemQueryId();
        f = _.Tf(c, 6);
        e && (d += "&winner_qid=" + encodeURIComponent(e));
        f && (d += "&xfpQid=" + encodeURIComponent(f));
        _.Uf(c, 4) && (d += "&is_plog=1");
        (e = _.Tf(c, 11)) && (d += "&ecrs=" + e);
        (null == c ? 0 : _.Uf(c, 21)) || (d += "&turtlexTest=1");
        d += "&applied_timeout_ms=" + (b + "&duration_ms=" + Math.round(a));
        bp(d)
    };
    dp = function() {
        return new _.v.Promise(function(a) {
            setTimeout(function() {
                a(null)
            }, 0)
        })
    };
    fp = function(a) {
        ep = a
    };
    gp = function(a, b, c, d) {
        ql(a, Ol("googletag.setConfig.commerce", Pl(b), c, Pl(d)))
    };
    hp = function(a) {
        return "string" === typeof a && 0 < a.length && 5E3 > a.length
    };
    ip = function(a) {
        if (!Array.isArray(a) || 0 === a.length) return !1;
        var b = a.length - 1;
        return a.every(function(c) {
            if ("string" !== typeof c || 0 === c.length) return !1;
            b += c.length;
            return 5E3 < b ? !1 : !0
        })
    };
    lp = function(a, b, c) {
        if ("object" === typeof a && null !== a && _.u(Object, "keys").call(Object, (0, B.K)(a)).some(function(d) {
                return (_.C = _.u(Object, "values").call(Object, jp), _.u(_.C, "includes")).call(_.C, Number(d))
            })) return !0;
        kp("taxonomies", a, b, c);
        return !1
    };
    np = function(a, b) {
        var c = Qe(b, mp, 1).filter(function(d) {
            return _.Se(d, 1, 0) !== a
        });
        _.Ad(b, 1, c)
    };
    up = function(a, b, c, d) {
        if (void 0 !== _.u(b, "values"))
            if (null === _.u(b, "values")) np(a, c);
            else if (op(_.u(b, "values"), d, b) && (b = pp(a, _.u(b, "values"), d, b), b.length)) {
            var e = (_.C = Qe(c, mp, 1), _.u(_.C, "find")).call(_.C, function(f) {
                return _.Se(f, 1, 0) === a
            });
            e ? qp(e, b) : rp(c, qp(sp(new mp, a), b));
            d.info(tp(Pl(b), Pl(a)))
        }
    };
    op = function(a, b, c) {
        if (Array.isArray(a)) return !0;
        kp("taxonomyData.values", a, b, c);
        return !1
    };
    pp = function(a, b, c, d) {
        var e = [],
            f = [],
            g = !1;
        b = _.x(b);
        for (var h = b.next(); !h.done; h = b.next()) h = h.value, 5 <= e.length && (g = !0), "string" !== typeof h ? f.push(h) : g || h in e || e.push(h);
        0 < f.length && kp("taxonomyData.values", f, c, d);
        g && ql(c, vp(Pl(a), Pl(5)));
        return e
    };
    kp = function(a, b, c, d) {
        ql(c, Ol("googletag.setConfig.pps", Pl(d), a, Pl(b)))
    };
    yp = function() {
        for (var a = _.x(_.u(Array, "from").call(Array, document.getElementsByTagName("script"))), b = a.next(); !b.done; b = a.next()) {
            var c = b = b.value,
                d = b.src;
            d && (Na(d, "/tag/js/gpt.js") || Na(d, "/tag/js/gpt_mobile.js")) && !c.googletag_executed && b.textContent && (c.googletag_executed = !0, c = document.createElement("script"), jb(c, new _.wp(b.textContent, xp)), document.head.appendChild(c), document.head.removeChild(c))
        }
    };
    zp = function(a, b) {
        b = _.x(_.u(Object, "entries").call(Object, b));
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = _.x(c.value);
            c = d.next().value;
            d = d.next().value;
            a.hasOwnProperty(c) || (a[c] = d)
        }
    };
    Cp = function(a, b, c) {
        var d = [];
        c = [].concat(_.ve(c.Y)).slice();
        if (b) {
            if (!Array.isArray(b)) return ql(a, Uk("googletag.destroySlots", [b])), !1;
            sa(b);
            d = c.filter(function(e) {
                return _.u(b, "includes").call(b, e.j)
            })
        } else d = c;
        if (!d.length) return !1;
        Ap(d);
        Bp(d);
        return !0
    };
    Sp = function(a, b, c, d, e, f, g, h, k, l) {
        var m = $k(),
            n, p, r = H(a, 74, function(w, D, F) {
                return e.defineSlot(a, b, w, D, F)
            }),
            t = {};
        r = (t._loaded_ = !0, t.cmd = [], t._vars_ = m._vars_, t.evalScripts = function() {
            try {
                yp()
            } catch (F) {
                ci(a, 297, F);
                var w, D;
                null == (w = window.console) || null == (D = w.error) || D.call(w, F)
            }
        }, t.display = H(a, 95, function(w) {
            void Dp(c, w, e)
        }), t.defineOutOfPageSlot = H(a, 73, function(w, D) {
            return (w = po(a, b, e, {
                be: D,
                adUnitPath: w
            })) ? w.j : null
        }), t.getVersion = H(a, 946, function() {
            return a.Ab ? String(a.Ab) : a.Na
        }), t.pubads = H(a, 947, function() {
            return om(a, b, c, e, h)
        }), t.companionAds = H(a, 816, function() {
            null != n || (n = new Ep(b, c, f, h));
            return Xk(a, b, n)
        }), t.content = H(a, 817, function() {
            null != p || (p = new Fp(b, g));
            return Zk(a, b, p)
        }), t.setAdIframeTitle = H(a, 729, fp), t.getEventLog = H(a, 945, function() {
            return new Gp(a, b)
        }), t.sizeMapping = H(a, 90, function() {
            return new Hp(a, b)
        }), t.enableServices = H(a, 91, function() {
            for (var w = _.x(Ip), D = w.next(); !D.done; D = w.next()) D = D.value, D.B && b.info(Jp()), Kp(D)
        }), t.destroySlots = H(a, 75, function(w) {
            return Cp(b, w, e)
        }), t.enums = El(), t.defineSlot = r, t.defineUnit = r, t.getWindowsThatCanCommunicateWithHostpageLibrary = H(a, 955, function(w) {
            return Lp(k, w).map(function(D) {
                var F;
                return null == (F = uj(D, document)) ? void 0 : F.contentWindow
            }).filter(function(D) {
                return !!D
            })
        }), t.disablePublisherConsole = H(a, 93, ll), t.onPubConsoleJsLoad = H(a, 731, ol), t.openConsole = H(a, 732, function(w) {
            gl = !0;
            var D;
            (null == (D = $k()) ? 0 : D.console) ? (0, B.K)($k().console).openConsole(w): (w && (nl = w), ml = !0, cl(a))
        }), t.setConfig = H(a, 1034, function(w) {
            if (_.pa(w)) {
                var D = w.commerce,
                    F = w.pps;
                if (null === D) wf(Mp(d, Np, 33), 1);
                else if (void 0 !== D)
                    if (w = Mp(d, Np, 33), _.pa(D)) {
                        var I = D.query,
                            S = D.categories,
                            M = D.productIds,
                            R = D.filter,
                            T = _.Cd(Op(w, Pp, 1), !1);
                        null === I ? wf(T, 1) : hp(I) ? _.z(T, 1, I) : void 0 !== I && gp(b, D, "query", I);
                        null === S ? _.z(T, 2, Vc) : ip(S) ? _.ed(T, 2, S, _.Fc) : void 0 !== S && gp(b, D, "categories", S);
                        null === M ? _.z(T, 3, Vc) : ip(M) ? _.ed(T, 3, M, _.Fc) : void 0 !== M && gp(b, D, "productIds", M);
                        null === R ? wf(T, 4) : hp(R) ? _.z(T, 4, R) : void 0 !== R && gp(b, D, "filter", R);
                        _.dg(T, 1) || _.hn(T, 2).length ? _.Th(w, 1, T) : ql(b, Qp())
                    } else ql(b, Uk("googletag.setConfig.commerce", [D]));
                if (null === F) wf(Mp(d, Np, 33), 2);
                else if (void 0 !== F && (D = Mp(Mp(d, Np, 33), Rp, 2), "object" === typeof F && (0, B.K)(F).hasOwnProperty("taxonomies") ? w = !0 : (ql(b, Uk("googletag.setConfig.pps", [F])), w = !1), w))
                    if (w = F.taxonomies, void 0 === w) kp("taxonomies", w, b, F);
                    else if (null === w) _.Ad(D, 1);
                else if (lp(w, b, F))
                    for (F = _.x(_.u(Object, "entries").call(Object, w)), I = F.next(); !I.done; I = F.next()) {
                        I = _.x(I.value);
                        var X = I.next().value;
                        I = I.next().value;
                        S = D;
                        M = b;
                        T = w;
                        if (void 0 === X || null === X) kp("taxonomy", X, M, T);
                        else {
                            R = Number(X);
                            var ka = R,
                                ca = M,
                                oa = T;
                            (_.C = _.u(Object, "values").call(Object, Dl), _.u(_.C, "includes")).call(_.C, Number(ka)) ? X = !0 : (kp("taxonomy", X, ca, oa), X = !1);
                            X && void 0 !== I && (null === I ? np(R, S) : (X = M, "object" === typeof I && (0, B.K)(I).hasOwnProperty("values") ? T = !0 : (kp("taxonomyData", I, X, T), T = !1), T && up(R, I, S, M)))
                        }
                    }
            } else ql(b, Uk("googletag.setConfig", [w]))
        }), t.apiReady = !0, t);
        Cg(m, l, function(w, D) {
            ci(a, w, D);
            var F, I;
            null == (I = (F = window.console).error) || I.call(F, D)
        });
        zp(m, r)
    };
    aq = function(a) {
        var b = window,
            c = new jg;
        if (_.E(Tp)) {
            var d = new Up(a);
            G(c, d);
            d = d.C
        }
        var e = new Vp(a, b);
        G(c, e);
        var f = new Wp(a, b);
        G(c, f);
        _.E(Xp) && G(c, new Yp(a, b));
        if (_.E(Zp)) {
            a = new $p(a);
            G(c, a);
            var g = a.C
        }
        ug(c);
        return {
            Lf: e.C,
            Pg: f.l,
            Zh: g,
            wh: d
        }
    };
    bq = function(a) {
        var b = function() {
            return a.Reflect.construct(a.HTMLElement, [], this.constructor)
        };
        b.prototype = a.HTMLElement.prototype;
        b.prototype.constructor = b;
        _.u(Object, "setPrototypeOf").call(Object, b, a.HTMLElement);
        return b
    };
    dq = function(a, b) {
        var c = _.Kf(cq);
        Math.random() <= c && Ye(b, a)
    };
    jq = function(a, b, c) {
        var d = {};
        if (!c) return b.error(eq("missing data-rendering attribute")), d;
        try {
            var e = fq(gq(c))
        } catch (k) {}
        var f;
        (null == (f = e) ? 0 : Do(f, hq, 1)) ? (b = new iq, b = _.fd(b, 4, 1, 0), b = _.fd(b, 2, 7, 0), a = _.jd(b, 3, a.bb || a.Na), b = Bf(e, hq, 1), a = _.Th(a, 5, b), a = _.hd(a, 6, !0), d.Oh = a) : b.error(eq("invalid data-rendering attribute"));
        var g;
        d.Fh = null == (g = e) ? void 0 : _.Tf(g, 2);
        var h;
        d.Sd = null == (h = e) ? void 0 : _.Tf(h, 3);
        return d
    };
    mq = function(a, b) {
        var c = kl(b, "ai");
        if (!c || 0 === c.length) return _.v.Promise.resolve(b);
        var d = kq();
        if (null == d ? 0 : d.gmaSdk) {
            if (c = d.gmaSdk.getClickSignalsWithTimeout ? d.gmaSdk.getClickSignalsWithTimeout(c, 200) : d.gmaSdk.getClickSignals(c)) return _.v.Promise.resolve(b.replace("?", "?ms=" + encodeURIComponent(c) + "&"))
        } else {
            var e, f;
            if (null == d ? 0 : null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaClickSignals) {
                e = new _.oh;
                var g = e.resolve;
                e = e.promise;
                lq(d.webkit.messageHandlers.getGmaClickSignals, {
                    click_string: c
                }, function(h) {
                    g(b.replace("?", "?" + h + "&"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Zh(a, h, k)
                });
                return e
            }
        }
        return _.v.Promise.resolve(b)
    };
    nq = function(a, b, c, d) {
        var e, f, g;
        return _.Bb(function(h) {
            e = b.getBoundingClientRect();
            f = {};
            var k = d.replace;
            var l = (f.nx = Math.floor(c.clientX - e.x), f.ny = Math.floor(c.clientY - e.y), f.dim = Math.floor(e.width) + "x" + Math.floor(e.height), f);
            var m = [];
            for (n in l) Jl(n, l[n], m);
            l = m.join("&");
            if (l) {
                m = -1;
                0 > m && (m = 0);
                var n = -1;
                if (0 > n || n > m) {
                    n = m;
                    var p = ""
                } else p = "".substring(n + 1, m);
                m = ["".slice(0, n), p, "".slice(m)];
                n = m[1];
                m[1] = l ? n ? n + "&" + l : l : n;
                l = m[0] + (m[1] ? "?" + m[1] : "") + m[2]
            } else l = "";
            g = k.call(d, "?", l + "&");
            return h.return(mq(a, g))
        })
    };
    oq = function(a, b, c) {
        var d;
        if (null == c ? 0 : null == (d = c.gmaSdk) ? 0 : d.getViewSignals) {
            if (c = c.gmaSdk.getViewSignals()) return c = b.replace(/^(.*?)(&adurl=)?$/, "$1&ms=" + c + "$2"), _.v.Promise.resolve(c)
        } else {
            var e, f;
            if (null == c ? 0 : null == (e = c.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals) {
                d = new _.oh;
                var g = d.resolve;
                d = d.promise;
                lq(c.webkit.messageHandlers.getGmaViewSignals, {}, function(h) {
                    g(b.replace(/^(.*?)(&adurl=)?$/, "$1&" + h + "$2"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Zh(a, h, k)
                });
                return d
            }
        }
        return _.v.Promise.resolve(b)
    };
    tq = function(a, b) {
        var c = window;
        var d = void 0 === d ? Jb : d;
        var e;
        if (c.customElements && null != (e = c.Reflect) && e.construct && !c.customElements.get("google-product-ad")) {
            var f = kq(),
                g;
            null == (g = f ? new pq(function(k, l) {
                return Zh(a, k, l)
            }, function() {}) : void 0) || qq(g);
            var h = bq(c);
            e = function() {
                return h.apply(this, arguments) || this
            };
            _.L(e, h);
            e.prototype.connectedCallback = function() {
                var k = jq(a, b, this.dataset.rendering),
                    l = k.Oh,
                    m = k.Fh;
                k = k.Sd;
                l && d(rq(window, l));
                m && oq(a, m, f).then(function(n) {
                    return void bp(n)
                });
                k && ("true" === this.getAttribute("data-enable-click") || this.querySelector('[data-enable-click="true"]') ? (this.Sd = k, this.addEventListener("click", this.j)) : ql(b, sq(k)))
            };
            e.prototype.j = function(k) {
                var l = k.target instanceof c.HTMLElement ? k.target.closest("[data-enable-click]") : void 0;
                l instanceof c.HTMLElement && "true" === l.getAttribute("data-enable-click") && nq(a, this, k, this.Sd).then(function(m) {
                    return void bp(m)
                })
            };
            c.customElements.define("google-product-ad", e)
        }
    };
    vq = function(a, b, c, d, e, f, g) {
        var h = document,
            k = c.getAdUnitPath();
        c = uq.get(_.Se(c, 2, 0));
        if (k && c) {
            var l, m = null == (l = po(a, g, f, {
                be: c,
                adUnitPath: k,
                jb: !0
            })) ? void 0 : l.j;
            m && (a = jo(vj(), m.getSlotElementId()), d && (null == a || ko(a, d)), b.cmd.push(function() {
                m.addService(b.pubads())
            }), lo(h, function() {
                b.display(m);
                J(e, 4) && b.pubads().refresh([m])
            }))
        }
    };
    wq = function(a) {
        .001 > _.Ve() && Ye({
            c: "sd",
            s: String(a)
        }, "gpt_whirs")
    };
    Bq = function(a, b, c, d) {
        d = d.Vh;
        var e = b.kind;
        switch (e) {
            case 0:
                return new(d ? xq : yq)(a, b, c);
            case 1:
                return new zq(a, b, c);
            case 2:
                return new Aq(a, b, c);
            default:
                gb(e)
        }
    };
    Cq = function(a) {
        if (!_.oe(a)) return -1;
        a = a.pageYOffset;
        return 0 > a ? -1 : a
    };
    Hq = function(a, b, c, d) {
        var e = lj(a, document);
        e && vh(e, window, d, !0);
        Dq(_.of(ai), "5", (0, B.K)(oi(c.U[a.getDomId()], 20)));
        a.dispatchEvent(Eq, 801, {
            Xe: null,
            isBackfill: !1
        });
        if (_.Fq(b, a) && !uj(a, document)) {
            b = c.T;
            c = c.U[a.getDomId()];
            var f;
            (null != (f = Ui(c, 10)) ? f : J(b, 11)) && An(a, document, c, b)
        }
        a.dispatchEvent(Gq, 825, {
            isEmpty: !0
        })
    };
    Iq = function(a, b) {
        var c = _.ze("DIV");
        c.id = a;
        c.textContent = b;
        _.xj(c, {
            height: "24px",
            "line-height": "24px",
            "text-align": "center",
            "vertical-align": "middle",
            color: "white",
            "background-color": "black",
            margin: "0",
            "font-family": "Roboto",
            "font-style": "normal",
            "font-weight": "500",
            "font-size": "11px",
            "letter-spacing": "0.08em"
        });
        return c
    };
    Lq = function(a) {
        var b = {
            threshold: [0, .3, .5, .75, 1]
        };
        return _.E(Jq) ? window.IntersectionObserver && new IntersectionObserver(a, b) : window.IntersectionObserver ? new IntersectionObserver(a, b) : new Kq(a, b)
    };
    Nq = function(a) {
        return null != go(a, 1) ? null != Mq(a, 3) && 0 !== (0, _.Vm)() ? (0, B.ua)(go(a, 1)) * (0, B.ua)(Mq(a, 3)) : go(a, 1) : null
    };
    Oq = function(a, b) {
        return "undefined" === typeof IntersectionObserver ? _.E(Jq) ? void 0 : new Kq(b, {
            rootMargin: a + "%"
        }) : new IntersectionObserver(b, {
            rootMargin: a + "%"
        })
    };
    Gr = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w, D, F, I, S) {
        var M = new jg,
            R = ui(!0, window),
            T = k.T,
            X = k.U[e.getDomId()],
            ka = new Pq(a, window);
        G(M, ka);
        var ca = m.Sg,
            oa = m.fi,
            la = m.Gg,
            va = m.df,
            na = m.bg,
            ya = m.Xg,
            Ka = m.Wh,
            Zb = m.Mg,
            Kb = m.Dg,
            $b = m.Pc,
            Mb = m.Xh,
            Oa = m.Wg,
            sb = m.hh,
            ac = m.Th,
            mb = m.ci,
            Gc = m.di,
            dc = m.Tg,
            Fd = m.xg,
            Ub = m.Ka,
            me = m.Mf,
            Hc = m.gi,
            Gd = m.yc;
        m = m.ig;
        .01 > Math.random() && (I = new Qq(a, Hc, null == I ? void 0 : I.nb, Ka, va), G(M, I));
        Hc = new Rq;
        N(Hc, r);
        I = new Sq(a, window.top, Hc);
        G(M, I);
        n = new Tq(a, console, void 0, n, I.C);
        G(M, n);
        n = new Uq(a, Om(X), R.height, Kb, ca);
        G(M, n);
        ca = new Vq(a, e, lj(e, p), e.getDomId(), tj(e), p, Om(X), h, f);
        G(M, ca);
        Ub = new Wq(a, Ub, na, ya, Ka);
        G(M, Ub);
        Ka = new Xq(a, T, X, na, Ka);
        G(M, Ka);
        mb = new Yq(a, Bf(T, Zq, 5), mb);
        G(M, mb);
        oa = new $q(a, e.getAdUnitPath(), X, R.width, f, $b, oa, n.C, Ub.C, ca.C);
        G(M, oa);
        $b = new ar(a, X, me);
        G(M, $b);
        f = new br(a, h, r, f, me, $b.C, oa.Ka, oa.L, ca.C, t);
        G(M, f);
        if (g || _.E(cr)) {
            var tb = new dr(a, e, k, h, va, f.A);
            G(M, tb);
            F = new er(a, F, f.A);
            G(M, F);
            tb = new fr(a, tb.l, F.C);
            G(M, tb);
            tb = tb.C
        }
        F = new gr(a, e, T, X, Om(X), p, h, ca.C, Ka.C, f.l, la, tb);
        G(M, F);
        g = new hr(a, F.C);
        G(M, g);
        r = new ir(a, e, R, h, g.C, mb.l, tb);
        G(M, r);
        g = new jr(a, window, ca.C);
        G(M, g);
        Gc = new kr(a, r.C, F.C, Gc, mb.l, void 0, tb);
        G(M, Gc);
        R = new lr(a, p, e, X, R, la, ca.C, F.C, f.l, oa.Pc, g.C, va, tb);
        G(M, R);
        Mb = new mr(a, T, X, f.Ka, Ka.C, Mb);
        G(M, Mb);
        Fd = new nr(a, window, Fd, ka.C, tb);
        G(M, Fd);
        g = new or(a, Om(X), p);
        G(M, g);
        r = new pr(a, window);
        G(M, r);
        D = new qr(a, D, Om(X), Kb, Zb, tb);
        G(M, D);
        sb = new rr(a, sb, tb);
        G(M, sb);
        _.E(fk) && (S = S.Lf) && (S = new sr(a, window, S, m), G(M, S));
        l = new tr(a, e, h, k, w, l, window, f.Ka, Ka.C, Gc.C, ca.C, F.C, f.l, va, la, Mb.C, ya, Oa, ac, R.C, Fd.C, g.C, D.C, me, r.C, tb);
        G(M, l);
        ya = new ur(a, window, e, l.A, Hc);
        G(M, ya);
        Kb = new vr(a, h, Om(X), e, window, Kb, l.l, ca.C, D.C);
        G(M, Kb);
        k = new wr(a, e, Om(X), (0, B.K)(k.Vb), Zb, l.l, ca.C, I.C, D.C, va);
        G(M, k);
        4 === Om(X) && (X = new xr(a, e, w, window, l.l, ca.C), _.Vn(M, X), ug(X));
        p = new yr(a, e, l.l, p, w);
        G(M, p);
        h = new zr(a, Ar(h, e), window.top, l.l, ka.C);
        G(M, h);
        e = new Br(a, e, la, na, ac, l.l, F.C, l.D);
        G(M, e);
        dc = new Cr(a, window, dc, l.l, F.C, ca.C);
        G(M, dc);
        _.E(Dr) ? G(M, new Er(a, $k(), T, b, (0, B.K)(c), d, [Gd])) : G(M, new Fr(a, $k(), T, b, d, Gd));
        return M
    };
    Jr = function() {
        if (Ya()) {
            var a = $a();
            var b = 0;
            a = Hr(String(a)).split(".");
            for (var c = Hr("11").split("."), d = Math.max(a.length, c.length), e = 0; 0 == b && e < d; e++) {
                var f = a[e] || "",
                    g = c[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    b = Ir(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Ir(0 == f[2].length, 0 == g[2].length) || Ir(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (0 == b)
            }
            b = 0 <= b
        } else b = 65 <= bb();
        return b
    };
    Kr = function(a, b) {
        return _.E(Jq) ? window.IntersectionObserver && new IntersectionObserver(a, {
            rootMargin: b
        }) : window.IntersectionObserver ? new IntersectionObserver(a, {
            rootMargin: b
        }) : new Kq(a, {
            rootMargin: b
        })
    };
    Lr = function(a) {
        function b(f) {
            var g = f;
            return function() {
                var h = _.xb.apply(0, arguments);
                if (g) {
                    var k = g;
                    g = null;
                    k.apply(null, _.ve(h))
                }
            }
        }
        var c = null,
            d = 0,
            e = 0;
        return function() {
            var f, g, h, k;
            return _.Bb(function(l) {
                if (1 == l.j) return d && clearTimeout(d), d = 0, f = new _.oh, g = b(f.resolve), h = ++e, Cb(l, 0, 2);
                if (e !== h) return g(!1), l.return(f.promise);
                c ? c(!1) : g(!0);
                k = b(function() {
                    c = null;
                    d = 0;
                    g(!0)
                });
                d = setTimeout(k, 1E3);
                _.qo(a, function() {
                    return void g(!1)
                });
                c = g;
                return l.return(f.promise)
            })
        }
    };
    Tr = function() {
        var a = new Mr;
        var b = (new Nr).setCorrelator(tf(_.q));
        var c = _.of(pf).j().join();
        b = _.jd(b, 5, c);
        b = _.fd(b, 2, 1, 0);
        a = _.Th(a, 1, b);
        b = new Or;
        c = _.E(Pr);
        b = _.hd(b, 7, c);
        c = _.E(Qr);
        b = _.hd(b, 8, c);
        c = _.E(Rr);
        b = _.hd(b, 9, c);
        b = _.hd(b, 10, !0);
        c = _.E(Sr);
        b = _.hd(b, 13, c);
        b = _.hd(b, 16, !0);
        a = _.Th(a, 2, b);
        window.google_rum_config = a.toJSON()
    };
    Vr = function() {
        var a = Ur,
            b = Number(a);
        return 1 > b || Math.floor(b) !== b ? (Ye({
            v: a
        }, "gpt_inv_ver"), "1") : a
    };
    Xr = function(a) {
        var b = Wr() || (0, _.Ue)() ? 1 : _.Ve(),
            c = .001 > b;
        c ? (a.l = !0, qf(31067358)) : .002 > b && qf(31067357);
        rf(23);
        return {
            Dc: c,
            jh: 1E3,
            Mh: 1E-4 > b,
            ih: 1E4,
            Jf: c,
            bf: 1E3
        }
    };
    $r = function(a) {
        var b = Vr();
        if (/m\d+/.test("m202303210101")) var c = Number("202303210101");
        else Ye({
            mjsv: "m202303210101"
        }, "gpt_inv_ver"), c = void 0;
        var d = tf(window),
            e = window.document.URL,
            f = _.Kf(Yr);
        return _.u(Object, "assign").call(Object, {}, a, {
            Na: b,
            bb: "m202303210101",
            Ab: c,
            pvsid: d,
            Eb: new _.Zr(f),
            tg: e
        })
    };
    _.ba = [];
    as = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    };
    bs = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };
    cs = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    };
    _.ds = cs(this);
    es = "function" === typeof Symbol && "symbol" === typeof Symbol("x");
    _.v = {};
    fs = {};
    _.u = function(a, b, c) {
        if (!c || null != a) {
            c = fs[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    };
    gs = function(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in _.v ? f = _.v : f = _.ds;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = es && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? bs(_.v, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === fs[d] && (a = 1E9 * Math.random() >>> 0, fs[d] = es ? _.ds.Symbol(d) : "$jscp$" + a + "$" + d), bs(f, fs[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    };
    gs("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.j = f;
            bs(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.j
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    gs("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, _.v.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = _.ds[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && bs(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return hs(as(this))
                }
            })
        }
        return a
    }, "es6");
    hs = function(a) {
        a = {
            next: a
        };
        a[_.u(_.v.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    _.O = function(a) {
        return a.raw = a
    };
    is = function(a, b) {
        a.raw = b;
        return a
    };
    _.x = function(a) {
        var b = "undefined" != typeof _.v.Symbol && _.u(_.v.Symbol, "iterator") && a[_.u(_.v.Symbol, "iterator")];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: as(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    };
    _.ve = function(a) {
        if (!(a instanceof Array)) {
            a = _.x(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    };
    js = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    ks = es && "function" == typeof _.u(Object, "assign") ? _.u(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) js(d, e) && (a[e] = d[e])
        }
        return a
    };
    gs("Object.assign", function(a) {
        return a || ks
    }, "es6");
    var ls = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ms = function() {
            function a() {
                function c() {}
                new c;
                _.u(_.v.Reflect, "construct").call(_.v.Reflect, c, [], function() {});
                return new c instanceof c
            }
            if (es && "undefined" != typeof _.v.Reflect && _.u(_.v.Reflect, "construct")) {
                if (a()) return _.u(_.v.Reflect, "construct");
                var b = _.u(_.v.Reflect, "construct");
                return function(c, d, e) {
                    c = b(c, d);
                    e && _.u(_.v.Reflect, "setPrototypeOf").call(_.v.Reflect, c, e.prototype);
                    return c
                }
            }
            return function(c, d, e) {
                void 0 === e && (e = c);
                e = ls(e.prototype || Object.prototype);
                return Function.prototype.apply.call(c, e, d) || e
            }
        }(),
        ns;
    if (es && "function" == typeof _.u(Object, "setPrototypeOf")) ns = _.u(Object, "setPrototypeOf");
    else {
        var os;
        a: {
            var ps = {
                    a: !0
                },
                qs = {};
            try {
                qs.__proto__ = ps;
                os = qs.a;
                break a
            } catch (a) {}
            os = !1
        }
        ns = os ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    rs = ns;
    _.L = function(a, b) {
        a.prototype = ls(b.prototype);
        a.prototype.constructor = a;
        if (rs) rs(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Ph = b.prototype
    };
    ss = function() {
        this.l = !1;
        this.H = null;
        this.o = void 0;
        this.j = 1;
        this.J = this.m = 0;
        this.B = null
    };
    ts = function(a) {
        if (a.l) throw new TypeError("Generator is already running");
        a.l = !0
    };
    ss.prototype.I = function(a) {
        this.o = a
    };
    var us = function(a, b) {
        a.B = {
            ef: b,
            Zg: !0
        };
        a.j = a.m || a.J
    };
    ss.prototype.return = function(a) {
        this.B = {
            return: a
        };
        this.j = this.J
    };
    Cb = function(a, b, c) {
        a.j = c;
        return {
            value: b
        }
    };
    Eb = function(a, b) {
        a.j = b;
        a.m = 0
    };
    Fb = function(a) {
        a.m = 0;
        var b = a.B.ef;
        a.B = null;
        return b
    };
    vs = function(a) {
        this.j = new ss;
        this.o = a
    };
    ys = function(a, b) {
        ts(a.j);
        var c = a.j.H;
        if (c) return ws(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.j.return);
        a.j.return(b);
        return xs(a)
    };
    ws = function(a, b, c, d) {
        try {
            var e = b.call(a.j.H, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.j.l = !1, e;
            var f = e.value
        } catch (g) {
            return a.j.H = null, us(a.j, g), xs(a)
        }
        a.j.H = null;
        d.call(a.j, f);
        return xs(a)
    };
    xs = function(a) {
        for (; a.j.j;) try {
            var b = a.o(a.j);
            if (b) return a.j.l = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.j.o = void 0, us(a.j, c)
        }
        a.j.l = !1;
        if (a.j.B) {
            b = a.j.B;
            a.j.B = null;
            if (b.Zg) throw b.ef;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    };
    zs = function(a) {
        this.next = function(b) {
            ts(a.j);
            a.j.H ? b = ws(a, a.j.H.next, b, a.j.I) : (a.j.I(b), b = xs(a));
            return b
        };
        this.throw = function(b) {
            ts(a.j);
            a.j.H ? b = ws(a, a.j.H["throw"], b, a.j.I) : (us(a.j, b), b = xs(a));
            return b
        };
        this.return = function(b) {
            return ys(a, b)
        };
        this[_.u(_.v.Symbol, "iterator")] = function() {
            return this
        }
    };
    As = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new _.v.Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : _.v.Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    };
    _.Bb = function(a) {
        return As(new zs(new vs(a)))
    };
    _.xb = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    gs("Reflect", function(a) {
        return a ? a : {}
    }, "es6");
    gs("Reflect.construct", function() {
        return ms
    }, "es6");
    gs("Reflect.setPrototypeOf", function(a) {
        return a ? a : rs ? function(b, c) {
            try {
                return rs(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6");
    gs("Promise", function(a) {
        function b() {
            this.j = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.o = function(g) {
            if (null == this.j) {
                this.j = [];
                var h = this;
                this.m(function() {
                    h.B()
                })
            }
            this.j.push(g)
        };
        var d = _.ds.setTimeout;
        b.prototype.m = function(g) {
            d(g, 0)
        };
        b.prototype.B = function() {
            for (; this.j && this.j.length;) {
                var g = this.j;
                this.j = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.H(l)
                    }
                }
            }
            this.j = null
        };
        b.prototype.H = function(g) {
            this.m(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.o = 0;
            this.m = void 0;
            this.j = [];
            this.I = !1;
            var h = this.H();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.H = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.R),
                reject: g(this.B)
            }
        };
        e.prototype.R = function(g) {
            if (g === this) this.B(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.L(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = null != g;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.D(g) : this.l(g)
            }
        };
        e.prototype.D = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.B(k);
                return
            }
            "function" == typeof h ? this.N(h, g) : this.l(g)
        };
        e.prototype.B = function(g) {
            this.J(2, g)
        };
        e.prototype.l = function(g) {
            this.J(1, g)
        };
        e.prototype.J = function(g, h) {
            if (0 != this.o) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.o);
            this.o = g;
            this.m = h;
            2 === this.o && this.G();
            this.A()
        };
        e.prototype.G = function() {
            var g = this;
            d(function() {
                if (g.ha()) {
                    var h = _.ds.console;
                    "undefined" !== typeof h && h.error(g.m)
                }
            }, 1)
        };
        e.prototype.ha = function() {
            if (this.I) return !1;
            var g = _.ds.CustomEvent,
                h = _.ds.Event,
                k = _.ds.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = _.ds.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.m;
            return k(g)
        };
        e.prototype.A = function() {
            if (null != this.j) {
                for (var g = 0; g < this.j.length; ++g) f.o(this.j[g]);
                this.j = null
            }
        };
        var f = new b;
        e.prototype.L = function(g) {
            var h = this.H();
            g.Sc(h.resolve, h.reject)
        };
        e.prototype.N = function(g, h) {
            var k = this.H();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(p, r) {
                return "function" == typeof p ? function(t) {
                    try {
                        l(p(t))
                    } catch (w) {
                        m(w)
                    }
                } : r
            }
            var l, m, n = new e(function(p, r) {
                l = p;
                m = r
            });
            this.Sc(k(g, l), k(h, m));
            return n
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Sc = function(g, h) {
            function k() {
                switch (l.o) {
                    case 1:
                        g(l.m);
                        break;
                    case 2:
                        h(l.m);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.o);
                }
            }
            var l = this;
            null == this.j ? f.o(k) : this.j.push(k);
            this.I = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = _.x(g), m = l.next(); !m.done; m = l.next()) c(m.value).Sc(h, k)
            })
        };
        e.all = function(g) {
            var h = _.x(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function n(t) {
                    return function(w) {
                        p[t] = w;
                        r--;
                        0 == r && l(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, c(k.value).Sc(n(p.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    }, "es6");
    gs("Object.setPrototypeOf", function(a) {
        return a || rs
    }, "es6");
    gs("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.j = (e += Math.random() + 1).toString();
                if (g) {
                    g = _.x(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!js(g, d)) {
                var k = new b;
                bs(g, d, {
                    value: k
                })
            }
            if (!js(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.j] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && js(g, d) ? g[d][this.j] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && js(g, d) && js(g[d], this.j)
        };
        f.prototype.delete = function(g) {
            return c(g) && js(g, d) && js(g[d], this.j) ? delete g[d][this.j] : !1
        };
        return f
    }, "es6");
    gs("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(_.x([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = _.u(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new _.v.WeakMap,
            c = function(h) {
                this.o = {};
                this.j = f();
                this.size = 0;
                if (h) {
                    h = _.x(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this.o[l.id] = []);
            l.sa ? l.sa.value = k : (l.sa = {
                next: this.j,
                eb: this.j.eb,
                head: this.j,
                key: h,
                value: k
            }, l.list.push(l.sa), this.j.eb.next = l.sa, this.j.eb = l.sa, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.sa && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.o[h.id], h.sa.eb.next = h.sa.next, h.sa.next.eb = h.sa.eb, h.sa.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this.o = {};
            this.j = this.j.eb = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).sa
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).sa) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = _.u(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[_.u(_.v.Symbol, "iterator")] = _.u(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h.o[l];
                if (m && js(h.o, l))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (k !== k && n.key !== n.key || k === n.key) return {
                            id: l,
                            list: m,
                            index: h,
                            sa: n
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    sa: void 0
                }
            },
            e = function(h, k) {
                var l = h.j;
                return hs(function() {
                    if (l) {
                        for (; l.head != h.j;) l = l.eb;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.eb = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    var Es = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[_.u(_.v.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    gs("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Es(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    gs("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Es(this, function(b) {
                return b
            })
        }
    }, "es6");
    var Fs = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    gs("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Fs(this, b, "endsWith");
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    }, "es6");
    var Gs = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                i: e,
                Pf: f
            }
        }
        return {
            i: -1,
            Pf: void 0
        }
    };
    gs("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            return Gs(this, b, c).Pf
        }
    }, "es6");
    gs("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    gs("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    gs("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof _.v.Symbol && _.u(_.v.Symbol, "iterator") && b[_.u(_.v.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    gs("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return _.u(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    gs("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Es(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    gs("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(_.x([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = _.u(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.j = new _.v.Map;
            if (c) {
                c = _.x(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.j.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.j.set(c, c);
            this.size = this.j.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.j.delete(c);
            this.size = this.j.size;
            return c
        };
        b.prototype.clear = function() {
            this.j.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.j.has(c)
        };
        b.prototype.entries = function() {
            return _.u(this.j, "entries").call(this.j)
        };
        b.prototype.values = function() {
            return _.u(this.j, "values").call(this.j)
        };
        b.prototype.keys = _.u(b.prototype, "values");
        b.prototype[_.u(_.v.Symbol, "iterator")] = _.u(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.j.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    gs("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) js(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    gs("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Fs(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    gs("globalThis", function(a) {
        return a || _.ds
    }, "es_2020");
    gs("Array.prototype.flatMap", function(a) {
        return a ? a : function(b, c) {
            var d = [];
            Array.prototype.forEach.call(this, function(e, f) {
                e = b.call(c, e, f, this);
                Array.isArray(e) ? d.push.apply(d, e) : d.push(e)
            });
            return d
        }
    }, "es9");
    gs("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    gs("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || _.u(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    gs("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Fs(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    gs("AggregateError", function(a) {
        if (a) return a;
        a = function(b, c) {
            c = Error(c);
            "stack" in c && (this.stack = c.stack);
            this.errors = b;
            this.message = c.message
        };
        _.L(a, Error);
        a.prototype.name = "AggregateError";
        return a
    }, "es_2021");
    gs("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : _.u(Array, "from").call(Array, b);
            return _.v.Promise.all(b.map(function(c) {
                return _.v.Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new _.v.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    gs("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) js(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    gs("Object.fromEntries", function(a) {
        return a ? a : function(b) {
            var c = {};
            if (!(_.u(_.v.Symbol, "iterator") in b)) throw new TypeError("" + b + " is not iterable");
            b = b[_.u(_.v.Symbol, "iterator")].call(b);
            for (var d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                c[d[0]] = d[1]
            }
            return c
        }
    }, "es_2019");
    gs("Array.prototype.findIndex", function(a) {
        return a ? a : function(b, c) {
            return Gs(this, b, c).i
        }
    }, "es6");
    gs("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = _.u(Array.prototype, "flat").call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    }, "es9");
    gs("Promise.prototype.finally", function(a) {
        return a ? a : function(b) {
            return this.then(function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    return c
                })
            }, function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    throw c;
                })
            })
        }
    }, "es9");
    gs("String.raw", function(a) {
        return a ? a : function(b, c) {
            if (null == b) throw new TypeError("Cannot convert undefined or null to object");
            for (var d = b.raw, e = d.length, f = "", g = 0; g < e; ++g) f += d[g], g + 1 < e && g + 1 < arguments.length && (f += String(arguments[g + 1]));
            return f
        }
    }, "es6");
    _.q = this || self;
    Is = function(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = _.q, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    };
    za = function(a) {
        var b = typeof a;
        b = "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null";
        return "array" == b || "object" == b && "number" == typeof a.length
    };
    _.pa = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    };
    qa = "closure_uid_" + (1E9 * Math.random() >>> 0);
    ra = 0;
    Ks = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    };
    Os = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    };
    _.Ps = function(a, b, c) {
        Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? _.Ps = Ks : _.Ps = Os;
        return _.Ps.apply(null, arguments)
    };
    _.Qs = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    };
    hf = function() {
        return Date.now()
    };
    var Rs;
    var Ws, Ts, Ss;
    _.Us = function(a, b) {
        this.j = a === Ss && b || "";
        this.o = Ts
    };
    _.Us.prototype.Pa = !0;
    _.Us.prototype.Ea = function() {
        return this.j
    };
    _.Vs = function(a) {
        return a instanceof _.Us && a.constructor === _.Us && a.o === Ts ? a.j : "type_error:Const"
    };
    Ws = function(a) {
        return new _.Us(Ss, a)
    };
    Ts = {};
    Ss = {};
    var Ib = Ws("https://tpc.googlesyndication.com/sodar/%{basename}.js");
    var Xs, Ys, mj, $s;
    Xs = function() {
        return !0
    };
    Ys = function(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    };
    mj = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    _.Zs = function(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    $s = function(a, b, c) {
        var d = 0,
            e = !1,
            f = [],
            g = function() {
                d = 0;
                e && (e = !1, h())
            },
            h = function() {
                d = _.q.setTimeout(g, b);
                var k = f;
                f = [];
                a.apply(c, k)
            };
        return function(k) {
            f = arguments;
            d ? e = !0 : h()
        }
    };
    var at, ea;
    at = {
        passive: !0
    };
    ea = mj(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            _.q.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });
    _.zb = function(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, fa(d)), !0) : !1
    };
    _.Ae = function(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, fa(d)), !0) : !1
    };
    var ct;
    _.ha = function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };
    _.bt = function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    _.lh = function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    };
    _.zd = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };
    ct = function(a, b) {
        return Array.prototype.reduce.call(a, b, 0)
    };
    _.Kh = function(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    };
    var Ha = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    var dt = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var xp;
    xp = {};
    _.wp = function(a, b) {
        this.j = b === xp ? a : "";
        this.Pa = !0
    };
    _.wp.prototype.toString = function() {
        return this.j.toString()
    };
    _.wp.prototype.Ea = function() {
        return this.j.toString()
    };
    _.ib = function(a) {
        return a instanceof _.wp && a.constructor === _.wp ? a.j : "type_error:SafeScript"
    };
    var Hb, ht, gt, it, et, se, jt;
    _.ft = function(a, b) {
        this.j = b === et ? a : ""
    };
    _.ft.prototype.toString = function() {
        return this.j + ""
    };
    _.ft.prototype.Pa = !0;
    _.ft.prototype.Ea = function() {
        return this.j.toString()
    };
    _.kb = function(a) {
        return a instanceof _.ft && a.constructor === _.ft ? a.j : "type_error:TrustedResourceUrl"
    };
    Hb = function(a, b) {
        var c = _.Vs(a);
        if (!gt.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(ht, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof _.Us ? _.Vs(d) : encodeURIComponent(String(d))
        });
        return se(a)
    };
    ht = /%{(\w+)}/g;
    gt = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i");
    it = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;
    et = {};
    se = function(a) {
        return new _.ft(a, et)
    };
    jt = function(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var kt = function(a, b) {
            var c = a.length - b.length;
            return 0 <= c && a.indexOf(b, c) == c
        },
        pl = function(a) {
            return /^[\s\xa0]*$/.test(a)
        },
        Hr = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        st = function(a) {
            if (!lt.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(mt, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(nt, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(ot, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(pt, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(qt, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(rt, "&#0;"));
            return a
        },
        mt = /&/g,
        nt = /</g,
        ot = />/g,
        pt = /"/g,
        qt = /'/g,
        rt = /\x00/g,
        lt = /[\x00&<>"']/,
        Na = function(a, b) {
            return -1 != a.indexOf(b)
        },
        Ir = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var ut, vt, xt, yt, tt, ub;
    _.cb = function(a, b) {
        this.j = b === tt ? a : ""
    };
    _.cb.prototype.toString = function() {
        return this.j.toString()
    };
    _.cb.prototype.Pa = !0;
    _.cb.prototype.Ea = function() {
        return this.j.toString()
    };
    _.db = function(a) {
        return a instanceof _.cb && a.constructor === _.cb ? a.j : "type_error:SafeUrl"
    };
    ut = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;
    vt = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    _.wt = function(a) {
        if (a instanceof _.cb) return a;
        a = "object" == typeof a && a.Pa ? a.Ea() : String(a);
        vt.test(a) ? a = ub(a) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(ut) ? ub(a) : null);
        return a
    };
    try {
        new URL("s://g"), xt = !0
    } catch (a) {
        xt = !1
    }
    yt = xt;
    tt = {};
    ub = function(a) {
        return new _.cb(a, tt)
    };
    _.vb = ub("about:invalid#zClosurez");
    _.zt = {};
    _.At = function(a, b) {
        this.j = b === _.zt ? a : "";
        this.Pa = !0
    };
    _.At.prototype.Ea = function() {
        return this.j
    };
    _.At.prototype.toString = function() {
        return this.j.toString()
    };
    _.Bt = new _.At("", _.zt);
    _.Ct = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$");
    _.Dt = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g");
    _.Et = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g");
    var La = Is(610401301, !1),
        Ft = Is(513561853, Is(1, !0));
    var Ma, Gt = _.q.navigator;
    Ma = Gt ? Gt.userAgentData || null : null;
    var Ht, Kt, Nt, Lt, Pt, Mt, ah;
    Ht = {};
    _.It = function(a, b) {
        this.j = b === Ht ? a : "";
        this.Pa = !0
    };
    _.It.prototype.Ea = function() {
        return this.j.toString()
    };
    _.It.prototype.toString = function() {
        return this.j.toString()
    };
    _.nb = function(a) {
        return a instanceof _.It && a.constructor === _.It ? a.j : "type_error:SafeHtml"
    };
    Kt = function(a) {
        return a instanceof _.It ? a : _.Jt(st("object" == typeof a && a.Pa ? a.Ea() : String(a)))
    };
    _.ch = function(a) {
        if (!Lt.test(a)) throw Error("");
        if (a.toUpperCase() in Mt) throw Error("");
    };
    Nt = function(a) {
        var b = Kt(ah),
            c = [],
            d = function(e) {
                Array.isArray(e) ? e.forEach(d) : (e = Kt(e), c.push(_.nb(e).toString()))
            };
        a.forEach(d);
        return _.Jt(c.join(_.nb(b).toString()))
    };
    _.Ot = function(a) {
        return Nt(Array.prototype.slice.call(arguments))
    };
    _.Jt = function(a) {
        return new _.It(a, Ht)
    };
    _.dh = function(a, b, c) {
        var d = "";
        if (b)
            for (var e in b)
                if (Object.prototype.hasOwnProperty.call(b, e)) {
                    if (!Lt.test(e)) throw Error("");
                    var f = b[e];
                    if (null != f) {
                        var g = e;
                        if (f instanceof _.Us) f = _.Vs(f);
                        else {
                            if ("style" == g.toLowerCase()) throw Error("");
                            if (/^on/i.test(g)) throw Error("");
                            if (g.toLowerCase() in Pt)
                                if (f instanceof _.ft) f = _.kb(f).toString();
                                else if (f instanceof _.cb) f = _.db(f);
                            else if ("string" === typeof f) f = (_.wt(f) || _.vb).Ea();
                            else throw Error("");
                        }
                        f.Pa && (f = f.Ea());
                        f = g + '="' + st(String(f)) + '"';
                        d += " " + f
                    }
                }
        b = "<" + a + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === dt[a.toLowerCase()] ? b += ">" : (c = _.Ot(c), b += ">" + _.nb(c).toString() + "</" + a + ">");
        return _.Jt(b)
    };
    Lt = /^[a-zA-Z0-9-]+$/;
    Pt = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    };
    Mt = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    };
    ah = new _.It(_.q.trustedTypes && _.q.trustedTypes.emptyHTML || "", Ht);
    _.Qt = _.Jt("<br>");
    var Rt;
    try {
        new URL("s://g"), Rt = !0
    } catch (a) {
        Rt = !1
    }
    var eb = Rt;
    var St = {
            Ji: 0,
            Fi: 1,
            Gi: 2,
            0: "HTML_FORMATTED_CONTENT",
            1: "EMBEDDED_INTERNAL_CONTENT",
            2: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
        },
        Tt = function(a, b) {
            b = Error.call(this, a + " cannot be used with intent " + St[b]);
            this.message = b.message;
            "stack" in b && (this.stack = b.stack);
            this.type = a;
            this.name = "TypeCannotBeUsedWithIntentError"
        };
    _.L(Tt, Error);
    var pb = function(a) {
            this.eh = a
        },
        rb = [qb("data"), qb("http"), qb("https"), qb("mailto"), qb("ftp"), new pb(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })];
    var Db = function(a) {
        return new _.v.Promise(function(b, c) {
            var d = new XMLHttpRequest;
            d.onreadystatechange = function() {
                d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
            };
            d.open("GET", a, !0);
            d.send()
        })
    };
    var Nb, Lb = "undefined" !== typeof TextEncoder;
    _.Ut = function(a) {
        _.Ut[" "](a);
        return a
    };
    _.Ut[" "] = function() {};
    var Vt = function(a, b) {
        try {
            return _.Ut(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Wt, Yt, Zt, $t, au, bu;
    Wt = Ta();
    _.Xt = Ua();
    Yt = Qa("Edge");
    Zt = Qa("Gecko") && !(Na(Ja().toLowerCase(), "webkit") && !Qa("Edge")) && !(Qa("Trident") || Qa("MSIE")) && !Qa("Edge");
    $t = Na(Ja().toLowerCase(), "webkit") && !Qa("Edge");
    au = function() {
        var a = _.q.document;
        return a ? a.documentMode : void 0
    };
    a: {
        var cu = "",
            du = function() {
                var a = Ja();
                if (Zt) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Yt) return /Edge\/([\d\.]+)/.exec(a);
                if (_.Xt) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if ($t) return /WebKit\/(\S+)/.exec(a);
                if (Wt) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();du && (cu = du ? du[1] : "");
        if (_.Xt) {
            var eu = au();
            if (null != eu && eu > parseFloat(cu)) {
                bu = String(eu);
                break a
            }
        }
        bu = cu
    }
    var fu = bu,
        gu;
    if (_.q.document && _.Xt) {
        var hu = au();
        gu = hu ? hu : parseInt(fu, 10) || void 0
    } else gu = void 0;
    var iu = gu;
    !Qa("Android") || Xa();
    Xa();
    Ya();
    var ju = {},
        ku = null,
        lu = Zt || $t || "function" == typeof _.q.btoa,
        Qb = function(a, b) {
            void 0 === b && (b = 0);
            mu();
            b = ju[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        nu = function(a, b) {
            if (lu && !b) a = _.q.btoa(a);
            else {
                for (var c = [], d = 0, e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    255 < f && (c[d++] = f & 255, f >>= 8);
                    c[d++] = f
                }
                a = Qb(c, b)
            }
            return a
        },
        gq = function(a) {
            var b = "";
            ou(a, function(c) {
                b += String.fromCharCode(c)
            });
            return b
        },
        pu = function(a) {
            var b = a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : Na("=.", a[b - 1]) && (c = Na("=.", a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            ou(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        ou = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = ku[l];
                    if (null != m) return m;
                    if (!pl(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            mu();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        mu = function() {
            if (!ku) {
                ku = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    ju[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === ku[f] && (ku[f] = e)
                    }
                }
            }
        };
    var Vb = "undefined" !== typeof Uint8Array,
        Pb = !_.Xt && "function" === typeof _.q.btoa,
        qu = /[-_.]/g,
        Sb = {
            "-": "+",
            _: "/",
            ".": "="
        },
        ok, Xb = {};
    var ru, uc = function(a, b) {
            Yb(b);
            this.j = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        },
        vc = function() {
            return ru || (ru = new uc(null, Xb))
        },
        nd = function(a) {
            var b = a.j;
            return null == b ? "" : "string" === typeof b ? b : a.j = Rb(b)
        };
    uc.prototype.isEmpty = function() {
        return null == this.j
    };
    var nk = function(a) {
        Yb(Xb);
        var b = a.j;
        if (null != b && !Wb(b))
            if ("string" === typeof b)
                if (Pb) {
                    qu.test(b) && (b = b.replace(qu, Tb));
                    b = atob(b);
                    for (var c = new Uint8Array(b.length), d = 0; d < b.length; d++) c[d] = b.charCodeAt(d);
                    b = c
                } else b = pu(b);
        else b = null;
        return null == b ? b : a.j = b
    };
    var cc = 0,
        ec = 0,
        gc = "function" === typeof BigInt;
    var su = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        uu = function(a) {
            if (!a) return tu || (tu = new su(0, 0));
            if (!/^\d+$/.test(a)) return null;
            hc(a);
            return new su(cc, ec)
        },
        tu, vu = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        Yd = function(a) {
            if (!a) return wu || (wu = new vu(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            hc(a);
            return new vu(cc, ec)
        },
        wu;
    var xu = function() {
        this.j = []
    };
    xu.prototype.length = function() {
        return this.j.length
    };
    xu.prototype.end = function() {
        var a = this.j;
        this.j = [];
        return a
    };
    var $d = function(a, b, c) {
            for (; 0 < c || 127 < b;) a.j.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
            a.j.push(b)
        },
        Zd = function(a, b) {
            for (; 127 < b;) a.j.push(b & 127 | 128), b >>>= 7;
            a.j.push(b)
        },
        yu = function(a, b) {
            if (0 <= b) Zd(a, b);
            else {
                for (var c = 0; 9 > c; c++) a.j.push(b & 127 | 128), b >>= 7;
                a.j.push(1)
            }
        };
    var ge = function() {
            this.m = [];
            this.o = 0;
            this.j = new xu
        },
        he = function(a, b) {
            0 !== b.length && (a.m.push(b), a.o += b.length)
        },
        zu = function(a, b) {
            Zd(a.j, 8 * b + 2);
            b = a.j.end();
            he(a, b);
            b.push(a.o);
            return b
        },
        Au = function(a, b) {
            var c = b.pop();
            for (c = a.o + a.j.length() - c; 127 < c;) b.push(c & 127 | 128), c >>>= 7, a.o++;
            b.push(c);
            a.o++
        },
        Kd = function(a, b) {
            if (b = b.oe) {
                he(a, a.j.end());
                for (var c = 0; c < b.length; c++) he(a, nk(b[c]) || ok || (ok = new Uint8Array(0)))
            }
        },
        Bu = function(a, b, c) {
            Zd(a.j, 8 * b + 2);
            Zd(a.j, c.length);
            he(a, a.j.end());
            he(a, c)
        };
    var ic = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : void 0;
    var Jc = {},
        Cu, Vc = Object.freeze(mc([], 23)),
        Du = function(a) {
            this.lf = 0;
            this.Pe = a
        };
    Du.prototype.next = function() {
        return this.lf < this.Pe.length ? {
            done: !1,
            value: this.Pe[this.lf++]
        } : {
            done: !0,
            value: void 0
        }
    };
    Du.prototype[_.u(_.v.Symbol, "iterator")] = function() {
        return this
    };
    var Eu = !Ft || !1;
    var Nc = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : "di";
    var bd = function(a, b, c, d) {
            c = void 0 === c ? Oc : c;
            d = void 0 === d ? Oc : d;
            var e = lc(a);
            e |= 32;
            mc(a, e);
            this.m = e;
            this.o = b;
            this.H = c || Oc;
            this.B = this.o ? Tc : d || Oc;
            var f = new _.v.Map;
            this.j = f;
            for (var g = 0; g < a.length; g++) {
                var h = a[g],
                    k = c(h[0], !1, !0),
                    l = h[1];
                b || (l = d(h[1], !1, !0, void 0, void 0, e));
                null != k && f.set(k, l)
            }
            this.size = f.size
        },
        Fu = function(a) {
            if (a.m & 2) throw Error("Cannot mutate an immutable Map");
        },
        od = function(a, b) {
            b = void 0 === b ? Uc : b;
            for (var c = Gu(a), d = 0; d < c.length; d++) {
                var e = c[d],
                    f = a.j.get(c[d]);
                c[d] = [b(e), b(f)]
            }
            return c
        },
        cd = function(a, b) {
            b = void 0 === b ? Uc : b;
            var c = [];
            a = _.u(a.j, "entries").call(a.j);
            for (var d; !(d = a.next()).done;) d = d.value, d[0] = b(d[0]), d[1] = b(d[1]), c.push(d);
            return c
        };
    _.aa = bd.prototype;
    _.aa.clear = function() {
        Fu(this);
        this.j.clear();
        this.size = 0
    };
    _.aa.delete = function(a) {
        Fu(this);
        return this.j.delete(a) ? (this.size = this.j.size, !0) : !1
    };
    _.aa.entries = function() {
        for (var a = Gu(this), b = 0; b < a.length; b++) {
            var c = a[b];
            a[b] = [c, this.get(c)]
        }
        return new Du(a)
    };
    _.aa.keys = function() {
        return Eu ? new Du(Gu(this)) : _.u(this.j, "keys").call(this.j)
    };
    _.aa.values = function() {
        for (var a = Gu(this), b = 0; b < a.length; b++) a[b] = this.get(a[b]);
        return new Du(a)
    };
    _.aa.forEach = function(a, b) {
        var c = this;
        if (Eu)
            for (var d = Gu(this), e = 0; e < d.length; e++) {
                var f = d[e];
                a.call(b, this.get(f), f, this)
            } else this.j.forEach(function(g, h) {
                a.call(b, c.get(h), h, c)
            })
    };
    _.aa.set = function(a, b) {
        Fu(this);
        var c = this.j;
        a = this.H(a, !0, !1);
        if (null == a) return this;
        if (null == b) return c.delete(a), this;
        c.set(a, this.B(b, !0, !0, this.o, !1, this.m));
        this.size = c.size;
        return this
    };
    _.aa.get = function(a) {
        a = this.H(a, !1, !1);
        var b = this.j,
            c = b.get(a);
        if (void 0 !== c) {
            var d = this.m,
                e = this.o;
            return e ? (Array.isArray(c) && d & 16 && qc(c), d = this.B(c, !1, !0, e, this.l, d), d !== c && b.set(a, d), d) : c
        }
    };
    _.aa.has = function(a) {
        return this.o ? null != this.get(a) : this.j.has(a)
    };
    var Gu = function(a) {
        return Eu ? _.u(Array, "from").call(Array, _.u(a.j, "keys").call(a.j)).sort(Rc) : _.u(Array, "from").call(Array, _.u(a.j, "keys").call(a.j))
    };
    bd.prototype[_.u(_.v.Symbol, "iterator")] = function() {
        return _.u(this, "entries").call(this)
    };
    var Hu, y, Wc, Rl, Do, Mq, J, ad, wf, ik, Vf, mk, Mp, Iu, Op, Bf, Qe, Ju, Te, go, Ui, Ku, oi, Lu, Nu, ho, Ou, Pu, Qu, eo, qg, Ru;
    Hu = function(a) {
        var b = a.o + a.rb;
        return a.Qa || (a.Qa = a.fa[b] = {})
    };
    y = function(a, b, c) {
        return -1 === b ? null : b >= a.o ? a.Qa ? a.Qa[b] : void 0 : c && a.Qa && (c = a.Qa[b], null != c) ? c : a.fa[b + a.rb]
    };
    _.z = function(a, b, c, d) {
        yc(a);
        return Wc(a, b, c, d)
    };
    Wc = function(a, b, c, d) {
        a.B && (a.B = void 0);
        if (b >= a.o || d) return Hu(a)[b] = c, a;
        a.fa[b + a.rb] = c;
        (c = a.Qa) && b in c && delete c[b];
        return a
    };
    Rl = function(a, b) {
        return null != y(a, b, !1)
    };
    Do = function(a, b, c) {
        return void 0 !== Iu(a, b, c, !1)
    };
    Mq = function(a, b) {
        var c = y(a, b);
        var d = null == c ? c : "number" === typeof c || "NaN" === c || "Infinity" === c || "-Infinity" === c ? Number(c) : void 0;
        null != d && d !== c && Wc(a, b, d);
        return d
    };
    J = function(a, b) {
        a = y(a, b);
        return null == a ? a : !!a
    };
    _.Uf = function(a, b, c) {
        return kd(J(a, b), void 0 === c ? !1 : c)
    };
    wf = function(a, b) {
        return _.z(a, b, void 0, !1)
    };
    ik = function(a, b, c, d) {
        yc(a);
        (c = mk(a, c)) && c !== b && null != d && Wc(a, c, void 0, !1);
        return Wc(a, b, d)
    };
    Vf = function(a, b, c) {
        return mk(a, b) === c ? c : -1
    };
    mk = function(a, b) {
        for (var c = 0, d = 0; d < b.length; d++) {
            var e = b[d];
            null != y(a, e) && (0 !== c && Wc(a, c, void 0, !1), c = e)
        }
        return c
    };
    Mp = function(a, b, c) {
        var d = lc(a.fa);
        xc(d);
        var e = y(a, c);
        b = Sc(Mc(e, b, !0, d));
        e !== b && Wc(a, c, b);
        return b
    };
    Iu = function(a, b, c, d) {
        var e = y(a, c, d);
        b = Mc(e, b, !1, lc(a.fa));
        b !== e && null != b && Wc(a, c, b, d);
        return b
    };
    Op = function(a, b, c) {
        return (a = Iu(a, b, c, !1)) ? a : Kc(b)
    };
    Bf = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        b = Iu(a, b, c, d);
        if (null == b) return b;
        if (!oc(a.fa)) {
            var e = Sc(b);
            e !== b && (b = e, Wc(a, c, b, d))
        }
        return b
    };
    Qe = function(a, b, c) {
        var d = lc(a.fa),
            e = !!(d & 2);
        b = gd(a, b, c, e ? 1 : 2, d);
        a = Xc(a, c, 3, void 0, e);
        if (!(e || lc(a) & 8)) {
            for (e = 0; e < b.length; e++) c = b[e], d = Sc(c), c !== d && (b[e] = d, a[e] = d.fa);
            jc(a, 8)
        }
        return b
    };
    _.Th = function(a, b, c) {
        yc(a);
        null == c && (c = void 0);
        return Wc(a, b, c)
    };
    _.Wh = function(a, b, c, d) {
        yc(a);
        null == d && (d = void 0);
        return ik(a, b, c, d)
    };
    _.Ad = function(a, b, c, d) {
        yc(a);
        var e = null == c ? Vc : nc([]);
        if (null != c) {
            for (var f = !!c.length, g = 0; g < c.length; g++) {
                var h = c[g];
                f = f && !oc(h.fa);
                e[g] = h.fa
            }
            f = (f ? 8 : 0) | 1;
            g = lc(e);
            (g & f) !== f && (Object.isFrozen(e) && (e = Array.prototype.slice.call(e)), mc(e, g | f));
            a.j || (a.j = {});
            a.j[b] = c
        } else a.j && (a.j[b] = void 0);
        return Wc(a, b, e, d)
    };
    Ju = function(a, b, c, d) {
        var e = lc(a.fa);
        xc(e);
        e = gd(a, c, b, 2, e);
        c = null != d ? d : new c;
        a = Xc(a, b, 2, void 0, !1);
        e.push(c);
        a.push(c.fa);
        oc(c.fa) && kc(a, 8);
        return c
    };
    _.Zf = function(a, b, c, d) {
        Ju(a, b, c, d);
        return a
    };
    Te = function(a, b) {
        return kd(y(a, b), 0)
    };
    go = function(a, b) {
        return Bc(y(a, b))
    };
    Ui = function(a, b) {
        a = J(a, b);
        return null == a ? void 0 : a
    };
    Ku = function(a, b) {
        return kd(oi(a, b), 0)
    };
    oi = function(a, b) {
        a: if (a = y(a, b), null != a) {
            switch (typeof a) {
                case "string":
                    a = +a;
                    break a;
                case "number":
                    break a
            }
            a = void 0
        }return a
    };
    _.af = function(a, b, c) {
        return kd(y(a, b), void 0 === c ? 0 : c)
    };
    Lu = function() {
        var a = vj().j;
        return y(a, 26)
    };
    Nu = function(a) {
        var b = Mu;
        var c = void 0 === c ? 0 : c;
        return _.af(a, Vf(a, b, 3), c)
    };
    _.hn = function(a, b, c, d) {
        return Yc(a, b, Ic, c, d)
    };
    ho = function(a, b) {
        return Xc(a, b, 0, !1, oc(a.fa))
    };
    _.Tf = function(a, b) {
        return kd(y(a, b), "")
    };
    _.Se = function(a, b, c) {
        return kd(y(a, b), void 0 === c ? 0 : c)
    };
    Ou = function(a, b, c) {
        a = _.hn(a, b, void 0, 2);
        if (0 > c || c >= a.length) throw Error();
        return a[c]
    };
    Pu = function(a, b, c) {
        yc(a);
        Xc(a, b, 2, !1, !1).push(c);
        return a
    };
    Qu = function(a, b) {
        return _.Tf(a, Vf(a, b, 2))
    };
    eo = function(a, b, c, d) {
        return Bf(a, b, Vf(a, d, c))
    };
    qg = function(a, b) {
        a = y(a, b);
        return null == a ? void 0 : a
    };
    Ru = function(a, b) {
        a = y(a, b);
        return null == a ? void 0 : a
    };
    _.dg = function(a, b) {
        return null != y(a, b)
    };
    var ld;
    _.P = function(a, b, c, d) {
        null == a && (a = ld);
        ld = void 0;
        var e = this.constructor.messageId;
        if (null == a) {
            a = e ? [e] : [];
            var f = 48;
            var g = !0;
            d && (f |= 128);
            mc(a, f)
        } else {
            if (!Array.isArray(a)) throw Error();
            if (e && e !== a[0]) throw Error();
            f = jc(a, 0) | 32;
            g = 0 !== (16 & f);
            if (d) {
                if (f |= 128, 0 < a.length) {
                    var h = a[a.length - 1];
                    if (tc(h) && "g" in h) {
                        delete h.g;
                        var k = !0,
                            l;
                        for (l in h) {
                            k = !1;
                            break
                        }
                        k && a.pop()
                    }
                }
            } else if (128 & f) throw Error();
            mc(a, f)
        }
        this.rb = e ? 0 : -1;
        this.j = void 0;
        this.fa = a;
        a: {
            f = this.fa.length;e = f - 1;
            if (f && (f = this.fa[e], tc(f))) {
                this.Qa = f;
                this.o = e - this.rb;
                break a
            }
            void 0 !== b && -1 < b ? (this.o = Math.max(b, e + 1 - this.rb), this.Qa = void 0) : this.o = Number.MAX_VALUE
        }
        if (!d && this.Qa && "g" in this.Qa) throw Error('Unexpected "g" flag in sparse object of message that is not a group type.');
        if (c) {
            b = g && !0;
            d = this.o;
            var m;
            for (g = 0; g < c.length; g++) e = c[g], e < d ? (e += this.rb, (f = a[e]) ? Dd(f, b) : a[e] = Vc) : (m || (m = Hu(this)), (f = m[e]) ? Dd(f, b) : m[e] = Vc)
        }
    };
    _.P.prototype.toJSON = function() {
        var a = this.fa,
            b;
        Cu ? b = a : b = qd(a, ud, vd, void 0, !1);
        return b
    };
    var Ne = function(a) {
        Cu = !0;
        try {
            return JSON.stringify(a.toJSON(), Ed)
        } finally {
            Cu = !1
        }
    };
    _.P.prototype.se = Jc;
    var Pd = (0, _.v.Symbol)(),
        Nd = (0, _.v.Symbol)(),
        Md = (0, _.v.Symbol)(),
        Su = Wd(function(a, b, c) {
            if (5 !== a.j()) return !1;
            _.z(b, c, a.l());
            return !0
        }, function(a, b, c) {
            b = Mq(b, c);
            if (null != b) {
                Zd(a.j, 8 * c + 5);
                a = a.j;
                var d = +b;
                0 === d ? 0 < 1 / d ? cc = ec = 0 : (ec = 0, cc = 2147483648) : isNaN(d) ? (ec = 0, cc = 2147483647) : (d = (c = 0 > d ? -2147483648 : 0) ? -d : d, 3.4028234663852886E38 < d ? (ec = 0, cc = (c | 2139095040) >>> 0) : 1.1754943508222875E-38 > d ? (d = Math.round(d / Math.pow(2, -149)), ec = 0, cc = (c | d) >>> 0) : (b = Math.floor(Math.log(d) / Math.LN2), d *= Math.pow(2, -b), d = Math.round(8388608 * d), 16777216 <= d && ++b, ec = 0, cc = (c | b + 127 << 23 | d & 8388607) >>> 0));
                c = cc;
                a.j.push(c >>> 0 & 255);
                a.j.push(c >>> 8 & 255);
                a.j.push(c >>> 16 & 255);
                a.j.push(c >>> 24 & 255)
            }
        }),
        Tu = Wd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.A());
            return !0
        }, ae),
        Uu = Wd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.J());
            return !0
        }, ae),
        Vu = Wd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.ha());
            return !0
        }, function(a, b, c) {
            b = y(b, c);
            null != b && ("string" === typeof b && uu(b), null != b && (Zd(a.j, 8 * c), "number" === typeof b ? (a = a.j, fc(b), $d(a, cc, ec)) : (c = uu(b), $d(a.j, c.o, c.j))))
        }),
        Wu = Wd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.I());
            return !0
        }, function(a, b, c) {
            b = go(b, c);
            null != b && null != b && (Zd(a.j, 8 * c), yu(a.j, b))
        }),
        Xu = Wd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.H());
            return !0
        }, function(a, b, c) {
            b = J(b, c);
            null != b && (Zd(a.j, 8 * c), a.j.j.push(b ? 1 : 0))
        }),
        Yu = Wd(function(a, b, c) {
            if (2 !== a.j()) return !1;
            _.z(b, c, a.m());
            return !0
        }, function(a, b, c) {
            b = y(b, c);
            null != b && Bu(a, c, Ob(b))
        }),
        Zu = Wd(function(a, b, c) {
            if (2 !== a.j()) return !1;
            Pu(b, c, a.m());
            return !0
        }, function(a, b, c) {
            b = _.hn(b, c);
            if (null != b)
                for (var d = 0; d < b.length; d++) {
                    var e = b[d];
                    null != e && Bu(a, c, Ob(e))
                }
        }),
        $u = Wd(function(a, b, c, d, e) {
            if (2 !== a.j()) return !1;
            a.o(Mp(b, d, c), e);
            return !0
        }, function(a, b, c, d, e) {
            b = Bf(b, d, c);
            null != b && (c = zu(a, c), e(b, a), Au(a, c))
        }),
        av = Wd(function(a, b, c, d, e) {
            if (2 !== a.j()) return !1;
            a.o(Ju(b, c, d), e);
            return !0
        }, function(a, b, c, d, e) {
            b = Qe(b, d, c);
            if (null != b)
                for (d = 0; d < b.length; d++) {
                    var f = zu(a, c);
                    e(b[d], a);
                    Au(a, f)
                }
        }),
        bv = Wd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.B());
            return !0
        }, function(a, b, c) {
            b = y(b, c);
            null != b && (b = parseInt(b, 10), Zd(a.j, 8 * c), yu(a.j, b))
        });
    var B = {
        sj: function() {
            return ""
        }
    };
    B.me = be;
    var cv = be(function(a) {
        return null !== a && void 0 !== a
    }, "exists");
    B.assert = function() {};
    B.ua = function(a) {
        return a
    };
    var ce = void 0;
    B.xj = de;
    B.zj = ee;
    B.nj = function() {};
    B.qj = function(a) {
        return a
    };
    B.yf = fe;
    B.Bj = function(a, b) {
        fe(a, b);
        return a
    };
    B.mj = function() {};
    B.K = function(a) {
        return a
    };
    B.yj = function(a, b) {
        de(a, cv, b)
    };
    B.Aj = function(a, b) {
        return ee(a, cv, b)
    };
    B.rj = function(a, b) {
        return a(b)
    };
    B.tj = function(a) {
        fe(!ce);
        ce = function() {
            var b = "function" === typeof a ? a() : a;
            ce = void 0;
            return b
        }
    };
    var hq = function(a) {
        _.P.call(this, a)
    };
    _.L(hq, _.P);
    var iq = function(a) {
        _.P.call(this, a)
    };
    _.L(iq, _.P);
    var dv = function(a) {
            this.j = a.o;
            this.o = a.m;
            this.H = a.H;
            this.uc = a.uc;
            this.F = a.F;
            this.Qb = a.Qb;
            this.kd = a.kd;
            this.Ed = a.Ed;
            this.jd = a.jd;
            this.m = a.j
        },
        ev = function(a, b, c) {
            this.o = a;
            this.m = b;
            this.H = c;
            this.F = window;
            this.Qb = "env";
            this.kd = "n";
            this.Ed = "0";
            this.jd = "1";
            this.j = !0
        };
    ev.prototype.build = function() {
        return new dv(this)
    };
    var rq = function(a, b) {
        var c = void 0 === _.Uf(b, 6) ? !0 : _.Uf(b, 6),
            d, e;
        a: switch (_.Se(b, 4, 0)) {
            case 1:
                var f = "pt";
                break a;
            case 2:
                f = "cr";
                break a;
            default:
                f = ""
        }
        f = new ev(ke(_.Se(b, 2, 0)), _.Tf(b, 3), f);
        b = null != (e = null == (d = Bf(b, hq, 5)) ? void 0 : _.Tf(d, 1)) ? e : "";
        f.uc = b;
        f.j = c;
        f.F = a;
        return f.build()
    };
    var fv = function(a) {
        _.P.call(this, a)
    };
    _.L(fv, _.P);
    fv.prototype.getId = function() {
        return _.Tf(this, 1)
    };
    var Io = function(a) {
            var b = new fv;
            return _.z(b, 1, a)
        },
        gv = [fv, 1, Yu];
    var hv = function(a) {
        _.P.call(this, a)
    };
    _.L(hv, _.P);
    hv.prototype.getWidth = function() {
        return Te(this, 1)
    };
    var No = function(a) {
        var b = new hv;
        return _.z(b, 1, a)
    };
    hv.prototype.getHeight = function() {
        return Te(this, 2)
    };
    var Mo = function(a, b) {
            return _.z(a, 2, b)
        },
        iv = [hv, 1, Wu, 2, Wu];
    var jv = function(a) {
        _.P.call(this, a)
    };
    _.L(jv, _.P);
    var kv = [jv, 1, Uu, 2, Xu];
    var Go = function(a) {
        _.P.call(this, a, -1, lv)
    };
    _.L(Go, _.P);
    var Jo = function(a, b) {
            _.ed(a, 4, b, _.Fc)
        },
        Ho = function(a, b) {
            _.Th(a, 6, b)
        },
        Lo = function(a, b) {
            _.Th(a, 7, b)
        },
        lv = [4],
        mv = [Go, 1, Yu, 2, Uu, 8, Uu, 3, Yu, 4, Zu, 5, bv, 6, $u, gv, 7, $u, iv, 9, $u, kv];
    var Nn = function(a) {
        _.P.call(this, a)
    };
    _.L(Nn, _.P);
    var Mn = function(a, b) {
            return _.z(a, 1, b)
        },
        Kn = function(a, b) {
            return _.z(a, 4, b)
        },
        Ln = function(a, b) {
            return _.z(a, 2, b)
        },
        nv = [Nn, 1, bv, 4, Xu, 2, Wu, 3, Yu];
    var xo = function(a) {
        _.P.call(this, a, -1, ov)
    };
    _.L(xo, _.P);
    var wo = function(a, b) {
            return _.z(a, 1, b)
        },
        Ao = function(a, b) {
            _.z(a, 2, b)
        },
        uo = function(a, b) {
            return _.Zf(a, 3, Go, b)
        },
        vo = function(a, b) {
            return _.z(a, 4, b)
        };
    xo.prototype.jf = function() {
        return _.Se(this, 7, 0)
    };
    var ov = [10, 3],
        pv = [xo, 1, Yu, 10, Zu, 2, Uu, 3, av, mv, 4, bv, 5, $u, nv, 6, Xu, 7, bv];
    var qv = function(a) {
        _.P.call(this, a)
    };
    _.L(qv, _.P);
    var rv = [qv, 1, bv, 2, Xu];
    var tv = function(a) {
        _.P.call(this, a, -1, sv)
    };
    _.L(tv, _.P);
    var to = function(a, b) {
            return Ju(a, 2, xo, b)
        },
        Eo = function(a, b) {
            _.Th(a, 5, b)
        },
        uv = function(a, b) {
            _.Th(a, 9, b)
        },
        sv = [2],
        vv = [tv, 1, bv, 6, Yu, 2, av, pv, 3, bv, 4, Yu, 5, $u, nv, 9, $u, rv, 7, Xu, 8, Wu];
    var xv = function(a) {
        _.P.call(this, a, -1, wv)
    };
    _.L(xv, _.P);
    var yv = function(a) {
            var b = new tv;
            b = _.z(b, 1, 1);
            return Ju(a, 1, tv, b)
        },
        wv = [1];
    xv.prototype.m = ie([xv, 1, av, vv]);
    var zv = function(a) {
        _.P.call(this, a)
    };
    _.L(zv, _.P);
    var Mu = [2, 3];
    var Bv = function(a) {
        _.P.call(this, a, -1, Av)
    };
    _.L(Bv, _.P);
    var Av = [1];
    var Dv = function(a) {
        _.P.call(this, a, -1, Cv)
    };
    _.L(Dv, _.P);
    var Cv = [1];
    var Ev = function(a) {
        _.P.call(this, a)
    };
    _.L(Ev, _.P);
    Ev.prototype.m = function() {
        return _.Tf(this, 1)
    };
    Ev.prototype.H = function() {
        return Qu(this, Wf)
    };
    var Wf = [2, 3];
    var Gv = function(a) {
        _.P.call(this, a, -1, Fv)
    };
    _.L(Gv, _.P);
    Gv.prototype.m = function() {
        return Qe(this, Ev, 2)
    };
    var cg = je(Gv),
        Fv = [2];
    var Iv = function(a) {
        _.P.call(this, a, -1, Hv)
    };
    _.L(Iv, _.P);
    var Hv = [4];
    var Jv = function(a) {
        _.P.call(this, a)
    };
    _.L(Jv, _.P);
    var Lv = function(a) {
        _.P.call(this, a, -1, Kv)
    };
    _.L(Lv, _.P);
    Lv.prototype.ed = function() {
        return Op(this, Jv, 2)
    };
    var Kv = [1];
    var Mv = function(a) {
        _.P.call(this, a)
    };
    _.L(Mv, _.P);
    var Ov = function(a) {
        _.P.call(this, a, -1, Nv)
    };
    _.L(Ov, _.P);
    var Nv = [1];
    var Pv = function(a) {
        _.P.call(this, a)
    };
    _.L(Pv, _.P);
    var Qv = [Pv, 1, bv, 2, Uu];
    var Rv = function(a) {
        _.P.call(this, a)
    };
    _.L(Rv, _.P);
    var Sv = [Rv, 1, Tu];
    var Tv = function(a) {
        _.P.call(this, a)
    };
    _.L(Tv, _.P);
    Tv.prototype.getEscapedQemQueryId = function() {
        return _.Tf(this, 1)
    };
    var Uv = [Tv, 1, Yu, 2, $u, Sv, 3, $u, Qv];
    var Vv = function(a) {
        _.P.call(this, a)
    };
    _.L(Vv, _.P);
    Vv.prototype.getAdUnitPath = function() {
        return _.Tf(this, 1)
    };
    var fo = function(a) {
        _.P.call(this, a)
    };
    _.L(fo, _.P);
    var bo = function(a) {
        _.P.call(this, a)
    };
    _.L(bo, _.P);
    var co = [1, 2];
    var Xv = function(a) {
        _.P.call(this, a, -1, Wv)
    };
    _.L(Xv, _.P);
    var Wv = [1, 2];
    var io = function(a) {
        _.P.call(this, a)
    };
    _.L(io, _.P);
    io.prototype.getAdUnitPath = function() {
        return _.Tf(this, 2)
    };
    io.prototype.getWidth = function() {
        return Te(this, 3)
    };
    io.prototype.getHeight = function() {
        return Te(this, 4)
    };
    var Zv = function(a) {
        _.P.call(this, a, -1, Yv)
    };
    _.L(Zv, _.P);
    var Yv = [3];
    var aw = function(a) {
        _.P.call(this, a, -1, $v)
    };
    _.L(aw, _.P);
    var $v = [5];
    var cw = function(a) {
            _.P.call(this, a, -1, bw)
        },
        bw;
    _.L(cw, _.P);
    _.dw = function(a) {
        return Qe(a, aw, 15)
    };
    bw = [2, 15];
    var ew = function(a) {
        _.P.call(this, a)
    };
    _.L(ew, _.P);
    ew.prototype.getAdUnitPath = function() {
        return _.Tf(this, 2)
    };
    var fw = function(a) {
        _.P.call(this, a)
    };
    _.L(fw, _.P);
    var gw = [5, 6, 7, 8, 9];
    var iw = function(a) {
        _.P.call(this, a, -1, hw)
    };
    _.L(iw, _.P);
    var hw = [4, 5, 6];
    var jw = function(a) {
        _.P.call(this, a)
    };
    _.L(jw, _.P);
    jw.prototype.oc = function() {
        return _.dg(this, 2)
    };
    var lw = function(a) {
        _.P.call(this, a, -1, kw)
    };
    _.L(lw, _.P);
    var kw = [13];
    var nw = function(a) {
        _.P.call(this, a, -1, mw)
    };
    _.L(nw, _.P);
    var mw = [13];
    var Cf = function(a) {
        _.P.call(this, a)
    };
    _.L(Cf, _.P);
    var Af = function(a, b) {
            return _.z(a, 1, b)
        },
        ow = [Cf, 1, bv];
    var Rf = function(a) {
        _.P.call(this, a)
    };
    _.L(Rf, _.P);
    var Yf = function(a) {
        var b = new Rf;
        return _.z(b, 1, a)
    };
    Rf.prototype.Ha = function(a) {
        return _.Th(this, 10, a)
    };
    var pw = je(Rf),
        qw = [Rf, 1, Yu, 2, Yu, 3, Uu, 7, Uu, 8, Su, 4, Wu, 5, Wu, 6, Wu, 9, Xu, 11, Xu, 10, $u, ow];
    var rw = function(a) {
        _.P.call(this, a)
    };
    _.L(rw, _.P);
    var sw = [rw, 4, bv, 5, Yu];
    var tw = function(a) {
        _.P.call(this, a)
    };
    _.L(tw, _.P);
    var uw = [tw, 1, Vu, 2, Vu, 3, Vu];
    var vw = function(a) {
        _.P.call(this, a)
    };
    _.L(vw, _.P);
    vw.prototype.Ha = function(a) {
        return _.Th(this, 7, a)
    };
    var ww = [vw, 5, Yu, 4, Yu, 2, $u, uw, 3, $u, uw, 6, Xu, 7, $u, sw, 8, Uu];
    var Nf = function(a) {
        _.P.call(this, a, -1, xw)
    };
    _.L(Nf, _.P);
    var xw = [1, 2];
    Nf.prototype.m = ie([Nf, 1, av, ww, 2, av, qw]);
    var yw = function(a) {
        _.P.call(this, a)
    };
    _.L(yw, _.P);
    yw.prototype.m = function() {
        return _.Tf(this, 1)
    };
    yw.prototype.H = function() {
        return Qu(this, zw)
    };
    var zw = [2, 3];
    var Bw = function(a) {
        _.P.call(this, a, -1, Aw)
    };
    _.L(Bw, _.P);
    Bw.prototype.m = function() {
        return Qe(this, yw, 1)
    };
    var Aw = [1];
    var Cw = function(a) {
        _.P.call(this, a)
    };
    _.L(Cw, _.P);
    Cw.prototype.oc = function() {
        return _.dg(this, 1)
    };
    Cw.prototype.getVersion = function() {
        return y(this, 5)
    };
    var Dw = function(a) {
        _.P.call(this, a)
    };
    _.L(Dw, _.P);
    var Ew = function(a) {
        _.P.call(this, a)
    };
    _.L(Ew, _.P);
    var Fw = function(a) {
        _.P.call(this, a)
    };
    _.L(Fw, _.P);
    var Hw = function(a) {
        _.P.call(this, a, -1, Gw)
    };
    _.L(Hw, _.P);
    Hw.prototype.getEscapedQemQueryId = function() {
        return _.Tf(this, 4)
    };
    var Gw = [2];
    var Iw = function(a) {
        _.P.call(this, a)
    };
    _.L(Iw, _.P);
    var Jw = function(a) {
        _.P.call(this, a)
    };
    _.L(Jw, _.P);
    var Kw = function(a) {
        _.P.call(this, a)
    };
    _.L(Kw, _.P);
    var Lw = function(a) {
        _.P.call(this, a)
    };
    _.L(Lw, _.P);
    Lw.prototype.getEscapedQemQueryId = function() {
        return _.Tf(this, 2)
    };
    var Nw = function(a) {
        _.P.call(this, a, -1, Mw)
    };
    _.L(Nw, _.P);
    Nw.prototype.getWidth = function() {
        return Te(this, 9)
    };
    Nw.prototype.getHeight = function() {
        return Te(this, 10)
    };
    var Mw = [3, 7, 11];
    var Pw = function(a) {
        _.P.call(this, a, -1, Ow)
    };
    _.L(Pw, _.P);
    Pw.prototype.getHeight = function() {
        return go(this, 6)
    };
    Pw.prototype.getWidth = function() {
        return go(this, 7)
    };
    Pw.prototype.getEscapedQemQueryId = function() {
        return y(this, 34)
    };
    var Ow = [14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 23, 27, 38, 53, 62, 63],
        Qw = [39, 48];
    var Rw = function(a) {
        _.P.call(this, a)
    };
    _.L(Rw, _.P);
    var fq = je(Rw);
    var Tw = function(a) {
        _.P.call(this, a, -1, Sw)
    };
    _.L(Tw, _.P);
    var Uw = je(Tw),
        Sw = [1, 2, 3];
    var Vw = window;
    var Or = function(a) {
        _.P.call(this, a, -1, Ww)
    };
    _.L(Or, _.P);
    var Ww = [15];
    var Nr = function(a) {
        _.P.call(this, a)
    };
    _.L(Nr, _.P);
    Nr.prototype.getCorrelator = function() {
        return _.af(this, 1)
    };
    Nr.prototype.setCorrelator = function(a) {
        return _.id(this, 1, a)
    };
    var Mr = function(a) {
        _.P.call(this, a)
    };
    _.L(Mr, _.P);
    var Xw = _.Xt || $t;
    var Zw, $w;
    _.Yw = mj(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = _.nb(ah);
        return !b.parentElement
    });
    Zw = /^[\w+/_-]+[=]{0,2}$/;
    $w = function(a, b) {
        b = (b || _.q).document;
        return b.querySelector ? (a = b.querySelector(a)) && (a = a.nonce || a.getAttribute("nonce")) && Zw.test(a) ? a : "" : ""
    };
    _.Zi = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    _.Zi.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    _.Zi.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    _.Zi.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    _.bj = function(a, b) {
        this.width = a;
        this.height = b
    };
    _.aa = _.bj.prototype;
    _.aa.aspectRatio = function() {
        return this.width / this.height
    };
    _.aa.isEmpty = function() {
        return !(this.width * this.height)
    };
    _.aa.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    _.aa.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    _.aa.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var ax, bx, cx, ex;
    ax = function(a) {
        return a = st(a)
    };
    bx = function() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ hf()).toString(36)
    };
    cx = 2147483648 * Math.random() | 0;
    _.dx = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    ex = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var hx, jx, ix, mx, ox, le, pe;
    hx = function(a) {
        return a ? new _.fx(_.gx(a)) : Rs || (Rs = new _.fx)
    };
    jx = function(a, b) {
        Ea(b, function(c, d) {
            c && "object" == typeof c && c.Pa && (c = c.Ea());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : ix.hasOwnProperty(d) ? a.setAttribute(ix[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
        })
    };
    ix = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.lx = function(a) {
        a = a.document;
        a = _.kx(a) ? a.documentElement : a.body;
        return new _.bj(a.clientWidth, a.clientHeight)
    };
    mx = function(a) {
        return a.scrollingElement ? a.scrollingElement : !$t && _.kx(a) ? a.documentElement : a.body || a.documentElement
    };
    _.nx = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    };
    ox = function(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!za(f) || _.pa(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (_.pa(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                _.bt(g ? ja(f) : f, d)
            }
        }
    };
    _.px = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    };
    _.kx = function(a) {
        return "CSS1Compat" == a.compatMode
    };
    _.qx = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    _.rx = function(a) {
        var b;
        if (Xw && (b = a.parentElement)) return b;
        b = a.parentNode;
        return _.pa(b) && 1 == b.nodeType ? b : null
    };
    le = function(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (1 == c) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (var h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    };
    _.gx = function(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    };
    pe = function(a) {
        try {
            return a.contentWindow || (a.contentDocument ? _.nx(a.contentDocument) : null)
        } catch (b) {}
        return null
    };
    _.fx = function(a) {
        this.j = a || _.q.document || document
    };
    _.aa = _.fx.prototype;
    _.aa.Ng = function(a) {
        return "string" === typeof a ? this.j.getElementById(a) : a
    };
    _.aa.li = _.fx.prototype.Ng;
    _.aa.getElementsByTagName = function(a, b) {
        return (b || this.j).getElementsByTagName(String(a))
    };
    _.aa.createElement = function(a) {
        return _.px(this.j, a)
    };
    _.aa.createTextNode = function(a) {
        return this.j.createTextNode(String(a))
    };
    _.aa.append = function(a, b) {
        ox(_.gx(a), a, arguments)
    };
    _.aa.Uf = _.qx;
    var sx = function() {
        return La && Ma ? !Ma.mobile && (Qa("iPad") || Qa("Android") || Qa("Silk")) : Qa("iPad") || Qa("Android") && !Qa("Mobile") || Qa("Silk")
    };
    var ux, Jl, vx, kl;
    _.tx = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    ux = function(a) {
        return a ? decodeURI(a) : a
    };
    Jl = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) Jl(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };
    vx = /#|$/;
    kl = function(a, b) {
        var c = a.search(vx);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };
    var ne, yg, wx, zg, il, nj, Kk, We, Wr, yx, zx, oj, Ax, Bx, Cx, Dx, Ex, Fx, Gx, Hx, Ix, Nj, Pj, Oj, Jx, Kx, Mx, Nx, Ox, Px, Qx, tf, Rx, lo, ym, pm, Pl, Sx;
    _.oe = function(a) {
        try {
            return !!a && null != a.location.href && Vt(a, "foo")
        } catch (b) {
            return !1
        }
    };
    ne = function(a, b, c, d) {
        b = void 0 === b ? !1 : b;
        d = void 0 === d ? _.q : d;
        c = (void 0 === c ? 0 : c) ? wx(d) : d;
        for (d = 0; c && 40 > d++ && (!b && !_.oe(c) || !a(c));) c = wx(c)
    };
    yg = function() {
        var a = window;
        ne(function(b) {
            a = b;
            return !1
        });
        return a
    };
    wx = function(a) {
        try {
            var b = a.parent;
            if (b && b != a) return b
        } catch (c) {}
        return null
    };
    zg = function(a) {
        return _.oe(a.top) ? a.top : null
    };
    il = function(a, b) {
        var c = _.ze("SCRIPT", a);
        lb(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    };
    nj = function(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    };
    _.Ve = function() {
        if (!_.v.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            _.v.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    _.Ml = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    _.xx = function(a) {
        var b = [];
        _.Ml(a, function(c) {
            b.push(c)
        });
        return b
    };
    Kk = function(a, b) {
        return Ga(a, function(c, d) {
            return Object.prototype.hasOwnProperty.call(a, d) && b(c, d)
        })
    };
    _.xi = function(a) {
        var b = a.length;
        if (0 == b) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    };
    _.Ue = mj(function() {
        return _.Kh(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], yx) || 1E-4 > Math.random()
    });
    We = function(a, b) {
        try {
            if (a) return a.setItem("google_experiment_mod", b), b
        } catch (c) {}
        return null
    };
    Wr = mj(function() {
        return yx("MSIE")
    });
    yx = function(a) {
        return Na(Ja(), a)
    };
    zx = /^([0-9.]+)px$/;
    oj = function(a) {
        return (a = zx.exec(a)) ? +a[1] : null
    };
    Ax = function() {
        var a = window;
        try {
            for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                case "https:":
                    return !0;
                case "file:":
                    return !0;
                case "http:":
                    return !1
            }
        } catch (c) {}
        return !0
    };
    Bx = function(a) {
        if (!a) return "";
        var b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            var c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && 1 < c[1].length ? c[1].substring(1) : "true"
        } catch (d) {}
        return ""
    };
    Cx = {
        pi: "allow-forms",
        ri: "allow-modals",
        si: "allow-orientation-lock",
        ti: "allow-pointer-lock",
        vi: "allow-popups",
        wi: "allow-popups-to-escape-sandbox",
        xi: "allow-presentation",
        yi: "allow-same-origin",
        zi: "allow-scripts",
        Ai: "allow-top-navigation",
        Bi: "allow-top-navigation-by-user-activation"
    };
    Dx = mj(function() {
        return _.xx(Cx)
    });
    Ex = function(a) {
        var b = Dx();
        return a.length ? _.lh(b, function(c) {
            return !(0 <= _.ha(a, c))
        }) : b
    };
    Fx = function() {
        var a = _.ze("IFRAME"),
            b = {};
        _.bt(Dx(), function(c) {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    };
    Gx = function(a) {
        a = a && a.toString && a.toString();
        return "string" === typeof a && Na(a, "[native code]")
    };
    Hx = function(a, b) {
        for (var c = 0; 50 > c; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (e) {
                d = !1
            }
            if (d) return a;
            if (!(a = wx(a))) break
        }
        return null
    };
    Ix = function(a) {
        if (!a || !a.frames) return null;
        if (a.frames.google_ads_top_frame) return a.frames.google_ads_top_frame.frameElement;
        try {
            var b = a.document,
                c = b.head,
                d, e = null != (d = b.body) ? d : null == c ? void 0 : c.parentElement;
            if (e) {
                var f = _.ze("IFRAME");
                f.name = "google_ads_top_frame";
                f.id = "google_ads_top_frame";
                f.style.display = "none";
                f.style.position = "fixed";
                f.style.left = "-999px";
                f.style.top = "-999px";
                f.style.width = "0px";
                f.style.height = "0px";
                e.appendChild(f);
                return f
            }
        } catch (g) {}
        return null
    };
    _.Vm = mj(function() {
        return (La && Ma ? Ma.mobile : !sx() && (Qa("iPod") || Qa("iPhone") || Qa("Android") || Qa("IEMobile"))) ? 2 : sx() ? 1 : 0
    });
    Nj = function(a, b) {
        var c;
        for (c = void 0 === c ? 100 : c; a && c--;) {
            if (a == b) return !0;
            a = a.parentElement
        }
        return !1
    };
    _.xj = function(a, b) {
        _.Ml(b, function(c, d) {
            a.style.setProperty(d, c, "important")
        })
    };
    Pj = function(a, b, c) {
        for (c = void 0 === c ? 100 : c; a && c-- && !1 !== b(a);) a = a.parentElement
    };
    Oj = function(a, b) {
        for (var c = 100; a && c--;) {
            var d = nj(a, window);
            if (d) {
                if (b(d)) return !0;
                a = a.parentElement
            }
        }
        return !1
    };
    Jx = function(a) {
        if (!a) return null;
        a = a.transform;
        if (!a) return null;
        a = a.replace(/^.*\(([0-9., -]+)\)$/, "$1").split(/, /);
        return 6 != a.length ? null : _.zd(a, parseFloat)
    };
    Kx = {};
    _.Lx = (Kx["http://googleads.g.doubleclick.net"] = !0, Kx["http://pagead2.googlesyndication.com"] = !0, Kx["https://googleads.g.doubleclick.net"] = !0, Kx["https://pagead2.googlesyndication.com"] = !0, Kx);
    Mx = function(a) {
        _.q.console && _.q.console.warn && _.q.console.warn(a)
    };
    Nx = [];
    Ox = function() {
        var a = Nx;
        Nx = [];
        a = _.x(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                b()
            } catch (c) {}
        }
    };
    Px = function(a) {
        return a.replace(/\\(n|r|\\)/g, function(b, c) {
            return "n" == c ? "\n" : "r" == c ? "\r" : "\\"
        })
    };
    Qx = function() {
        return Math.floor(Math.random() * Math.pow(2, 52))
    };
    tf = function(a) {
        if ("number" !== typeof a.goog_pvsid) try {
            Object.defineProperty(a, "goog_pvsid", {
                value: Qx(),
                configurable: !1
            })
        } catch (b) {}
        return Number(a.goog_pvsid) || -1
    };
    Rx = function(a, b) {
        qe(_.nx(_.gx(a)), a, b)
    };
    lo = function(a, b) {
        "complete" === a.readyState || "interactive" === a.readyState ? (Nx.push(b), 1 == Nx.length && (_.v.Promise ? _.v.Promise.resolve().then(Ox) : window.setImmediate ? setImmediate(Ox) : setTimeout(Ox, 0))) : a.addEventListener("DOMContentLoaded", b)
    };
    ym = function(a) {
        return "number" === typeof a && isFinite(a) && 0 == a % 1 && 0 < a
    };
    pm = function(a) {
        return 0 === a || ym(a)
    };
    Pl = function(a) {
        try {
            var b = JSON.stringify(a)
        } catch (c) {}
        return b || String(a)
    };
    _.ze = function(a, b) {
        b = void 0 === b ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    Sx = function(a) {
        for (var b = a; a && a != a.parent;) a = a.parent, _.oe(a) && (b = a);
        return b
    };
    _.Tx = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    _.Tx.prototype.getWidth = function() {
        return this.right - this.left
    };
    _.Tx.prototype.getHeight = function() {
        return this.bottom - this.top
    };
    _.Ux = function(a) {
        return new _.Tx(a.top, a.right, a.bottom, a.left)
    };
    _.Tx.prototype.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    _.Tx.prototype.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    _.Tx.prototype.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    var Vx = function(a, b, c, d) {
            this.left = a;
            this.top = b;
            this.width = c;
            this.height = d
        },
        Wx = function(a) {
            return new _.Tx(a.top, a.left + a.width, a.top + a.height, a.left)
        },
        Xx = function(a, b) {
            var c = Math.max(a.left, b.left),
                d = Math.min(a.left + a.width, b.left + b.width);
            if (c <= d) {
                var e = Math.max(a.top, b.top);
                a = Math.min(a.top + a.height, b.top + b.height);
                if (e <= a) return new Vx(c, e, d - c, a - e)
            }
            return null
        };
    Vx.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    Vx.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    Vx.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Yx = function(a) {
        return (a = void 0 === a ? re() : a) ? _.oe(a.master) ? a.master : null : null
    };
    var ay, Fh, aj, cy, dy, Yi;
    _.$x = function(a, b, c) {
        if ("string" === typeof b)(b = _.Zx(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = _.Zx(c, d);
                f && (c.style[f] = e)
            }
    };
    ay = {};
    _.Zx = function(a, b) {
        var c = ay[b];
        if (!c) {
            var d = _.dx(b);
            c = d;
            void 0 === a.style[d] && (d = ($t ? "Webkit" : Zt ? "Moz" : _.Xt ? "ms" : null) + ex(d), void 0 !== a.style[d] && (c = d));
            ay[b] = c
        }
        return c
    };
    _.by = function(a, b) {
        var c = _.gx(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    };
    Fh = function(a, b) {
        return _.by(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    };
    aj = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };
    cy = function(a) {
        if (_.Xt && !(8 <= Number(iu))) return a.offsetParent;
        var b = _.gx(a),
            c = Fh(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = Fh(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
        return null
    };
    dy = function(a) {
        var b = _.gx(a),
            c = new _.Zi(0, 0);
        var d = b ? _.gx(b) : document;
        d = !_.Xt || 9 <= Number(iu) || _.kx(hx(d).j) ? d.documentElement : d.body;
        if (a == d) return c;
        a = aj(a);
        d = hx(b).j;
        b = mx(d);
        d = d.parentWindow || d.defaultView;
        b = _.Xt && d.pageYOffset != b.scrollTop ? new _.Zi(b.scrollLeft, b.scrollTop) : new _.Zi(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    };
    Yi = function(a, b) {
        var c = new _.Zi(0, 0),
            d = _.nx(_.gx(a));
        if (!Vt(d, "parent")) return c;
        do {
            var e = d == b ? dy(a) : _.ey(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    _.ey = function(a) {
        a = aj(a);
        return new _.Zi(a.left, a.top)
    };
    _.fy = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    };
    _.Gh = function(a, b) {
        if ("none" != Fh(b, "display")) return a(b);
        var c = b.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = a(b);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    };
    _.Hh = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = $t && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = aj(a), new _.bj(a.right - a.left, a.bottom - a.top)) : new _.bj(b, c)
    };
    var Jj = function(a) {
        a = Yx(re(a)) || a;
        a = a.google_unique_id;
        return "number" === typeof a ? a : 0
    };
    var gy = function(a, b) {
        if (_.v.globalThis.fetch) _.v.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var hy = function(a) {
        _.P.call(this, a)
    };
    _.L(hy, _.P);
    var iy = function(a) {
        _.P.call(this, a)
    };
    _.L(iy, _.P);
    var $h = function(a) {
        _.P.call(this, a)
    };
    _.L($h, _.P);
    var Vh = function(a) {
        _.P.call(this, a)
    };
    _.L(Vh, _.P);
    var Sh = function(a) {
        _.P.call(this, a)
    };
    _.L(Sh, _.P);
    var jy = function(a) {
        _.P.call(this, a)
    };
    _.L(jy, _.P);
    var Rh = function(a) {
        _.P.call(this, a, -1, ky)
    };
    _.L(Rh, _.P);
    Rh.prototype.getTagSessionCorrelator = function() {
        return _.af(this, 2)
    };
    var ky = [4],
        Xh = [6, 7, 8, 9, 11];
    var ji = function(a) {
        _.P.call(this, a, -1, ly)
    };
    _.L(ji, _.P);
    var ly = [3];
    var hi = function(a) {
        _.P.call(this, a, -1, my)
    };
    _.L(hi, _.P);
    var my = [4, 5];
    var gi = function(a) {
        _.P.call(this, a, -1, ny)
    };
    _.L(gi, _.P);
    gi.prototype.getTagSessionCorrelator = function() {
        return _.af(this, 1)
    };
    var ny = [2];
    var fi = function(a) {
        _.P.call(this, a)
    };
    _.L(fi, _.P);
    var mi = [4];
    _.Q = function() {
        this.H = this.H;
        this.ha = this.ha
    };
    _.Q.prototype.H = !1;
    _.Q.prototype.Da = function() {
        this.H || (this.H = !0, this.o())
    };
    _.Vn = function(a, b) {
        _.qo(a, _.Qs(ye, b))
    };
    _.qo = function(a, b) {
        a.H ? b() : (a.ha || (a.ha = []), a.ha.push(b))
    };
    _.Q.prototype.o = function() {
        if (this.ha)
            for (; this.ha.length;) this.ha.shift()()
    };
    var oy = function(a, b, c, d, e) {
            this.l = a;
            this.B = b;
            this.I = c;
            this.m = d;
            this.H = e;
            this.j = [];
            this.o = null
        },
        py = function(a) {
            null !== a.o && (clearTimeout(a.o), a.o = null);
            if (a.j.length) {
                var b = ue(a.j);
                a.B(a.l + "?e=1", b);
                a.j = []
            }
        };
    oy.prototype.Ge = function() {
        var a = _.xb.apply(0, arguments),
            b = this;
        this.H && 65536 <= ue(this.j.concat(a)).length && py(this);
        this.j.push.apply(this.j, _.ve(a));
        this.j.length >= this.m && py(this);
        this.j.length && null === this.o && (this.o = setTimeout(function() {
            py(b)
        }, this.I))
    };
    _.Zr = function(a, b, c) {
        oy.call(this, "https://pagead2.googlesyndication.com/pagead/ping", gy, void 0 === a ? 1E3 : a, void 0 === b ? 100 : b, (void 0 === c ? !1 : c) && !!_.v.globalThis.fetch)
    };
    _.L(_.Zr, oy);
    var U = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? !1 : b
        },
        qy = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? 0 : b
        },
        ry = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? "" : b
        },
        sy = function(a) {
            var b = void 0 === b ? [] : b;
            this.j = a;
            this.defaultValue = b
        };
    var ty, uy, vy, Kj, wy, Ko, xy, yy, In, yo, zy, Ay, By, Cy, Dy, Ey, Jq, Fy, Gy, Hy, Iy, Jy, Ky, Ly, My, Ny, Oy, Py, Qy, cq, Ry, cr, Sy, Ty, Uy, eg, Vy, Wy, Zp, Xy, Yy, Qm, Zy, $y, az, bi, bz, cz, dz, ez, fz, gz, hz, iz, jz, Dr, kz, Il, Fl, lz, fj, mz, wg, Tp, pz, wn, qz, rz, sz, xm, tz, uz, Yr, vz, wz, fk, xz, yz, zz, Az, Bz, Cz, Dz, Ez, Fz, Gz, Hz, Iz, Jz, bg, ag, Kz, Lz, Qr, Rr, Jm, Sr, Pr, Mz, Nz, Xp, Oz, Sn, Pz, bA, cA;
    ty = new U(1122, !0);
    uy = new ry(3);
    vy = new sy(481);
    Kj = new qy(7, .1);
    wy = new U(212);
    Ko = new qy(474069761);
    xy = new qy(455645877);
    yy = new qy(462420536);
    In = new U(476475256);
    yo = new U(514499457, !0);
    zy = new qy(448338836, .01);
    Ay = new qy(427198696, 1);
    By = new qy(438663674);
    Cy = new U(513922122);
    Dy = new U(23);
    Ey = new U(369430);
    Jq = new U(510178293);
    Fy = new U(513037477);
    Gy = new U(477812799, !0);
    Hy = new U(514091619, !0);
    Iy = new qy(408380992, .01);
    Jy = new qy(377289019, 1E4);
    Ky = new qy(488);
    Ly = new qy(529, 20);
    My = new ry(10);
    Ny = new U(489217043);
    Oy = new U(495013820);
    Py = new qy(428094087);
    Qy = new U(492198798, !0);
    cq = new qy(447000223, .01);
    Ry = new U(360245597, !0);
    cr = new U(485209195);
    Sy = new U(499996722);
    Ty = new U(471855283);
    Uy = new U(514858268);
    eg = new U(465118388);
    Vy = new U(220);
    Wy = new U(200);
    Zp = new U(494337909);
    Xy = new U(503331120);
    Yy = new U(512833161);
    Qm = new qy(492, .01);
    Zy = new qy(363650251);
    $y = new qy(474872234);
    az = new U(83);
    bi = new U(85);
    bz = new U(437061931, !0);
    cz = new sy(466086960);
    dz = new U(45388169);
    ez = new qy(398776877, 6E4);
    fz = new qy(374201269, 6E4);
    gz = new qy(371364213, 6E4);
    hz = new qy(376149757, .0025);
    iz = new U(453275889);
    jz = new U(377936516, !0);
    Dr = new U(512710196, !0);
    kz = new qy(24);
    Il = new sy(1);
    Fl = new ry(2, "1-0-40");
    lz = new U(441529989);
    fj = new qy(504377075);
    mz = new U(514876375);
    wg = new U(516945042);
    Tp = new U(513069161);
    _.nz = new qy(506394061, 100);
    _.oz = new qy(506394060);
    pz = new U(510521772, !0);
    wn = new sy(489);
    qz = new U(392065905);
    rz = new qy(360245595, 500);
    sz = new U(510486687);
    xm = new U(45397804);
    tz = new U(45398607);
    uz = new U(424117738);
    Yr = new qy(397316938, 1E3);
    vz = new U(512195429);
    wz = new U(512150702, !0);
    fk = new U(507033477);
    xz = new U(399705355);
    yz = new U(515410344);
    zz = new qy(514795754);
    Az = new U(491464096);
    Bz = new U(502572081);
    Cz = new U(501);
    Dz = new U(439828594);
    Ez = new U(483962503);
    Fz = new qy(494575051);
    Gz = new sy(489560439);
    Hz = new sy(505762507);
    Iz = new U(453);
    Jz = new U(454);
    bg = new sy(471270390);
    ag = new U(478009624);
    Kz = new U(512522806);
    Lz = new U(506738118);
    Qr = new U(77);
    Rr = new U(78);
    Jm = new U(309);
    Sr = new U(80);
    Pr = new U(76);
    Mz = new U(84);
    Nz = new U(1958);
    Xp = new U(1973);
    Oz = new U(188);
    Sn = new U(1975, !0);
    Pz = new U(1974, !0);
    _.Qz = new qy(1972);
    _.Rz = new U(504787204);
    _.Sz = new U(1162);
    _.Tz = new qy(1157);
    _.Uz = new U(494741144);
    _.Vz = new qy(1119, 300);
    _.Wz = new qy(1103);
    _.Xz = new qy(1116, 300);
    _.Yz = new U(1121);
    _.Zz = new qy(469675170, 3E4);
    _.$z = new U(506619840);
    _.aA = new U(506852289);
    bA = new U(485990406);
    cA = new U(501411886, !0);
    var dA = function(a, b, c, d, e, f) {
            try {
                var g = a.j,
                    h = _.ze("SCRIPT", g);
                h.async = !0;
                lb(h, b);
                g.head.appendChild(h);
                h.addEventListener("load", function() {
                    e();
                    d && g.head.removeChild(h)
                });
                h.addEventListener("error", function() {
                    0 < c ? dA(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
                })
            } catch (k) {
                f()
            }
        },
        eA = function(a, b, c, d) {
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            dA(hx(a), b, 0, !1, c, d)
        };
    Fa({
        Ui: 0,
        Ti: 1,
        Qi: 2,
        Li: 3,
        Ri: 4,
        Mi: 5,
        Si: 6,
        Oi: 7,
        Pi: 8,
        Ki: 9,
        Ni: 10
    }).map(function(a) {
        return Number(a)
    });
    Fa({
        Wi: 0,
        Xi: 1,
        Vi: 2
    }).map(function(a) {
        return Number(a)
    });
    var fA = function(a) {
        var b = a.document,
            c = function() {
                if (!a.frames.googlefcPresent)
                    if (b.body) {
                        var d = _.ze("IFRAME", b);
                        d.style.display = "none";
                        d.style.width = "0px";
                        d.style.height = "0px";
                        d.style.border = "none";
                        d.style.zIndex = "-1000";
                        d.style.left = "-1000px";
                        d.style.top = "-1000px";
                        d.name = "googlefcPresent";
                        b.body.appendChild(d)
                    } else a.setTimeout(c, 5)
            };
        c()
    };
    var gA = function(a, b, c, d, e) {
            Be(a, b, void 0 === c ? null : c, void 0 === d ? !1 : d, void 0 === e ? !1 : e)
        },
        Ye = function(a, b) {
            var c = void 0 === c ? !1 : c;
            var d = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + b;
            _.Ml(a, function(e, f) {
                if (e || 0 === e) d += "&" + f + "=" + encodeURIComponent("" + e)
            });
            bp(d, c)
        },
        bp = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : gA(c, a, void 0, b, d)
        };
    var hA = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        iA = function(a, b) {
            b = void 0 === b ? {} : b;
            _.Q.call(this);
            this.m = a;
            this.j = null;
            this.l = {};
            this.A = 0;
            var c;
            this.J = null != (c = b.Ra) ? c : 500;
            var d;
            this.I = null != (d = b.eg) ? d : !1;
            this.B = null
        };
    _.L(iA, _.Q);
    iA.prototype.o = function() {
        this.l = {};
        this.B && (_.Ae(this.m, "message", this.B), delete this.B);
        delete this.l;
        delete this.m;
        delete this.j;
        _.Q.prototype.o.call(this)
    };
    var kA = function(a) {
        return "function" === typeof a.m.__tcfapi || null != jA(a)
    };
    iA.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.I
            },
            d = _.Zs(function() {
                return a(c)
            }),
            e = 0; - 1 !== this.J && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.J));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = hA(c), c.internalBlockOnErrors = b.I, h && 0 === c.internalErrorState || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            lA(this, "addEventListener", f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    iA.prototype.removeEventListener = function(a) {
        a && a.listenerId && lA(this, "removeEventListener", null, a.listenerId)
    };
    var mA = function(a, b) {
            var c = void 0 === c ? "755" : c;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var d = a.publisher.restrictions[b];
                    if (void 0 !== d) {
                        d = d[void 0 === c ? "755" : c];
                        break a
                    }
                }
                d = void 0
            }
            if (0 === d) return !1;
            a.purpose && a.vendor ? (d = a.vendor.consents, (c = !(!d || !d[void 0 === c ? "755" : c])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
            return b
        },
        lA = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.m.__tcfapi) a = a.m.__tcfapi, a(b, 2, c, d);
            else if (jA(a)) {
                nA(a);
                var e = ++a.A;
                a.l[e] = c;
                a.j && (c = {}, a.j.postMessage((c.__tcfapiCall = {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }, c), "*"))
            } else c({}, !1)
        },
        jA = function(a) {
            if (a.j) return a.j;
            a.j = Hx(a.m, "__tcfapiLocator");
            return a.j
        },
        nA = function(a) {
            a.B || (a.B = function(b) {
                try {
                    var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.l[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, _.zb(a.m, "message", a.B))
        },
        oA = function(a) {
            if (!1 === a.gdprApplies) return !0;
            void 0 === a.internalErrorState && (a.internalErrorState = hA(a));
            return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Ye({
                e: String(a.internalErrorState)
            }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
        },
        pA = function(a, b) {
            return !1 === a.gdprApplies ? !0 : b.every(function(c) {
                return mA(a, c)
            })
        };
    var qA = function(a, b, c) {
            this.j = a;
            this.m = b;
            this.o = void 0 === c ? function() {} : c
        },
        rA = function(a, b, c) {
            return new qA(a, b, c)
        };
    qA.prototype.start = function() {
        if (this.j === this.j.top) try {
            fA(this.j), sA(this)
        } catch (a) {}
    };
    var sA = function(a) {
        var b = Hb(Ws("https://fundingchoicesmessages.google.com/i/%{id}?ers=%{ers}"), {
            id: a.m,
            ers: 3
        });
        eA(a.j, b, function() {
            a.o(!0)
        }, function() {
            a.o(!1)
        })
    };
    var tA = _.v.Promise;
    var uA = function(a) {
        this.m = a
    };
    uA.prototype.o = function(a, b, c) {
        this.m.then(function(d) {
            d.o(a, b, c)
        })
    };
    uA.prototype.j = function(a, b) {
        return this.m.then(function(c) {
            return c.j(a, b)
        })
    };
    var vA = function(a) {
        this.data = a
    };
    var wA = function(a) {
        this.m = a
    };
    wA.prototype.o = function(a, b, c) {
        c = void 0 === c ? [] : c;
        var d = new MessageChannel;
        xA(d.port1, b);
        this.m.postMessage(a, [d.port2].concat(c))
    };
    wA.prototype.j = function(a, b) {
        var c = this;
        return new tA(function(d) {
            c.o(a, d, b)
        })
    };
    var yA = function(a, b) {
            xA(a, b);
            return new wA(a)
        },
        xA = function(a, b) {
            b && (a.onmessage = function(c) {
                b(new vA(c.data, yA(c.ports[0])))
            })
        };
    var dk = function(a) {
            var b = a.hd,
                c = void 0 === a.Sa ? "ZNWN1d" : a.Sa,
                d = void 0 === a.onMessage ? void 0 : a.onMessage,
                e = void 0 === a.xd ? void 0 : a.xd;
            return zA({
                destination: a.destination,
                jf: function() {
                    return b.contentWindow
                },
                qh: AA(a.origin),
                Sa: c,
                onMessage: d,
                xd: e
            })
        },
        zA = function(a) {
            var b = a.destination,
                c = a.jf,
                d = a.qh,
                e = void 0 === a.Je ? void 0 : a.Je,
                f = a.Sa,
                g = void 0 === a.onMessage ? void 0 : a.onMessage,
                h = void 0 === a.xd ? void 0 : a.xd,
                k = Object.create(null);
            d.forEach(function(l) {
                k[l] = !0
            });
            return new uA(new tA(function(l, m) {
                var n = function(p) {
                    p.source && p.source === c() && !0 === k[p.origin] && (p.data.n || p.data) === f && (b.removeEventListener("message", n, !1), e && p.data.t !== e ? m(Error('Token mismatch while establishing channel "' + f + '". Expected ' + e + ", but received " + p.data.t + ".")) : (l(yA(p.ports[0], g)), h && h(p)))
                };
                b.addEventListener("message", n, !1)
            }))
        },
        AA = function(a) {
            a = "string" === typeof a ? [a] : a;
            var b = Object.create(null);
            a.forEach(function(c) {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };
    var ii = (0, B.me)(function(a) {
        return "string" === typeof a
    }, "string");
    var BA = navigator,
        CA = function(a) {
            var b = 1,
                c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        DA = function(a, b) {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return CA(a.toLowerCase())
        },
        EA = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        FA = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        GA = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");
    var Wi = function(a) {
            return !!a && a.top == a
        },
        HA = function(a, b, c) {
            b = b || a.google_ad_width;
            c = c || a.google_ad_height;
            if (Wi(a)) return !1;
            var d = a.document,
                e = d.documentElement;
            if (b && c) {
                var f = 1,
                    g = 1;
                a.innerHeight ? (f = a.innerWidth, g = a.innerHeight) : e && e.clientHeight ? (f = e.clientWidth, g = e.clientHeight) : d.body && (f = d.body.clientWidth, g = d.body.clientHeight);
                if (g > 2 * c || f > 2 * b) return !1
            }
            return !0
        };
    var IA = function(a) {
        a = void 0 === a ? window : a;
        return a._gmptnl ? "afma-gpt-sdk-a" : a.webkit && a.webkit.messageHandlers && a.webkit.messageHandlers._gmptnl ? "afma-gpt-sdk-i" : null
    };
    var Dj = function() {
        this.j = [];
        this.o = -1
    };
    Dj.prototype.set = function(a, b) {
        b = void 0 === b ? !0 : b;
        0 <= a && 52 > a && _.u(Number, "isInteger").call(Number, a) && this.j[a] !== b && (this.j[a] = b, this.o = -1)
    };
    Dj.prototype.get = function(a) {
        return !!this.j[a]
    };
    var Fj = function(a) {
        -1 === a.o && (a.o = ct(a.j, function(b, c, d) {
            return c ? b + Math.pow(2, d) : b
        }));
        return a.o
    };
    var Re = function(a) {
        _.P.call(this, a)
    };
    _.L(Re, _.P);
    var Me = function(a) {
            var b = new Re;
            return _.fd(b, 1, a, 0)
        },
        Le = function(a, b) {
            return _.fd(a, 2, b, 0)
        };
    var Pe = function(a) {
        _.P.call(this, a, -1, JA)
    };
    _.L(Pe, _.P);
    var He = function(a, b) {
            _.Zf(a, 1, Re, b)
        },
        Ge = je(Pe),
        JA = [1];
    var KA = function(a, b, c, d) {
        _.Q.call(this);
        this.G = b;
        this.R = c;
        this.D = d;
        this.A = new _.v.Map;
        this.L = 0;
        this.l = new _.v.Map;
        this.J = new _.v.Map;
        this.I = new _.v.Map;
        this.B = void 0;
        this.m = a
    };
    _.L(KA, _.Q);
    KA.prototype.o = function() {
        delete this.j;
        this.A.clear();
        this.l.clear();
        this.J.clear();
        this.I.clear();
        this.B && (_.Ae((0, B.K)(this.m), "message", this.B), delete this.B);
        delete this.m;
        delete this.D;
        _.Q.prototype.o.call(this)
    };
    var LA = function(a) {
            if (a.j) return a.j;
            a.R && a.R((0, B.K)(a.m)) ? a.j = a.m : a.j = Hx((0, B.K)(a.m), a.G);
            var b;
            return null != (b = a.j) ? b : null
        },
        NA = function(a, b) {
            if (LA(a))
                if (a.j === a.m) {
                    var c = a.A.get("getDataWithCallback");
                    c && c((0, B.K)(a.j), b)
                } else if ((c = a.l.get("getDataWithCallback")) && c.qe) {
                MA(a);
                var d = ++a.L;
                a.J.set(d, c.tf);
                a.I.set(d, c.qf(b));
                a.j.postMessage(c.qe(b, d), "*")
            }
        },
        MA = function(a) {
            a.B || (a.B = function(b) {
                try {
                    var c = a.D ? a.D(b) : void 0;
                    if (c) {
                        var d = c.Ce,
                            e = a.J.get(d);
                        if (e) {
                            a.J.delete(d);
                            var f = a.I.get(c.Ce);
                            a.I.delete(d);
                            e(f, c.payload)
                        }
                    }
                } catch (g) {}
            }, _.zb((0, B.K)(a.m), "message", a.B))
        };
    var OA = function(a, b) {
            (0, B.K)(a.__uspapi)("getUSPData", 1, function(c, d) {
                b.hc({
                    consentData: null != c ? c : void 0,
                    cf: d ? void 0 : 2
                })
            })
        },
        PA = {
            qf: function(a) {
                return a.hc
            },
            qe: function(a, b) {
                a = {};
                return a.__uspapiCall = {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }, a
            },
            tf: function(a, b) {
                b = b.__uspapiReturn;
                var c;
                a({
                    consentData: null != (c = b.returnValue) ? c : void 0,
                    cf: b.success ? void 0 : 2
                })
            }
        },
        QA = function(a) {
            _.Q.call(this);
            this.caller = new KA(a, "__uspapiLocator", function(b) {
                return "function" === typeof b.__uspapi
            }, Ze);
            this.caller.A.set("getDataWithCallback", OA);
            this.caller.l.set("getDataWithCallback", PA)
        };
    _.L(QA, _.Q);
    QA.prototype.o = function() {
        this.caller.Da();
        _.Q.prototype.o.call(this)
    };
    QA.prototype.l = function() {
        return !!LA(this.caller)
    };
    QA.prototype.J = function(a) {
        var b = {};
        if (this.l()) {
            var c = _.Zs(function() {
                a(b)
            });
            NA(this.caller, {
                hc: function(d) {
                    d.cf || (b = (0, B.K)(d.consentData));
                    c()
                }
            });
            setTimeout(c, 500)
        } else a(b)
    };
    var SA = function(a) {
        _.P.call(this, a, -1, RA)
    };
    _.L(SA, _.P);
    var RA = [1, 2];
    var TA = function(a) {
        _.P.call(this, a)
    };
    _.L(TA, _.P);
    var $e = je(TA);
    var UA = function(a, b) {
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, function(c) {
                c = $e(c);
                b.hc({
                    consentData: c
                })
            })
        },
        VA = {
            qf: function(a) {
                return a.hc
            },
            qe: function(a, b) {
                var c = {};
                return c.__fciCall = {
                    callId: b,
                    command: a.command
                }, c
            },
            tf: function(a, b) {
                a({
                    consentData: b
                })
            }
        },
        Tn = function(a) {
            _.Q.call(this);
            this.j = null;
            this.B = !1;
            this.caller = new KA(a, "googlefcPresent", void 0, bf);
            this.caller.A.set("getDataWithCallback", UA);
            this.caller.l.set("getDataWithCallback", VA)
        };
    _.L(Tn, _.Q);
    Tn.prototype.o = function() {
        this.caller.Da();
        _.Q.prototype.o.call(this)
    };
    Tn.prototype.m = function() {
        this.B || (this.j = LA(this.caller), this.B = !0);
        return !!this.j
    };
    Tn.prototype.A = function() {
        var a = this;
        return new _.v.Promise(function(b) {
            a.m() && NA(a.caller, {
                command: "loaded",
                hc: function(c) {
                    b((0, B.K)(c.consentData))
                }
            })
        })
    };
    var ff = function(a) {
            this.j = a || {
                cookie: ""
            }
        },
        YA = function() {
            var a = WA;
            if (!_.q.navigator.cookieEnabled) return !1;
            if (!a.isEmpty()) return !0;
            a.set("TESTCOOKIESENABLED", "1", {
                re: 60
            });
            if ("1" !== a.get("TESTCOOKIESENABLED")) return !1;
            XA(a, "TESTCOOKIESENABLED");
            return !0
        };
    ff.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.Ej;
            d = c.Kh || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.re
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.j.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    ff.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.j.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = Hr(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    var XA = function(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            re: 0,
            path: c,
            domain: d
        })
    };
    ff.prototype.isEmpty = function() {
        return !this.j.cookie
    };
    ff.prototype.clear = function() {
        for (var a = (this.j.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = Hr(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) XA(this, b[a])
    };
    var WA = new ff("undefined" == typeof document ? null : document);
    _.ZA = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var cB, bB, eB, dB;
    _.$A = function() {
        this.m = "&";
        this.o = {};
        this.H = 0;
        this.j = []
    };
    _.aB = function(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    };
    cB = function(a, b, c, d, e) {
        var f = [];
        _.Ml(a, function(g, h) {
            (g = bB(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    };
    bB = function(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push(bB(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(cB(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    };
    eB = function(a, b) {
        var c = "https://pagead2.googlesyndication.com" + b,
            d = dB(a) - b.length;
        if (0 > d) return "";
        a.j.sort(function(m, n) {
            return m - n
        });
        b = null;
        for (var e = "", f = 0; f < a.j.length; f++)
            for (var g = a.j[f], h = a.o[g], k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                var l = cB(h[k], a.m, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.m;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    };
    dB = function(a) {
        var b = 1,
            c;
        for (c in a.o) b = c.length > b ? c.length : b;
        return 3997 - b - a.m.length - 1
    };
    _.fB = function() {
        this.j = _.E(Xy) ? .001 : _.Qh(23);
        this.o = Math.random()
    };
    _.Ih = function(a, b, c, d, e) {
        if (((void 0 === d ? 0 : d) ? a.o : Math.random()) < (e || a.j)) try {
            if (c instanceof _.$A) var f = c;
            else f = new _.$A, _.Ml(c, function(h, k) {
                var l = f,
                    m = l.H++;
                h = _.aB(k, h);
                l.j.push(m);
                l.o[m] = h
            });
            var g = eB(f, "/pagead/gen_204?id=" + b + "&");
            g && gA(_.q, g)
        } catch (h) {}
    };
    var gB = null,
        hB = function() {
            if (null === gB) {
                gB = "";
                try {
                    var a = "";
                    try {
                        a = _.q.top.location.hash
                    } catch (c) {
                        a = _.q.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        gB = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return gB
        };
    var iB = function(a, b, c, d, e) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = void 0 === d ? 0 : d;
        this.uniqueId = Math.random();
        this.slotId = e;
        this.taskId = void 0
    };
    var jB, kB, lB, mB, nB;
    jB = _.q.performance;
    kB = !!(jB && jB.mark && jB.measure && jB.clearMarks);
    lB = mj(function() {
        var a;
        if (a = kB) a = hB(), a = !!a.indexOf && 0 <= a.indexOf("1337");
        return a
    });
    mB = function(a, b) {
        this.o = [];
        var c = null;
        b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.o = b.google_js_reporting_queue, c = b.google_measure_js_timing);
        this.j = lB() || (null != c ? c : Math.random() < a)
    };
    _.di = function(a) {
        a && jB && lB() && (jB.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), jB.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    nB = function(a, b, c, d, e, f) {
        a.j && (b = new iB(b, c, d, void 0 === e ? 0 : e, f), !a.j || 2048 < a.o.length || a.o.push(b))
    };
    mB.prototype.start = function(a, b) {
        if (!this.j) return null;
        a = new iB(a, b, _.kf() || _.jf());
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        jB && lB() && jB.mark(b);
        return a
    };
    mB.prototype.end = function(a) {
        if (this.j && "number" === typeof a.value) {
            a.duration = (_.kf() || _.jf()) - a.value;
            var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            jB && lB() && jB.mark(b);
            !this.j || 2048 < this.o.length || this.o.push(a)
        }
    };
    var Dq = function(a, b, c) {
        var d = _.kf();
        d && nB(a, b, 9, d, 0, c)
    };
    _.oB = function(a, b) {
        try {
            -1 == a.indexOf(b) && (a = b + "\n" + a);
            for (var c; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (d) {
            return b
        }
    };
    var Bm = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, Bm.prototype)
    };
    _.L(Bm, Error);
    Bm.prototype.name = "PublisherInputError";
    var pB = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, pB.prototype)
    };
    _.L(pB, Error);
    pB.prototype.name = "ServerError";
    var qB = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, qB.prototype)
    };
    _.L(qB, Error);
    qB.prototype.name = "NetworkError";
    _.of = function(a) {
        var b = "xb";
        if (a.xb && a.hasOwnProperty(b)) return a.xb;
        b = new a;
        return a.xb = b
    };
    var pf = function() {};
    pf.prototype.o = function() {};
    pf.prototype.H = function() {};
    pf.prototype.m = function() {
        return []
    };
    pf.prototype.j = function() {
        return []
    };
    var Xg = function(a, b) {
        a.o = nf(1, b, function() {});
        a.m = function(c) {
            return nf(2, b, function() {
                return []
            })(c, 2)
        };
        a.j = function() {
            return nf(3, b, function() {
                return []
            })(2)
        };
        a.H = function(c) {
            nf(16, b, function() {})(c, 2)
        }
    };
    var rB = function() {};
    rB.j = function() {
        throw Error("Must be overridden");
    };
    var sf = function() {
        this.j = 0
    };
    _.L(sf, rB);
    sf.xb = void 0;
    sf.j = function() {
        return sf.xb ? sf.xb : sf.xb = new sf
    };
    var sB = function() {
            this.cache = {}
        },
        xf = function() {
            tB || (tB = new sB);
            return tB
        },
        $f = function(a) {
            var b = y(a, 3);
            if (!b) return 3;
            if (void 0 === y(a, 2)) return 4;
            a = Date.now();
            return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
        };
    sB.prototype.get = function(a, b) {
        if (this.cache[a]) return {
            pb: this.cache[a],
            success: !0
        };
        var c = "";
        try {
            c = b.getItem("_GESPSK-" + a)
        } catch (g) {
            var d;
            uf(6, a, null == (d = g) ? void 0 : d.message);
            return {
                pb: null,
                success: !1
            }
        }
        if (!c) return {
            pb: null,
            success: !0
        };
        try {
            var e = pw(c);
            this.cache[a] = e;
            return {
                pb: e,
                success: !0
            }
        } catch (g) {
            var f;
            uf(5, a, null == (f = g) ? void 0 : f.message);
            return {
                pb: null,
                success: !1
            }
        }
    };
    sB.prototype.set = function(a, b) {
        var c = (0, B.K)(y(a, 1)),
            d = "_GESPSK-" + c;
        _.z(a, 3, Date.now());
        try {
            b.setItem(d, Ne(a))
        } catch (f) {
            var e;
            uf(7, c, null == (e = f) ? void 0 : e.message);
            return !1
        }
        this.cache[c] = a;
        return !0
    };
    var tB = null;
    var yf = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    var Jf = function() {
        var a = {};
        this.j = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.m = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.H = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.B = function() {}
    };
    var uB = function(a) {
        _.Q.call(this);
        this.I = a;
        this.m = [];
        this.j = [];
        this.l = [];
        this.B = []
    };
    _.L(uB, _.Q);
    var wB = function(a, b, c) {
        a.j.push({
            qb: void 0 === c ? !1 : c,
            Ya: b
        });
        _.E(Ty) && vB(b, a.I)
    };
    uB.prototype.o = function() {
        this.m.length = 0;
        this.l.length = 0;
        if (_.E(Ty))
            for (var a = _.x(this.j), b = a.next(); !b.done; b = a.next()) b.value.Ya.Rd();
        this.j.length = 0;
        this.B.length = 0;
        _.Q.prototype.o.call(this)
    };
    _.oh = function() {
        var a = this;
        this.promise = new _.v.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };
    var xB = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, xB.prototype);
        this.name = "InputError"
    };
    _.L(xB, Error);
    var yB = function() {
            this.Va = !1
        },
        zB = function() {
            yB.apply(this, arguments);
            this.j = [];
            this.Cd = new _.oh
        };
    _.L(zB, yB);
    var N = function(a, b) {
            a.Va || (a.Va = !0, a.Ob = b, a.Cd.resolve(b), _.E(Ty) && AB(a))
        },
        BB = function(a, b) {
            a.Va = !0;
            a.ze = b;
            a.Cd.reject(b);
            _.E(Ty) && AB(a)
        },
        AB = function(a) {
            for (var b = _.x(a.j), c = b.next(); !c.done; c = b.next()) c = c.value, c(a.Ob);
            a.j.length = 0
        };
    zB.prototype.Rd = function() {
        this.j.length = 0
    };
    var vB = function(a, b) {
        _.E(Ty) && a.j.push(b)
    };
    _.ds.Object.defineProperties(zB.prototype, {
        promise: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Cd.promise
            }
        },
        Wa: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Va
            }
        },
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.ze
            }
        }
    });
    var Rq = function() {
        zB.apply(this, arguments)
    };
    _.L(Rq, zB);
    var CB = function(a, b) {
            N(a, b)
        },
        DB = function(a, b) {
            N(a, null != b ? b : null)
        },
        EB = function(a) {
            N(a, null)
        },
        FB = function(a, b) {
            b.then(function(c) {
                N(a, c)
            })
        };
    Rq.prototype.Ha = function(a) {
        this.Va || (this.Va = !0, this.Ob = null, this.ze = a, this.Cd.reject(a), _.E(Ty) && AB(this))
    };
    var GB = function(a) {
        this.Va = !1;
        this.lb = a
    };
    _.L(GB, yB);
    GB.prototype.Wa = function() {
        return this.lb.Va
    };
    GB.prototype.oc = function() {
        return null != this.lb.Ob
    };
    _.ds.Object.defineProperties(GB.prototype, {
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.lb.ze
            }
        }
    });
    var HB = function(a) {
        GB.call(this, a);
        this.lb = a
    };
    _.L(HB, GB);
    _.ds.Object.defineProperties(HB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return (0, B.K)(this.lb.Ob)
            }
        }
    });
    var IB = function(a) {
        GB.call(this, a);
        this.lb = a
    };
    _.L(IB, GB);
    _.ds.Object.defineProperties(IB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.lb.Ob) ? a : null
            }
        }
    });
    var JB = function() {
        GB.apply(this, arguments)
    };
    _.L(JB, GB);
    _.ds.Object.defineProperties(JB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.lb.Ob) ? a : null
            }
        }
    });
    var KB = function() {
        zB.apply(this, arguments)
    };
    _.L(KB, zB);
    KB.prototype.notify = function() {
        N(this, null)
    };
    var LB = function(a, b) {
            b.then(function() {
                a.notify()
            })
        },
        MB = function(a, b) {
            b = void 0 === b ? !1 : b;
            zB.call(this);
            var c = this;
            this.m = a;
            this.o = 0;
            if (_.E(Ty)) {
                a = {};
                for (var d = _.x(this.m), e = d.next(); !e.done; a = {
                        Zb: a.Zb
                    }, e = d.next()) a.Zb = e.value, vB(a.Zb, function(f) {
                    return function(g) {
                        c.o += 1;
                        f.Zb.error ? BB(c, f.Zb.error) : b || null !== g ? N(c, null != g ? g : null) : c.o === c.m.length && N(c, null)
                    }
                }(a))
            } else a = a.map(function(f) {
                return f.promise.then(function(g) {
                    if (b || null != g) return g;
                    throw g;
                }, function(g) {
                    BB(c, g);
                    return null
                })
            }), _.u(_.v.Promise, "any").call(_.v.Promise, a).then(function(f) {
                c.Va || N(c, f)
            }, function() {
                c.Va || N(c, null)
            })
        };
    _.L(MB, zB);
    var NB = function(a, b) {
        zB.call(this);
        this.Ra = a;
        this.defaultValue = b
    };
    _.L(NB, zB);
    var fg = function(a) {
        setTimeout(function() {
            var b;
            N(a, null != (b = a.defaultValue) ? b : null)
        }, a.Ra)
    };
    var PB = function(a, b) {
        _.Q.call(this);
        var c = this;
        this.id = a;
        this.Ra = b;
        this.na = this.ja = this.ia = this.J = !1;
        this.Ba = -1;
        this.B = new uB(function() {
            OB(c)
        });
        _.Vn(this, this.B)
    };
    _.L(PB, _.Q);
    PB.prototype.start = function() {
        var a = this,
            b, c;
        return _.Bb(function(d) {
            switch (d.j) {
                case 1:
                    if (a.J) return d.return();
                    a.J = !0;
                    d.m = 2;
                    b = a;
                    return Cb(d, gg(a.B.j, a.B.B, a.Ra), 4);
                case 4:
                    b.Ba = d.o;
                    if (a.H) {
                        d.j = 5;
                        break
                    }
                    for (var e = 0, f = _.x(a.B.l), g = f.next(); !g.done; g = f.next()) {
                        if (!g.value.oc()) throw Error("missing input: " + a.id + "/" + e);
                        ++e
                    }
                    return Cb(d, a.j(), 5);
                case 5:
                    Eb(d, 0);
                    break;
                case 2:
                    c = Fb(d);
                    if (a.H) return d.return();
                    c instanceof xB ? a.I(c) : c instanceof Error && (a.R(c), a.m(c));
                    d.j = 0
            }
        })
    };
    var OB = function(a) {
            if (!a.J && a.ia) try {
                var b = a.B.j,
                    c = a.Ra ? b.filter(function(k) {
                        return !k.qb
                    }) : b,
                    d = b.filter(function(k) {
                        return k.qb
                    }),
                    e, f = null == (e = _.u(b, "find").call(b, function(k) {
                        return void 0 !== k.Ya.error
                    })) ? void 0 : e.Ya.error;
                if (f) throw a.J = !0, f;
                if (!c.some(function(k) {
                        return !k.Ya.Wa
                    })) {
                    if (d.length)
                        if (_.E(eg)) {
                            for (var g = _.x(a.B.B), h = g.next(); !h.done; h = g.next()) fg(h.value);
                            if (d.some(function(k) {
                                    return !k.Ya.Wa
                                })) return
                        } else if (a.ja || (a.ja = !0, setTimeout(function() {
                            a.na = !0;
                            OB(a)
                        }, a.Ra)), d.some(function(k) {
                            return !k.Ya.Wa
                        }) && !a.na) return;
                    a.J = !0;
                    a.j()
                }
            } catch (k) {
                a.H || (k instanceof xB ? a.I(k) : k instanceof Error && (a.R(k), a.m(k)))
            }
        },
        V = function(a) {
            var b = new Rq;
            a.B.m.push(b);
            return b
        },
        QB = function(a) {
            var b = new KB;
            a.B.m.push(b);
            return b
        },
        W = function(a, b) {
            wB(a.B, b);
            b = new HB(b);
            a.B.l.push(b);
            return b
        },
        Y = function(a, b) {
            wB(a.B, b);
            return new IB(b)
        },
        RB = function(a, b) {
            if (_.E(eg)) {
                if (a.Ra) {
                    var c = new NB(a.Ra, void 0);
                    b = new MB([b, c], !0);
                    wB(a.B, b, !0);
                    a.B.B.push(c);
                    return new IB(b)
                }
                wB(a.B, b);
                return new IB(b)
            }
            wB(a.B, b, !0);
            return new IB(b)
        },
        SB = function(a, b) {
            wB(a.B, b)
        },
        TB = function(a, b) {
            if (_.E(eg))
                if (a.Ra) {
                    var c = new NB(a.Ra);
                    b = new MB([b, c], !0);
                    wB(a.B, b, !0);
                    a.B.B.push(c)
                } else SB(a, b);
            else wB(a.B, b, !0)
        },
        UB = function(a, b) {
            b = new MB(b);
            wB(a.B, b);
            b = new HB(b);
            a.B.l.push(b);
            return b
        };
    PB.prototype.I = function() {};
    PB.prototype.m = function(a) {
        if (this.B.m.length) {
            a = new xB(a.message);
            for (var b = _.x(this.B.m), c = b.next(); !c.done; c = b.next()) c = c.value, c.Wa || BB(c, a)
        }
    };
    var VB = function(a, b) {
        PB.call(this, a);
        this.id = a;
        this.D = b
    };
    _.L(VB, PB);
    VB.prototype.R = function(a) {
        this.D(this.id, a)
    };
    var lg = function(a, b, c, d) {
        VB.call(this, 1041, d);
        this.storage = b;
        this.l = c;
        this.G = W(this, a);
        this.l && (this.A = W(this, this.l))
    };
    _.L(lg, VB);
    lg.prototype.j = function() {
        var a = this.G.value,
            b, c, d = (0, B.K)(null != (c = null == (b = this.A) ? void 0 : b.value) ? c : this.storage);
        xf().set(a, d) && _.dg(a, 2) && uf(27, (0, B.K)(y(a, 1)))
    };
    var ng = function(a, b) {
        VB.call(this, 1048, b);
        this.l = V(this);
        this.A = V(this);
        this.G = W(this, a)
    };
    _.L(ng, VB);
    ng.prototype.j = function() {
        var a = this.G.value,
            b = function(c) {
                var d = {};
                uf(c, (0, B.K)(y(a, 1)), null, (d.tic = String(Math.round((Date.now() - (0, B.K)(y(a, 3))) / 6E4)), d))
            };
        switch ($f(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                N(this.A, a);
                break;
            case 2:
                b(26);
                N(this.l, a);
                break;
            case 3:
                uf(9, (0, B.K)(y(a, 1)));
                N(this.l, a);
                break;
            case 4:
                b(23), N(this.l, a)
        }
    };
    var WB = function(a, b, c) {
        VB.call(this, 1094, c);
        this.storage = a;
        this.l = QB(this);
        b && (this.A = W(this, b))
    };
    _.L(WB, VB);
    WB.prototype.j = function() {
        var a, b, c = (0, B.K)(null != (b = null == (a = this.A) ? void 0 : a.value) ? b : this.storage);
        if (void 0 !== c)
            for (a = _.x(_.u(Object, "keys").call(Object, c)), b = a.next(); !b.done; b = a.next())
                if (b = b.value, _.u(b, "startsWith").call(b, "_GESPSK")) try {
                    c.removeItem(b)
                } catch (d) {}
        tB = new sB;
        this.l.notify()
    };
    var Gg = function(a, b, c) {
        VB.call(this, 1049, c);
        this.storage = b;
        SB(this, a)
    };
    _.L(Gg, VB);
    Gg.prototype.j = function() {
        for (var a = _.x(If(this.storage)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = xf().get(b, this.storage).pb;
            if (c) {
                var d = $f(c);
                if (2 === d || 3 === d) {
                    d = void 0;
                    var e = xf();
                    c = (0, B.K)(y(c, 1));
                    try {
                        this.storage.removeItem("_GESPSK-" + c), delete e.cache[c]
                    } catch (f) {
                        uf(8, c, null == (d = f) ? void 0 : d.message)
                    }
                    uf(40, b)
                }
            }
        }
    };
    var rg = function(a, b, c, d, e) {
        VB.call(this, 658, e);
        this.collectorFunction = a;
        this.storage = c;
        this.l = V(this);
        this.G = V(this);
        this.A = Y(this, b);
        d && (this.L = W(this, d))
    };
    _.L(rg, VB);
    rg.prototype.j = function() {
        var a = this,
            b, c, d = (0, B.K)(null != (c = null == (b = this.L) ? void 0 : b.value) ? c : this.storage);
        if (this.A.value) {
            b = function(g) {
                N(a.l, {
                    id: (0, B.K)(y(g, 1)),
                    collectorGeneratedData: y(g, 2)
                })
            };
            c = this.A.value;
            var e = (0, B.K)(y(c, 1)),
                f = $f(c);
            hg(c);
            switch (f) {
                case 0:
                    b(c);
                    break;
                case 1:
                    b(c);
                    N(this.G, c);
                    break;
                case 3:
                case 2:
                case 4:
                    _.z(c, 2, null), zf(e, c, this.collectorFunction, d).then(b)
            }
        } else EB(this.l)
    };
    var kg = function(a, b, c, d) {
        VB.call(this, 1027, d);
        this.Uc = a;
        this.storage = b;
        this.l = V(this);
        this.A = V(this);
        c && (this.G = W(this, c))
    };
    _.L(kg, VB);
    kg.prototype.j = function() {
        var a, b, c = (0, B.K)(null != (b = null == (a = this.G) ? void 0 : a.value) ? b : this.storage);
        a = xf().get(this.Uc, c).pb;
        a || (a = Yf(this.Uc), a = _.z(a, 3, Date.now()), b = a.Ha(Af(new Cf, 100)), N(this.A, b));
        N(this.l, a)
    };
    var og = function(a, b, c) {
        VB.call(this, 1047, c);
        this.collectorFunction = a;
        this.A = V(this);
        this.l = V(this);
        this.G = V(this);
        this.L = W(this, b)
    };
    _.L(og, VB);
    og.prototype.j = function() {
        var a = this,
            b = this.L.value,
            c = (0, B.K)(y(b, 1));
        uf(18, c);
        try {
            var d = _.jf();
            this.collectorFunction().then(function(e) {
                uf(29, c, null, {
                    delta: String(_.jf() - d)
                });
                var f = _.z(b, 2, e);
                N(a.A, f);
                DB(a.G, e)
            }).catch(function(e) {
                uf(28, c, ig(e));
                e = b.Ha(Af(new Cf, 106));
                N(a.l, e)
            })
        } catch (e) {
            uf(1, c, ig(e)), CB(this.l, b.Ha(Af(new Cf, 107)))
        }
    };
    var sg = function(a, b, c, d, e) {
        VB.call(this, 662, e);
        this.A = a;
        this.storage = c;
        this.G = W(this, b);
        d && (this.l = W(this, d))
    };
    _.L(sg, VB);
    sg.prototype.j = function() {
        var a = this,
            b, c, d = (0, B.K)(null != (c = null == (b = this.l) ? void 0 : b.value) ? c : this.storage);
        Hf().then(function() {
            var e = (0, B.K)(a.G.value);
            zf((0, B.K)(y(e, 1)), e, a.A, d)
        })
    };
    var mg = function(a, b) {
        VB.call(this, 1028, b);
        this.l = V(this);
        this.A = W(this, a)
    };
    _.L(mg, VB);
    mg.prototype.j = function() {
        var a = this.A.value,
            b = (0, B.K)(y(a, 1));
        null != y(a, 3) || uf(35, b);
        N(this.l, a)
    };
    var pg = function(a, b, c, d, e) {
        VB.call(this, 1050, e);
        this.L = c;
        this.G = d;
        this.l = V(this);
        this.A = W(this, a);
        this.N = Y(this, b)
    };
    _.L(pg, VB);
    pg.prototype.j = function() {
        var a = this.A.value,
            b = (0, B.K)(y(a, 1)),
            c = this.N.value;
        if (null == c) uf(41, b), a.Ha(Af(new Cf, 111)), N(this.l, a);
        else if ("string" !== typeof c) uf(21, b), a = a.Ha(Af(new Cf, 113)), N(this.l, a);
        else {
            if (c.length > (/^(\d+)$/.test(b) ? this.G : this.L)) {
                var d = {};
                uf(12, b, null, (d.sl = String(c.length), d));
                b = a.Ha(Af(new Cf, 108));
                wf(b, 2)
            } else c.length || uf(20, b), wf(a, 10);
            N(this.l, a)
        }
    };
    var jg = function() {
        _.Q.apply(this, arguments);
        this.l = [];
        this.J = [];
        this.I = {};
        this.j = [];
        this.m = new _.oh
    };
    _.L(jg, _.Q);
    var G = function(a, b) {
            _.Vn(a, b);
            a.l.push(b)
        },
        tg = function(a, b) {
            b = _.x(b);
            for (var c = b.next(); !c.done; c = b.next()) G(a, c.value)
        },
        ug = function(a) {
            var b, c, d, e, f, g, h, k, l, m, n, p;
            _.Bb(function(r) {
                switch (r.j) {
                    case 1:
                        if (!a.j.length) {
                            r.j = 2;
                            break
                        }
                        return Cb(r, _.v.Promise.all(a.j.map(function(t) {
                            return t.m.promise
                        })), 2);
                    case 2:
                        b = _.x(a.l);
                        for (c = b.next(); !c.done; c = b.next()) d = c.value, _.E(Ty) ? (d.ia = !0, OB(d)) : d.start();
                        e = _.x(a.J);
                        for (f = e.next(); !f.done; f = e.next()) g = f.value, ug(g);
                        if (!a.B || !_.u(Object, "keys").call(Object, a.B).length) {
                            r.j = 4;
                            break
                        }
                        h = _.u(Object, "keys").call(Object, a.B);
                        return Cb(r, _.v.Promise.all(_.u(Object, "values").call(Object, a.B).map(function(t) {
                            return t.promise
                        })), 5);
                    case 5:
                        for (k = r.o, l = 0, m = _.x(h), n = m.next(); !n.done; n = m.next()) p = n.value, a.I[p] = k[l++];
                    case 4:
                        return a.m.resolve(a.I), r.return(a.m.promise)
                }
            })
        };
    jg.prototype.o = function() {
        _.Q.prototype.o.call(this);
        this.l.length = 0;
        this.J.length = 0;
        this.j.length = 0
    };
    var XB = function(a, b, c, d, e) {
        VB.call(this, 1059, e);
        this.L = b;
        this.storage = c;
        this.G = d;
        this.l = V(this);
        this.N = W(this, a);
        d && (this.A = Y(this, d))
    };
    _.L(XB, VB);
    XB.prototype.j = function() {
        var a, b, c = null != (b = this.storage) ? b : null == (a = this.A) ? void 0 : a.value;
        if (c) {
            var d = this.N.value;
            b = d.id;
            a = d.collectorFunction;
            var e;
            d = (0, B.K)(null != (e = d.networkCode) ? e : b);
            e = {};
            uf(42, d, null, (e.ea = String(Number(this.L)), e));
            FB(this.l, vg(d, a, c, this.G, this.D))
        }
    };
    var YB = function(a, b) {
        VB.call(this, 1057, b);
        this.l = a;
        this.A = V(this);
        this.G = V(this)
    };
    _.L(YB, VB);
    YB.prototype.j = function() {
        if (this.l)
            if ("object" !== typeof this.l) uf(46, "UNKNOWN_COLLECTOR_ID"), ZB(this, "UNKNOWN_COLLECTOR_ID", 112);
            else {
                var a = this.l.id,
                    b = this.l.networkCode;
                a && b && (delete this.l.id, uf(47, a + ";" + b));
                a = null != b ? b : a;
                "string" !== typeof a ? (b = {}, uf(37, "INVALID_COLLECTOR_ID", null, (b.ii = JSON.stringify(a), b)), ZB(this, "INVALID_COLLECTOR_ID", 102)) : "function" !== typeof this.l.collectorFunction ? (uf(14, a), ZB(this, a, 105)) : (_.C = Mf(Hz), _.u(_.C, "includes")).call(_.C, a) ? (uf(22, a), ZB(this, a, 104)) : N(this.G, this.l)
            }
        else uf(39, "UNKNOWN_COLLECTOR_ID"), ZB(this, "UNKNOWN_COLLECTOR_ID", 110)
    };
    var ZB = function(a, b, c) {
        b = Yf(b).Ha(Af(new Cf, c));
        N(a.A, b)
    };
    var Dg = function(a, b, c, d) {
        var e = void 0 === e ? document : e;
        this.storage = null;
        this.j = b;
        this.I = c;
        this.H = d;
        this.X = e;
        this.l = [];
        this.B = [];
        this.m = [];
        this.o = 0;
        a = _.x(a);
        for (b = a.next(); !b.done; b = a.next()) this.push(b.value)
    };
    _.aa = Dg.prototype;
    _.aa.push = function(a) {
        var b = this,
            c = this.H.Le ? function(f, g) {
                return void b.Lc(f, g)
            } : this.Lc;
        a = new YB(a, c);
        var d = new lg(a.A, this.storage, this.j, c);
        c = new XB(a.G, this.I, this.storage, this.j, c);
        var e = new jg;
        tg(e, [a, d, c]);
        ug(e);
        a = c.l.promise;
        this.l.push(a);
        d = _.x(this.B);
        for (c = d.next(); !c.done; c = d.next()) a.then(c.value)
    };
    _.aa.addOnSignalResolveCallback = function(a) {
        this.B.push(a);
        for (var b = _.x(this.l), c = b.next(); !c.done; c = b.next()) c.value.then(a)
    };
    _.aa.addErrorHandler = function(a) {
        this.m.push(a)
    };
    _.aa.clearAllCache = function() {
        var a = this,
            b = this.X.currentScript instanceof HTMLScriptElement ? this.X.currentScript.src : "";
        if (1 === this.o) {
            var c = {};
            uf(49, "", null, (c.url = b, c))
        } else if (c = String(_.xi(null != b ? b : "")), (_.C = Mf(Gz), _.u(_.C, "includes")).call(_.C, c)) c = {}, uf(48, "", null, (c.url = b, c));
        else {
            var d = new jg;
            c = new WB(this.storage, this.j, this.H.Le ? function(e, f) {
                return void a.Lc(e, f)
            } : this.Lc);
            G(d, c);
            ug(d);
            this.o = 1;
            setTimeout(function() {
                a.o = 0
            }, 1E3 * _.Kf(Fz));
            d = {};
            uf(43, "", null, (d.url = b, d));
            return c.l.promise
        }
    };
    _.aa.Lc = function(a, b) {
        for (var c = _.x(this.m), d = c.next(); !d.done; d = c.next()) d = d.value, d(a, b)
    };
    var Eg = function(a) {
        this.push = function(b) {
            a.push(b)
        };
        this.addOnSignalResolveCallback = function(b) {
            a.addOnSignalResolveCallback(b)
        };
        this.addErrorHandler = function(b) {
            a.addErrorHandler(b)
        };
        this.clearAllCache = function() {
            a.clearAllCache()
        }
    };
    var xg = {
        Le: !1
    };
    var Jg = function(a, b) {
        VB.call(this, 1036, b);
        this.l = V(this);
        this.A = W(this, a)
    };
    _.L(Jg, VB);
    Jg.prototype.j = function() {
        var a = this.A.value;
        0 !== $f(a) && N(this.l, a)
    };
    var Kg = function(a, b, c) {
        VB.call(this, 1035, c);
        this.A = b;
        this.l = V(this);
        this.G = W(this, a)
    };
    _.L(Kg, VB);
    Kg.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c = (0, B.K)(y(b, 1)),
            d = this.A.toString(),
            e = {};
        uf(30, c, null, (e.url = d, e));
        var f = document.createElement("script");
        f.setAttribute("esp-signal", "true");
        lb(f, this.A);
        var g = function() {
            var h = {};
            uf(31, (0, B.K)(c), null, (h.url = d, h));
            h = b.Ha(Af(new Cf, 109));
            N(a.l, h);
            _.Ae(f, "error", g)
        };
        document.head.appendChild(f);
        _.zb(f, "error", g)
    };
    var Fg = function(a) {
        VB.call(this, 1046, a);
        this.C = QB(this)
    };
    _.L(Fg, VB);
    Fg.prototype.j = function() {
        var a = this;
        Hf().then(function() {
            return a.C.notify()
        })
    };
    var Ig = new _.v.Set;
    var $B = 0,
        aC = se(_.Vs(Ws("https://pagead2.googlesyndication.com/pagead/expansion_embed.js")));
    var Vg = function() {
            this.j = function() {}
        },
        Zg = function(a, b) {
            a.j = nf(14, b, function() {})
        };
    var ui = function(a, b, c) {
            a && null !== b && b != b.top && (b = b.top);
            try {
                return (void 0 === c ? 0 : c) ? (new _.bj(b.innerWidth, b.innerHeight)).round() : _.lx(b || window).round()
            } catch (d) {
                return new _.bj(-12245933, -12245933)
            }
        },
        bC = function(a) {
            return "CSS1Compat" == a.compatMode ? a.documentElement : a.body
        },
        on = function(a, b) {
            b = void 0 === b ? _.q : b;
            a = a.scrollingElement || bC(a);
            return new _.Zi(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
        },
        pj = function(a) {
            try {
                return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
            } catch (b) {
                return !1
            }
        };
    var cC = function(a) {
        _.P.call(this, a)
    };
    _.L(cC, _.P);
    var cf = function(a) {
        return J(a, 5)
    };
    var fC, gC, hC;
    _.dC = function(a, b) {
        this.j = a;
        this.m = void 0 === b ? !1 : b;
        this.o = 0
    };
    fC = function(a, b) {
        if (0 === a.o) {
            if (_.eC(a, "__gads", b)) b = !0;
            else {
                var c = a.j;
                cf(b) && ef(c) && (new ff(c.document)).set("GoogleAdServingTest", "Good", void 0);
                if (c = "Good" === gf("GoogleAdServingTest", b, a.j)) {
                    var d = a.j;
                    cf(b) && ef(d) && XA(new ff(d.document), "GoogleAdServingTest")
                }
                b = c
            }
            a.o = b ? 2 : 1
        }
        return 2 === a.o
    };
    _.eC = function(a, b, c) {
        return c ? gf(b, c, a.j) : null
    };
    gC = function(a, b, c, d) {
        if (d) {
            var e = y(c, 2) - Date.now() / 1E3;
            e = {
                re: a.m ? Math.max(e, 0) : e,
                path: y(c, 3),
                domain: y(c, 4),
                Kh: !1
            };
            a = a.j;
            cf(d) && ef(a) && (new ff(a.document)).set(b, y(c, 1), e)
        }
    };
    hC = function(a, b, c) {
        if (c && gf(b, c, a.j)) {
            var d = a.j.location.hostname;
            if ("localhost" === d) d = ["localhost"];
            else if (d = d.split("."), 2 > d.length) d = [];
            else {
                for (var e = [], f = 0; f < d.length - 1; ++f) e.push(d.slice(f).join("."));
                d = e
            }
            d = _.x(d);
            for (e = d.next(); !e.done; e = d.next()) f = a.j, cf(c) && ef(f) && XA(new ff(f.document), b, "/", e.value)
        }
    };
    var iC = {},
        jC = (iC[3] = se(_.Vs(Ws("https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"))), iC);
    ({})[3] = se(_.Vs(Ws("https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js")));
    var kC = function(a) {
            this.j = a;
            this.o = bx()
        },
        lC = function(a) {
            var b = {};
            _.bt(a, function(c) {
                b[c.j] = c.o
            });
            return b
        };
    var mC = _.O(["https://adservice.google.com/adsid/integrator.", ""]),
        nC = _.O(["https://adservice.google.ad/adsid/integrator.", ""]),
        oC = _.O(["https://adservice.google.ae/adsid/integrator.", ""]),
        pC = _.O(["https://adservice.google.com.af/adsid/integrator.", ""]),
        qC = _.O(["https://adservice.google.com.ag/adsid/integrator.", ""]),
        rC = _.O(["https://adservice.google.com.ai/adsid/integrator.", ""]),
        sC = _.O(["https://adservice.google.al/adsid/integrator.", ""]),
        tC = _.O(["https://adservice.google.co.ao/adsid/integrator.", ""]),
        uC = _.O(["https://adservice.google.com.ar/adsid/integrator.", ""]),
        vC = _.O(["https://adservice.google.as/adsid/integrator.", ""]),
        wC = _.O(["https://adservice.google.at/adsid/integrator.", ""]),
        MC = _.O(["https://adservice.google.com.au/adsid/integrator.", ""]),
        OC = _.O(["https://adservice.google.az/adsid/integrator.", ""]),
        TC = _.O(["https://adservice.google.com.bd/adsid/integrator.", ""]),
        VC = _.O(["https://adservice.google.be/adsid/integrator.", ""]),
        WC = _.O(["https://adservice.google.bf/adsid/integrator.", ""]),
        XC = _.O(["https://adservice.google.bg/adsid/integrator.", ""]),
        YC = _.O(["https://adservice.google.com.bh/adsid/integrator.", ""]),
        ZC = _.O(["https://adservice.google.bi/adsid/integrator.", ""]),
        $C = _.O(["https://adservice.google.bj/adsid/integrator.", ""]),
        aD = _.O(["https://adservice.google.com.bn/adsid/integrator.", ""]),
        bD = _.O(["https://adservice.google.com.bo/adsid/integrator.", ""]),
        cD = _.O(["https://adservice.google.com.br/adsid/integrator.", ""]),
        dD = _.O(["https://adservice.google.bs/adsid/integrator.", ""]),
        eD = _.O(["https://adservice.google.bt/adsid/integrator.", ""]),
        fD = _.O(["https://adservice.google.co.bw/adsid/integrator.", ""]),
        gD = _.O(["https://adservice.google.com.bz/adsid/integrator.", ""]),
        hD = _.O(["https://adservice.google.ca/adsid/integrator.", ""]),
        iD = _.O(["https://adservice.google.cd/adsid/integrator.", ""]),
        jD = _.O(["https://adservice.google.cf/adsid/integrator.", ""]),
        kD = _.O(["https://adservice.google.cg/adsid/integrator.", ""]),
        lD = _.O(["https://adservice.google.ch/adsid/integrator.", ""]),
        mD = _.O(["https://adservice.google.ci/adsid/integrator.", ""]),
        nD = _.O(["https://adservice.google.co.ck/adsid/integrator.", ""]),
        oD = _.O(["https://adservice.google.cl/adsid/integrator.", ""]),
        pD = _.O(["https://adservice.google.cm/adsid/integrator.", ""]),
        qD = _.O(["https://adservice.google.com.co/adsid/integrator.", ""]),
        rD = _.O(["https://adservice.google.co.cr/adsid/integrator.", ""]),
        sD = _.O(["https://adservice.google.com.cu/adsid/integrator.", ""]),
        tD = _.O(["https://adservice.google.cv/adsid/integrator.", ""]),
        uD = _.O(["https://adservice.google.com.cy/adsid/integrator.", ""]),
        vD = _.O(["https://adservice.google.cz/adsid/integrator.", ""]),
        wD = _.O(["https://adservice.google.de/adsid/integrator.", ""]),
        xD = _.O(["https://adservice.google.dj/adsid/integrator.", ""]),
        yD = _.O(["https://adservice.google.dk/adsid/integrator.", ""]),
        zD = _.O(["https://adservice.google.dm/adsid/integrator.", ""]),
        AD = _.O(["https://adservice.google.dz/adsid/integrator.", ""]),
        BD = _.O(["https://adservice.google.com.ec/adsid/integrator.", ""]),
        CD = _.O(["https://adservice.google.ee/adsid/integrator.", ""]),
        DD = _.O(["https://adservice.google.com.eg/adsid/integrator.", ""]),
        ED = _.O(["https://adservice.google.es/adsid/integrator.", ""]),
        FD = _.O(["https://adservice.google.com.et/adsid/integrator.", ""]),
        GD = _.O(["https://adservice.google.fi/adsid/integrator.", ""]),
        HD = _.O(["https://adservice.google.com.fj/adsid/integrator.", ""]),
        ID = _.O(["https://adservice.google.fm/adsid/integrator.", ""]),
        JD = _.O(["https://adservice.google.fr/adsid/integrator.", ""]),
        KD = _.O(["https://adservice.google.ga/adsid/integrator.", ""]),
        LD = _.O(["https://adservice.google.ge/adsid/integrator.", ""]),
        MD = _.O(["https://adservice.google.gg/adsid/integrator.", ""]),
        ND = _.O(["https://adservice.google.com.gh/adsid/integrator.", ""]),
        OD = _.O(["https://adservice.google.com.gi/adsid/integrator.", ""]),
        PD = _.O(["https://adservice.google.gl/adsid/integrator.", ""]),
        QD = _.O(["https://adservice.google.gm/adsid/integrator.", ""]),
        RD = _.O(["https://adservice.google.gr/adsid/integrator.", ""]),
        SD = _.O(["https://adservice.google.com.gt/adsid/integrator.", ""]),
        TD = _.O(["https://adservice.google.gy/adsid/integrator.", ""]),
        UD = _.O(["https://adservice.google.com.hk/adsid/integrator.", ""]),
        VD = _.O(["https://adservice.google.hn/adsid/integrator.", ""]),
        WD = _.O(["https://adservice.google.hr/adsid/integrator.", ""]),
        XD = _.O(["https://adservice.google.ht/adsid/integrator.", ""]),
        YD = _.O(["https://adservice.google.hu/adsid/integrator.", ""]),
        ZD = _.O(["https://adservice.google.co.id/adsid/integrator.", ""]),
        $D = _.O(["https://adservice.google.ie/adsid/integrator.", ""]),
        aE = _.O(["https://adservice.google.co.il/adsid/integrator.", ""]),
        bE = _.O(["https://adservice.google.im/adsid/integrator.", ""]),
        cE = _.O(["https://adservice.google.co.in/adsid/integrator.", ""]),
        dE = _.O(["https://adservice.google.iq/adsid/integrator.", ""]),
        eE = _.O(["https://adservice.google.is/adsid/integrator.", ""]),
        fE = _.O(["https://adservice.google.it/adsid/integrator.", ""]),
        gE = _.O(["https://adservice.google.je/adsid/integrator.", ""]),
        hE = _.O(["https://adservice.google.com.jm/adsid/integrator.", ""]),
        iE = _.O(["https://adservice.google.jo/adsid/integrator.", ""]),
        jE = _.O(["https://adservice.google.co.jp/adsid/integrator.", ""]),
        kE = _.O(["https://adservice.google.co.ke/adsid/integrator.", ""]),
        lE = _.O(["https://adservice.google.com.kh/adsid/integrator.", ""]),
        mE = _.O(["https://adservice.google.ki/adsid/integrator.", ""]),
        nE = _.O(["https://adservice.google.kg/adsid/integrator.", ""]),
        oE = _.O(["https://adservice.google.co.kr/adsid/integrator.", ""]),
        pE = _.O(["https://adservice.google.com.kw/adsid/integrator.", ""]),
        qE = _.O(["https://adservice.google.kz/adsid/integrator.", ""]),
        rE = _.O(["https://adservice.google.la/adsid/integrator.", ""]),
        sE = _.O(["https://adservice.google.com.lb/adsid/integrator.", ""]),
        tE = _.O(["https://adservice.google.li/adsid/integrator.", ""]),
        uE = _.O(["https://adservice.google.lk/adsid/integrator.", ""]),
        vE = _.O(["https://adservice.google.co.ls/adsid/integrator.", ""]),
        wE = _.O(["https://adservice.google.lt/adsid/integrator.", ""]),
        xE = _.O(["https://adservice.google.lu/adsid/integrator.", ""]),
        yE = _.O(["https://adservice.google.lv/adsid/integrator.", ""]),
        zE = _.O(["https://adservice.google.com.ly/adsid/integrator.", ""]),
        AE = _.O(["https://adservice.google.md/adsid/integrator.", ""]),
        BE = _.O(["https://adservice.google.me/adsid/integrator.", ""]),
        CE = _.O(["https://adservice.google.mg/adsid/integrator.", ""]),
        DE = _.O(["https://adservice.google.mk/adsid/integrator.", ""]),
        EE = _.O(["https://adservice.google.ml/adsid/integrator.", ""]),
        FE = _.O(["https://adservice.google.com.mm/adsid/integrator.", ""]),
        GE = _.O(["https://adservice.google.mn/adsid/integrator.", ""]),
        HE = _.O(["https://adservice.google.ms/adsid/integrator.", ""]),
        IE = _.O(["https://adservice.google.com.mt/adsid/integrator.", ""]),
        JE = _.O(["https://adservice.google.mu/adsid/integrator.", ""]),
        KE = _.O(["https://adservice.google.mv/adsid/integrator.", ""]),
        LE = _.O(["https://adservice.google.mw/adsid/integrator.", ""]),
        ME = _.O(["https://adservice.google.com.mx/adsid/integrator.", ""]),
        NE = _.O(["https://adservice.google.com.my/adsid/integrator.", ""]),
        OE = _.O(["https://adservice.google.co.mz/adsid/integrator.", ""]),
        PE = _.O(["https://adservice.google.com.na/adsid/integrator.", ""]),
        QE = _.O(["https://adservice.google.com.ng/adsid/integrator.", ""]),
        RE = _.O(["https://adservice.google.com.ni/adsid/integrator.", ""]),
        SE = _.O(["https://adservice.google.ne/adsid/integrator.", ""]),
        TE = _.O(["https://adservice.google.nl/adsid/integrator.", ""]),
        UE = _.O(["https://adservice.google.no/adsid/integrator.", ""]),
        VE = _.O(["https://adservice.google.com.np/adsid/integrator.", ""]),
        WE = _.O(["https://adservice.google.nr/adsid/integrator.", ""]),
        XE = _.O(["https://adservice.google.nu/adsid/integrator.", ""]),
        YE = _.O(["https://adservice.google.co.nz/adsid/integrator.", ""]),
        ZE = _.O(["https://adservice.google.com.om/adsid/integrator.", ""]),
        $E = _.O(["https://adservice.google.com.pa/adsid/integrator.", ""]),
        aF = _.O(["https://adservice.google.com.pe/adsid/integrator.", ""]),
        bF = _.O(["https://adservice.google.com.pg/adsid/integrator.", ""]),
        cF = _.O(["https://adservice.google.com.ph/adsid/integrator.", ""]),
        dF = _.O(["https://adservice.google.com.pk/adsid/integrator.", ""]),
        eF = _.O(["https://adservice.google.pl/adsid/integrator.", ""]),
        fF = _.O(["https://adservice.google.pn/adsid/integrator.", ""]),
        gF = _.O(["https://adservice.google.com.pr/adsid/integrator.", ""]),
        hF = _.O(["https://adservice.google.ps/adsid/integrator.", ""]),
        iF = _.O(["https://adservice.google.pt/adsid/integrator.", ""]),
        jF = _.O(["https://adservice.google.com.py/adsid/integrator.", ""]),
        kF = _.O(["https://adservice.google.com.qa/adsid/integrator.", ""]),
        lF = _.O(["https://adservice.google.ro/adsid/integrator.", ""]),
        mF = _.O(["https://adservice.google.rw/adsid/integrator.", ""]),
        nF = _.O(["https://adservice.google.com.sa/adsid/integrator.", ""]),
        oF = _.O(["https://adservice.google.com.sb/adsid/integrator.", ""]),
        pF = _.O(["https://adservice.google.sc/adsid/integrator.", ""]),
        qF = _.O(["https://adservice.google.se/adsid/integrator.", ""]),
        rF = _.O(["https://adservice.google.com.sg/adsid/integrator.", ""]),
        sF = _.O(["https://adservice.google.sh/adsid/integrator.", ""]),
        tF = _.O(["https://adservice.google.si/adsid/integrator.", ""]),
        uF = _.O(["https://adservice.google.sk/adsid/integrator.", ""]),
        vF = _.O(["https://adservice.google.sn/adsid/integrator.", ""]),
        wF = _.O(["https://adservice.google.so/adsid/integrator.", ""]),
        xF = _.O(["https://adservice.google.sm/adsid/integrator.", ""]),
        yF = _.O(["https://adservice.google.sr/adsid/integrator.", ""]),
        zF = _.O(["https://adservice.google.st/adsid/integrator.", ""]),
        AF = _.O(["https://adservice.google.com.sv/adsid/integrator.", ""]),
        BF = _.O(["https://adservice.google.td/adsid/integrator.", ""]),
        CF = _.O(["https://adservice.google.tg/adsid/integrator.", ""]),
        DF = _.O(["https://adservice.google.co.th/adsid/integrator.", ""]),
        EF = _.O(["https://adservice.google.com.tj/adsid/integrator.", ""]),
        FF = _.O(["https://adservice.google.tl/adsid/integrator.", ""]),
        GF = _.O(["https://adservice.google.tm/adsid/integrator.", ""]),
        HF = _.O(["https://adservice.google.tn/adsid/integrator.", ""]),
        IF = _.O(["https://adservice.google.to/adsid/integrator.", ""]),
        JF = _.O(["https://adservice.google.com.tr/adsid/integrator.", ""]),
        KF = _.O(["https://adservice.google.tt/adsid/integrator.", ""]),
        LF = _.O(["https://adservice.google.com.tw/adsid/integrator.", ""]),
        MF = _.O(["https://adservice.google.co.tz/adsid/integrator.", ""]),
        NF = _.O(["https://adservice.google.com.ua/adsid/integrator.", ""]),
        OF = _.O(["https://adservice.google.co.ug/adsid/integrator.", ""]),
        PF = _.O(["https://adservice.google.co.uk/adsid/integrator.", ""]),
        QF = _.O(["https://adservice.google.com.uy/adsid/integrator.", ""]),
        RF = _.O(["https://adservice.google.co.uz/adsid/integrator.", ""]),
        SF = _.O(["https://adservice.google.com.vc/adsid/integrator.", ""]),
        TF = _.O(["https://adservice.google.co.ve/adsid/integrator.", ""]),
        UF = _.O(["https://adservice.google.vg/adsid/integrator.", ""]),
        VF = _.O(["https://adservice.google.co.vi/adsid/integrator.", ""]),
        WF = _.O(["https://adservice.google.com.vn/adsid/integrator.", ""]),
        XF = _.O(["https://adservice.google.vu/adsid/integrator.", ""]),
        YF = _.O(["https://adservice.google.ws/adsid/integrator.", ""]),
        ZF = _.O(["https://adservice.google.rs/adsid/integrator.", ""]),
        $F = _.O(["https://adservice.google.co.za/adsid/integrator.", ""]),
        aG = _.O(["https://adservice.google.co.zm/adsid/integrator.", ""]),
        bG = _.O(["https://adservice.google.co.zw/adsid/integrator.", ""]),
        cG = _.O(["https://adservice.google.cat/adsid/integrator.", ""]),
        dG = new _.v.Map([
            [".google.com", function(a) {
                return _.A(mC, a)
            }],
            [".google.ad", function(a) {
                return _.A(nC, a)
            }],
            [".google.ae", function(a) {
                return _.A(oC, a)
            }],
            [".google.com.af", function(a) {
                return _.A(pC, a)
            }],
            [".google.com.ag", function(a) {
                return _.A(qC, a)
            }],
            [".google.com.ai", function(a) {
                return _.A(rC, a)
            }],
            [".google.al", function(a) {
                return _.A(sC, a)
            }],
            [".google.co.ao", function(a) {
                return _.A(tC, a)
            }],
            [".google.com.ar", function(a) {
                return _.A(uC, a)
            }],
            [".google.as", function(a) {
                return _.A(vC, a)
            }],
            [".google.at", function(a) {
                return _.A(wC, a)
            }],
            [".google.com.au", function(a) {
                return _.A(MC, a)
            }],
            [".google.az", function(a) {
                return _.A(OC, a)
            }],
            [".google.com.bd", function(a) {
                return _.A(TC, a)
            }],
            [".google.be", function(a) {
                return _.A(VC, a)
            }],
            [".google.bf", function(a) {
                return _.A(WC, a)
            }],
            [".google.bg", function(a) {
                return _.A(XC, a)
            }],
            [".google.com.bh", function(a) {
                return _.A(YC, a)
            }],
            [".google.bi", function(a) {
                return _.A(ZC, a)
            }],
            [".google.bj", function(a) {
                return _.A($C, a)
            }],
            [".google.com.bn", function(a) {
                return _.A(aD, a)
            }],
            [".google.com.bo", function(a) {
                return _.A(bD, a)
            }],
            [".google.com.br", function(a) {
                return _.A(cD, a)
            }],
            [".google.bs", function(a) {
                return _.A(dD, a)
            }],
            [".google.bt", function(a) {
                return _.A(eD, a)
            }],
            [".google.co.bw", function(a) {
                return _.A(fD, a)
            }],
            [".google.com.bz", function(a) {
                return _.A(gD, a)
            }],
            [".google.ca", function(a) {
                return _.A(hD, a)
            }],
            [".google.cd", function(a) {
                return _.A(iD, a)
            }],
            [".google.cf", function(a) {
                return _.A(jD, a)
            }],
            [".google.cg", function(a) {
                return _.A(kD, a)
            }],
            [".google.ch", function(a) {
                return _.A(lD, a)
            }],
            [".google.ci", function(a) {
                return _.A(mD, a)
            }],
            [".google.co.ck", function(a) {
                return _.A(nD, a)
            }],
            [".google.cl", function(a) {
                return _.A(oD, a)
            }],
            [".google.cm", function(a) {
                return _.A(pD, a)
            }],
            [".google.com.co", function(a) {
                return _.A(qD, a)
            }],
            [".google.co.cr", function(a) {
                return _.A(rD, a)
            }],
            [".google.com.cu", function(a) {
                return _.A(sD, a)
            }],
            [".google.cv", function(a) {
                return _.A(tD, a)
            }],
            [".google.com.cy", function(a) {
                return _.A(uD, a)
            }],
            [".google.cz", function(a) {
                return _.A(vD, a)
            }],
            [".google.de", function(a) {
                return _.A(wD, a)
            }],
            [".google.dj", function(a) {
                return _.A(xD, a)
            }],
            [".google.dk", function(a) {
                return _.A(yD, a)
            }],
            [".google.dm", function(a) {
                return _.A(zD, a)
            }],
            [".google.dz", function(a) {
                return _.A(AD, a)
            }],
            [".google.com.ec", function(a) {
                return _.A(BD, a)
            }],
            [".google.ee", function(a) {
                return _.A(CD, a)
            }],
            [".google.com.eg", function(a) {
                return _.A(DD, a)
            }],
            [".google.es", function(a) {
                return _.A(ED, a)
            }],
            [".google.com.et", function(a) {
                return _.A(FD, a)
            }],
            [".google.fi", function(a) {
                return _.A(GD, a)
            }],
            [".google.com.fj", function(a) {
                return _.A(HD, a)
            }],
            [".google.fm", function(a) {
                return _.A(ID, a)
            }],
            [".google.fr", function(a) {
                return _.A(JD, a)
            }],
            [".google.ga", function(a) {
                return _.A(KD, a)
            }],
            [".google.ge", function(a) {
                return _.A(LD, a)
            }],
            [".google.gg", function(a) {
                return _.A(MD, a)
            }],
            [".google.com.gh", function(a) {
                return _.A(ND, a)
            }],
            [".google.com.gi", function(a) {
                return _.A(OD, a)
            }],
            [".google.gl", function(a) {
                return _.A(PD, a)
            }],
            [".google.gm", function(a) {
                return _.A(QD, a)
            }],
            [".google.gr", function(a) {
                return _.A(RD, a)
            }],
            [".google.com.gt", function(a) {
                return _.A(SD, a)
            }],
            [".google.gy", function(a) {
                return _.A(TD, a)
            }],
            [".google.com.hk", function(a) {
                return _.A(UD, a)
            }],
            [".google.hn", function(a) {
                return _.A(VD, a)
            }],
            [".google.hr", function(a) {
                return _.A(WD, a)
            }],
            [".google.ht", function(a) {
                return _.A(XD, a)
            }],
            [".google.hu", function(a) {
                return _.A(YD, a)
            }],
            [".google.co.id", function(a) {
                return _.A(ZD, a)
            }],
            [".google.ie", function(a) {
                return _.A($D, a)
            }],
            [".google.co.il", function(a) {
                return _.A(aE, a)
            }],
            [".google.im", function(a) {
                return _.A(bE, a)
            }],
            [".google.co.in", function(a) {
                return _.A(cE, a)
            }],
            [".google.iq", function(a) {
                return _.A(dE, a)
            }],
            [".google.is", function(a) {
                return _.A(eE, a)
            }],
            [".google.it", function(a) {
                return _.A(fE, a)
            }],
            [".google.je", function(a) {
                return _.A(gE, a)
            }],
            [".google.com.jm", function(a) {
                return _.A(hE, a)
            }],
            [".google.jo", function(a) {
                return _.A(iE, a)
            }],
            [".google.co.jp", function(a) {
                return _.A(jE, a)
            }],
            [".google.co.ke", function(a) {
                return _.A(kE, a)
            }],
            [".google.com.kh", function(a) {
                return _.A(lE, a)
            }],
            [".google.ki", function(a) {
                return _.A(mE, a)
            }],
            [".google.kg", function(a) {
                return _.A(nE, a)
            }],
            [".google.co.kr", function(a) {
                return _.A(oE, a)
            }],
            [".google.com.kw", function(a) {
                return _.A(pE, a)
            }],
            [".google.kz", function(a) {
                return _.A(qE, a)
            }],
            [".google.la", function(a) {
                return _.A(rE, a)
            }],
            [".google.com.lb", function(a) {
                return _.A(sE, a)
            }],
            [".google.li", function(a) {
                return _.A(tE, a)
            }],
            [".google.lk", function(a) {
                return _.A(uE, a)
            }],
            [".google.co.ls", function(a) {
                return _.A(vE, a)
            }],
            [".google.lt", function(a) {
                return _.A(wE, a)
            }],
            [".google.lu", function(a) {
                return _.A(xE, a)
            }],
            [".google.lv", function(a) {
                return _.A(yE, a)
            }],
            [".google.com.ly", function(a) {
                return _.A(zE, a)
            }],
            [".google.md", function(a) {
                return _.A(AE, a)
            }],
            [".google.me", function(a) {
                return _.A(BE, a)
            }],
            [".google.mg", function(a) {
                return _.A(CE, a)
            }],
            [".google.mk", function(a) {
                return _.A(DE, a)
            }],
            [".google.ml", function(a) {
                return _.A(EE, a)
            }],
            [".google.com.mm", function(a) {
                return _.A(FE, a)
            }],
            [".google.mn", function(a) {
                return _.A(GE, a)
            }],
            [".google.ms", function(a) {
                return _.A(HE, a)
            }],
            [".google.com.mt", function(a) {
                return _.A(IE, a)
            }],
            [".google.mu", function(a) {
                return _.A(JE, a)
            }],
            [".google.mv", function(a) {
                return _.A(KE, a)
            }],
            [".google.mw", function(a) {
                return _.A(LE, a)
            }],
            [".google.com.mx", function(a) {
                return _.A(ME, a)
            }],
            [".google.com.my", function(a) {
                return _.A(NE, a)
            }],
            [".google.co.mz", function(a) {
                return _.A(OE, a)
            }],
            [".google.com.na", function(a) {
                return _.A(PE, a)
            }],
            [".google.com.ng", function(a) {
                return _.A(QE, a)
            }],
            [".google.com.ni", function(a) {
                return _.A(RE, a)
            }],
            [".google.ne", function(a) {
                return _.A(SE, a)
            }],
            [".google.nl", function(a) {
                return _.A(TE, a)
            }],
            [".google.no", function(a) {
                return _.A(UE, a)
            }],
            [".google.com.np", function(a) {
                return _.A(VE, a)
            }],
            [".google.nr", function(a) {
                return _.A(WE, a)
            }],
            [".google.nu", function(a) {
                return _.A(XE, a)
            }],
            [".google.co.nz", function(a) {
                return _.A(YE, a)
            }],
            [".google.com.om", function(a) {
                return _.A(ZE, a)
            }],
            [".google.com.pa", function(a) {
                return _.A($E, a)
            }],
            [".google.com.pe", function(a) {
                return _.A(aF, a)
            }],
            [".google.com.pg", function(a) {
                return _.A(bF, a)
            }],
            [".google.com.ph", function(a) {
                return _.A(cF, a)
            }],
            [".google.com.pk", function(a) {
                return _.A(dF, a)
            }],
            [".google.pl", function(a) {
                return _.A(eF, a)
            }],
            [".google.pn", function(a) {
                return _.A(fF, a)
            }],
            [".google.com.pr", function(a) {
                return _.A(gF, a)
            }],
            [".google.ps", function(a) {
                return _.A(hF, a)
            }],
            [".google.pt", function(a) {
                return _.A(iF, a)
            }],
            [".google.com.py", function(a) {
                return _.A(jF, a)
            }],
            [".google.com.qa", function(a) {
                return _.A(kF, a)
            }],
            [".google.ro", function(a) {
                return _.A(lF, a)
            }],
            [".google.rw", function(a) {
                return _.A(mF, a)
            }],
            [".google.com.sa", function(a) {
                return _.A(nF, a)
            }],
            [".google.com.sb", function(a) {
                return _.A(oF, a)
            }],
            [".google.sc", function(a) {
                return _.A(pF, a)
            }],
            [".google.se", function(a) {
                return _.A(qF, a)
            }],
            [".google.com.sg", function(a) {
                return _.A(rF, a)
            }],
            [".google.sh", function(a) {
                return _.A(sF, a)
            }],
            [".google.si", function(a) {
                return _.A(tF, a)
            }],
            [".google.sk", function(a) {
                return _.A(uF, a)
            }],
            [".google.sn", function(a) {
                return _.A(vF, a)
            }],
            [".google.so", function(a) {
                return _.A(wF, a)
            }],
            [".google.sm", function(a) {
                return _.A(xF, a)
            }],
            [".google.sr", function(a) {
                return _.A(yF, a)
            }],
            [".google.st", function(a) {
                return _.A(zF, a)
            }],
            [".google.com.sv", function(a) {
                return _.A(AF, a)
            }],
            [".google.td", function(a) {
                return _.A(BF, a)
            }],
            [".google.tg", function(a) {
                return _.A(CF, a)
            }],
            [".google.co.th", function(a) {
                return _.A(DF, a)
            }],
            [".google.com.tj", function(a) {
                return _.A(EF, a)
            }],
            [".google.tl", function(a) {
                return _.A(FF, a)
            }],
            [".google.tm", function(a) {
                return _.A(GF, a)
            }],
            [".google.tn", function(a) {
                return _.A(HF, a)
            }],
            [".google.to", function(a) {
                return _.A(IF, a)
            }],
            [".google.com.tr", function(a) {
                return _.A(JF, a)
            }],
            [".google.tt", function(a) {
                return _.A(KF, a)
            }],
            [".google.com.tw", function(a) {
                return _.A(LF, a)
            }],
            [".google.co.tz", function(a) {
                return _.A(MF, a)
            }],
            [".google.com.ua", function(a) {
                return _.A(NF, a)
            }],
            [".google.co.ug", function(a) {
                return _.A(OF, a)
            }],
            [".google.co.uk", function(a) {
                return _.A(PF, a)
            }],
            [".google.com.uy", function(a) {
                return _.A(QF, a)
            }],
            [".google.co.uz", function(a) {
                return _.A(RF, a)
            }],
            [".google.com.vc", function(a) {
                return _.A(SF, a)
            }],
            [".google.co.ve", function(a) {
                return _.A(TF, a)
            }],
            [".google.vg", function(a) {
                return _.A(UF, a)
            }],
            [".google.co.vi", function(a) {
                return _.A(VF, a)
            }],
            [".google.com.vn", function(a) {
                return _.A(WF, a)
            }],
            [".google.vu", function(a) {
                return _.A(XF, a)
            }],
            [".google.ws", function(a) {
                return _.A(YF, a)
            }],
            [".google.rs", function(a) {
                return _.A(ZF, a)
            }],
            [".google.co.za", function(a) {
                return _.A($F, a)
            }],
            [".google.co.zm", function(a) {
                return _.A(aG, a)
            }],
            [".google.co.zw", function(a) {
                return _.A(bG, a)
            }],
            [".google.cat", function(a) {
                return _.A(cG, a)
            }]
        ].map(function(a) {
            var b = _.x(a);
            a = b.next().value;
            b = b.next().value;
            var c = {};
            return [a, (c.json = b("json"), c.js = b("js"), c["sync.js"] = b("sync.js"), c)]
        }));
    var eG = function(a, b, c) {
        var d = _.ze("LINK", a);
        try {
            if (d.rel = "preload", Na("preload", "stylesheet")) {
                d.href = _.kb(b).toString();
                var e = $w('style[nonce],link[rel="stylesheet"][nonce]', d.ownerDocument && d.ownerDocument.defaultView);
                e && d.setAttribute("nonce", e)
            } else {
                if (b instanceof _.ft) var f = _.kb(b).toString();
                else {
                    if (b instanceof _.cb) var g = _.db(b);
                    else {
                        if (b instanceof _.cb) var h = b;
                        else {
                            b = "object" == typeof b && b.Pa ? b.Ea() : String(b);
                            b: if (e = b, yt) {
                                try {
                                    var k = new URL(e)
                                } catch (p) {
                                    var l = "https:";
                                    break b
                                }
                                l = k.protocol
                            } else c: {
                                var m = document.createElement("a");
                                try {
                                    m.href = e
                                } catch (p) {
                                    l = void 0;
                                    break c
                                }
                                var n = m.protocol;l = ":" === n || "" === n ? "https:" : n
                            }
                            "javascript:" === l && (b = "about:invalid#zClosurez");
                            h = ub(b)
                        }
                        g = _.db(h)
                    }
                    f = g
                }
                d.href = f
            }
        } catch (p) {
            return
        }
        d.as = "script";
        c && d.setAttribute("nonce", c);
        if (a = a.getElementsByTagName("head")[0]) try {
            a.appendChild(d)
        } catch (p) {}
    };
    var bh = /^data-(?!xml)[_a-z][_a-z.0-9-]*$/;
    var gh = _.q,
        fG = function(a) {
            var b = new _.v.Map([
                ["domain", _.q.location.hostname]
            ]);
            hh[3] >= hf() && b.set("adsid", hh[1]);
            return te(dG.get(a).js, b)
        },
        hh, gG, fh = function() {
            gh = _.q;
            hh = gh.googleToken = gh.googleToken || {};
            var a = hf();
            hh[1] && hh[3] > a && 0 < hh[2] || (hh[1] = "", hh[2] = -1, hh[3] = -1, hh[4] = "", hh[6] = "");
            gG = gh.googleIMState = gh.googleIMState || {};
            dG.has(gG[1]) || (gG[1] = ".google.com");
            Array.isArray(gG[5]) || (gG[5] = []);
            "boolean" !== typeof gG[6] && (gG[6] = !1);
            Array.isArray(gG[7]) || (gG[7] = []);
            "number" !== typeof gG[8] && (gG[8] = 0)
        },
        hG = function(a) {
            fh();
            dG.has(a) && (gG[1] = a)
        },
        ih = {
            je: function() {
                return 0 < gG[8]
            },
            Ch: function() {
                gG[8]++
            },
            Dh: function() {
                0 < gG[8] && gG[8]--
            },
            Eh: function() {
                gG[8] = 0
            },
            Gj: function() {
                return !1
            },
            dd: function() {
                return gG[5]
            },
            Re: function(a) {
                try {
                    a()
                } catch (b) {
                    _.q.setTimeout(function() {
                        throw b;
                    }, 0)
                }
            },
            Bf: function() {
                if (!ih.je()) {
                    var a = _.q.document,
                        b = function(e) {
                            e = fG(e);
                            a: {
                                try {
                                    var f = $w("script[nonce]");
                                    break a
                                } catch (g) {}
                                f = void 0
                            }
                            eG(a, e.toString(), f);
                            f = _.ze("SCRIPT", a);
                            f.type = "text/javascript";
                            f.onerror = function() {
                                return _.q.processGoogleToken({}, 2)
                            };
                            lb(f, e);
                            try {
                                (a.head || a.body || a.documentElement).appendChild(f), ih.Ch()
                            } catch (g) {}
                        },
                        c = gG[1];
                    b(c);
                    ".google.com" != c && b(".google.com");
                    b = {};
                    var d = (b.newToken = "FBT", b);
                    _.q.setTimeout(function() {
                        return _.q.processGoogleToken(d, 1)
                    }, 1E3)
                }
            }
        },
        iG = function(a) {
            _.q.processGoogleToken = _.q.processGoogleToken || function(b, c) {
                var d = b;
                d = void 0 === d ? {} : d;
                c = void 0 === c ? 0 : c;
                b = d.newToken || "";
                var e = "NT" == b,
                    f = parseInt(d.freshLifetimeSecs || "", 10),
                    g = parseInt(d.validLifetimeSecs || "", 10),
                    h = d["1p_jar"] || "";
                d = d.pucrd || "";
                fh();
                1 == c ? ih.Eh() : ih.Dh();
                var k = gh.googleToken = gh.googleToken || {},
                    l = 0 == c && b && "string" === typeof b && !e && "number" === typeof f && 0 < f && "number" === typeof g && 0 < g && "string" === typeof h;
                e = e && !ih.je() && (!(hh[3] >= hf()) || "NT" == hh[1]);
                var m = !(hh[3] >= hf()) && 0 != c;
                if (l || e || m) e = hf(), f = e + 1E3 * f, g = e + 1E3 * g, 1E-5 > Math.random() && gA(_.q, "https://pagead2.googlesyndication.com/pagead/gen_204?id=imerr&err=" + c), k[5] = c, k[1] = b, k[2] = f, k[3] = g, k[4] = h, k[6] = d, fh();
                if (l || !ih.je()) {
                    c = ih.dd();
                    for (b = 0; b < c.length; b++) ih.Re(c[b]);
                    c.length = 0
                }
            };
            jh(a)
        };
    var Kq = function(a, b) {
            b = void 0 === b ? {} : b;
            this.root = b.root ? b.root : null;
            this.I = b.rootMargin ? kh(b.rootMargin) : [{
                value: 0,
                type: "px"
            }, {
                value: 0,
                type: "px"
            }, {
                value: 0,
                type: "px"
            }, {
                value: 0,
                type: "px"
            }];
            this.rootMargin = _.zd(this.I, function(c) {
                return "" + c.value + c.type
            }).join(" ");
            this.A = mh(b.threshold);
            this.J = a;
            this.j = [];
            this.H = [];
            this.B = !1;
            this.o = null;
            this.m = $s(this.l, 100, this)
        },
        jG = function(a) {
            if (a.root) var b = nh(a.root);
            else {
                var c = _.lx(window);
                b = {
                    top: 0,
                    right: c.width,
                    bottom: c.height,
                    left: 0,
                    width: c.width,
                    height: c.height
                }
            }
            a = _.zd(a.I, function(d, e) {
                return "px" == d.type ? d.value : d.value * (e % 2 ? b.width : b.height) / 100
            });
            return {
                top: b.top - a[0],
                right: b.right + a[1],
                bottom: b.bottom + a[2],
                left: b.left - a[3],
                width: b.width + a[1] + a[3],
                height: b.height + a[0] + a[2]
            }
        },
        kG = function(a, b, c) {
            if (!b || b.isIntersecting != c.isIntersecting) return !0;
            var d = b.intersectionRatio,
                e = c.intersectionRatio;
            return d == e ? !1 : _.Kh(a.A, function(f) {
                return f < d != f < e
            })
        };
    Kq.prototype.l = function() {
        var a = this,
            b = jG(this);
        _.bt(this.j, function(c) {
            var d = c.target,
                e = nh(d),
                f = e.width * e.height;
            var g = Math.max(b.top, e.top);
            var h = Math.min(b.right, e.right),
                k = Math.min(b.bottom, e.bottom),
                l = Math.max(b.left, e.left),
                m = h - l,
                n = k - g;
            g = 0 <= m && 0 <= n ? {
                top: g,
                right: h,
                bottom: k,
                left: l,
                width: m,
                height: n
            } : null;
            h = !!g;
            k = g ? g.width * g.height : 0;
            l = window.performance;
            d = {
                boundingClientRect: e,
                intersectionRatio: f ? k / f : h ? 1 : 0,
                intersectionRect: g || {
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    width: 0,
                    height: 0
                },
                isIntersecting: h,
                rootBounds: b,
                target: d,
                time: l && l.now ? l.now() : 0
            };
            kG(a, c.sa, d) && a.H.push(d);
            c.sa = d
        });
        this.H.length && this.J(lG(this), this)
    };
    Kq.prototype.observe = function(a) {
        _.Kh(this.j, function(b) {
            return b.target == a
        }) || (this.j.push({
            target: a,
            sa: null
        }), this.l(), this.B || (this.B = !0, _.zb(_.q, "scroll", this.m), _.zb(_.q, "resize", this.m), _.q.MutationObserver && !this.o && (this.o = new MutationObserver(this.m), this.o.observe(_.q.document, {
            attributes: !0,
            childList: !0,
            characterData: !0,
            subtree: !0
        }))))
    };
    Kq.prototype.unobserve = function(a) {
        this.j = _.lh(this.j, function(b) {
            return b.target != a
        });
        0 == this.j.length && this.disconnect()
    };
    Kq.prototype.disconnect = function() {
        this.B = !1;
        this.j.length = 0;
        _.Ae(_.q, "scroll", this.m);
        _.Ae(_.q, "resize", this.m);
        this.o && (this.o.disconnect(), this.o = null)
    };
    var lG = function(a) {
        var b = [].concat(_.ve(a.H));
        a.H.length = 0;
        return b
    };
    var mG = function(a, b, c, d, e, f) {
        _.Q.call(this);
        this.Sa = a;
        this.status = 1;
        this.B = b;
        this.m = c;
        this.G = d;
        this.tc = !!e;
        this.l = Math.random();
        this.I = {};
        this.j = null;
        this.A = (0, _.Ps)(this.R, this);
        this.J = f
    };
    _.L(mG, _.Q);
    mG.prototype.R = function(a) {
        if (!("*" !== this.m && a.origin !== this.m || !this.tc && a.source != this.B)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (_.pa(b) && (a = b.i, b.c === this.Sa && a != this.l)) {
                if (2 !== this.status) try {
                    this.status = 2, nG(this), this.j && (this.j(), this.j = null)
                } catch (c) {}
                a = b.s;
                b = b.p;
                if ("string" === typeof a && ("string" === typeof b || _.pa(b)) && this.I.hasOwnProperty(a)) this.I[a](b)
            }
        }
    };
    var nG = function(a) {
        var b = {};
        b.c = a.Sa;
        b.i = a.l;
        a.J && (b.e = a.J);
        a.B.postMessage(JSON.stringify(b), a.m)
    };
    mG.prototype.D = function() {
        if (1 === this.status) {
            try {
                this.B.postMessage && nG(this)
            } catch (a) {}
            window.setTimeout((0, _.Ps)(this.D, this), 50)
        }
    };
    mG.prototype.connect = function(a) {
        a && (this.j = a);
        _.zb(window, "message", this.A);
        this.G && this.D()
    };
    var oG = function(a, b, c) {
            a.I[b] = c
        },
        pG = function(a, b, c) {
            var d = {};
            d.c = a.Sa;
            d.i = a.l;
            d.s = b;
            d.p = c;
            try {
                a.B.postMessage(JSON.stringify(d), a.m)
            } catch (e) {}
        };
    mG.prototype.o = function() {
        this.status = 3;
        _.Ae(window, "message", this.A);
        _.Q.prototype.o.call(this)
    };
    var qG = new _.v.Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        rG = new _.v.Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);
    var sG = function(a) {
        _.P.call(this, a)
    };
    _.L(sG, _.P);
    var tG = je(sG);
    var uG = function(a) {
        _.P.call(this, a)
    };
    _.L(uG, _.P);
    var vG = function(a) {
        _.P.call(this, a)
    };
    _.L(vG, _.P);
    var wG = function(a) {
            return a.prerendering ? 3 : {
                visible: 1,
                hidden: 2,
                prerender: 3,
                preview: 4,
                unloaded: 5
            }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
        },
        xG = function(a) {
            var b;
            a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
            return b
        },
        yG = function(a) {
            return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
        },
        zG = function(a, b) {
            if (3 == wG(b)) return !1;
            a();
            return !0
        },
        AG = function(a, b) {
            if (!zG(a, b)) {
                var c = !1,
                    d = xG(b),
                    e = function() {
                        !c && zG(a, b) && (c = !0, _.Ae(b, d, e))
                    };
                d && _.zb(b, d, e)
            }
        };
    var pq = function(a, b) {
            this.j = a;
            this.m = b;
            this.o = {}
        },
        qq = function(a) {
            kq() && (document.addEventListener("touchstart", function(b) {
                a.j(902, function() {
                    a.o[b.touches[0].identifier] = Date.now()
                })()
            }, at), document.addEventListener("touchend", function(b) {
                a.j(902, function() {
                    var c = b.changedTouches[0],
                        d = c.clientX,
                        e = c.clientY,
                        f = c.force;
                    c = a.o[c.identifier];
                    if (void 0 !== c) try {
                        var g = kq(),
                            h = {
                                x: d,
                                y: e,
                                duration_ms: Date.now() - c
                            };
                        if (null == g ? 0 : g.gmaSdk) g.gmaSdk.reportTouchEvent(JSON.stringify(_.u(Object, "assign").call(Object, {}, h, {
                            type: 1,
                            force: f
                        })));
                        else {
                            var k, l, m;
                            null == g || null == (k = g.webkit) || null == (l = k.messageHandlers) || null == (m = l.reportGmaTouchEvent) || m.postMessage(h)
                        }
                    } catch (n) {
                        a.m("paw_sigs", {
                            msg: "reportTouchError",
                            err: n instanceof Error ? n.message : "nonError"
                        })
                    }
                })()
            }, at))
        },
        lq = function(a, b, c, d, e) {
            var f = 200,
                g = dq;
            b = void 0 === b ? {} : b;
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            f = void 0 === f ? 200 : f;
            var h = String(Math.floor(2147483647 * _.Ve())),
                k = 0,
                l = function(m) {
                    try {
                        var n = "object" === typeof m.data ? m.data : JSON.parse(m.data);
                        h === n.paw_id && (window.clearTimeout(k), window.removeEventListener("message", l), n.signal ? c(n.signal) : n.error && d(n.error))
                    } catch (p) {
                        g("paw_sigs", {
                            msg: "postmessageError",
                            err: p instanceof Error ? p.message : "nonError",
                            data: null == m.data ? "null" : 500 < m.data.length ? m.data.substring(0, 500) : m.data
                        })
                    }
                };
            window.addEventListener("message", function(m) {
                e(903, function() {
                    l(m)
                })()
            });
            a.postMessage(_.u(Object, "assign").call(Object, {}, {
                paw_id: h
            }, b));
            k = window.setTimeout(function() {
                window.removeEventListener("message", l);
                d("PAW GMA postmessage timed out.")
            }, f)
        },
        kq = function() {
            var a = window,
                b, c;
            if (a.gmaSdk || (null == (b = a.webkit) ? 0 : null == (c = b.messageHandlers) ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, f;
                if (d.gmaSdk || (null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals)) return d
            } catch (g) {}
            return null
        };
    var CG = function(a) {
        _.P.call(this, a, -1, BG)
    };
    _.L(CG, _.P);
    var BG = [1],
        DG = [CG, 1, av, Uv];
    var FG = function(a) {
        _.P.call(this, a, -1, EG)
    };
    _.L(FG, _.P);
    var EG = [1, 2];
    FG.prototype.m = ie([FG, 1, av, Uv, 2, av, DG]);
    var HG, GG;
    HG = function() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new GG;
        this.sideRailProcessedFixedElements = new _.v.Set;
        this.sideRailAvailableSpace = new _.v.Map
    };
    _.Tm = function(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new _.v.Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new _.v.Map)) : a.google_reactive_ads_global_state = new HG;
        return a.google_reactive_ads_global_state
    };
    GG = function() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = []
    };
    var MG, JG;
    _.IG = function(a) {
        this.j = _.Tm(a).floatingAdsStacking
    };
    _.KG = function(a, b) {
        return new JG(a, b)
    };
    _.LG = function(a) {
        a = _.xx(a.j.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    };
    MG = function(a) {
        var b = _.LG(a);
        _.bt(a.j.maxZIndexListeners, function(c) {
            return c(b)
        })
    };
    JG = function(a, b) {
        this.o = a;
        this.m = b;
        this.j = null
    };
    _.NG = function(a) {
        if (null == a.j) {
            var b = a.o,
                c = a.m,
                d = b.j.nextRestrictionId++;
            b.j.maxZIndexRestrictions[d] = c;
            MG(b);
            a.j = d
        }
    };
    _.OG = function(a) {
        if (null != a.j) {
            var b = a.o;
            delete b.j.maxZIndexRestrictions[a.j];
            MG(b);
            a.j = null
        }
    };
    var xh, yh;
    _.Um = 728 * 1.38;
    _.wh = function(a) {
        return a.innerHeight >= a.innerWidth
    };
    _.PG = function(a) {
        var b = _.Km(a).clientWidth;
        a = a.innerWidth;
        return b && a ? b / a : 0
    };
    xh = function(a, b) {
        return (a = _.Km(a).clientWidth) ? a > (void 0 === b ? 420 : b) ? 32768 : 320 > a ? 65536 : 0 : 16384
    };
    yh = function(a) {
        return (a = _.PG(a)) ? 1.05 < a ? 262144 : .95 > a ? 524288 : 0 : 131072
    };
    _.Km = function(a) {
        a = a.document;
        var b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };
    _.QG = function(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    };
    var Ah = 90 * 1.38;
    var RG;
    _.SG = function(a, b) {
        if (!a.body) return null;
        var c = new RG;
        c.apply(a, b);
        return function() {
            _.$x(a.body, {
                filter: c.j,
                webkitFilter: c.j,
                overflow: c.m,
                position: c.H,
                top: c.B
            });
            b.scrollTo(0, c.o)
        }
    };
    RG = function() {
        this.j = this.B = this.H = this.m = null;
        this.o = 0
    };
    RG.prototype.apply = function(a, b) {
        this.m = a.body.style.overflow;
        this.H = a.body.style.position;
        this.B = a.body.style.top;
        this.j = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
        this.o = _.QG(b);
        _.$x(a.body, "top", -this.o + "px")
    };
    _.Mm = function(a, b) {
        var c;
        if (!(c = 0 >= b) && !(c = null == a)) {
            try {
                a.setItem("__storage_test__", "__storage_test__");
                var d = a.getItem("__storage_test__");
                a.removeItem("__storage_test__");
                var e = "__storage_test__" === d
            } catch (f) {
                e = !1
            }
            c = !e
        }
        return c ? null : Lh(a, b)
    };
    _.Lm = function(a) {
        return !!a && 1 > a.length
    };
    var TG = function(a) {
        _.Q.call(this);
        this.j = a;
        this.m = null;
        this.I = {};
        this.A = 0;
        this.B = null
    };
    _.L(TG, _.Q);
    TG.prototype.o = function() {
        this.B && _.Ae(this.j, "message", this.B);
        _.Q.prototype.o.call(this)
    };
    TG.prototype.l = function() {
        var a;
        return "function" === typeof(null == (a = this.j) ? void 0 : a.__uspapi) || null != UG(this)
    };
    TG.prototype.J = function(a) {
        var b = {};
        if (this.l()) {
            var c = _.Zs(function() {
                return a(b)
            });
            VG(this, function(d, e) {
                e && (b = d);
                c()
            });
            setTimeout(c, 500)
        } else a(b)
    };
    var VG = function(a, b) {
            var c;
            "function" === typeof(null == (c = a.j) ? void 0 : c.__uspapi) ? (a = a.j.__uspapi, a("getUSPData", 1, b)) : UG(a) && (WG(a), c = ++a.A, a.I[c] = b, a.m && (b = {}, a.m.postMessage((b.__uspapiCall = {
                command: "getUSPData",
                version: 1,
                callId: c
            }, b), "*")))
        },
        UG = function(a) {
            if (a.m) return a.m;
            a.m = Hx(a.j, "__uspapiLocator");
            return a.m
        },
        WG = function(a) {
            a.B || (a.B = function(b) {
                try {
                    var c = {};
                    "string" === typeof b.data ? c = JSON.parse(b.data) : c = b.data;
                    var d = c.__uspapiReturn;
                    var e;
                    null == (e = a.I) || e[d.callId](d.returnValue, d.success)
                } catch (f) {}
            }, _.zb(a.j, "message", a.B))
        };
    var Un = function(a) {
        _.Q.call(this);
        this.l = a;
        this.B = this.j = null;
        this.J = {};
        this.D = 0;
        this.I = !1
    };
    _.L(Un, _.Q);
    Un.prototype.m = function() {
        if (!this.I) {
            if (!this.j) {
                var a = Hx(this.l, "googlefcPresent");
                this.j = a ? a : null
            }
            this.I = !0
        }
        return !!this.j
    };
    Un.prototype.A = function() {
        var a = this;
        return new _.v.Promise(function(b) {
            if (a.m())
                if (a.j === a.l) {
                    var c = a.j.googlefc || (a.j.googlefc = {});
                    c.__fci = c.__fci || [];
                    c.__fci.push("loaded", function(e) {
                        b($e(e))
                    })
                } else {
                    XG(a);
                    c = a.D++;
                    a.J[c] = b;
                    var d = {};
                    (0, B.K)(a.j).postMessage((d.__fciCall = {
                        command: "loaded",
                        callId: c
                    }, d), "*")
                }
        })
    };
    var XG = function(a) {
        a.B || (a.B = function(b) {
            try {
                var c = $e(b.data.__fciReturn);
                (0, a.J[_.af(c, 1)])(c)
            } catch (d) {}
        }, _.zb(a.l, "message", a.B))
    };
    var YG = {},
        Ph = (YG[23] = .001, YG[253] = !1, YG[246] = [], YG[150] = "", YG[221] = /^true$/.test("false"), YG[36] = /^true$/.test("false"), YG[172] = null, YG[260] = void 0, YG[251] = null, YG),
        Oh = function() {
            this.j = !1
        };
    var fl = function(a) {
            var b = void 0 === b ? tf(_.q) : b;
            this.id = a;
            this.o = Math.random() < (_.E(Xy) ? .001 : _.Qh(23));
            this.j = {
                pvsid: String(b)
            }
        },
        ZG = function(a) {
            a = Nh(a);
            var b;
            li.set(a, (null != (b = li.get(a)) ? b : 0) + 1)
        },
        ki = function() {
            return [].concat(_.ve(_.u(li, "values").call(li))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        K = function(a, b, c) {
            "string" !== typeof c && (c = String(c));
            /^\w+$/.test(b) && (c ? a.j[b] = c : delete a.j[b])
        },
        hl = function(a) {
            var b = 1;
            b = void 0 === b ? null : b;
            if ($G()) b = !0;
            else {
                var c = a.o;
                b && 0 <= b && (c = Math.random() < b);
                b = c && !!a.id
            }
            b && gA(window, aH(a) || "", void 0, _.E(bz))
        },
        aH = function(a) {
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + encodeURIComponent(a.id);
            _.Ml(a.j, function(c, d) {
                c && (b += "&" + d + "=" + encodeURIComponent(c))
            });
            return b
        },
        bH = function(a) {
            var b = [].concat(_.ve(_.u(li, "keys").call(li)));
            b = b.map(function(c) {
                return c.replace(/,/g, "\\,")
            });
            3 >= b.length ? K(a, "nw_id", b.join()) : (b = b.slice(0, 3), b.push("__extra__"), K(a, "nw_id", b.join()))
        },
        Ij = function(a, b) {
            K(a, "vrg", String(b.Ab || b.Na));
            bH(a);
            K(a, "nslots", ki().toString());
            b = _.of(pf).j();
            b.length && K(a, "eid", b.join());
            K(a, "pub_url", document.URL)
        },
        Cj = function(a, b, c) {
            c = void 0 === c ? _.E(Xy) ? .001 : _.Qh(23) : c;
            if (void 0 === c || 0 > c || 1 < c) c = _.E(Xy) ? .001 : _.Qh(23);
            Math.random() < c && (a = new fl(a), b(a), hl(a))
        },
        li = new _.v.Map,
        $G = mj(function() {
            return !!Bx(_.q.location.href)
        });
    var ai = function() {
        mB.call(this, _.E(bi) || _.E(Mz) ? 1 : 0, _.q);
        this.m = 0;
        var a = _.E(bi) || _.E(Mz);
        _.q.google_measure_js_timing = a || _.q.google_measure_js_timing
    };
    _.L(ai, mB);
    _.cH = function(a) {
        this.context = a
    };
    _.cH.prototype.Cb = function(a, b) {
        return ei(this.context, a, b)
    };
    _.cH.prototype.pa = function(a, b) {
        return Zh(this.context, a, b)
    };
    _.cH.prototype.Nb = function(a, b) {
        ci(this.context, a, b);
        return !1
    };
    _.cH.prototype.xc = da(0);
    var dH = {},
        eH = (dH.companion_ads = "companionAds", dH.content = "content", dH.publisher_ads = "pubads", dH);
    var ni = function(a) {
        _.P.call(this, a)
    };
    _.L(ni, _.P);
    ni.prototype.getWidth = function() {
        return oi(this, 1)
    };
    var si = function(a, b) {
        return _.z(a, 1, b)
    };
    ni.prototype.getHeight = function() {
        return oi(this, 2)
    };
    var ri = function(a, b) {
            return _.z(a, 2, b)
        },
        sm = function() {
            var a = new ni;
            return _.z(a, 3, !0)
        };
    var ul = function(a) {
        _.P.call(this, a, -1, fH)
    };
    _.L(ul, _.P);
    var tl = function(a, b) {
            return _.z(a, 1, b)
        },
        sl = function(a, b) {
            return _.ed(a, 2, b, _.Fc)
        },
        gH = function(a, b) {
            return Pu(a, 2, b)
        },
        fH = [2];
    var Zq = function(a) {
        _.P.call(this, a)
    };
    _.L(Zq, _.P);
    var hH = function(a, b) {
        return _.z(a, 3, _.Ac(b))
    };
    var mp = function(a) {
        _.P.call(this, a, -1, iH)
    };
    _.L(mp, _.P);
    var sp = function(a, b) {
            return _.z(a, 1, b)
        },
        qp = function(a, b) {
            return _.ed(a, 2, b, _.Fc)
        },
        iH = [2];
    var Rp = function(a) {
        _.P.call(this, a, -1, jH)
    };
    _.L(Rp, _.P);
    var rp = function(a, b) {
            _.Zf(a, 1, mp, b)
        },
        jH = [1];
    var Pp = function(a) {
        _.P.call(this, a, -1, kH)
    };
    _.L(Pp, _.P);
    var kH = [2, 3];
    var Np = function(a) {
        _.P.call(this, a)
    };
    _.L(Np, _.P);
    var lH = function(a) {
        _.P.call(this, a)
    };
    _.L(lH, _.P);
    lH.prototype.setTagForChildDirectedTreatment = function(a) {
        return _.z(this, 5, a)
    };
    lH.prototype.clearTagForChildDirectedTreatment = function() {
        return wf(this, 5)
    };
    lH.prototype.setTagForUnderAgeOfConsent = function(a) {
        return _.z(this, 6, a)
    };
    var Ll = function(a) {
        _.P.call(this, a)
    };
    _.L(Ll, _.P);
    var nH = function(a) {
        _.P.call(this, a, -1, mH)
    };
    _.L(nH, _.P);
    nH.prototype.getCategoryExclusions = function(a) {
        return Ou(this, 3, a)
    };
    nH.prototype.wa = function() {
        return Qe(this, ul, 14)
    };
    nH.prototype.Za = function() {
        return Bf(this, Ll, 18)
    };
    var yn = function(a) {
        return Bf(a, lH, 25)
    };
    nH.prototype.getCorrelator = function() {
        return y(this, 26)
    };
    nH.prototype.setCorrelator = function(a) {
        return _.z(this, 26, a)
    };
    nH.prototype.ed = function() {
        return Op(this, Np, 33)
    };
    var mH = [2, 3, 14];
    var dj = function() {
        this.j = new _.v.Map
    };
    var oH = function() {
            this.o = {};
            this.j = new nH;
            this.m = new _.v.Map;
            this.j.setCorrelator(Qx());
            _.Qh(36) && _.z(this.j, 15, !0)
        },
        pH = function(a) {
            var b = vj(),
                c = a.getDomId();
            if (c && !b.o.hasOwnProperty(c)) {
                var d = _.of(dj),
                    e = ++_.of(ai).m;
                d.j.set(c, e);
                _.z(a, 20, e);
                b.o[c] = a
            }
        },
        jo = function(a, b) {
            return a.o[b]
        },
        vj = function() {
            return _.of(oH)
        };
    var hj = mj(gj);
    var Rj = ["auto", "inherit", "100%"],
        Sj = Rj.concat(["none"]);
    var Zm = function(a, b, c) {
        if (!a) return !0;
        var d = !0;
        Pj(a, function(e) {
            return d = Qj(e, b, 10, 10)
        }, c);
        return d
    };
    var qH = function(a, b, c, d, e, f) {
            this.m = _.Ux(a);
            this.o = _.Ux(b);
            this.H = c;
            this.j = _.Ux(d);
            this.B = e;
            this.l = f
        },
        rH = function(a) {
            return JSON.stringify({
                windowCoords_t: a.m.top,
                windowCoords_r: a.m.right,
                windowCoords_b: a.m.bottom,
                windowCoords_l: a.m.left,
                frameCoords_t: a.o.top,
                frameCoords_r: a.o.right,
                frameCoords_b: a.o.bottom,
                frameCoords_l: a.o.left,
                styleZIndex: a.H,
                allowedExpansion_t: a.j.top,
                allowedExpansion_r: a.j.right,
                allowedExpansion_b: a.j.bottom,
                allowedExpansion_l: a.j.left,
                xInView: a.B,
                yInView: a.l
            })
        },
        sH = function(a) {
            var b = window,
                c = b.screenX || b.screenLeft || 0,
                d = b.screenY || b.screenTop || 0;
            b = new _.Tx(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
            c = dy(a);
            d = _.Gh(_.Hh, a);
            var e = new Vx(c.x, c.y, d.width, d.height);
            c = Wx(e);
            d = String(Fh(a, "zIndex"));
            var f = new _.Tx(0, Infinity, Infinity, 0);
            for (var g = hx(a), h = g.j.body, k = g.j.documentElement, l = mx(g.j); a = cy(a);)
                if (!(_.Xt && 0 == a.clientWidth || $t && 0 == a.clientHeight && a == h) && a != h && a != k && "visible" != Fh(a, "overflow")) {
                    var m = dy(a),
                        n = new _.Zi(a.clientLeft, a.clientTop);
                    m.x += n.x;
                    m.y += n.y;
                    f.top = Math.max(f.top, m.y);
                    f.right = Math.min(f.right, m.x + a.clientWidth);
                    f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                    f.left = Math.max(f.left, m.x)
                }
            a = l.scrollLeft;
            l = l.scrollTop;
            f.left = Math.max(f.left, a);
            f.top = Math.max(f.top, l);
            g = g.j;
            g = _.lx(g.parentWindow || g.defaultView || window);
            f.right = Math.min(f.right, a + g.width);
            f.bottom = Math.min(f.bottom, l + g.height);
            l = (f = (f = 0 <= f.top && 0 <= f.left && f.bottom > f.top && f.right > f.left ? f : null) ? new Vx(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ? Xx(e, f) : null;
            g = a = 0;
            l && !(new _.bj(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
            l = new _.Tx(0, 0, 0, 0);
            if (h = f)(e = Xx(e, f)) ? (k = Wx(f), m = Wx(e), h = m.right != k.left && k.right != m.left, k = m.bottom != k.top && k.bottom != m.top, h = (0 != e.width || h) && (0 != e.height || k)) : h = !1;
            h && (l = new _.Tx(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
            return new qH(b, c, d, l, a, g)
        };
    var tH = function(a) {
        this.H = a;
        this.B = null;
        this.ha = this.status = 0;
        this.o = null;
        this.Sa = "sfchannel" + a
    };
    var uH = function(a) {
        this.j = a
    };
    var vH = function(a, b) {
        this.Yc = a;
        this.Zc = b;
        this.o = this.j = !1
    };
    var wH = function(a, b, c, d, e, f, g, h) {
        h = void 0 === h ? [] : h;
        this.o = a;
        this.m = b;
        this.H = c;
        this.permissions = d;
        this.metadata = e;
        this.B = f;
        this.tc = g;
        this.hostpageLibraryTokens = h;
        this.j = ""
    };
    var xH = function(a, b) {
        this.o = a;
        this.H = b
    };
    xH.prototype.j = function(a) {
        this.H && a && (a.sentinel = this.H);
        return JSON.stringify(a)
    };
    var yH = function(a, b, c) {
        xH.call(this, a, void 0 === c ? "" : c);
        this.version = b
    };
    _.L(yH, xH);
    yH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            version: this.version
        })
    };
    var zH = function(a, b, c, d) {
        xH.call(this, a, void 0 === d ? "" : d);
        this.B = b;
        this.m = c
    };
    _.L(zH, xH);
    zH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            initialWidth: this.B,
            initialHeight: this.m
        })
    };
    var AH = function(a, b, c) {
        xH.call(this, a, void 0 === c ? "" : c);
        this.description = b
    };
    _.L(AH, xH);
    AH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            description: this.description
        })
    };
    var BH = function(a, b, c, d) {
        xH.call(this, a, void 0 === d ? "" : d);
        this.m = b;
        this.push = c
    };
    _.L(BH, xH);
    BH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        })
    };
    var CH = function(a, b) {
        xH.call(this, a, void 0 === b ? "" : b)
    };
    _.L(CH, xH);
    CH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o
        })
    };
    var DH = function(a, b, c) {
        xH.call(this, a, void 0 === c ? "" : c);
        this.B = b
    };
    _.L(DH, xH);
    DH.prototype.j = function() {
        var a = {
            uid: this.o,
            newGeometry: rH(this.B)
        };
        return xH.prototype.j.call(this, a)
    };
    var EH = function(a, b, c, d, e, f) {
        DH.call(this, a, c, void 0 === f ? "" : f);
        this.success = b;
        this.m = d;
        this.push = e
    };
    _.L(EH, DH);
    EH.prototype.j = function() {
        var a = {
            uid: this.o,
            success: this.success,
            newGeometry: rH(this.B),
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        };
        this.H && (a.sentinel = this.H);
        return JSON.stringify(a)
    };
    var FH = function(a, b, c, d) {
        xH.call(this, a, void 0 === d ? "" : d);
        this.width = b;
        this.height = c
    };
    _.L(FH, xH);
    FH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            width: this.width,
            height: this.height
        })
    };
    var GH = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        ne(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    var HH = function() {
            this.j = []
        },
        JH = function(a, b, c, d, e) {
            a.j.push(new IH(b, c, d, e))
        },
        KH = function(a) {
            for (var b = a.j.length - 1; 0 <= b; b--) {
                var c = a.j[b];
                c.o ? (c.m.style.removeProperty(c.j), c.m.style.setProperty(c.j, String(c.H), c.B)) : c.m.style[c.j] = c.H
            }
            a.j.length = 0
        },
        IH = function(a, b, c, d) {
            this.m = a;
            this.j = (this.o = !(void 0 === d || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
            this.H = this.o ? a.style.getPropertyValue(this.j) : a.style[this.j];
            this.B = this.o ? a.style.getPropertyPriority(this.j) : void 0;
            this.o ? (a.style.removeProperty(this.j), a.style.setProperty(this.j, String(c), d)) : a.style[this.j] = String(c)
        };
    var LH = function(a, b) {
            b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
            2048 > b.length && b.push(a)
        },
        MH = function() {
            var a = window,
                b = _.kf(a);
            b && LH({
                label: "2",
                type: 9,
                value: b
            }, a)
        },
        NH = function(a, b, c) {
            var d = void 0 === d ? !1 : d;
            var e = window,
                f = "undefined" !== typeof queueMicrotask;
            return function() {
                d && f && queueMicrotask(function() {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                var g = _.kf(),
                    h = 3;
                try {
                    var k = b.apply(this, arguments)
                } catch (l) {
                    h = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    e.google_measure_js_timing && g && LH(_.u(Object, "assign").call(Object, {}, {
                        label: a.toString(),
                        value: g,
                        duration: (_.kf() || 0) - g,
                        type: h
                    }, d && f && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    }), e)
                }
                return k
            }
        };
    var SH = function(a) {
        tH.call(this, a.uniqueId);
        var b = this;
        this.I = a.uj;
        this.A = 1 === a.size;
        this.P = new vH(a.permissions.Yc && !this.A, a.permissions.Zc && !this.A);
        this.l = a.Be;
        var c;
        this.la = null != (c = a.hostpageLibraryTokens) ? c : [];
        var d = window.location;
        c = d.protocol;
        d = d.host;
        this.ga = "file:" == c ? "*" : c + "//" + d;
        this.ma = !!a.tc;
        this.L = a.Gf ? "//" + a.Gf + ".safeframe.googlesyndication.com" : "//tpc.googlesyndication.com";
        this.ca = a.hd ? "*" : "https:" + this.L;
        this.W = !!a.wg;
        this.na = OH(a);
        this.m = new HH;
        PH(this, a.Be, a.size);
        this.B = this.ja = sH(a.Be);
        this.G = a.Jh || "1-0-40";
        var e;
        this.ba = null != (e = a.hg) ? e : "";
        QH(this, a);
        this.D = NH(412, function() {
            return RH(b)
        }, a.Ma);
        this.R = -1;
        this.J = 0;
        var f = NH(415, function() {
            b.j && (b.j.name = "", a.uf && a.uf(), _.Ae(b.j, "load", f))
        }, a.Ma);
        _.zb(this.j, "load", f);
        this.ne = NH(413, this.ne, a.Ma);
        this.De = NH(417, this.De, a.Ma);
        this.Ee = NH(419, this.Ee, a.Ma);
        this.fe = NH(411, this.fe, a.Ma);
        this.Ud = NH(409, this.Ud, a.Ma);
        this.N = NH(410, this.N, a.Ma);
        this.we = NH(416, this.we, a.Ma);
        this.o = new mG(this.Sa, this.j.contentWindow, this.ca, !1);
        oG(this.o, "init_done", (0, _.Ps)(this.ne, this));
        oG(this.o, "register_done", (0, _.Ps)(this.De, this));
        oG(this.o, "report_error", (0, _.Ps)(this.Ee, this));
        oG(this.o, "expand_request", (0, _.Ps)(this.fe, this));
        oG(this.o, "collapse_request", (0, _.Ps)(this.Ud, this));
        oG(this.o, "creative_geometry_update", (0, _.Ps)(this.N, this));
        this.o.connect((0, _.Ps)(this.we, this))
    };
    _.L(SH, tH);
    var PH = function(a, b, c) {
            a.A ? (b.style.width = _.fy("100%", !0), b.style.height = _.fy("auto", !0)) : (b.style.width = _.fy(c.width, !0), b.style.height = _.fy(c.height, !0))
        },
        QH = function(a, b) {
            var c = b.hd,
                d = b.content,
                e = b.qc,
                f = b.size,
                g = void 0 === b.rc ? "3rd party ad content" : b.rc,
                h = b.bd;
            b = b.Qd;
            var k = {
                shared: {
                    sf_ver: a.G,
                    ck_on: YA() ? 1 : 0,
                    flash_ver: "0"
                }
            };
            d = c ? "" : null != d ? d : "";
            d = a.G + ";" + d.length + ";" + d;
            k = new wH(a.H, a.ga, a.ja, a.P, new uH(k), a.A, a.ma, a.la);
            var l = {};
            l.uid = k.o;
            l.hostPeerName = k.m;
            l.initialGeometry = rH(k.H);
            var m = k.permissions;
            m = JSON.stringify({
                expandByOverlay: m.Yc,
                expandByPush: m.Zc,
                readCookie: m.j,
                writeCookie: m.o
            });
            l = (l.permissions = m, l.metadata = JSON.stringify(k.metadata.j), l.reportCreativeGeometry = k.B, l.isDifferentSourceWindow = k.tc, l.goog_safeframe_hlt = lC(k.hostpageLibraryTokens), l);
            k.j && (l.sentinel = k.j);
            k = JSON.stringify(l);
            d += k;
            a.W && f instanceof _.bj && (k = _.nx(_.gx(a.l)), l = _.nx(_.gx(a.l)).location.protocol + a.L, $B || il(k.document, aC), $B++, k.google_eas_queue = k.google_eas_queue || [], k.google_eas_queue.push({
                a: e,
                b: l,
                c: f.width,
                d: f.height,
                e: "sf-gdn-exp-" + $B,
                f: void 0,
                g: void 0,
                h: void 0,
                i: void 0
            }));
            k = f.width;
            f = f.height;
            a.A && (f = k = 0);
            l = {};
            e = (l.id = e, l.title = g, l.name = d, l.scrolling = "no", l.marginWidth = "0", l.marginHeight = "0", l.width = String(k), l.height = String(f), l["data-is-safeframe"] = "true", l);
            void 0 === c && (g = _.nx(_.gx(a.l)), f = a.ba, d = a.L, (k = f) && (k = "?" + k), d = (void 0 === d ? "//tpc.googlesyndication.com" : d) + ("/safeframe/" + a.G + "/html/container.html" + k), (k = GH(g)) && (d += (f ? "&" : "?") + "n=" + k), f = "https:" + d, d = [], a.W && (k = Bx(g.location.href), g = d.push, k = [0 < k.length ? "google_debug" + (k ? "=" + k : "") + "&" : "", "xpc=", "sf-gdn-exp-" + a.H, "&p=", encodeURIComponent(_.q.document.location.protocol), "//", encodeURIComponent(_.q.document.location.host)].join(""), g.call(d, k)), d.length && (f += "#" + d.join("&")), e.src = f);
            null !== a.na && (e.sandbox = a.na);
            h && (e.allow = h);
            b && (e.credentialless = "true");
            e.role = "region";
            e["aria-label"] = "Advertisement";
            e.tabIndex = "0";
            c ? (a.j = c, jx(a.j, e)) : (c = {}, c = (c.frameborder = 0, c.allowTransparency = "true", c.style = "border:0;vertical-align:bottom;", c.src = "about:blank", c), e && Ia(c, e), h = _.ze("IFRAME"), jx(h, c), a.j = h);
            a.A && (a.j.style.minWidth = "100%");
            a.l.appendChild(a.j)
        };
    _.aa = SH.prototype;
    _.aa.we = function() {
        _.zb(window, "resize", this.D);
        _.zb(window, "scroll", this.D)
    };
    _.aa.ne = function(a) {
        try {
            if (0 != this.status) throw Error("Container already initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.pa(b) || !Uj(b.uid) || "string" !== typeof b.version) throw Error("Cannot parse JSON message");
            var c = new yH(b.uid, b.version, b.sentinel);
            if (this.H !== c.o || this.G !== c.version) throw Error("Wrong source container");
            this.status = 1
        } catch (e) {
            var d;
            null == (d = this.I) || d.error("Invalid INITIALIZE_DONE message. Reason: " + e.message)
        }
    };
    _.aa.De = function(a) {
        try {
            if (1 != this.status) throw Error("Container not initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.pa(b) || !Uj(b.uid) || "number" !== typeof b.initialWidth || "number" !== typeof b.initialHeight) throw Error("Cannot parse JSON message");
            if (this.H !== (new zH(b.uid, b.initialWidth, b.initialHeight, b.sentinel)).o) throw Error("Wrong source container");
            this.status = 2
        } catch (d) {
            var c;
            null == (c = this.I) || c.error("Invalid REGISTER_DONE message. Reason: " + d.message)
        }
    };
    _.aa.Ee = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.pa(b) || !Uj(b.uid) || "string" !== typeof b.description) throw Error("Cannot parse JSON message");
            var c = new AH(b.uid, b.description, b.sentinel);
            if (this.H !== c.o) throw Error("Wrong source container");
            var d;
            null == (d = this.I) || d.info("Ext reported an error. Description: " + c.description)
        } catch (f) {
            var e;
            null == (e = this.I) || e.error("Invalid REPORT_ERROR message. Reason: " + f.message)
        }
    };
    _.aa.fe = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (0 != this.ha) throw Error("Container is not collapsed");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.pa(b) || !Uj(b.uid) || "number" !== typeof b.expand_t || "number" !== typeof b.expand_r || "number" !== typeof b.expand_b || "number" !== typeof b.expand_l || "boolean" !== typeof b.push) throw Error("Cannot parse JSON message");
            var c = new BH(b.uid, new _.Tx(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.H !== c.o) throw Error("Wrong source container");
            if (!(0 <= c.m.top && 0 <= c.m.left && 0 <= c.m.bottom && 0 <= c.m.right)) throw Error("Invalid expansion amounts");
            var d;
            if (d = c.push && this.P.Zc || !c.push && this.P.Yc) {
                var e = c.m,
                    f = c.push,
                    g = this.B = sH(this.j);
                if (e.top <= g.j.top && e.right <= g.j.right && e.bottom <= g.j.bottom && e.left <= g.j.left) {
                    if (!f)
                        for (var h = this.j.parentNode; h && h.style; h = h.parentNode) JH(this.m, h, "overflowX", "visible", "important"), JH(this.m, h, "overflowY", "visible", "important");
                    var k = Wx(new Vx(0, 0, this.B.o.getWidth(), this.B.o.getHeight()));
                    _.pa(e) ? (k.top -= e.top, k.right += e.right, k.bottom += e.bottom, k.left -= e.left) : (k.top -= e, k.right += Number(void 0), k.bottom += Number(void 0), k.left -= Number(void 0));
                    JH(this.m, this.l, "position", "relative");
                    JH(this.m, this.j, "position", "absolute");
                    if (f) {
                        var l = k.getWidth();
                        JH(this.m, this.l, "width", l + "px");
                        var m = k.getHeight();
                        JH(this.m, this.l, "height", m + "px")
                    } else JH(this.m, this.j, "zIndex", "10000");
                    var n = k.getWidth();
                    JH(this.m, this.j, "width", n + "px");
                    var p = k.getHeight();
                    JH(this.m, this.j, "height", p + "px");
                    JH(this.m, this.j, "left", k.left + "px");
                    JH(this.m, this.j, "top", k.top + "px");
                    this.ha = 2;
                    this.B = sH(this.j);
                    d = !0
                } else d = !1
            }
            a = d;
            pG(this.o, "expand_response", (new EH(this.H, a, this.B, c.m, c.push)).j());
            if (!a) throw Error("Viewport or document body not large enough to expand into.");
        } catch (t) {
            var r;
            null == (r = this.I) || r.error("Invalid EXPAND_REQUEST message. Reason: " + t.message)
        }
    };
    _.aa.Ud = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (2 != this.ha) throw Error("Container is not expanded");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.pa(b) || !Uj(b.uid)) throw Error("Cannot parse JSON message");
            if (this.H !== (new CH(b.uid, b.sentinel)).o) throw Error("Wrong source container");
            KH(this.m);
            this.ha = 0;
            this.j && (this.B = sH(this.j));
            pG(this.o, "collapse_response", (new DH(this.H, this.B)).j())
        } catch (d) {
            var c;
            null == (c = this.I) || c.error("Invalid COLLAPSE_REQUEST message. Reason: " + d.message)
        }
    };
    var RH = function(a) {
        if (1 == a.status || 2 == a.status) switch (a.J) {
            case 0:
                TH(a);
                a.R = window.setTimeout((0, _.Ps)(a.ia, a), 1E3);
                a.J = 1;
                break;
            case 1:
                a.J = 2;
                break;
            case 2:
                a.J = 2
        }
    };
    SH.prototype.N = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.pa(b) || !Uj(b.uid) || "number" !== typeof b.width || "number" !== typeof b.height || b.sentinel && "string" !== typeof b.sentinel) throw Error("Cannot parse JSON message");
            var c = new FH(b.uid, b.width, b.height, b.sentinel);
            if (this.H !== c.o) throw Error("Wrong source container");
            var d = String(c.height);
            if (this.A) d !== this.j.height && (this.j.height = d, RH(this));
            else {
                var e;
                null == (e = this.I) || e.error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            }
        } catch (g) {
            var f;
            null == (f = this.I) || f.error("Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: " + g.message)
        }
    };
    SH.prototype.ia = function() {
        if (1 == this.status || 2 == this.status) switch (this.J) {
            case 1:
                this.J = 0;
                break;
            case 2:
                TH(this), this.R = window.setTimeout((0, _.Ps)(this.ia, this), 1E3), this.J = 1
        }
    };
    var TH = function(a) {
            a.B = sH(a.j);
            pG(a.o, "geometry_update", (new DH(a.H, a.B)).j())
        },
        OH = function(a) {
            var b = null;
            a.If && (b = a.If);
            return null == b ? null : b.join(" ")
        },
        UH = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        VH = ["allow-top-navigation"],
        WH = ["allow-same-origin"],
        XH = Ex([].concat(_.ve(UH), _.ve(VH)));
    Ex([].concat(_.ve(UH), _.ve(WH)));
    Ex([].concat(_.ve(UH), _.ve(VH), _.ve(WH)));
    var YH = _.O(["https://tpc.googlesyndication.com/safeframe/", "/html/container.html"]),
        ZH = {
            fh: function(a) {
                if ("string" !== typeof a.version) throw new TypeError("version is not a string");
                if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError("Invalid version: " + a.version);
                if ("string" !== typeof a.Fd) throw new TypeError("subdomain is not a string");
                if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.Fd)) throw new RangeError("Invalid subdomain: " + a.Fd);
                return se("https://" + a.Fd + ".safeframe.googlesyndication.com/safeframe/" + a.version + "/html/container.html")
            },
            Fj: function(a) {
                return _.A(YH, a)
            }
        };
    var Wj = function(a, b) {
        try {
            Jb(rq(a, b))
        } catch (c) {}
    };
    var $H = function(a) {
        _.P.call(this, a)
    };
    _.L($H, _.P);
    $H.prototype.m = ie([$H, 4, Uu, 2, Uu, 1, Uu, 3, Uu, 5, Xu]);
    var aI = [.05, .1, .2, .5],
        bI = [0, .5, 1],
        cI = function(a) {
            a = zg(a);
            if (!a) return -1;
            try {
                var b = bC(a.document);
                var c = new _.bj(b.clientWidth, b.clientHeight)
            } catch (d) {
                c = new _.bj(-12245933, -12245933)
            }
            return -12245933 == c.width || -12245933 == c.height ? -1 : c.width * c.height
        },
        dI = function(a, b) {
            return 0 >= a || 0 >= b ? [] : _.zd(aI, function(c) {
                return Math.min(a / b * c, 1)
            })
        },
        fI = function(a) {
            this.B = a.F;
            this.m = a.ib;
            this.l = a.Fb;
            this.o = null;
            this.H = a.Ma;
            this.j = eI(this, a.qg);
            this.I = a.Nh || !1
        },
        gI = function() {
            var a;
            return !(_.E(Jq) && !window.IntersectionObserver || !Gx(null == (a = window.performance) ? void 0 : a.now))
        };
    fI.prototype.getSlotId = function() {
        return this.o
    };
    var iI = function(a, b) {
            if (a.j) {
                if (null != a.o) {
                    try {
                        hI(a, Math.round(performance.now()), 0, 0, 0, !1)
                    } catch (c) {
                        a.H && a.H(c)
                    }
                    a.j && a.j.unobserve(a.m)
                }
                a.o = b;
                a.j.observe(a.m)
            }
        },
        eI = function(a, b) {
            var c = a.m.offsetWidth * a.m.offsetHeight,
                d = cI(a.B);
            c = [].concat(_.ve(bI), _.ve(dI(d, c)));
            sa(c);
            return _.q.IntersectionObserver ? new _.q.IntersectionObserver(function(e) {
                return jI(a, e)
            }, {
                threshold: c
            }) : b ? null : new Kq(function(e) {
                return jI(a, e)
            }, {
                threshold: c
            })
        },
        jI = function(a, b) {
            try {
                var c = cI(a.B);
                _.bt(b, function(d) {
                    a.I && hI(a, Math.round(d.time), d.boundingClientRect.width * d.boundingClientRect.height, d.intersectionRect.width * d.intersectionRect.height, c, d.isIntersecting)
                })
            } catch (d) {
                a.H && a.H(d)
            }
        },
        hI = function(a, b, c, d, e, f) {
            if (null == a.o) throw Error("Not Attached.");
            var g = new $H;
            c = _.z(g, 1, c);
            d = _.z(c, 2, d);
            e = _.z(d, 3, e);
            b = _.z(e, 4, b);
            f = _.z(b, 5, f);
            f = Qb(f.m(), 4);
            nB(a.l, "1", 10, f, void 0, a.o)
        };
    var kI = function(a, b) {
            this.j = a;
            this.o = b
        },
        lI = function(a) {
            if (a.j.frames.google_ads_top_frame) return !0;
            var b = Ix(a.j);
            b = b && b.contentWindow;
            if (!b) return !1;
            b.addEventListener("message", function(c) {
                var d = c.ports;
                "__goog_top_url_req" === c.data.msgType && d.length && d[0].postMessage({
                    msgType: "__goog_top_url_resp",
                    topUrl: a.o
                })
            }, !1);
            return !0
        };
    var hk = function(a) {
        _.P.call(this, a)
    };
    _.L(hk, _.P);
    var lk = je(hk),
        jk = [1, 3];
    var Ce = {
        kj: 0,
        gj: 1,
        hj: 9,
        ej: 2,
        fj: 3,
        jj: 5,
        ij: 7
    };
    var mI = _.O(["https://securepubads.g.doubleclick.net/static/topics/topics_frame.html"]),
        bk = _.A(mI);
    var Hk = function(a) {
        _.P.call(this, a)
    };
    _.L(Hk, _.P);
    Hk.prototype.getVersion = function() {
        return _.Tf(this, 2)
    };
    var Gk = function(a) {
        _.P.call(this, a, -1, nI)
    };
    _.L(Gk, _.P);
    var Ak = function(a, b) {
            return _.z(a, 2, b)
        },
        Fk = function(a, b) {
            return _.z(a, 3, b)
        },
        Ck = function(a, b) {
            return _.z(a, 4, b)
        },
        zk = function(a, b) {
            return _.z(a, 5, b)
        },
        Ek = function(a, b) {
            return _.z(a, 9, b)
        },
        yk = function(a, b) {
            return _.Ad(a, 10, b)
        },
        xk = function(a, b) {
            return _.z(a, 11, b)
        },
        Bk = function(a, b) {
            return _.z(a, 1, b)
        },
        Dk = function(a, b) {
            return _.z(a, 7, b)
        },
        nI = [10, 6];
    var vk = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");
    var oI = function() {
            this.id = "goog_" + cx++
        },
        pI = function(a) {
            _.Q.call(this);
            this.context = a;
            this.m = new _.v.Map
        };
    _.L(pI, _.Q);
    pI.prototype.o = function() {
        _.Q.prototype.o.call(this);
        this.m.clear()
    };
    pI.prototype.Z = function(a, b) {
        var c = this;
        if (this.H) return function() {};
        var d = "string" === typeof a ? a : a.id,
            e, f, g = null != (f = null == (e = this.m.get(d)) ? void 0 : e.add(b)) ? f : new _.v.Set([b]);
        this.m.set(d, g);
        return function() {
            return void qI(c, a, b)
        }
    };
    var rI = function(a, b, c) {
            c = void 0 === c ? function() {
                return !0
            } : c;
            return new _.v.Promise(function(d) {
                var e = a.Z(b, function(f) {
                    c(f) && (e(), d(f))
                })
            })
        },
        qI = function(a, b, c) {
            var d;
            return !(null == (d = a.m.get("string" === typeof b ? b : b.id)) || !d.delete(c))
        };
    pI.prototype.dispatchEvent = function(a, b, c) {
        var d = this,
            e, f, g, h, k, l, m, n;
        return _.Bb(function(p) {
            e = "string" === typeof a ? a : a.id;
            f = d.m.get(e);
            if (null == (g = f) || !g.size) return p.return();
            h = "function" === typeof window.CustomEvent ? new CustomEvent(e, {
                detail: c,
                bubbles: !0,
                cancelable: !0
            }) : function() {
                var r = document.createEvent("CustomEvent");
                r.initCustomEvent(e, !0, !0, c);
                return r
            }();
            k = [];
            l = {};
            m = _.x(f);
            for (n = m.next(); !n.done; l = {
                    Ic: l.Ic
                }, n = m.next()) l.Ic = n.value, k.push(new _.v.Promise(function(r) {
                return function(t) {
                    return _.Bb(function(w) {
                        if (1 == w.j) return Cb(w, 0, 2);
                        ei(d.context, b, function() {
                            d.m.has(e) && f.has(r.Ic) && r.Ic(h)
                        }, !0);
                        t();
                        w.j = 0
                    })
                }
            }(l)));
            return Cb(p, _.v.Promise.all(k), 0)
        })
    };
    var sI = new oI,
        tI = new oI,
        Eq = new oI,
        uI = new oI,
        Gq = new oI,
        vI = new oI,
        wI = new oI,
        Ro = new oI,
        xI = new oI,
        yI = new oI;
    var zI = function() {
        this.data = void 0;
        this.status = 0;
        this.j = []
    };
    zI.prototype.dd = function() {
        return this.j
    };
    zI.prototype.Rd = function() {
        this.j = []
    };
    var AI, EI, HI, Ar, II, JI, DI, CI, BI, KI;
    AI = function() {
        this.j = new _.v.Map;
        this.B = 0;
        this.o = new _.v.Map;
        this.Wc = null;
        this.H = this.m = this.J = this.l = 0;
        this.I = new zI
    };
    EI = function(a, b) {
        a.j.get(b) || (a.j.set(b, {
            Db: !0,
            Ae: "",
            Ib: "",
            Df: 0,
            pf: 0,
            xe: [],
            ye: [],
            wb: !1
        }), _.qo(b, function() {
            a.j.delete(b);
            BI(a, b)
        }), b.Z(tI, function(c) {
            c = c.detail;
            var d = (0, B.K)(a.j.get(b));
            d.Ae = y(c, 33) || "";
            d.wb = !0;
            CI(a, b, function() {
                return void(d.Ae = "")
            });
            DI(a, b, function() {
                return void(d.wb = !1)
            })
        }))
    };
    _.Fq = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.j.get(b)) ? void 0 : c.Db) ? d : !1
    };
    _.FI = function(a, b) {
        if (a = a.j.get(b)) a.Db = !1
    };
    _.GI = function(a, b) {
        if (a = a.j.get(b)) a.Db = !0
    };
    HI = function(a, b) {
        if (!b.length) return [];
        var c = Nh(b[0].getAdUnitPath());
        b.every(function(g) {
            return Nh(g.getAdUnitPath()) === c
        });
        var d = [];
        a = _.x(a.j);
        for (var e = a.next(); !e.done; e = a.next()) {
            var f = _.x(e.value);
            e = f.next().value;
            (f = f.next().value.Ae) && Nh(e.getAdUnitPath()) === c && !_.u(b, "includes").call(b, e) && d.push(f)
        }
        return d
    };
    Ar = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.j.get(b)) ? void 0 : c.Ib) ? d : ""
    };
    II = function(a, b) {
        return (a = a.j.get(b)) ? a.Df - 1 : 0
    };
    JI = function(a, b) {
        var c = (0, B.K)(a.o.get(b)) - 1;
        0 === c ? a.o.delete(b) : a.o.set(b, c);
        return c
    };
    DI = function(a, b, c) {
        (a = a.j.get(b)) && a.xe.push(c)
    };
    CI = function(a, b, c) {
        (a = a.j.get(b)) && a.ye.push(c)
    };
    BI = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.ye.slice(), a.ye.length = 0, a = _.x(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    KI = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.xe.slice(), a.xe.length = 0, a = _.x(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    AI.prototype.wb = function(a) {
        var b, c;
        return null != (c = null == (b = this.j.get(a)) ? void 0 : b.wb) ? c : !1
    };
    var LI = function(a, b, c) {
            if (a = a.j.get(b)) a.Cf = c
        },
        MI = function(a, b) {
            if (a = a.j.get(b)) {
                var c;
                null == (c = a.Cf) || c.Da();
                delete a.Cf
            }
        };
    var NI = function() {
        var a = {};
        return a.adsense_channel_ids = "channel", a.adsense_ad_types = "ad_type", a.adsense_ad_format = "format", a.adsense_background_color = "color_bg", a.adsense_border_color = "color_border", a.adsense_link_color = "color_link", a.adsense_text_color = "color_text", a.adsense_url_color = "color_url", a.page_url = "url", a.adsense_allow_expandable_ads = "ea", a.adsense_encoding = "oe", a.adsense_family_safe = "adsafe", a.adsense_flash_version = "flash", a.adsense_font_face = "f", a.adsense_hints = "hints", a.adsense_keyword_type = "kw_type", a.adsense_keywords = "kw", a.adsense_test_mode = "adtest", a.alternate_ad_iframe_color = "alt_color", a.alternate_ad_url = "alternate_ad_url", a.demographic_age = "cust_age", a.demographic_gender = "cust_gender", a.document_language = "hl", a
    };
    var Z = function(a, b, c) {
        PB.call(this, b, c);
        this.context = a
    };
    _.L(Z, PB);
    Z.prototype.R = function(a) {
        ci(this.context, this.id, a);
        var b, c;
        null == (b = window.console) || null == (c = b.error) || c.call(b, a)
    };
    var OI = function(a, b, c, d, e) {
        var f = null,
            g = Zh(a.context, b, e);
        _.zb(c, d, g) && (f = function() {
            return _.Ae(c, d, g)
        }, _.qo(a, f));
        return f
    };
    var PI = /(<head(\s+[^>]*)?>)/i,
        Wq = function(a, b, c, d, e) {
            Z.call(this, a, 665);
            this.C = V(this);
            this.l = W(this, b);
            this.D = Y(this, c);
            this.G = W(this, d);
            this.A = W(this, e)
        };
    _.L(Wq, Z);
    Wq.prototype.j = function() {
        var a;
        0 === this.l.value.kind && null != (a = this.D.value) && y(a, 1) ? (a = this.l.value.Ta, this.A.value || Wa() || (a = a.replace(PI, "$1<meta http-equiv=Content-Security-Policy content=\"script-src https://cdn.ampproject.org/;object-src 'none';child-src blob:;frame-src 'none'\">")), this.G.value && !this.A.value && (a = a.replace(PI, '$1<meta name="referrer" content="origin">')), N(this.C, {
            kind: 0,
            Ta: a
        })) : N(this.C, this.l.value)
    };
    var Br = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 718);
        this.D = Y(this, c);
        this.l = Y(this, d);
        SB(this, e);
        this.G = W(this, f);
        this.A = W(this, g);
        this.N = W(this, h);
        this.L = rI(b, xI)
    };
    _.L(Br, Z);
    Br.prototype.j = function() {
        var a = this,
            b, c, d;
        return _.Bb(function(e) {
            if (1 == e.j) {
                var f = !a.N.value;
                if (null == a.l.value || "height" !== a.D.value || f) return e.return();
                b = a.G.value;
                c = a.A.value;
                QI(c, !1);
                _.$x(c, "min-width", "100%");
                _.$x(b, "min-width", "100%");
                return Cb(e, a.L, 2)
            }
            if (a.H) return e.return();
            d = b.contentDocument;
            if (!d) return e.return();
            f = d.body.offsetWidth;
            b.setAttribute("height", String(d.body.offsetHeight));
            b.setAttribute("width", String(f));
            QI(c, !0);
            e.j = 0
        })
    };
    var QI = function(a, b) {
        _.$x(a, "visibility", b ? "visible" : "hidden")
    };
    var Nk = new _.v.Map,
        Mk = new _.v.Map;
    var Pk = function(a, b) {
        this.push = H(a, 76, b.push.bind(b))
    };
    var Rk = function(a, b) {
        this.messageId = a;
        this.messageArgs = b
    };
    Rk.prototype.getMessageId = function() {
        return this.messageId
    };
    Rk.prototype.getMessageArgs = function() {
        return this.messageArgs
    };
    var RI = Sk(2),
        SI = Sk(3),
        TI = Sk(4),
        UI = Sk(5),
        VI = Sk(6),
        WI = Sk(12),
        XI = Sk(14),
        YI = Sk(16),
        ZI = Sk(19),
        $I = Sk(20),
        aJ = Sk(23),
        bJ = Sk(26),
        cJ = Sk(28),
        dJ = Sk(149),
        eJ = Sk(30),
        fJ = Sk(31),
        gJ = Sk(34),
        hJ = Sk(35),
        iJ = Sk(36),
        Jp = Sk(38),
        jJ = Sk(40),
        kJ = Sk(48),
        lJ = Sk(50),
        mJ = Sk(60),
        nJ = Sk(63),
        oJ = Sk(64),
        pJ = Sk(66),
        qJ = Sk(68),
        rJ = Sk(69),
        sJ = Sk(70),
        tJ = Sk(71),
        uJ = Sk(78),
        vJ = Sk(80),
        wJ = Sk(82),
        xJ = Sk(84),
        yJ = Sk(85),
        zJ = Sk(87),
        vl = Sk(88),
        AJ = Sk(92),
        BJ = Sk(93),
        CJ = Sk(99),
        DJ = Sk(103),
        EJ = Sk(104),
        FJ = Sk(105),
        GJ = Sk(106),
        HJ = Sk(107),
        IJ = Sk(108),
        JJ = Sk(113),
        KJ = Sk(114),
        LJ = Sk(115),
        MJ = Sk(117),
        NJ = Sk(118),
        OJ = Sk(119),
        Ol = Sk(121),
        PJ = Sk(122),
        QJ = Sk(123),
        eq = Sk(125),
        RJ = Sk(126),
        SJ = Sk(127),
        TJ = Sk(144),
        tp = Sk(129),
        vp = Sk(132),
        UJ = Sk(134),
        VJ = Sk(135),
        WJ = Sk(136),
        XJ = Sk(137),
        YJ = Sk(138),
        ZJ = Sk(139),
        $J = Sk(140),
        sq = Sk(142),
        aK = Sk(143),
        bK = Sk(145),
        cK = Sk(147),
        Qp = Sk(148),
        dK = Sk(150);
    var eK = function(a, b, c) {
        var d = this;
        this.addEventListener = H(a, 86, function(e, f) {
            if ("function" !== typeof f) return ql(b, Uk("Service.addEventListener", [e, f])), d;
            var g = Vk(e);
            if (!g) return ql(b, BJ(e)), d;
            c.addEventListener(g, f);
            return d
        });
        this.removeEventListener = H(a, 904, function(e, f) {
            var g = Vk(e);
            "function" === typeof f && g ? c.removeEventListener(g, f) : ql(b, Uk("Service.removeEventListener", [e, f]))
        });
        this.getSlots = H(a, 573, function() {
            return c.m.map(function(e) {
                return (0, B.K)(e.j)
            })
        });
        this.getSlotIdMap = H(a, 574, function() {
            for (var e = {}, f = _.x(c.m), g = f.next(); !g.done; g = f.next()) g = g.value, e[g.toString()] = g.j;
            return e
        });
        this.getName = H(a, 575, function() {
            return c.getName()
        })
    };
    var Wk = function(a, b, c) {
        eK.call(this, a, b, c);
        this.notifyUnfilledSlots = H(a, 69, function(d) {
            c.Db && fK(c, gK(c, d))
        });
        this.refreshAllSlots = H(a, 60, function() {
            c.Db && fK(c)
        });
        this.setVideoSession = H(a, 61, function(d, e, f) {
            c.G = e;
            c.L = f;
            "number" === typeof d && (e = vj().j, _.z(e, 29, d))
        });
        this.getDisplayAdsCorrelator = H(a, 62, function(d) {
            return hK(c, d)
        });
        this.getVideoStreamCorrelator = H(a, 63, function() {
            var d = vj().j;
            d = y(d, 29);
            return null != d ? d : 0
        });
        this.isSlotAPersistentRoadblock = H(a, 64, function(d) {
            var e = _.u(c.m, "find").call(c.m, function(f) {
                return f.j === d
            });
            return !!e && iK(c, e)
        });
        this.onImplementationLoaded = H(a, 65, function() {
            c.j.info(kJ("GPT CompanionAds"))
        });
        this.slotRenderEnded = H(a, 67, function(d, e, f) {
            var g = _.u(c.m, "find").call(c.m, function(h) {
                return h.j === d
            });
            return g && jK(c, g, e, f)
        });
        this.setRefreshUnfilledSlots = H(a, 59, function(d) {
            return c.setRefreshUnfilledSlots(d)
        })
    };
    _.L(Wk, eK);
    var Yk = function(a, b, c) {
        eK.call(this, a, b, c);
        this.setContent = H(a, 72, function(d) {
            var e = _.u(c.m, "find").call(c.m, function(f) {
                return f.j === d
            });
            ql(b, TJ(), e)
        })
    };
    _.L(Yk, eK);
    var kK = _.O(["https://console.googletagservices.com/pubconsole/loader.js"]),
        jl = _.A(kK),
        nl, ml = !1,
        el = !1,
        gl = !1;
    var Gp = function(a, b) {
        this.getAllEvents = H(a, 563, function() {
            return el ? lK(b).slice() : []
        });
        this.getEventsBySlot = H(a, 565, function(c) {
            return el ? mK(b, c).slice() : []
        });
        this.getEventsByLevel = H(a, 566, function(c) {
            return el ? nK(b, c).slice() : []
        })
    };
    var yl = function(a, b, c, d) {
        var e = this,
            f = c.getSlotId(),
            g = vj().j,
            h = (0, B.K)(jo(vj(), f.getDomId()));
        this.set = H(a, 83, function(k, l) {
            "page_url" === k && l && (k = [sl(tl(new ul, k), [String(l)])], _.Ad(h, 3, k));
            return e
        });
        this.get = H(a, 84, function(k) {
            if ("page_url" !== k) return null;
            var l, m;
            return null != (m = null == (l = (_.C = (0, B.K)(h.wa()), _.u(_.C, "find")).call(_.C, function(n) {
                return y(n, 1) === k
            })) ? void 0 : _.hn(l, 2)[0]) ? m : null
        });
        this.setClickUrl = H(a, 79, function(k) {
            "string" === typeof k ? h.setClickUrl(k) : ql(b, Uk("Slot.setClickUrl", [k]), f);
            return e
        });
        this.setTargeting = H(a, 81, function(k, l) {
            wl(f, h, k, l, b);
            return e
        });
        this.updateTargetingFromMap = H(a, 85, function(k) {
            xl(f, h, k, b);
            return e
        });
        this.display = H(a, 78, function() {
            oK(d, f, ej(g, vj().o))
        });
        this.setTagForChildDirectedTreatment = H(a, 80, function(k) {
            if (0 === k || 1 === k) {
                var l = yn(g) || new lH;
                l.setTagForChildDirectedTreatment(k);
                _.Th(g, 25, l)
            }
            return e
        });
        this.setForceSafeFrame = H(a, 567, function(k) {
            "boolean" === typeof k ? _.z(h, 12, k) : ql(b, Uk("PassbackSlot.setForceSafeFrame", [String(k)]), f);
            return e
        });
        this.setTagForUnderAgeOfConsent = H(a, 448, function(k) {
            if (0 === k || 1 === k) {
                var l = yn(g) || new lH;
                l.setTagForUnderAgeOfConsent(k);
                _.Th(g, 25, l)
            }
            return e
        })
    };
    var Qn = function(a, b) {
        this.push = H(a, 932, function(c) {
            b.push(c)
        })
    };
    var jp = {
        dj: 0,
        aj: 1,
        bj: 2,
        cj: 3
    };
    var Bl = {
            REWARDED: 4,
            TOP_ANCHOR: 2,
            BOTTOM_ANCHOR: 3,
            INTERSTITIAL: 5
        },
        Dl = {
            IAB_AUDIENCE_1_1: 1,
            IAB_CONTENT_2_1: 2,
            IAB_CONTENT_2_2: 3
        },
        Cl = {
            PURCHASED: 1,
            ORGANIC: 2
        };
    var lm = function(a, b, c) {
        pI.call(this, a);
        this.slotId = b;
        this.j = c
    };
    _.L(lm, pI);
    lm.prototype.getSlotId = function() {
        return this.slotId
    };
    var pK = "",
        Hl = null,
        Nl = _.Zs(function() {
            var a, b;
            null == (a = window.console) || null == (b = a.warn) || b.call(a, "googletag.pubads().setSafeFrameConfig({useUniqueDomain: ...}) has been removed, and no longer has any effect.")
        });
    var Ee = function(a, b, c, d) {
        pI.call(this, a);
        this.adUnitPath = b;
        this.ib = d;
        this.j = null;
        this.id = this.adUnitPath + "_" + c
    };
    _.L(Ee, pI);
    _.aa = Ee.prototype;
    _.aa.getId = function() {
        return this.id
    };
    _.aa.getAdUnitPath = function() {
        return this.adUnitPath
    };
    _.aa.getName = function() {
        return this.adUnitPath
    };
    _.aa.toString = function() {
        return this.getId()
    };
    _.aa.getDomId = function() {
        return this.ib
    };
    var qK = function(a, b) {
        a.j = b
    };
    var Tl = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;
    var rK = _.Zs(function() {
            return void Mx("google_DisableInitialLoad is deprecated and will be removed. Please use googletag.pubads().isInitialLoadDisabled() instead to check if initial load has been disabled.")
        }),
        sK = _.Zs(function() {
            return void Mx("googletag.pubads().setCookieOptions() has been removed, and no longer has any effect. Consider migrating to Limited Ads.")
        }),
        tK = _.Zs(function() {
            return void Mx("The following functions are deprecated: googletag.pubads().setTagForChildDirectedTreatment(), googletag.pubads().clearTagForChildDirectedTreatment(), googletag.pubads().setRequestNonPersonalizedAds(), and googletag.pubads().setTagForUnderAgeOfConsent(). Please use googletag.pubads().setPrivacySettings() instead.")
        }),
        uK = function() {
            Object.defineProperty(window, "google_DisableInitialLoad", {
                get: function() {
                    rK();
                    return !0
                },
                set: function() {
                    rK()
                },
                configurable: !0
            })
        },
        nm = function(a, b, c, d, e) {
            eK.call(this, a, b, c);
            var f = this,
                g = vj().j,
                h = vj().o,
                k = !1;
            this.setTargeting = H(a, 1, function(l, m) {
                var n = null;
                "string" === typeof m ? n = [m] : Array.isArray(m) ? n = m : za(m) && (n = _.u(Array, "from").call(Array, m));
                var p = "string" === typeof l && !pl(l);
                n = n && Da(n);
                var r, t = null != (r = null == n ? void 0 : n.every(function(w) {
                    return "string" === typeof w
                })) ? r : !1;
                if (!p || !t) return ql(b, Uk("PubAdsService.setTargeting", [l, m])), f;
                m = n;
                p = (_.C = Qe(g, ul, 2), _.u(_.C, "find")).call(_.C, function(w) {
                    return y(w, 1) === l
                });
                if ("gpt-beta" === l) {
                    if (c.B) return ql(b, GJ(m.join())), f;
                    if (p) return ql(b, HJ(m.join())), f;
                    m = jm(m, e)
                }
                p ? sl(p, m) : (p = sl(tl(new ul, l), m), _.Zf(g, 2, ul, p));
                b.info(vl(l, m.join(), c.getName()));
                return f
            });
            this.clearTargeting = H(a, 2, function(l) {
                if (void 0 === l) return _.Ad(g, 2), b.info(EJ(c.getName())), f;
                if ("gpt-beta" === l) return ql(b, IJ(l)), f;
                var m = Qe(g, ul, 2),
                    n = _.u(m, "findIndex").call(m, function(p) {
                        return y(p, 1) === l
                    });
                if (0 > n) return ql(b, xJ(l, c.getName())), f;
                m.splice(n, 1);
                _.Ad(g, 2, m);
                b.info(wJ(l, c.getName()));
                return f
            });
            this.getTargeting = H(a, 38, function(l) {
                if ("string" !== typeof l) return ql(b, Uk("PubAdsService.getTargeting", [l])), [];
                var m = (_.C = Qe(g, ul, 2), _.u(_.C, "find")).call(_.C, function(n) {
                    return y(n, 1) === l
                });
                return m ? _.hn(m, 2).slice() : []
            });
            this.getTargetingKeys = H(a, 39, function() {
                return Qe(g, ul, 2).map(function(l) {
                    return (0, B.K)(y(l, 1))
                })
            });
            this.setCategoryExclusion = H(a, 3, function(l) {
                if ("string" !== typeof l || pl(l)) return ql(b, Uk("PubAdsService.setCategoryExclusion", [l])), f;
                (_.C = _.hn(g, 3), _.u(_.C, "includes")).call(_.C, l) || Pu(g, 3, l);
                b.info(yJ(l));
                return f
            });
            this.clearCategoryExclusions = H(a, 4, function() {
                _.z(g, 3, Vc);
                b.info(zJ());
                return f
            });
            this.disableInitialLoad = H(a, 5, function() {
                _.z(g, 4, !0);
                k || (k = !0, uK())
            });
            this.enableSingleRequest = H(a, 6, function() {
                if (c.B && !J(g, 6)) return ql(b, mJ("PubAdsService.enableSingleRequest")), !1;
                b.info(nJ("single request"));
                _.z(g, 6, !0);
                return !0
            });
            this.enableAsyncRendering = H(a, 7, function() {
                return !0
            });
            this.enableSyncRendering = H(a, 8, function() {
                Mx("GPT synchronous rendering is no longer supported, ads will be requested and rendered asynchronously. See https://support.google.com/admanager/answer/9212594 for more details.");
                return !1
            });
            this.enableLazyLoad = H(a, 485, function(l) {
                var m = new Zq;
                m = _.z(m, 1, 800);
                m = _.z(m, 2, 400);
                m = hH(m, 3);
                if (_.pa(l)) {
                    var n = l.fetchMarginPercent;
                    "number" === typeof n && (0 <= n ? _.z(m, 1, n) : -1 === n && wf(m, 1));
                    n = l.renderMarginPercent;
                    "number" === typeof n && (0 <= n ? _.z(m, 2, n) : -1 === n && wf(m, 2));
                    l = l.mobileScaling;
                    "number" === typeof l && (0 < l ? _.z(m, 3, _.Ac(l)) : -1 === l && _.z(m, 3, _.Ac(1)))
                }
                _.E(Jq) && !window.IntersectionObserver && (go(m, 1) || go(m, 2)) ? ql(b, dK()) : _.Th(g, 5, m)
            });
            this.setCentering = H(a, 9, function(l) {
                l = !!l;
                b.info(oJ("centering", String(l)));
                _.z(g, 15, l)
            });
            this.definePassback = H(a, 10, function(l, m) {
                return (l = mm(a, b, c, l, m, d)) && l.xf
            });
            this.refresh = H(a, 11, function() {
                var l = _.xb.apply(0, arguments),
                    m = _.x(l),
                    n = m.next().value;
                m = m.next().value;
                m = void 0 === m ? {} : m;
                n && !Array.isArray(n) || !_.pa(m) || m.changeCorrelator && "boolean" !== typeof m.changeCorrelator ? ql(b, Uk("PubAdsService.refresh", l)) : (m && !1 === m.changeCorrelator || g.setCorrelator(Qx()), n = n ? hm(n, c) : c.m, c.refresh(ej(g, h), n) || ql(b, Uk("PubAdsService.refresh", l)))
            });
            this.enableVideoAds = H(a, 12, function() {
                _.z(g, 21, !0);
                vK(c, g)
            });
            this.setVideoContent = H(a, 13, function(l, m) {
                wK(c, l, m, g)
            });
            this.collapseEmptyDivs = H(a, 14, function(l) {
                l = void 0 === l ? !1 : l;
                _.z(g, 11, !0);
                l = !!l;
                _.z(g, 10, l);
                b.info(uJ(String(l)));
                return !!J(g, 11)
            });
            this.clear = H(a, 15, function(l) {
                if (Array.isArray(l)) return xK(c, g, h, hm(l, c));
                if (void 0 === l) return xK(c, g, h, c.m);
                ql(b, Uk("PubAdsService.clear", [l]));
                return !1
            });
            this.setLocation = H(a, 16, function(l) {
                if ("string" !== typeof l) return ql(b, Uk("PubAdsService.setLocation", [l])), f;
                _.z(g, 8, l);
                return f
            });
            this.setCookieOptions = H(a, 17, function() {
                sK();
                return f
            });
            this.setTagForChildDirectedTreatment = H(a, 18, function(l) {
                tK();
                if (1 !== l && 0 !== l) return ql(b, PJ("PubadsService.setTagForChildDirectedTreatment", Pl(l), "0,1")), f;
                var m = yn(g) || new lH;
                m.setTagForChildDirectedTreatment(l);
                _.Th(g, 25, m);
                return f
            });
            this.clearTagForChildDirectedTreatment = H(a, 19, function() {
                tK();
                var l = yn(g);
                if (!l) return f;
                l.clearTagForChildDirectedTreatment();
                _.Th(g, 25, l);
                return f
            });
            this.setPublisherProvidedId = H(a, 20, function(l) {
                l = String(l);
                b.info(oJ("PPID", l));
                _.z(g, 16, l);
                return f
            });
            this.set = H(a, 21, function(l, m) {
                if ("string" !== typeof l || !l.length || void 0 === NI()[l] || "string" !== typeof m) return ql(b, Uk("PubAdsService.set", [l, m])), f;
                var n = (_.C = g.wa(), _.u(_.C, "find")).call(_.C, function(p) {
                    return y(p, 1) === l
                });
                n ? sl(n, [m]) : (n = gH(tl(new ul, l), m), _.Zf(g, 14, ul, n));
                b.info(iJ(l, String(m), c.getName()));
                return f
            });
            this.get = H(a, 22, function(l) {
                if ("string" !== typeof l) return ql(b, Uk("PubAdsService.get", [l])), null;
                var m = (_.C = g.wa(), _.u(_.C, "find")).call(_.C, function(n) {
                    return y(n, 1) === l
                });
                return (m = m && _.hn(m, 2)) ? m[0] : null
            });
            this.getAttributeKeys = H(a, 23, function() {
                return g.wa().map(function(l) {
                    return (0, B.K)(y(l, 1))
                })
            });
            this.display = H(a, 24, function(l, m, n, p) {
                return void c.display(l, m, d, n, p)
            });
            this.updateCorrelator = H(a, 25, function() {
                Mx(Vl("update"));
                ql(b, LJ());
                g.setCorrelator(Qx());
                return f
            });
            this.defineOutOfPagePassback = H(a, 35, function(l) {
                l = mm(a, b, c, l, [1, 1], d);
                if (!l) return null;
                _.z(l.fb, 15, 1);
                return l.xf
            });
            this.setForceSafeFrame = H(a, 36, function(l) {
                if ("boolean" !== typeof l) return ql(b, Uk("PubAdsService.setForceSafeFrame", [Pl(l)])), f;
                _.z(g, 13, l);
                return f
            });
            this.setSafeFrameConfig = H(a, 37, function(l) {
                var m = Ql(b, l);
                if (!m) return ql(b, Uk("PubAdsService.setSafeFrameConfig", [l])), f;
                _.Th(g, 18, m);
                return f
            });
            this.setRequestNonPersonalizedAds = H(a, 445, function(l) {
                tK();
                if (0 !== l && 1 !== l) return ql(b, PJ("PubAdsService.setRequestNonPersonalizedAds", Pl(l), "0,1")), f;
                var m = yn(g) || new lH;
                _.z(m, 8, !!l);
                _.Th(g, 25, m);
                return f
            });
            this.setTagForUnderAgeOfConsent = H(a, 447, function(l) {
                l = void 0 === l ? 2 : l;
                tK();
                if (2 !== l && 0 !== l && 1 !== l) return ql(b, PJ("PubadsService.setTagForUnderAgeOfConsent", Pl(l), "2,0,1")), f;
                var m = yn(g) || new lH;
                m.setTagForUnderAgeOfConsent(l);
                _.Th(g, 25, m);
                return f
            });
            this.getCorrelator = H(a, 27, function() {
                return String(y(g, 26))
            });
            this.getTagSessionCorrelator = H(a, 631, function() {
                return tf(_.q)
            });
            this.getVideoContent = H(a, 30, function() {
                return yK(c, g)
            });
            this.getVersion = H(a, 568, function() {
                return a.Ab ? String(a.Ab) : a.Na
            });
            this.forceExperiment = H(a, 569, function(l) {
                return void c.forceExperiment(l)
            });
            this.setCorrelator = H(a, 28, function(l) {
                Mx(Vl("set"));
                ql(b, KJ());
                if (Wi(window)) return f;
                if (!ym(l)) return ql(b, Uk("PubadsService.setCorrelator", [Pl(l)])), f;
                l = g.setCorrelator(l);
                _.z(l, 27, !0);
                return f
            });
            this.markAsAmp = H(a, 570, function() {
                window.console && window.console.warn && window.console.warn("googletag.pubads().markAsAmp() is deprecated and ignored.")
            });
            this.isSRA = H(a, 571, function() {
                return !!J(g, 6)
            });
            this.setImaContent = H(a, 328, function(l, m) {
                _.dg(g, 22) ? wK(c, l, m, g) : (_.z(g, 21, !0), vK(c, g), "string" === typeof l && _.z(g, 19, l), "string" === typeof m && _.z(g, 20, m))
            });
            this.getImaContent = H(a, 329, function() {
                return _.dg(g, 22) ? yK(c, g) : c.B ? {
                    vid: y(g, 19) || "",
                    cmsid: y(g, 20) || ""
                } : null
            });
            this.isInitialLoadDisabled = H(a, 572, function() {
                return !!J(g, 4)
            });
            this.setPrivacySettings = H(a, 648, function(l) {
                if (!_.pa(l)) return ql(b, Uk("PubAdsService.setPrivacySettings", [l])), f;
                var m = l.restrictDataProcessing,
                    n = l.childDirectedTreatment,
                    p = l.underAgeOfConsent,
                    r = l.limitedAds,
                    t = l.nonPersonalizedAds,
                    w = l.userOptedOutOfPersonalization,
                    D = l.trafficSource,
                    F, I = null != (F = yn(g)) ? F : new lH;
                "boolean" === typeof t ? _.z(I, 8, t) : void 0 !== t && ql(b, Ol("PubAdsService.setPrivacySettings", Pl(l), "nonPersonalizedAds", Pl(t)));
                "boolean" === typeof w ? _.z(I, 13, w) : void 0 !== w && ql(b, Ol("PubAdsService.setPrivacySettings", Pl(l), "userOptedOutOfPersonalization", Pl(w)));
                "boolean" === typeof m ? _.z(I, 1, m) : void 0 !== m && ql(b, Ol("PubAdsService.setPrivacySettings", Pl(l), "restrictDataProcessing", Pl(m)));
                "boolean" === typeof r ? (m = Ul(), r && !J(I, 9) && a.Dc && (t = a.Eb, w = Uh(a), F = new jy, F = _.hd(F, 1, !0), F = _.hd(F, 2, m), w = _.Wh(w, 11, Xh, F), xe(t, w)), m ? _.z(I, 9, r) : r && ql(b, cK())) : void 0 !== r && ql(b, Ol("PubAdsService.setPrivacySettings", Pl(l), "limitedAds", Pl(r)));
                void 0 !== p && (null === p ? I.setTagForUnderAgeOfConsent(2) : !1 === p ? I.setTagForUnderAgeOfConsent(0) : !0 === p ? I.setTagForUnderAgeOfConsent(1) : ql(b, Ol("PubAdsService.setPrivacySettings", Pl(l), "underAgeOfConsent", Pl(p))));
                void 0 !== n && (null === n ? I.clearTagForChildDirectedTreatment() : !1 === n ? I.setTagForChildDirectedTreatment(0) : !0 === n ? I.setTagForChildDirectedTreatment(1) : ql(b, Ol("PubAdsService.setPrivacySettings", Pl(l), "childDirectedTreatment", Pl(n))));
                void 0 !== D && (null === D ? wf(I, 10) : (_.C = _.u(Object, "values").call(Object, Cl), _.u(_.C, "includes")).call(_.C, D) ? _.z(I, 10, D) : ql(b, Ol("PubAdsService.setPrivacySettings", Pl(l), "trafficSource", Pl(D))));
                _.Th(g, 25, I);
                return f
            })
        };
    _.L(nm, eK);
    var Hp = function(a, b) {
        var c = this,
            d = [],
            e = [];
        this.addSize = Zh(a, 88, function(f, g) {
            var h;
            if (h = rm(f)) h = g, h = qm(h) || Array.isArray(h) && h.every(qm);
            h ? (_.E(tz) && (h = Am(g), h !== g && (g = Tk([f, g]), g = g.substring(1, g.length - 1), ql(b, new Rk(151, ["SizeMappingBuilder.addSize", g])), g = h)), d.push([f, g])) : (e.push([f, g]), ql(b, Uk("SizeMappingBuilder.addSize", [f, g])));
            return c
        });
        this.build = Zh(a, 89, function() {
            if (e.length) return ql(b, gJ(Pl(e))), null;
            xa(d);
            return d
        })
    };
    var zK = function(a, b) {
        this.getId = H(a, 593, function() {
            return b.getId()
        });
        this.getAdUnitPath = H(a, 594, function() {
            return b.getAdUnitPath()
        });
        this.getName = H(a, 595, function() {
            return b.getName()
        });
        this.toString = H(a, 596, function() {
            return b.toString()
        });
        this.getDomId = H(a, 597, function() {
            return b.getDomId()
        })
    };
    var qi = function(a) {
        _.P.call(this, a, -1, AK)
    };
    _.L(qi, _.P);
    var AK = [2];
    var CK = function(a) {
        _.P.call(this, a, -1, BK)
    };
    _.L(CK, _.P);
    CK.prototype.getAdUnitPath = function() {
        return y(this, 1)
    };
    CK.prototype.getDomId = function() {
        return y(this, 2)
    };
    var DK = function(a, b) {
        _.z(a, 2, b)
    };
    CK.prototype.wa = function() {
        return Qe(this, ul, 3)
    };
    CK.prototype.getServices = function(a) {
        return Ou(this, 4, a)
    };
    var EK = function(a, b) {
        _.Ad(a, 5, b)
    };
    CK.prototype.getClickUrl = function() {
        return y(this, 7)
    };
    CK.prototype.setClickUrl = function(a) {
        return _.z(this, 7, a)
    };
    CK.prototype.getCategoryExclusions = function(a) {
        return Ou(this, 8, a)
    };
    var rl = function(a) {
        return Qe(a, ul, 9)
    };
    CK.prototype.Za = function() {
        return Bf(this, Ll, 13)
    };
    var Om = function(a) {
            return _.Se(a, 15, 0)
        },
        ko = function(a, b) {
            _.Zf(a, 27, Tv, b)
        },
        FK = function(a) {
            a = dd(a, y(a, 26), oc(a.fa));
            return null == a ? a : a
        },
        BK = [3, 4, 5, 6, 8, 9, 27];
    var GK = function() {
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.creativeId = this.campaignId = this.advertiserId = null;
            this.isBackfill = !1;
            this.encryptedTroubleshootingInfo = this.creativeTemplateId = this.companyIds = this.yieldGroupIds = null
        },
        HK = function(a, b) {
            a.advertiserId = b
        },
        IK = function(a, b) {
            a.campaignId = b
        },
        JK = function(a, b) {
            a.yieldGroupIds = b
        },
        KK = function(a, b) {
            a.companyIds = b
        };
    var LK = function(a, b) {
        this.width = a;
        this.height = b
    };
    LK.prototype.getWidth = function() {
        return this.width
    };
    LK.prototype.getHeight = function() {
        return this.height
    };
    var Dm = function(a, b, c) {
        var d = this,
            e = (0, B.K)(jo(vj(), c.getDomId())),
            f = "",
            g = null,
            h = function() {
                return ""
            },
            k = "",
            l = !1;
        _.qo(c, function() {
            e = new CK;
            f = "";
            g = null;
            h = function() {
                return ""
            };
            k = ""
        });
        c.Z(Eq, function(n) {
            var p = n.detail;
            n = p.Xe;
            p = p.isBackfill;
            n && (f = n, l = p)
        });
        this.set = H(a, 40, function(n, p) {
            if ("string" !== typeof n || "string" !== typeof p || void 0 === NI()[n]) return ql(b, Uk("Slot.set", [n, p]), c), d;
            var r = (_.C = e.wa(), _.u(_.C, "find")).call(_.C, function(t) {
                return y(t, 1) === n
            });
            r ? sl(r, [p]) : (r = tl(new ul, n), gH(r, p), _.Zf(e, 3, ul, r));
            return d
        });
        this.get = H(a, 41, function(n) {
            if ("string" !== typeof n) return ql(b, Uk("Slot.get", [n]), c), null;
            var p = (_.C = e.wa(), _.u(_.C, "find")).call(_.C, function(r) {
                return y(r, 1) === n
            });
            return (p = p && _.hn(p, 2)) ? p[0] : null
        });
        this.getAttributeKeys = H(a, 42, function() {
            return e.wa().map(function(n) {
                return (0, B.K)(y(n, 1))
            })
        });
        this.addService = H(a, 43, function(n) {
            n = Nk.get(n);
            if (!n) return ql(b, Uk("Slot.addService", [n]), c), d;
            var p = n.getName();
            if ((_.C = _.hn(e, 4), _.u(_.C, "includes")).call(_.C, p)) return b.info(WI(p, c.toString()), c), d;
            n.slotAdded(c, e);
            return d
        });
        this.defineSizeMapping = H(a, 44, function(n) {
            try {
                var p = e;
                if (!Array.isArray(n)) throw new Bm("Size mapping must be an array");
                var r = n.map(Cm);
                _.Ad(p, 6, r)
            } catch (t) {
                n = t, ci(a, 44, n), Mx("Incorrect usage of googletag.Slot defineSizeMapping: " + n.message)
            }
            return d
        });
        this.setClickUrl = H(a, 45, function(n) {
            if ("string" !== typeof n) return ql(b, Uk("Slot.setClickUrl", [n]), c), d;
            e.setClickUrl(n);
            return d
        });
        this.setCategoryExclusion = H(a, 46, function(n) {
            "string" !== typeof n || pl(n) ? ql(b, Uk("Slot.setCategoryExclusion", [n]), c) : ((_.C = _.hn(e, 8), _.u(_.C, "includes")).call(_.C, n) || Pu(e, 8, n), b.info(XI(n), c));
            return d
        });
        this.clearCategoryExclusions = H(a, 47, function() {
            _.z(e, 8, Vc);
            b.info(YI(), c);
            return d
        });
        this.getCategoryExclusions = H(a, 48, function() {
            return _.hn(e, 8).slice()
        });
        this.setTargeting = H(a, 49, function(n, p) {
            wl(c, e, n, p, b);
            return d
        });
        this.updateTargetingFromMap = H(a, 649, function(n) {
            xl(c, e, n, b);
            return d
        });
        this.clearTargeting = H(a, 50, function(n) {
            if (void 0 === n) return _.Ad(e, 9), b.info(ZI(c.getAdUnitPath()), c), d;
            var p = rl(e),
                r = _.u(p, "findIndex").call(p, function(t) {
                    return y(t, 1) === n
                });
            if (0 > r) return ql(b, xJ(n, c.getAdUnitPath()), c), d;
            p.splice(r, 1);
            _.Ad(e, 9, p);
            b.info(DJ(n, c.getAdUnitPath()), c);
            return d
        });
        this.getTargeting = H(a, 51, function(n) {
            if ("string" !== typeof n) return ql(b, Uk("Slot.getTargeting", [n]), c), [];
            var p = (_.C = rl(e), _.u(_.C, "find")).call(_.C, function(r) {
                return y(r, 1) === n
            });
            return p ? _.hn(p, 2).slice() : []
        });
        this.getTargetingKeys = H(a, 52, function() {
            return rl(e).map(function(n) {
                return (0, B.K)(y(n, 1))
            })
        });
        this.setCollapseEmptyDiv = H(a, 53, function(n, p) {
            p = void 0 === p ? !1 : p;
            if ("boolean" !== typeof n || "boolean" !== typeof p) return ql(b, Uk("Slot.setCollapseEmptyDiv", [n, p]), c), d;
            _.z(e, 10, n);
            _.z(e, 11, n && p);
            p && !n && ql(b, $I(c.toString()), c);
            return d
        });
        this.getAdUnitPath = H(a, 54, function() {
            return c.getAdUnitPath()
        });
        this.getSlotElementId = H(a, 598, function() {
            return c.getDomId()
        });
        this.setForceSafeFrame = H(a, 55, function(n) {
            if ("boolean" !== typeof n) return ql(b, Uk("Slot.setForceSafeFrame", [String(n)]), c), d;
            _.z(e, 12, n);
            return d
        });
        this.setSafeFrameConfig = H(a, 56, function(n) {
            var p = Ql(b, n);
            if (!p) return b.error(Uk("Slot.setSafeFrameConfig", [n]), c), d;
            _.Th(e, 13, p);
            return d
        });
        c.Z(tI, function(n) {
            n = n.detail;
            if (J(n, 8)) g = null;
            else {
                g = new GK;
                var p = !!J(n, 9);
                g.isBackfill = p;
                var r = Yc(n, 15, Dc),
                    t = Yc(n, 16, Dc);
                r.length && t.length && (g.sourceAgnosticCreativeId = r[0], g.sourceAgnosticLineItemId = t[0], p || (g.creativeId = r[0], g.lineItemId = t[0], (p = Yc(n, 22, Dc)) && p.length && (g.creativeTemplateId = p[0])));
                Yc(n, 17, Dc).length && HK(g, Yc(n, 17, Dc)[0]);
                Yc(n, 18, Dc).length && IK(g, Yc(n, 18, Dc)[0]);
                Yc(n, 19, Dc).length && JK(g, Yc(n, 19, Dc));
                Yc(n, 20, Dc).length && KK(g, Yc(n, 20, Dc));
                n = Yc(n, 45, lc(n.fa) & 18 ? Zc : $c).map(function(w) {
                    return nd(w)
                });
                n.length && (g.encryptedTroubleshootingInfo = n[0])
            }
        });
        this.getResponseInformation = H(a, 355, function() {
            return g
        });
        this.getName = H(a, 170, function() {
            b.error(aK());
            return c.getAdUnitPath()
        });
        var m = new zK(a, c);
        this.getSlotId = H(a, 579, function() {
            return m
        });
        this.getServices = H(a, 580, function() {
            return _.hn(e, 4).map(function(n) {
                var p = eH[n];
                if (p) {
                    var r, t, w;
                    n = null != (w = null == (t = (r = $k())[p]) ? void 0 : t.call(r)) ? w : null
                } else n = null;
                return n
            })
        });
        this.getSizes = H(a, 581, function(n, p) {
            var r, t;
            return null != (t = null == (r = ti(e, n, p)) ? void 0 : r.map(function(w) {
                return J(w, 3) ? "fluid" : new LK(w.getWidth(), w.getHeight())
            })) ? t : null
        });
        this.getClickUrl = H(a, 582, function() {
            var n;
            return null != (n = e.getClickUrl()) ? n : ""
        });
        this.getTargetingMap = H(a, 583, function() {
            for (var n = {}, p = _.x(rl(e)), r = p.next(); !r.done; r = p.next()) r = r.value, y(r, 1) && (n[y(r, 1)] = _.hn(r, 2));
            return n
        });
        this.getOutOfPage = H(a, 584, function(n) {
            return "number" === typeof n ? Om(e) === n : 0 !== Om(e)
        });
        this.getCollapseEmptyDiv = H(a, 585, function() {
            return Rl(e, 10) ? J(e, 10) : null
        });
        this.getDivStartsCollapsed = H(a, 586, function() {
            return Rl(e, 11) ? J(e, 11) : null
        });
        c.Z(uI, function(n) {
            h = n.detail.og
        });
        this.getContentUrl = H(a, 587, function() {
            return h()
        });
        this.getFirstLook = H(a, 588, function() {
            Mx("The getFirstLook method of SlotInterface is deprecated. Please update your code to no longer call this method.");
            return 0
        });
        c.Z(tI, function(n) {
            var p;
            k = null != (p = n.detail.getEscapedQemQueryId()) ? p : ""
        });
        this.getEscapedQemQueryId = H(a, 591, function() {
            return k
        });
        this.getHtml = H(a, 592, function() {
            return l ? (window.console && console.warn && console.warn("This ad's html cannot be accessed using the getHtml method on googletag.Slot. Returning the empty string instead."), "") : f
        });
        this.setConfig = H(a, 1022, function(n) {
            var p = n.componentAuction;
            if (void 0 !== p) {
                n = FK(e);
                p = _.x(p);
                for (var r = p.next(); !r.done; r = p.next()) {
                    var t = r.value;
                    r = t.configKey;
                    t = t.auctionConfig;
                    "string" !== typeof r || pl(r) || (null === t ? n.delete(r) : t && n.set(r, JSON.stringify(t)))
                }
            }
        })
    };
    var MK = {},
        Hm = (MK[64] = UJ, MK[134217728] = VJ, MK[32768] = WJ, MK[536870912] = XJ, MK[8] = YJ, MK[512] = ZJ, MK[1048576] = $J, MK[4194304] = bK, MK);
    var Pm = function(a) {
        return "22639388115" === Nh(a.getAdUnitPath())
    };
    var NK = null;
    var en = {
        oa: "|"
    };
    var pn = 0,
        OK = new _.Zi(-9, -9);
    var sn = 0;
    var un = new _.v.Set([function(a, b) {
            var c = a.aa.O.T;
            b.set("pvsid", {
                value: a.da.context.pvsid
            }).set("correlator", {
                value: y(c, 26)
            })
        }, function(a, b) {
            a = a.Qf;
            var c = a.ec;
            "wbn" === a.wc && b.set("wbsu", {
                value: c
            })
        }, function(a, b) {
            var c = a.aa.O.T,
                d = a.mh;
            a = d.Zf;
            var e = d.Bh;
            d = d.gh;
            _.E(Wy) || (c = 0 === _.Se(c, 24, 0), b.set("adsid", {
                value: c ? a : null
            }).set("pucrd", {
                value: c ? e : null
            }).set("jar", {
                value: d
            }))
        }, function(a, b) {
            var c = a.aa.O.T,
                d = a.bi;
            a = d.Ub;
            d = d.Tb;
            var e = J(c, 21);
            b = b.set("hxva", {
                value: e ? 1 : null
            }).set("cmsid", {
                value: e ? y(c, 23) : null
            }).set("vid", {
                value: e ? y(c, 22) : null
            }).set("pod", {
                value: d
            }).set("ppos", {
                value: a
            });
            c = y(c, 29);
            b.set.call(b, "scor", {
                value: null == c ? void 0 : c
            })
        }, function(a, b) {
            var c = a.aa,
                d = c.Y,
                e = c.O.U;
            c = a.zh;
            var f = c.Rg,
                g = c.Lg;
            b.set("eid", {
                value: a.da.he
            }).set("debug_experiment_id", {
                value: hB().split(",")
            }).set("expflags", {
                value: _.Qh(253) ? Lf(My) || null : null
            }).set("pied", {
                value: function() {
                    var h = new FG,
                        k = !1,
                        l = !1;
                    f && (k = !0, _.Zf(h, 1, Tv, f));
                    var m = d.map(function(p) {
                        var r = new CG,
                            t;
                        p = null == (t = e[p.getDomId()]) ? void 0 : Qe(t, Tv, 27);
                        if (null == p || !p.length) return r;
                        l = k = !0;
                        t = _.x(p);
                        for (p = t.next(); !p.done; p = t.next()) _.Zf(r, 1, Tv, p.value);
                        return r
                    });
                    l && _.Ad(h, 2, m);
                    m = _.x(null != g ? g : []);
                    for (var n = m.next(); !n.done; n = m.next()) _.Zf(h, 1, Tv, n.value), k = !0;
                    return k ? Qb(h.m(), 3) : null
                }()
            })
        }, function(a, b) {
            var c = a.da,
                d = c.context;
            c = c.Ja;
            b.set("output", {
                value: a.Qf.wc
            }).set("gdfp_req", {
                value: 1
            }).set("vrg", {
                value: d.Ab ? String(d.Ab) : d.Na
            }).set("ptt", {
                value: 17
            }).set("impl", {
                value: c ? "fifs" : "fif"
            })
        }, function(a, b) {
            a = a.aa.O.T;
            b.set("co", {
                value: 0 !== _.Se(a, 24, 0) ? _.Se(a, 24, 0) : null,
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            var c = a.da.V;
            a = yn(a.aa.O.T) || new lH;
            var d = _.Se(a, 6, 2);
            b.set("rdp", {
                value: J(a, 1) ? "1" : null
            }).set("ltd", {
                value: J(a, 9) ? "1" : null
            }).set("gdpr_consent", {
                value: qg(c, 2)
            }).set("gdpr", {
                value: Rl(c, 3) ? J(c, 3) ? "1" : "0" : null,
                options: {
                    ya: !0
                }
            }).set("addtl_consent", {
                value: qg(c, 4)
            }).set("tcfe", {
                value: Ru(c, 7)
            }).set("us_privacy", {
                value: qg(c, 1)
            }).set("npa", {
                value: J(c, 6) || J(a, 8) ? 1 : null
            }).set("puo", {
                value: _.E(iz) && J(a, 13) ? 1 : null
            }).set("tfua", {
                value: 2 !== d ? d : null,
                options: {
                    ya: !0
                }
            }).set("tfcd", {
                value: null != y(a, 5) ? y(a, 5) : null,
                options: {
                    ya: !0
                }
            }).set("trt", {
                value: null != y(a, 10) ? y(a, 10) : null,
                options: {
                    ya: !0
                }
            }).set("tad", {
                value: Rl(c, 8) ? J(c, 8) ? "1" : "0" : null,
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            var c = a.aa,
                d = c.O,
                e = c.Y,
                f = c.pe;
            a = a.da;
            var g = a.F,
                h = a.M,
                k = a.Ja;
            a = {
                oa: "~"
            };
            var l = e.map(function(n) {
                    return d.U[n.getDomId()]
                }),
                m = [];
            c = e.map(function(n) {
                return n.getAdUnitPath().replace(/,/g, ":").split("/").map(function(p) {
                    if (!p) return "";
                    var r = _.u(m, "findIndex").call(m, function(t) {
                        return t === p
                    });
                    return 0 <= r ? r : m.push(p) - 1
                }).join("/")
            });
            b.set("iu_parts", {
                value: m
            }).set("enc_prev_ius", {
                value: c
            }).set("prev_iu_szs", {
                value: l.map(function(n) {
                    return wi(n)
                })
            }).set("fluid", {
                value: function() {
                    var n = !1,
                        p = l.map(function(r) {
                            r = (_.C = vi(r), _.u(_.C, "includes")).call(_.C, "fluid");
                            n || (n = r);
                            return r ? "height" : "0"
                        });
                    return n ? p : null
                }()
            }).set("ifi", {
                value: function() {
                    var n = Jj(g);
                    if (!f) {
                        n += 1;
                        var p = g,
                            r = e.length;
                        r = void 0 === r ? 1 : r;
                        p = Yx(re(p)) || p;
                        p.google_unique_id = (p.google_unique_id || 0) + r
                    }
                    return n
                }()
            }).set("adks", {
                value: e.map(function(n) {
                    if (k) {
                        var p = d.U[n.getDomId()];
                        p = yi(p);
                        if (n = h.j.get(n)) n.Ib = p;
                        return p
                    }
                    p = d.T;
                    var r = d.U[n.getDomId()],
                        t;
                    if (!(t = Ar(h, n))) {
                        p = yi(r, J(p, 6) || J(r, 17) ? null : lj(n));
                        if (n = h.j.get(n)) n.Ib = p;
                        t = p
                    }
                    return t
                })
            }).set("didk", {
                value: _.E(qz) ? Gm(e, function(n) {
                    return _.xi(n.getDomId())
                }, a) : null,
                options: _.u(Object, "assign").call(Object, {}, a, {
                    kb: !0
                })
            }).set("tgts", {
                value: _.E(sz) ? Gm(e, function(n) {
                    var p;
                    return null == (p = /^div-gpt-ad-([0-9]{12,14})-/.exec(n.getDomId())) ? void 0 : p[1]
                }, a) : null,
                options: _.u(Object, "assign").call(Object, {}, a, {
                    kb: !0
                })
            })
        }, function(a, b) {
            var c = a.aa;
            a = c.Y;
            c = c.O;
            var d = c.T,
                e = c.U;
            b.set("sfv", {
                value: pK ? pK : pK = Gl()
            }).set("fsfs", {
                value: Gm(a, function(f) {
                    f = e[f.getDomId()];
                    var g;
                    return Number(null != (g = null == f ? void 0 : Ui(f, 12)) ? g : J(d, 13))
                }, {
                    lc: 0
                }),
                options: {
                    oa: ",",
                    Wd: 0,
                    kb: !0
                }
            }).set("fsbs", {
                value: Gm(a, function(f) {
                    f = e[f.getDomId()].Za();
                    var g = d.Za(),
                        h;
                    return (null != (h = null == f ? void 0 : Ui(f, 3)) ? h : null == g ? 0 : J(g, 3)) ? 1 : 0
                }, {
                    lc: 0
                }),
                options: {
                    Wd: 0,
                    kb: !0
                }
            })
        }, function(a, b) {
            var c = a.da,
                d = c.M,
                e = c.F;
            a = a.aa;
            c = a.Y;
            var f = a.pe;
            b.set("ris", {
                value: Gm(c, function(g) {
                    var h, k;
                    g = null != (k = null == (h = d.j.get(g)) ? void 0 : h.pf) ? k : 0;
                    h = _.kf(e);
                    return g && h ? Math.round(Math.min((h - g) / 1E3, 1800)) : null
                }, {
                    oa: "~"
                }),
                options: {
                    oa: "~",
                    kb: !0
                }
            }).set("rcs", {
                value: Gm(c, function(g) {
                    if (!f) {
                        var h = void 0 === h ? _.q : h;
                        var k = d.j.get(g);
                        k && (k.pf = _.kf(h) || 0, k.Df++)
                    }
                    return II(d, g)
                }, {
                    lc: 0
                }),
                options: {
                    Wd: 0,
                    kb: !0
                }
            })
        }, function(a, b) {
            var c = a.aa;
            a = a.da.Ja;
            c = c.O.U[c.Y[0].getDomId()];
            b.set("click", {
                value: !a && c.getClickUrl() ? y(c, 7) : null
            })
        }, function(a, b, c) {
            var d = a.aa,
                e = d.Y,
                f = d.O.U;
            a = a.da;
            var g = a.V,
                h = a.F;
            c = void 0 === c ? function(k, l) {
                return df(k, l)
            } : c;
            a = e.map(function(k) {
                return f[k.getDomId()]
            });
            b.set("ists", {
                value: Fm(a, function(k) {
                    return 0 !== Om(k)
                }) || null
            }).set("fas", {
                value: Gm(a, function(k) {
                    return Sm(Om(k))
                }, {
                    lc: 0
                }),
                options: {
                    Wd: 0,
                    kb: !0
                }
            }).set("itsi", {
                value: e.some(function(k) {
                    var l;
                    return !Pm(k) && 5 === (null == (l = f[k.getDomId()]) ? void 0 : Om(l))
                }) ? function() {
                    var k = c(g, h);
                    if (!k) return 1;
                    var l;
                    k = Math.max.apply(Math, _.ve(null != (l = _.Mm((0, B.K)(k), 604800)) ? l : []));
                    return isFinite(k) ? Math.floor(Math.max((Date.now() - k) / 6E4, 1)) : null
                }() : null
            })
        }, function(a, b) {
            a = a.aa;
            var c = a.O.U;
            a = a.Y.map(function(d) {
                return c[d.getDomId()]
            });
            b.set("rbvs", {
                value: Fm(a, function(d) {
                    return 4 === Om(d)
                }) || null
            })
        }, function(a, b) {
            var c = a.aa,
                d = c.O,
                e = c.O.T,
                f = c.Y;
            c = c.ob;
            var g = a.da;
            a = g.isSecureContext;
            g = g.F;
            b = b.set("prev_scp", {
                value: fn(f, d),
                options: {
                    kb: !0,
                    oa: "|"
                }
            });
            var h = b.set,
                k = d.T,
                l = d.U,
                m = new Dj;
            m.set(0, 1 !== c);
            l = l[f[0].getDomId()];
            m.set(1, !!J(l, 17));
            m.set(2, nn(f, d));
            m.set(3, J(k, 27) || !1);
            m.set(4, 3 === c);
            d = Fj(m);
            h.call(b, "eri", {
                value: d
            }).set("cust_params", {
                value: jn(e),
                options: {
                    oa: "&"
                }
            }).set("ppid", {
                value: 1 !== _.Se(e, 24, 0) && _.dg(e, 16) ? y(e, 16) : null,
                options: {
                    ya: !0
                }
            }).set("gct", {
                value: bn("google_preview", g)
            }).set("sc", {
                value: a ? 1 : 0,
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            var c = a.da,
                d = c.F,
                e = c.V;
            c = c.Aa;
            a = a.aa.O.T;
            var f = kn(a.wa());
            if (0 === _.Se(a, 24, 0)) {
                var g = _.eC(c, "__gads", e);
                a = "1" === _.eC(c, "__gpi_opt_out", e) ? "1" : null;
                b = b.set("cookie", {
                    value: g,
                    options: {
                        ya: !0
                    }
                }).set("cookie_enabled", {
                    value: !g && fC(c, e) ? "1" : null
                });
                g = d.document;
                var h = g.domain;
                d = b.set.call(b, "cdm", {
                    value: (f || Xi(d)) === g.URL ? "" : h
                });
                f = d.set;
                e = (e = _.eC(c, "__gpi", e)) && !_.u(e, "includes").call(e, "&") ? e : null;
                f.call(d, "gpic", {
                    value: e
                }).set("gpico", {
                    value: a
                }).set("pdopt", {
                    value: a
                })
            }
        }, function(a, b) {
            a = a.da.F;
            b.set("arp", {
                value: Lk(a) ? 1 : null
            }).set("abxe", {
                value: _.oe(a.top) || Gx(a.IntersectionObserver) ? 1 : null
            })
        }, function(a, b) {
            var c = a.da.F;
            a = kn(a.aa.O.T.wa());
            b.set("dt", {
                value: (new Date).getTime()
            });
            if (!a) {
                try {
                    var d = Math.round(Date.parse(c.document.lastModified) / 1E3) || null
                } catch (e) {
                    d = null
                }
                b.set("lmt", {
                    value: d
                })
            }
            d = sn;
            c = mf(c);
            0 < c && d >= c && b.set("dlt", {
                value: c
            }).set("idt", {
                value: d - c
            })
        }, function(a, b) {
            var c = a.aa,
                d = c.O,
                e = c.Y,
                f = c.O;
            c = f.T;
            f = f.U;
            var g = a.da;
            a = g.F;
            var h = g.Ja;
            g = ui(!0, a);
            for (var k = a.document, l = [], m = [], n = _.x(e), p = n.next(); !p.done; p = n.next()) {
                p = p.value;
                var r = f[p.getDomId()];
                p = rj(p, r, k, Vi(c, r));
                r = void 0;
                var t = h ? null != (r = p) ? r : OK : p;
                t && (l.push(Math.round(t.x)), m.push(Math.round(t.y)))
            }
            g && (d.Vb = g);
            c = Wi(a) ? null : ui(!1, a);
            try {
                var w = a.top;
                var D = on(w.document, w)
            } catch (F) {
                D = new _.Zi(-12245933, -12245933)
            }
            b.set("adxs", {
                value: l
            }).set("adys", {
                value: m
            }).set("biw", {
                value: g ? g.width : null
            }).set("bih", {
                value: g ? g.height : null
            }).set("isw", {
                value: g ? null == c ? void 0 : c.width : null
            }).set("ish", {
                value: g ? null == c ? void 0 : c.height : null
            }).set("scr_x", {
                value: Math.round(D.x),
                options: {
                    ya: !0
                }
            }).set("scr_y", {
                value: Math.round(D.y),
                options: {
                    ya: !0
                }
            }).set("btvi", {
                value: qn(e, a, d),
                options: {
                    ya: !0,
                    oa: "|"
                }
            })
        }, function(a, b) {
            var c = a.da.M;
            b.set("ucis", {
                value: a.aa.Y.map(function(d) {
                    d = (0, B.K)(c.j.get(d));
                    null != d.Gc || (d.Gc = window === window.top ? (++c.J).toString(36) : bx());
                    return d.Gc
                }),
                options: {
                    oa: "|"
                }
            }).set("oid", {
                value: 2
            })
        }, function(a, b) {
            a = a.aa;
            var c = a.Y,
                d = a.O,
                e = d.U;
            a = new _.v.Map;
            d = _.x(d.T.wa());
            for (var f = d.next(); !f.done; f = d.next()) {
                var g = f.value;
                a.set((0, B.K)(y(g, 1)), [_.hn(g, 2)[0]])
            }
            for (d = 0; d < c.length; d++)
                if (g = e[c[d].getDomId()])
                    for (g = _.x(g.wa()), f = g.next(); !f.done; f = g.next()) {
                        var h = f.value;
                        f = (0, B.K)(y(h, 1));
                        var k = a.get(f) || [];
                        h = _.hn(h, 2)[0];
                        1 === c.length ? k[0] = h : h !== k[0] && (k[d + 1] = h);
                        a.set(f, k)
                    }
            c = [];
            e = _.x(_.u(a, "keys").call(a));
            for (d = e.next(); !d.done; d = e.next()) g = d.value, d = NI()[g], g = a.get(g), d && g && (1 < g.length ? (g = g.map(function(l) {
                return encodeURIComponent(l || "")
            }).join(), c.push(d + "," + g)) : 1 === g.length && "url" !== d && b.set(d, {
                value: g[0]
            }));
            c.length && b.set("sps", {
                value: c,
                options: {
                    oa: "|"
                }
            })
        }, function(a, b) {
            var c = a.aa.O.T,
                d = a.da;
            a = d.F;
            var e = d.Yh;
            d = d.ab;
            e = e ? Ne(e) : _.Qh(251);
            var f, g, h, k, l, m, n;
            var p = a;
            p = void 0 === p ? Vw : p;
            try {
                var r = p.history.length
            } catch (Ka) {
                r = 0
            }
            b = b.set("u_his", {
                value: r
            }).set("u_h", {
                value: null == (f = a.screen) ? void 0 : f.height
            }).set("u_w", {
                value: null == (g = a.screen) ? void 0 : g.width
            }).set("u_ah", {
                value: null == (h = a.screen) ? void 0 : h.availHeight
            }).set("u_aw", {
                value: null == (k = a.screen) ? void 0 : k.availWidth
            }).set("u_cd", {
                value: null == (l = a.screen) ? void 0 : l.colorDepth
            });
            f = b.set;
            g = a;
            g = void 0 === g ? _.q : g;
            g = g.devicePixelRatio;
            f = f.call(b, "u_sd", {
                value: "number" === typeof g ? +g.toFixed(3) : null
            }).set("u_tz", {
                value: -(new Date).getTimezoneOffset()
            });
            g = f.set;
            try {
                var t, w, D, F, I = null != (F = null == (t = a.external) ? void 0 : null == (w = t.getHostEnvironmentValue) ? void 0 : null == (D = w.bind(a.external)) ? void 0 : D("os-mode")) ? F : "",
                    S, M = Number(null == (S = JSON.parse(I)) ? void 0 : S["os-mode"]);
                var R = 0 <= M ? M + 1 : null
            } catch (Ka) {
                R = null
            }
            R = g.call(f, "wsm", {
                value: R
            }).set("dmc", {
                value: null != (n = null == (m = a.navigator) ? void 0 : m.deviceMemory) ? n : null
            });
            m = R.set;
            (c = y(c, 8)) ? (50 < c.length && (c = c.substring(0, 50)), c = "a " + nu('role:1 producer:12 loc:"' + c + '"')) : c = "";
            c = m.call(R, "uule", {
                value: c
            });
            m = c.set;
            n = a;
            n = void 0 === n ? _.q : n;
            R = new Dj;
            n.SVGElement && n.document.createElementNS && R.set(0);
            t = Fx();
            t["allow-top-navigation-by-user-activation"] && R.set(1);
            t["allow-popups-to-escape-sandbox"] && R.set(2);
            n.crypto && n.crypto.subtle && R.set(3);
            n.TextDecoder && n.TextEncoder && R.set(4);
            n = Fj(R);
            e = m.call(c, "bc", {
                value: n
            }).set("uach", {
                value: e ? nu(e, 3) : null
            });
            c = e.set;
            if (d) var T = null;
            else if (d = null == (T = a.navigator) ? void 0 : T.userActivation) {
                T = 0;
                if (null == d ? 0 : d.hasBeenActive) T |= 1;
                if (null == d ? 0 : d.isActive) T |= 2
            } else T = void 0;
            T = c.call(e, "uas", {
                value: T
            });
            d = T.set;
            a: {
                try {
                    var X, ka, ca = null == (X = a.performance) ? void 0 : null == (ka = X.getEntriesByType("navigation")) ? void 0 : ka[0];
                    if (null == ca ? 0 : ca.type) {
                        var oa;
                        var la = null != (oa = qG.get(ca.type)) ? oa : null;
                        break a
                    }
                } catch (Ka) {}
                var va, na, ya;la = null != (ya = rG.get(null == (va = a.performance) ? void 0 : null == (na = va.navigation) ? void 0 : na.type)) ? ya : null
            }
            d.call(T, "nvt", {
                value: la
            })
        }, function(a, b) {
            var c = a.da,
                d = c.F,
                e = c.M;
            c = c.Ja;
            a = a.aa;
            var f = a.Y;
            a = a.O;
            var g = a.T,
                h = a.U;
            a = cn("google_preview", d);
            var k = d.document,
                l = a ? ln(k.URL) : k.URL;
            k = a ? ln(k.referrer) : k.referrer;
            a = !1;
            if (c) c = kn(g.wa());
            else {
                var m;
                c = null != (m = kn(h[f[0].getDomId()].wa())) ? m : kn(g.wa())
            }
            if (null != c) {
                var n = l;
                Wi(d) || (k = "", a = !0)
            } else c = l;
            m = mn(d);
            b.set("nhd", {
                value: m || null
            }).set("url", {
                value: c
            }).set("loc", {
                value: null !== n && n !== c ? n : null
            }).set("ref", {
                value: k
            });
            if (m) {
                n = b.set;
                var p, r;
                m = _.oe(d.top) && (null == (p = d.top) ? void 0 : null == (r = p.location) ? void 0 : r.href);
                var t;
                p = null == (t = d.location) ? void 0 : t.ancestorOrigins;
                d = sk(d) || "";
                t = (null == p ? void 0 : p[p.length - 1]) || "";
                d = (d = m || d || t) ? a ? ux(d.match(_.tx)[3] || null) : d : null;
                n.call(b, "top", {
                    value: d
                }).set("etu", {
                    value: e.Wc
                })
            }
        }, function(a, b) {
            a = a.da.context.pvsid;
            b.set("rumc", {
                value: _.E(Mz) || _.of(ai).j ? a : null
            }).set("rume", {
                value: _.E(az) ? 1 : null
            })
        }, function(a, b) {
            a = a.da.F;
            var c = b.set;
            var d = Sx(a);
            var e = HA(a, a.google_ad_width, a.google_ad_height);
            var f = d.location.href;
            if (d === d.top) f = !0;
            else {
                var g = !1,
                    h = d.document;
                h && h.referrer && (f = h.referrer, d.parent === d.top && (g = !0));
                (d = d.location.ancestorOrigins) && (d = d[d.length - 1]) && -1 === f.indexOf(d) && (g = !1, f = d);
                f = g
            }
            g = a.top == a ? 0 : _.oe(a.top) ? 1 : 2;
            d = 4;
            e || 1 != g ? e || 2 != g ? e && 1 == g ? d = 7 : e && 2 == g && (d = 8) : d = 6 : d = 5;
            f && (d |= 16);
            e = "" + d;
            if (a != a.top)
                for (f = a; f && f != f.top && _.oe(f) && !f.sf_ && !f.$sf && !f.inGptIF && !f.inDapIF; f = f.parent);
            c.call(b, "frm", {
                value: e || null
            }).set("vis", {
                value: wG(a.document)
            })
        }, function(a, b) {
            var c = a.aa.Y;
            a = a.da.F;
            for (var d = [], e = [], f = _.x(c), g = f.next(); !g.done; g = f.next()) {
                var h = void 0,
                    k = void 0,
                    l = void 0;
                var m = a;
                g = lj(g.value);
                var n = Jx((null == g ? void 0 : g.parentElement) && nj(g.parentElement, m) || null);
                !n || 1 === n[0] && 1 === n[3] ? (n = null != (l = null == g ? void 0 : g.parentElement) ? l : null, l = null != (k = cj(n)) ? k : new _.bj(0, 0), $m(l, n, m, 100), k = null != (h = cj(g)) ? h : new _.bj(0, 0), $m(k, g, m, 1), -1 === l.height && (k.height = -1), m = l, k = h = k, h = m.width + "x" + m.height, m = k.width + "x" + k.height) : m = h = "-1x-1";
                d.push(h);
                e.push(m)
            }
            null == NK && (f = HA(a, 500, 300), m = a.navigator, h = m.userAgent, k = m.platform, m = m.product, !/Win|Mac|Linux|iPad|iPod|iPhone/.test(k) && /^Opera/.test(h) ? h = !1 : /Win/.test(k) && /Trident/.test(h) && 11 <= a.document.documentMode ? h = !0 : (k = (/WebKit\/(\d+)/.exec(h) || [0, 0])[1], g = (/rv:(\d+\.\d+)/.exec(h) || [0, 0])[1], h = !k && "Gecko" === m && 27 <= g && !/ rv: 1\.8([^.] |\.0) /.test(h) || 536 <= k ? !0 : !1), NK = h && !f);
            g = 0 !== (0, _.Vm)();
            f = ui(!0, a, g).width;
            h = [];
            m = [];
            k = [];
            null !== a && a != a.top && (l = ui(!1, a).width, (-12245933 === f || -12245933 === l || l < f) && k.push(8)); - 12245933 !== f && (1.5 * f < a.document.documentElement.scrollWidth ? k.push(10) : g && 1.5 * a.outerWidth < f && k.push(10));
            c = _.x(c);
            for (l = c.next(); !l.done; l = c.next()) {
                g = new Dj;
                n = lj(l.value);
                l = 0;
                var p = !1,
                    r = !1;
                if (n) {
                    for (var t = 0, w = n; w && 100 > t; t++, w = w.parentElement) {
                        var D = nj(w, a);
                        if (D) {
                            var F = D,
                                I = F.display,
                                S = F.overflowX;
                            if ("visible" !== F.overflowY && (g.set(2), (F = cj(w)) && (l = l ? Math.min(l, F.width) : F.width), g.get(9))) break;
                            Ym(D) && g.set(9);
                            "none" === I && g.set(7);
                            "IFRAME" === w.nodeName && (D = parseInt(D.width, 10), D < f && (g.set(8), l = l ? Math.min(D, l) : D));
                            r || (r = "scroll" === S || "auto" === S);
                            p || (p = "flex" === I)
                        } else g.set(3)
                    }
                    r && p && (n = n.getBoundingClientRect().left, (n > f || 0 > n) && g.set(11))
                } else g.set(1);
                n = _.x(k);
                for (p = n.next(); !p.done; p = n.next()) g.set(p.value);
                h.push(Fj(g));
                m.push(l)
            }
            b.set("psz", {
                value: d,
                options: {
                    oa: "|"
                }
            }).set("msz", {
                value: e,
                options: {
                    oa: "|"
                }
            }).set("fws", {
                value: h
            }).set("ohw", {
                value: m
            }).set("ea", {
                value: NK ? null : "0",
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            b.set("psts", {
                value: HI(a.da.M, a.aa.Y)
            })
        }, function(a, b) {
            var c = a.da;
            a = c.V;
            c = c.F;
            var d;
            var e = c.document.domain,
                f = null != (d = cf(a) && ef(c) ? c.document.cookie : null) ? d : "",
                g = c.history.length,
                h = c.screen,
                k = c.document.referrer;
            if (re()) var l = window.gaGlobal || {};
            else {
                var m = Math.round((new Date).getTime() / 1E3),
                    n = c.google_analytics_domain_name;
                e = "undefined" == typeof n ? DA("auto", e) : DA(n, e);
                var p = -1 < f.indexOf("__utma=" + e + "."),
                    r = -1 < f.indexOf("__utmb=" + e);
                (d = (Yx() || window).gaGlobal) || (d = {}, (Yx() || window).gaGlobal = d);
                var t = !1;
                if (p) {
                    var w = f.split("__utma=" + e + ".")[1].split(";")[0].split(".");
                    r ? d.sid = w[3] : d.sid || (d.sid = m + "");
                    d.vid = w[0] + "." + w[1];
                    d.from_cookie = !0
                } else {
                    d.sid || (d.sid = m + "");
                    if (!d.vid) {
                        t = !0;
                        r = Math.round(2147483647 * Math.random());
                        p = BA.appName;
                        var D = BA.version,
                            F = BA.language ? BA.language : BA.browserLanguage,
                            I = BA.platform,
                            S = BA.userAgent;
                        try {
                            w = BA.javaEnabled()
                        } catch (M) {
                            w = !1
                        }
                        w = [p, D, F, I, S, w ? 1 : 0].join("");
                        h ? w += h.width + "x" + h.height + h.colorDepth : _.q.java && _.q.java.awt && (h = _.q.java.awt.Toolkit.getDefaultToolkit().getScreenSize(), w += h.screen.width + "x" + h.screen.height);
                        w = w + f + (k || "");
                        for (k = w.length; 0 < g;) w += g-- ^ k++;
                        d.vid = (r ^ CA(w) & 2147483647) + "." + m
                    }
                    d.from_cookie || (d.from_cookie = !1)
                }
                if (!d.cid) {
                    b: for (m = 999, n && (n = 0 == n.indexOf(".") ? n.substr(1) : n, m = n.split(".").length), n = 999, f = f.split(";"), w = 0; w < f.length; w++)
                        if (k = EA.exec(f[w]) || FA.exec(f[w]) || GA.exec(f[w])) {
                            h = k[1] || 0;
                            if (h == m) {
                                l = k[2];
                                break b
                            }
                            h < n && (n = h, l = k[2])
                        }t && l && -1 != l.search(/^\d+\.\d+$/) ? (d.vid = l, d.from_cookie = !0) : l != d.vid && (d.cid = l)
                }
                d.dh = e;
                d.hid || (d.hid = Math.round(2147483647 * Math.random()));
                l = d
            }
            e = l.sid;
            d = l.hid;
            t = l.from_cookie;
            f = l.cid;
            t && !cf(a) || b.set("ga_vid", {
                value: l.vid
            }).set("ga_sid", {
                value: e
            }).set("ga_hid", {
                value: d
            }).set("ga_fc", {
                value: t
            }).set("ga_cid", {
                value: f
            }).set("ga_wpids", {
                value: c.google_analytics_uacct
            })
        }, function(a, b) {
            a = a.da;
            var c = a.F;
            a = a.context.pvsid;
            b = b.set("js", {
                value: _.E(Dy) ? IA(c) : null
            });
            var d = b.set;
            if (_.E(Dy)) a: {
                var e = c;e = void 0 === e ? window : e;
                if (c = IA(e)) {
                    var f = null;
                    try {
                        "afma-gpt-sdk-a" == c ? f = e._gmptnl.pm("GAM=", a.toString()) || "5" : (f = e.__gmptnl_n || "5", e.webkit.messageHandlers._gmptnl.postMessage("GAM="))
                    } catch (g) {
                        a = "3";
                        break a
                    }
                    a = "string" === typeof f ? f : "3"
                } else a = null
            }
            else a = null;
            d.call(b, "ms", {
                value: a
            })
        }, function(a, b) {
            var c = a.da.F;
            a = c.navigator;
            c = c.document;
            _.E(bA) || "runAdAuction" in a && "joinAdInterestGroup" in a && Mg("run-ad-auction", c) && b.set("td", {
                value: 1
            })
        }, function(a, b) {
            var c = a.Qh.Rh;
            Mg("browsing-topics", a.da.F.document) && (b.set("topics", {
                value: c instanceof Uint8Array ? Qb(c, 3) : c
            }), !c || c instanceof Uint8Array || b.set("tps", {
                value: c
            }))
        }, function(a, b) {
            var c = a.da,
                d = c.F;
            c = c.V;
            var e = a.aa.Y,
                f = a.Lh;
            a = f.xh;
            var g = f.zg,
                h = f.vh;
            f = f.nh;
            _.E(Jz) || b.set("a3p", {
                value: Sf(df(c, d), Nh((0, B.K)(e[0]).getAdUnitPath()), a, g, f, h)
            })
        }, function(a, b) {
            var c = a.Nc.Oc,
                d = a.aa.Y;
            a = {
                oa: "~"
            };
            var e = function() {
                return c ? d.map(function(f) {
                    return (0, B.K)(c.get(f))
                }) : []
            }();
            b.set("cbidsp", {
                value: Gm(e, function(f) {
                    return Qb(f.m(), 3)
                }, a),
                options: _.u(Object, "assign").call(Object, {}, a, {
                    kb: !0
                })
            })
        }, function(a, b) {
            a = a.aa.O.T;
            Do(a.ed(), Pp, 1) && (a = Op(a.ed(), Pp, 1), b.set("cmrv", {
                value: 1
            }).set("cmrq", {
                value: y(a, 1)
            }).set("cmrc", {
                value: _.hn(a, 2),
                options: {
                    oa: ">"
                }
            }).set("cmrids", {
                value: _.hn(a, 3),
                options: {
                    oa: "!"
                }
            }).set("cmrf", {
                value: y(a, 4)
            }))
        }, function(a, b) {
            var c = [];
            a = _.x(Qe(Op(a.aa.O.T.ed(), Rp, 2), mp, 1));
            for (var d = a.next(); !d.done; d = a.next()) d = d.value, _.hn(d, 2).length && c.push(_.Se(d, 1, 0) + "=" + _.hn(d, 2).join("|"));
            b.set("pps", {
                value: c,
                options: {
                    oa: "~"
                }
            })
        }, function(a, b) {
            b.set("scar", {
                value: a.th.Og
            })
        }, function(a, b) {
            a = a.da.F.document;
            _.E(Lz) || Mg("attribution-reporting", a) && b.set("nt", {
                value: 1
            })
        }]),
        QK = function(a) {
            if (null == a || !a.aa.Y.length) return "";
            for (var b = new _.v.Set(Mf(wn)), c = _.x(rn(a.da.V)), d = c.next(); !d.done; d = c.next()) b.add(d.value);
            c = new _.v.Map;
            d = _.x(un);
            for (var e = d.next(); !e.done; e = d.next()) e = e.value, e(a, c);
            a = "https://" + (PK(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
            c = _.x(c);
            for (d = c.next(); !d.done; d = c.next()) {
                e = _.x(d.value);
                d = e.next().value;
                var f = e.next().value;
                e = f.value;
                f = void 0 === f.options ? {} : f.options;
                (new RegExp("[?&]" + d + "=")).test(a);
                if (!b.has(d) && null != e) {
                    var g = f;
                    f = void 0 === g.oa ? "," : g.oa;
                    g = void 0 === g.ya ? !1 : g.ya;
                    if (e = "object" !== typeof e ? null == e || !g && 0 === e ? null : encodeURIComponent(e) : Array.isArray(e) && e.length ? encodeURIComponent(e.join(f)) : null) "?" !== a[a.length - 1] && (a += "&"), a += d + "=" + e
                }
            }
            return a
        },
        PK = function(a) {
            var b = a.da.V,
                c, d;
            a = null != (d = null == (c = yn(a.aa.O.T)) ? void 0 : J(c, 9)) ? d : !1;
            c = J(b, 8);
            return a || c || !cf(b)
        };
    var UK = function(a, b, c, d) {
            var e = this;
            this.context = a;
            this.M = c;
            this.j = new _.v.Map;
            this.o = new _.v.Map;
            this.Fb = _.of(ai);
            gI() && (_.zb(window, "DOMContentLoaded", Zh(a, 334, function() {
                for (var f = _.x(e.j), g = f.next(); !g.done; g = f.next()) {
                    var h = _.x(g.value);
                    g = h.next().value;
                    h = h.next().value;
                    RK(e, g, h) && e.j.delete(g)
                }
            })), b.Z(vI, function(f) {
                f = f.detail;
                var g = f.U;
                return void SK(e, (0, B.K)(TK(d, f.Ie)), (0, B.K)(oi(g, 20)))
            }), b.Z(wI, function(f) {
                f = f.detail;
                var g = f.U;
                f = (0, B.K)(TK(d, f.Ie));
                g = (0, B.K)(oi(g, 20));
                var h = e.o.get(f);
                null != h ? iI(h, g) : SK(e, f, g)
            }))
        },
        SK = function(a, b, c) {
            RK(a, b, c) ? a.j.delete(b) : (a.j.set(b, c), _.qo(b, function() {
                return a.j.delete(b)
            }))
        },
        RK = function(a, b, c) {
            var d = lj(b);
            if ("DIV" !== (null == d ? void 0 : d.nodeName)) return !1;
            d = new fI({
                F: window,
                Fb: a.Fb,
                ib: (0, B.ua)(d),
                Ma: function(e) {
                    return void ci(a.context, 336, e)
                },
                Nh: _.E(Mz),
                qg: _.E(Jq)
            });
            if (!d.j) return !1;
            iI(d, c);
            a.o.set(b, d);
            DI(a.M, b, function() {
                return void a.o.delete(b)
            });
            return !0
        };
    var VK = function(a) {
        this.o = a;
        this.m = this.j = 0
    };
    VK.prototype.push = function() {
        for (var a = _.x(_.xb.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                "function" === typeof b && (b.call(_.v.globalThis), this.j++)
            } catch (c) {
                this.m++, b = void 0, null == (b = window.console) || b.error("Exception in queued GPT command", c), this.o.error(eJ(String(c)))
            }
        }
        this.o.info(fJ(String(this.j), String(this.m)));
        return this.j
    };
    var WK = function(a, b, c) {
        Z.call(this, a, 937, _.Kf(ez));
        this.window = c;
        this.sb = V(this);
        this.l = V(this);
        this.A = V(this);
        this.D = V(this);
        this.Jb = V(this);
        this.cc = V(this);
        this.G = RB(this, b)
    };
    _.L(WK, Z);
    WK.prototype.j = function() {
        if (this.window.top !== this.window) XK(this);
        else {
            var a = this.G.value;
            if (a) {
                var b = {},
                    c;
                if (null == (c = Bf(a, Jv, 2)) ? 0 : _.Uf(c, 2)) b["*"] = {
                    vc: !0
                };
                c = new _.v.Set;
                for (var d = _.x(Qe(a, Iv, 1)), e = d.next(); !e.done; e = d.next()) {
                    e = e.value;
                    for (var f = _.x([_.Tf(e, 2), _.Tf(e, 1)].filter(function(r) {
                            return !!r
                        })), g = f.next(); !g.done; g = f.next()) b[g.value] = {
                        vc: _.Uf(e, 3)
                    };
                    e = _.x(Yc(e, 4, Bc));
                    for (f = e.next(); !f.done; f = e.next()) c.add(f.value)
                }
                N(this.sb, b);
                CB(this.l, [].concat(_.ve(c)));
                var h, k;
                b = null == (h = Bf(a, Jv, 2)) ? void 0 : null == (k = Bf(h, Dv, 1)) ? void 0 : Qe(k, Bv, 1);
                DB(this.A, (null == b ? 0 : b.length) ? b : null);
                var l;
                CB(this.Jb, !(null == (l = Bf(a, Jv, 2)) || !_.Uf(l, 4)));
                var m;
                CB(this.cc, !(null == (m = Bf(a, Jv, 2)) || !_.Uf(m, 5)));
                var n, p;
                a = null == (n = Bf(a, Jv, 2)) ? void 0 : null == (p = Bf(n, Dv, 3)) ? void 0 : Qe(p, Bv, 1);
                DB(this.D, (null == a ? 0 : a.length) ? a : null)
            } else XK(this)
        }
    };
    var XK = function(a) {
        N(a.sb, {});
        N(a.l, []);
        EB(a.A);
        N(a.Jb, !1);
        N(a.cc, !1);
        EB(a.D)
    };
    WK.prototype.I = function(a) {
        this.m(a)
    };
    WK.prototype.m = function() {
        XK(this)
    };
    var YK = function(a, b, c, d, e, f) {
        Z.call(this, a, 980);
        this.A = b;
        this.C = new KB;
        this.l = [];
        this.L = W(this, c);
        this.G = W(this, d);
        this.D = W(this, e);
        a = _.x(f);
        for (b = a.next(); !b.done; b = a.next()) this.l.push(W(this, b.value))
    };
    _.L(YK, Z);
    YK.prototype.j = function() {
        (_.C = _.u(Object, "entries").call(Object, this.L.value), _.u(_.C, "find")).call(_.C, function(c) {
            var d = _.x(c);
            c = d.next().value;
            d = d.next().value;
            return "*" !== c && (null == d ? void 0 : d.vc)
        }) && (this.A.B = !0);
        rf(25);
        for (var a = _.x((_.C = [this.G.value, this.D.value, this.l.map(function(c) {
                return c.value
            })], _.u(_.C, "flat")).call(_.C)), b = a.next(); !b.done; b = a.next()) qf(b.value);
        this.C.notify()
    };
    var ZK = function(a, b) {
        Z.call(this, a, 892, _.Kf(gz));
        this.l = V(this);
        this.D = V(this);
        this.A = V(this);
        this.tb = V(this);
        this.yc = V(this);
        this.G = V(this);
        this.L = RB(this, b)
    };
    _.L(ZK, Z);
    ZK.prototype.j = function() {
        var a = this.L.value;
        if (!a) throw Error("config timeout");
        DB(this.l, Bf(a, Lv, 3));
        DB(this.D, Bf(a, Ov, 2));
        var b = Yc(a, 4, Bc);
        N(this.A, b);
        DB(this.tb, Qe(a, Gv, 6));
        DB(this.yc, Qe(a, fw, 5));
        DB(this.G, Bf(a, ew, 7))
    };
    ZK.prototype.I = function(a) {
        this.m(a)
    };
    ZK.prototype.m = function(a) {
        this.l.Ha(a);
        this.D.Ha(a);
        N(this.A, []);
        N(this.tb, []);
        N(this.yc, []);
        EB(this.G)
    };
    var $K = [{
            name: "Interstitial",
            ge: 1
        }, {
            name: "TopAnchor",
            ge: 2
        }, {
            name: "BottomAnchor",
            ge: 3
        }],
        aL = function(a, b) {
            Z.call(this, a, 789);
            this.l = b;
            this.C = V(this)
        };
    _.L(aL, Z);
    aL.prototype.j = function() {
        var a = this;
        CB(this.C, $K.filter(function(b) {
            return (new RegExp("gam" + b.name + "Demo", "i")).test(a.l)
        }).map(function(b) {
            var c = b.name;
            b = b.ge;
            var d, e;
            null == (d = window.console) || null == (e = d.warn) || e.call(d, "GPT - Demo " + c + " ENABLED");
            d = new fw;
            e = new Vv;
            b = _.z(e, 2, b);
            c = _.z(b, 1, "/22639388115/example/" + c.toLowerCase());
            return _.Wh(d, 5, gw, c)
        }))
    };
    var bL = function(a, b) {
        Z.call(this, a, 891);
        var c = this;
        this.l = V(this);
        this.error = void 0;
        var d = V(this);
        this.A = W(this, d);
        b ? b(function(e, f) {
            if (f) c.error = f, N(d, []);
            else try {
                if ("string" === typeof e) {
                    var g = JSON.parse(e || "[]");
                    Array.isArray(g) && N(d, g)
                }
            } catch (h) {} finally {
                d.Wa || (c.error = Error("malformed response"), N(d, []))
            }
        }) : (this.error = Error("missing input"), CB(d, []))
    };
    _.L(bL, Z);
    bL.prototype.j = function() {
        if (this.error) throw this.error;
        var a = Hd(iw, this.A.value);
        N(this.l, a)
    };
    var Fn = function(a, b, c, d) {
        Z.call(this, a, 959);
        this.hb = b;
        this.C = V(this);
        this.l = W(this, b);
        SB(this, c);
        SB(this, d)
    };
    _.L(Fn, Z);
    Fn.prototype.j = function() {
        N(this.C, this.l.value)
    };
    var En = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 874);
        this.A = b;
        this.M = c;
        this.F = d;
        this.G = e;
        this.l = QB(this);
        SB(this, f);
        this.D = W(this, g)
    };
    _.L(En, Z);
    En.prototype.j = function() {
        var a = this,
            b = new iA(this.F, {
                Ra: -1,
                eg: !0
            });
        _.Vn(this, b);
        if (kA(b)) {
            var c = this.M.I,
                d = c.status,
                e = function(f) {
                    var g = a.D.value,
                        h, k, l;
                    if (l = !(null == (h = a.G) ? 0 : J(h, 9))) {
                        var m = void 0 === m ? !1 : m;
                        l = oA(f) ? !1 === f.gdprApplies || "tcunavailable" === f.tcString || void 0 === f.gdprApplies && !m || "string" !== typeof f.tcString || !f.tcString.length ? !0 : mA(f, "1") : !1
                    }
                    h = _.z(g, 5, l);
                    l = !pA(f, ["3", "4"]);
                    h = _.z(h, 9, l);
                    h = _.z(h, 2, f.tcString);
                    l = null != (k = f.addtlConsent) ? k : "";
                    k = _.z(h, 4, l);
                    _.z(k, 7, f.internalErrorState);
                    null != f.gdprApplies && _.z(g, 3, f.gdprApplies);
                    _.E(uz) && !pA(f, ["2", "7", "9", "10"]) && _.z(g, 8, !0);
                    a.l.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    c.data = void 0;
                    c.status = 1;
                    c.j.push(e);
                    this.A.info(NJ());
                    b.addEventListener(function(f) {
                        oA(f) ? ("tcunavailable" === f.tcString ? a.A.info(OJ("failed")) : a.A.info(OJ("succeeded")), c.data = f, c.status = 2, c.dd().forEach(function(g) {
                            g(f)
                        }), c.Rd()) : (c.data = void 0, c.status = 1)
                    });
                    break;
                default:
                    throw Error("Impossible TCDataCacheStatus: " + d);
            }
        } else this.l.notify()
    };
    var Dn = function(a, b, c, d, e) {
        Z.call(this, a, 875);
        this.D = b;
        this.F = c;
        this.l = QB(this);
        SB(this, d);
        this.A = W(this, e)
    };
    _.L(Dn, Z);
    Dn.prototype.j = function() {
        var a = this,
            b = _.E(Pz) ? new QA(this.F) : new TG(this.F);
        _.Vn(this, b);
        if (b.l()) {
            var c = Zh(this.context, 660, function(d) {
                d && "string" === typeof d.uspString && _.z(a.A.value, 1, d.uspString);
                a.l.notify()
            });
            this.D.info(MJ());
            b.J(c)
        } else this.l.notify()
    };
    var Bn = function(a, b) {
        Z.call(this, a, 958);
        this.l = b;
        this.hb = V(this)
    };
    _.L(Bn, Z);
    Bn.prototype.j = function() {
        var a = new cC,
            b, c = null == (b = this.l) ? void 0 : J(b, 9);
        _.z(a, 5, !c);
        N(this.hb, a)
    };
    var Cn = function(a, b, c, d) {
        d = void 0 === d ? .001 : d;
        Z.call(this, a, 960);
        this.F = b;
        this.A = d;
        this.l = W(this, c)
    };
    _.L(Cn, Z);
    Cn.prototype.j = function() {
        var a = this;
        ei(this.context, 894, function() {
            return void Cj("cmpMet", function(b) {
                Ij(b, a.context);
                var c = new iA(a.F);
                _.Vn(a, c);
                var d = _.E(Pz) ? new QA(a.F) : new TG(a.F);
                _.Vn(a, d);
                K(b, "fc", Number(a.l.value));
                K(b, "tcfv1", Number(!!a.F.__cmp));
                K(b, "tcfv2", Number(kA(c)));
                K(b, "usp", Number(d.l()));
                K(b, "ptt", 17)
            }, a.A)
        })
    };
    var cL = function(a, b) {
        Z.call(this, a, 1052);
        this.A = V(this);
        this.l = V(this);
        this.D = Y(this, b)
    };
    _.L(cL, Z);
    cL.prototype.j = function() {
        var a = this.D.value,
            b = new Gv,
            c = new _.v.Map;
        if (a) {
            var d = new _.v.Set;
            a = _.x(a);
            for (var e = a.next(); !e.done; e = a.next()) {
                var f = e.value;
                if (_.dg(f, 1)) {
                    e = new _.v.Set;
                    c.set(_.Tf(f, 1).toString(), e);
                    f = _.x(f.m());
                    for (var g = f.next(); !g.done; g = f.next()) {
                        g = g.value;
                        var h = (0, B.K)(g.m());
                        e.add(h);
                        d.has(h) || _.Zf(b, 2, Ev, g);
                        d.add(h)
                    }
                }
            }
        }
        N(this.A, c);
        N(this.l, b)
    };
    var dL = function(a, b) {
        Z.call(this, a, 1040);
        this.l = V(this);
        this.A = Y(this, b)
    };
    _.L(dL, Z);
    dL.prototype.j = function() {
        var a = this.A.value;
        a ? (a = a.m(), CB(this.l, a.map(function(b) {
            var c = b.H();
            b = b.m();
            c = c && (_.u(c, "startsWith").call(c, location.protocol) || _.u(c, "startsWith").call(c, "data:") && 80 >= c.length) ? se(null === c ? "null" : void 0 === c ? "undefined" : c) : void 0;
            return {
                Uc: b,
                url: c
            }
        }))) : CB(this.l, [])
    };
    var Tq = function(a, b, c, d, e) {
        Z.call(this, a, 813);
        this.D = b;
        this.G = c;
        this.zb = e;
        this.A = V(this);
        d && (this.L = Y(this, d));
        this.l = Y(this, e)
    };
    _.L(Tq, Z);
    Tq.prototype.j = function() {
        var a = this,
            b, c, d = null != (c = this.G) ? c : null == (b = this.L) ? void 0 : b.value;
        if (d && d.length && this.l.value && !_.E(Iz)) {
            b = _.x(d);
            for (c = b.next(); !c.done; c = b.next()) d = c.value, c = d.Uc, (d = d.url) && _.Vn(this, Lg(c, d, this.l.value, this.zb, function(e, f) {
                ci(a.context, e, f);
                var g, h;
                null == (g = a.D) || null == (h = g.error) || h.call(g, f)
            }));
            N(this.A, !0)
        } else N(this.A, !1)
    };
    var eL = function(a, b, c) {
        Z.call(this, a, 1045);
        this.zb = c;
        this.l = W(this, b)
    };
    _.L(eL, Z);
    eL.prototype.j = function() {
        var a = this.l.value;
        if (a) {
            var b = this.context,
                c = this.zb;
            if (_.E(mz) || _.dg(a, 1)) {
                var d = new jg,
                    e = new Rq;
                N(e, a);
                a = new dL(b, e);
                G(d, a);
                b = new Tq(b, console, void 0, a.l, c);
                G(d, b);
                ug(d)
            }
        }
    };
    var Sq = function(a, b, c) {
        Z.call(this, a, 706);
        this.F = b;
        this.C = V(this);
        this.l = W(this, c)
    };
    _.L(Sq, Z);
    Sq.prototype.j = function() {
        DB(this.C, df(this.l.value, this.F))
    };
    var fL = function(a, b, c) {
        Z.call(this, a, 1051);
        this.A = b;
        this.l = Y(this, c)
    };
    _.L(fL, Z);
    fL.prototype.j = function() {
        var a = this;
        this.l.value && Hg(this.l.value, function(b, c) {
            ci(a.context, b, c);
            var d, e;
            null == (d = a.A) || null == (e = d.error) || e.call(d, c)
        })
    };
    var gL = function(a, b) {
        Z.call(this, a, 931);
        this.Pb = V(this);
        this.Kb = V(this);
        this.l = Y(this, b)
    };
    _.L(gL, Z);
    gL.prototype.j = function() {
        var a = this.l.value,
            b = new _.v.Map;
        N(this.Pb, new _.v.Map);
        if (a) {
            var c;
            a = _.x(null != (c = this.l.value) ? c : []);
            for (c = a.next(); !c.done; c = a.next()) {
                var d = c.value;
                c = Qe(d, zv, 1);
                c = 1 === _.Se(c[0], 1, 0) ? Nu(c[0]) : Qu(c[0], Mu);
                d = _.af(d, 2);
                var e = void 0;
                b.set(c, Math.min(null != (e = b.get(c)) ? e : Number.MAX_VALUE, d))
            }
        }
        N(this.Kb, b)
    };
    gL.prototype.m = function() {
        N(this.Pb, new _.v.Map);
        N(this.Kb, new _.v.Map)
    };
    var hL = function(a, b) {
        Z.call(this, a, 981);
        this.A = V(this);
        this.l = V(this);
        this.D = Y(this, b)
    };
    _.L(hL, Z);
    hL.prototype.j = function() {
        var a = new _.v.Map,
            b, c = _.x(null != (b = this.D.value) ? b : []);
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            var d = Qe(b, zv, 1);
            d = 1 === _.Se(d[0], 1, 0) ? Nu(d[0]) : Qu(d[0], Mu);
            a.set(d, _.af(b, 2))
        }
        N(this.A, a);
        a = new qv;
        N(this.l, a)
    };
    hL.prototype.m = function() {
        N(this.A, new _.v.Map);
        var a = this.l;
        var b = new qv;
        b = _.z(b, 1, 2);
        N(a, b)
    };
    var iL = function(a, b, c, d, e, f) {
        Z.call(this, a, 976);
        this.nextFunction = d;
        this.l = e;
        this.requestBidsConfig = f;
        SB(this, b);
        SB(this, c)
    };
    _.L(iL, Z);
    iL.prototype.j = function() {
        var a;
        null == (a = this.nextFunction) || a.apply(this.l, [this.requestBidsConfig])
    };
    var jL = function(a, b, c, d, e, f) {
        Z.call(this, a, 975);
        this.A = b;
        this.l = c;
        this.D = d;
        this.pbjs = e;
        this.requestBidsConfig = f;
        this.C = new KB
    };
    _.L(jL, Z);
    jL.prototype.j = function() {
        On(this.pbjs, this.A, this.l, this.D, this.requestBidsConfig);
        this.C.notify()
    };
    jL.prototype.m = function() {
        this.C.notify()
    };
    var kL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1100);
        this.pbjs = b;
        this.l = c;
        this.A = d;
        this.D = e;
        this.requestBidsConfig = f;
        this.C = new KB
    };
    _.L(kL, Z);
    kL.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.l) ? void 0 : a.get("*")) ? b : _.Kf(By);
        if (c) this.qb(c);
        else {
            var d, e, f, g;
            a = null != (g = null != (f = null == (d = this.requestBidsConfig) ? void 0 : d.adUnits) ? f : null == (e = this.pbjs) ? void 0 : e.adUnits) ? g : [];
            d = _.x(a);
            for (e = d.next(); !e.done; e = d.next())
                if (e = e.value.code) c = b = a = g = void 0, f = null != (g = null != (a = null == (c = this.l) ? void 0 : c.get(_.E(In) ? Hn(e) : e)) ? a : null == (b = this.l) ? void 0 : b.get(_.xi(e))) ? g : 0, this.qb(f)
        }
        this.C.notify()
    };
    kL.prototype.qb = function(a) {
        var b;
        null != (b = this.A) && _.z(b, 2, this.D);
        if (a) {
            var c;
            null == (c = this.A) || _.z(c, 1, 1);
            if (!this.D) {
                this.requestBidsConfig.timeout = a;
                var d, e, f;
                b = null != (f = null == (e = (d = this.pbjs).getConfig) ? void 0 : e.call(d).s2sConfig) ? f : [];
                if (Array.isArray(b))
                    for (d = _.x(b), e = d.next(); !e.done; e = d.next()) e.value.timeout = a;
                else b.timeout = a;
                var g, h;
                null == (h = (g = this.pbjs).setConfig) || h.call(g, {
                    bidderTimeout: a
                })
            }
        }
    };
    kL.prototype.m = function() {
        this.C.notify()
    };
    var lL = function(a, b, c, d, e, f, g, h) {
        _.Q.call(this);
        this.j = a;
        this.B = b;
        this.m = c;
        this.l = d;
        this.J = e;
        this.I = f;
        this.A = g;
        this.pbjs = h
    };
    _.L(lL, _.Q);
    lL.prototype.push = function(a) {
        var b = a.context,
            c = a.nextFunction;
        a = a.requestBidsConfig;
        if (this.pbjs) {
            var d = new jg;
            _.Vn(this, d);
            var e = new kL(this.j, this.pbjs, this.J, this.I, this.A, a),
                f = new jL(this.j, this.B, this.m, this.l, this.pbjs, a);
            G(d, e);
            G(d, f);
            G(d, new iL(this.j, f.C, e.C, c, b, a));
            ug(d)
        }
    };
    var mL = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 951);
        this.F = window;
        this.zd = V(this);
        this.Bd = V(this);
        this.G = W(this, b);
        this.A = Y(this, d);
        this.D = W(this, e);
        this.N = W(this, f);
        this.l = Y(this, g);
        this.P = Y(this, h);
        this.L = W(this, k);
        SB(this, c)
    };
    _.L(mL, Z);
    mL.prototype.j = function() {
        var a = !!$k().pbjs_hooks;
        N(this.Bd, a);
        DB(this.zd, a ? null : _.jf());
        var b, c = null == (b = this.A.value) ? void 0 : b.size,
            d;
        b = (null == (d = this.l.value) ? void 0 : d.size) || _.Kf(By);
        d = this.G.value;
        var e, f = null != (e = $k().pbjs_hooks) ? e : [];
        e = new lL(this.context, this.A.value, this.D.value, this.N.value, this.l.value, this.P.value, this.L.value, d);
        _.Vn(this, e);
        f = _.x(f);
        for (var g = f.next(); !g.done; g = f.next()) e.push(g.value);
        if (c || b || a) $k().pbjs_hooks = Rn(this.context, e);
        !c && !b || a || Pn(d, this.F)
    };
    var nL = function(a, b, c) {
        Z.call(this, a, 1093);
        this.A = new JB(b);
        this.l = W(this, c)
    };
    _.L(nL, Z);
    nL.prototype.j = function() {
        var a = this.A.value;
        if (a) {
            var b;
            (null == (b = this.l.value["*"]) ? 0 : b.vc) && Array.isArray(a.installedModules) && (b = new fl("pbjs_modules"), Ij(b, this.context), K(b, "pbmods", a.installedModules.join("~")), hl(b))
        }
    };
    var oL = function(a, b) {
        Z.call(this, a, 966);
        this.F = b;
        this.nb = V(this)
    };
    _.L(oL, Z);
    oL.prototype.j = function() {
        var a = this,
            b = uh(this.F);
        if (b) N(this.nb, b);
        else if ((b = Object.getOwnPropertyDescriptor(this.F, "_pbjsGlobals")) && !b.configurable) Cj("pdpg_error", function(d) {
            Ij(d, a.context)
        }, _.Kf(zy));
        else {
            var c = null;
            Object.defineProperty(this.F, "_pbjsGlobals", {
                set: function(d) {
                    c = d;
                    (d = uh(a.F)) && N(a.nb, d)
                },
                get: function() {
                    return c
                }
            })
        }
    };
    oL.prototype.m = function() {};
    var Xn = function(a, b, c, d) {
        Z.call(this, a, 879);
        this.A = b;
        this.l = V(this);
        c && (this.D = W(this, d))
    };
    _.L(Xn, Z);
    Xn.prototype.j = function() {
        var a, b;
        (null != (b = null == (a = this.D) ? void 0 : a.value) ? b : this.A.m()) ? (a = this.A.A(), FB(this.l, a)) : EB(this.l)
    };
    var Wn = function(a, b, c) {
        Z.call(this, a, 896);
        this.l = b;
        this.Lb = V(this);
        c && SB(this, c)
    };
    _.L(Wn, Z);
    Wn.prototype.j = function() {
        var a = this.l.m();
        N(this.Lb, a)
    };
    var pL = function(a, b) {
        Z.call(this, a, 1018);
        this.cd = QB(this);
        this.l = Y(this, b)
    };
    _.L(pL, Z);
    pL.prototype.j = function() {
        var a, b, c, d = _.x(null != (c = null == (a = this.l.value) ? void 0 : null == (b = Bf(a, SA, 5)) ? void 0 : Yc(b, 1, Bc)) ? c : []);
        for (a = d.next(); !a.done; a = d.next()) qf(a.value);
        this.cd.notify()
    };
    var qL = function(a, b) {
        Z.call(this, a, 1070);
        this.l = V(this);
        this.A = Y(this, b)
    };
    _.L(qL, Z);
    qL.prototype.j = function() {
        var a, b = null == (a = this.A.value) ? void 0 : Bf(a, SA, 5);
        if (b) {
            a = [];
            for (var c = _.x(Yc(b, 2, Ec)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value;
                d = new Tv;
                var f = new Rv;
                e = _.z(f, 1, e);
                d = _.Th(d, 2, e);
                null != go(b, 3) && (e = new Pv, e = _.z(e, 1, 1), e = _.z(e, 2, Te(b, 3)), _.Th(d, 3, e));
                a.push(d)
            }
            N(this.l, a)
        } else N(this.l, [])
    };
    var rL = function(a, b, c, d) {
        Z.call(this, a, 1016);
        this.C = V(this);
        this.A = Y(this, b);
        this.l = Y(this, c);
        this.D = UB(this, [b, d])
    };
    _.L(rL, Z);
    rL.prototype.j = function() {
        if (this.l.value) {
            var a = this.A.value || this.D.value;
            a && sL(this, a) ? N(this.C, a) : (EB(this.C), tL(this, a))
        } else EB(this.C)
    };
    rL.prototype.I = function(a) {
        this.m(a)
    };
    rL.prototype.m = function() {
        EB(this.C)
    };
    var sL = function(a, b) {
            return Qe((0, B.K)(a.l.value), Mv, 1).some(function(c) {
                return _.Tf(c, 1) === b
            })
        },
        tL = function(a, b) {
            Cj("pp_iris_failure", function(c) {
                K(c, "fnc", b);
                Ij(c, a.context)
            }, _.Kf(hz))
        };
    var uL = function(a, b) {
        Z.call(this, a, 1015);
        this.l = V(this);
        this.A = Y(this, b)
    };
    _.L(uL, Z);
    uL.prototype.j = function() {
        if (this.A.value) {
            var a = Qe(this.A.value, Mv, 1);
            (null == a ? 0 : a.length) ? (a = Qe(this.A.value, Mv, 1)[0], (_.C = [2, 3], _.u(_.C, "includes")).call(_.C, _.Se(a, 3, 0)) ? N(this.l, _.Tf(a, 1)) : EB(this.l)) : EB(this.l)
        } else EB(this.l)
    };
    uL.prototype.I = function(a) {
        this.m(a)
    };
    uL.prototype.m = function() {
        EB(this.l)
    };
    var vL = function(a, b, c) {
        Z.call(this, a, 1017);
        this.F = c;
        this.C = QB(this);
        this.l = Y(this, b)
    };
    _.L(vL, Z);
    vL.prototype.j = function() {
        var a = this;
        if (this.l.value) {
            var b = rA(this.F, this.l.value, function(c) {
                if (!c) {
                    c = hx(b.j);
                    for (var d = _.x(document.getElementsByName("googlefcPresent")), e = d.next(); !e.done; e = d.next()) c.Uf(e.value)
                }
                a.C.notify()
            });
            b.start()
        } else this.C.notify()
    };
    vL.prototype.I = function(a) {
        this.m(a)
    };
    vL.prototype.m = function() {
        this.C.notify()
    };
    var wL = function(a, b) {
        Z.call(this, a, 1056);
        this.C = V(this);
        this.l = W(this, b)
    };
    _.L(wL, Z);
    wL.prototype.j = function() {
        var a = Nh((0, B.K)(this.l.value.getAdUnitPath()));
        N(this.C, a)
    };
    wL.prototype.I = function(a) {
        this.m(a)
    };
    wL.prototype.m = function() {
        EB(this.C)
    };
    var xL = function() {
        Z.apply(this, arguments);
        this.value = this.promise = null;
        this.C = V(this)
    };
    _.L(xL, Z);
    xL.prototype.j = function() {
        var a = this;
        this.promise.then(function() {
            return void DB(a.C, a.value)
        })
    };
    var Qo = function(a, b, c, d) {
        xL.call(this, a, 1061);
        var e = this;
        this.promise = rI(b, c, function(f) {
            return null !== (e.value = d(f))
        })
    };
    _.L(Qo, xL);
    var yL = function(a, b, c, d) {
        Z.call(this, a, 906, _.Kf(fz));
        this.l = QB(this);
        if (b === b.top) {
            var e = new jg;
            _.Vn(this, e);
            var f = new uL(a, c);
            G(e, f);
            d = new Qo(a, d, vI, function(g) {
                return g.detail.U
            });
            G(e, d);
            d = new wL(a, d.C);
            G(e, d);
            a = new rL(a, f.l, c, d.C);
            G(e, a);
            b = new vL(this.context, a.C, b);
            G(e, b);
            TB(this, b.C);
            ug(e)
        } else this.l.notify()
    };
    _.L(yL, Z);
    yL.prototype.j = function() {
        this.l.notify()
    };
    yL.prototype.I = function(a) {
        this.m(a)
    };
    yL.prototype.m = function() {
        this.l.notify()
    };
    var zL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1096);
        this.networkCode = b;
        this.F = c;
        this.V = d;
        this.Ca = e;
        this.l = Y(this, f)
    };
    _.L(zL, Z);
    zL.prototype.j = function() {
        var a, b = null == (a = this.l.value) ? void 0 : a.Yf;
        b && b(this.Ca, this.V, this.F, this.networkCode)
    };
    var AL = function(a) {
        this.module = a
    };
    AL.prototype.toString = function() {
        return String(this.module)
    };
    _.BL = new AL(2);
    _.CL = new AL(5);
    var DL = function(a, b) {
        Z.call(this, a, 1095);
        this.l = b;
        this.C = V(this)
    };
    _.L(DL, Z);
    DL.prototype.j = function() {
        FB(this.C, this.l.load(_.CL))
    };
    var EL = function(a, b, c, d) {
        Z.call(this, a, 1090);
        this.l = b;
        this.A = W(this, c);
        this.D = Y(this, d)
    };
    _.L(EL, Z);
    EL.prototype.j = function() {
        var a = this.D.value,
            b;
        if (a && null != (b = Bf(a, cw, 1)) && _.dw(b).length) {
            b = new jg;
            _.Vn(this, b);
            var c = new DL(this.context, this.l);
            G(b, c);
            a = new zL(this.context, "", window, this.A.value, (0, B.K)(Bf(a, cw, 1)), c.C);
            G(b, a);
            ug(b)
        }
    };
    var FL = function(a, b) {
        Z.call(this, a, 1081);
        this.Oa = V(this);
        this.l = Y(this, b)
    };
    _.L(FL, Z);
    FL.prototype.j = function() {
        this.l.value ? N(this.Oa, this.l.value) : EB(this.Oa)
    };
    var GL = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1080);
        this.X = b;
        this.googletag = c;
        this.T = d;
        this.D = e;
        this.l = f;
        this.G = g;
        this.A = V(this)
    };
    _.L(GL, Z);
    GL.prototype.j = function() {
        if (Do(this.l, Xv, 2) && ao((0, B.K)(Bf(this.l, Xv, 2)))) {
            var a;
            mo(this.X, this.googletag, this.l, null != (a = this.T) ? a : this.D.j, this.G);
            null != go(this.l, 1) ? N(this.A, Te(this.l, 1)) : EB(this.A)
        } else EB(this.A)
    };
    var HL = new _.v.Map([
            [1, 5],
            [2, 2],
            [3, 3]
        ]),
        IL = function(a, b, c, d, e, f, g, h) {
            Z.call(this, a, 1079);
            this.googletag = b;
            this.T = c;
            this.L = d;
            this.l = e;
            this.G = f;
            this.D = g;
            this.A = h
        };
    _.L(IL, Z);
    IL.prototype.j = function() {
        var a = this,
            b = this.D.getAdUnitPath(),
            c = HL.get(_.Se(this.D, 2, 0));
        if (b && c && (b = po(this.context, this.G, this.L, {
                be: c,
                adUnitPath: b,
                jb: !0
            }))) {
            var d = (0, B.K)(b.j);
            this.A && ko((0, B.K)(jo(this.l, d.getSlotElementId())), this.A);
            this.googletag.cmd.push(function() {
                d.addService(a.googletag.pubads())
            });
            lo(document, function() {
                a.googletag.display(d);
                var e;
                J(null != (e = a.T) ? e : a.l.j, 4) && a.googletag.pubads().refresh([d])
            })
        }
    };
    var Er = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1082);
        this.googletag = b;
        this.T = c;
        this.P = d;
        this.A = e;
        this.N = f;
        this.L = [];
        this.G = V(this);
        this.D = new FL(this.context, this.G);
        this.l = [];
        this.Oa = this.D.Oa;
        _.Vn(this, this.D);
        a = _.x(g);
        for (b = a.next(); !b.done; b = a.next()) this.l.push(W(this, b.value))
    };
    _.L(Er, Z);
    Er.prototype.j = function() {
        if (_.E(jz)) {
            var a = JL(this),
                b = a.Wf,
                c = a.Ah,
                d;
            DB(this.G, null == (d = a.Qg) ? void 0 : Bf(d, Tv, 4));
            a = new jg;
            _.Vn(this, a);
            b = _.x(b);
            for (d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                var e = void 0;
                G(a, new IL(this.context, this.googletag, null != (e = this.T) ? e : this.A.j, this.P, this.A, this.N, (0, B.K)(eo(d, Vv, 5, gw)), Bf(d, Tv, 4)))
            }
            c = _.x(c);
            for (d = c.next(); !d.done; d = c.next()) b = d.value, b = new GL(this.context, document, this.googletag, this.T, this.A, (0, B.K)(eo(b, Zv, 6, gw)), Bf(b, Tv, 4)), G(a, b), this.L.push(b.A);
            G(a, this.D);
            ug(a)
        } else EB(this.Oa)
    };
    var JL = function(a) {
        var b = [],
            c = [];
        a = _.x(_.u(a.l, "flatMap").call(a.l, function(f) {
            return f.value
        }));
        for (var d = a.next(); !d.done; d = a.next()) switch (d = d.value, mk(d, gw)) {
            case 5:
                b.push(d);
                break;
            case 6:
                c.push(d);
                break;
            case 8:
                var e = d
        }
        return {
            Wf: b,
            Ah: c,
            Qg: e
        }
    };
    var KL = function(a, b, c, d, e, f, g, h) {
        _.Q.call(this);
        this.context = a;
        this.ja = b;
        this.ia = c;
        this.L = d;
        this.M = e;
        this.N = f;
        this.P = g;
        this.W = h;
        this.G = new bL(this.context, this.N);
        this.m = new ZK(this.context, this.G.l);
        this.j = new WK(this.context, this.m.l, window);
        this.B = new gL(this.context, this.j.A);
        this.l = new hL(this.context, this.j.D);
        var k;
        this.R = new aL(this.context, null != (k = window.location.hash) ? k : "");
        this.D = new Er(this.context, $k(), null, this.ja, this.ia, this.L, [this.R.C, this.m.yc]);
        this.I = new oL(this.context, window);
        this.J = new YK(this.context, this.P, this.j.sb, this.m.A, this.j.l, this.D.L);
        this.A = new mL(this.context, this.I.nb, this.J.C, this.B.Kb, this.j.Jb, this.B.Pb, this.l.A, this.l.l, this.j.cc);
        _.Vn(this, this.I);
        _.Vn(this, this.G);
        _.Vn(this, this.m);
        _.Vn(this, this.B);
        _.Vn(this, this.l);
        _.Vn(this, this.j);
        _.Vn(this, this.R);
        _.Vn(this, this.D);
        _.Vn(this, this.A);
        _.Vn(this, this.J)
    };
    _.L(KL, _.Q);
    var LL = function(a, b) {
        var c = new jg;
        _.Vn(a, c);
        G(c, a.I);
        G(c, a.G);
        G(c, a.m);
        G(c, a.j);
        G(c, a.B);
        G(c, a.J);
        G(c, a.l);
        b = new yL(a.context, window, a.m.D, b);
        a.vd = b.l;
        G(c, b);
        G(c, a.R);
        G(c, a.D);
        G(c, new nL(a.context, a.I.nb, a.j.sb));
        G(c, a.A);
        b = Yn(a.context, a.N, a.vd);
        var d = b.Lb,
            e = b.gf;
        _.Vn(c, b.nc);
        b = new pL(a.context, e);
        G(c, b);
        var f = new qL(a.context, e);
        G(c, f);
        var g = !_.E(Iz) && !Ul(),
            h = _.E(pz);
        if (g || h) {
            e = Gn(a.context, a.L, a.M, void 0, window, d, e);
            d = e.hb;
            _.Vn(a, e.nc);
            if (g)
                if (_.E(Hy)) {
                    var k = a.context;
                    $k();
                    e = a.m.tb;
                    var l = window;
                    g = new jg;
                    var m = new Sq(k, l, d);
                    l = m.C;
                    G(g, m);
                    e = new cL(k, e);
                    G(g, e);
                    G(g, new eL(k, e.l, l));
                    _.E(Kz) && (k = new fL(k, console, l), G(g, k));
                    ug(g);
                    k = e.A;
                    _.Vn(a, g)
                } else g = new Sq(a.context, window, d), l = g.C, G(c, g), e = new cL(a.context, a.m.tb), k = e.A, G(c, e), e = new eL(a.context, e.l, g.C), G(c, e), _.E(Kz) && (g = new fL(a.context, console, g.C), G(c, g));
            h && (g = a.context, e = a.W, m = a.m.G, h = new jg, d = new EL(g, e, d, m), G(h, d), ug(h), _.Vn(a, h))
        }
        ug(c);
        return {
            vd: a.vd,
            mg: a.J.C,
            nb: a.I.nb,
            sb: a.j.sb,
            Kb: a.B.Kb,
            Jb: a.j.Jb,
            cc: a.j.cc,
            Pb: a.B.Pb,
            zd: a.A.zd,
            Bd: a.A.Bd,
            cg: a.l.l,
            oh: k,
            Oa: a.D.Oa,
            tb: a.m.tb,
            cd: b.cd,
            Kg: f.l,
            zb: l
        }
    };
    new KB;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    new KB;
    new Rq;
    var ML = ["Debug", "Info", "Warning", "Error", "Fatal"],
        NL = function(a, b, c) {
            this.level = a;
            this.message = b;
            this.j = c;
            this.timestamp = new Date
        };
    _.aa = NL.prototype;
    _.aa.getSlot = function() {
        return this.j
    };
    _.aa.getLevel = function() {
        return this.level
    };
    _.aa.getTimestamp = function() {
        return this.timestamp
    };
    _.aa.getMessage = function() {
        return this.message
    };
    _.aa.toString = function() {
        return this.timestamp.toTimeString() + ": " + ML[this.level] + ": " + this.message
    };
    var OL = {
            20: function(a) {
                return "Ignoring a call to setCollapseEmptyDiv(false, true). Slots that start out collapsed should also collapse when empty. Slot: " + a[0] + "."
            },
            23: function(a) {
                return 'Error in googletag.display: could not find div with id "' + a[1] + '" in DOM for slot: ' + a[0] + "."
            },
            34: function(a) {
                return "Size mapping is null because invalid mappings were added: " + a[0] + "."
            },
            60: function(a) {
                return "Ignoring the " + a[0] + "(" + (a[1] || "") + ") call since the service is already enabled."
            },
            66: function(a) {
                return "Slot " + a[0] + " cannot be refreshed until PubAdsService is enabled."
            },
            68: function() {
                return "Slots cannot be cleared until service is enabled."
            },
            80: function(a) {
                return "Slot object at position " + a[0] + " is of incorrect type."
            },
            84: function(a) {
                return 'Cannot find targeting attribute "' + a[0] + '" for "' + a[1] + '".'
            },
            93: function(a) {
                return "Failed to register listener. Unknown event type: " + a[0] + "."
            },
            96: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + ")."
            },
            122: function(a) {
                return "Invalid argument: " + a[0] + "(" + a[1] + "). Valid values: " + a[2] + "."
            },
            121: function(a) {
                return "Invalid object passed to " + a[0] + "(" + a[1] + "), for " + a[2] + ": " + a[3] + "."
            },
            151: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + "). All zero-area slot sizes were removed."
            },
            105: function(a) {
                return "SRA requests may include a maximum of 30 ad slots. " + a[1] + " were requested, so the last " + a[2] + " were ignored."
            },
            106: function(a) {
                return "Publisher betas " + a[0] + " were declared after enableServices() was called."
            },
            107: function(a) {
                return "Publisher betas may only be declared once. " + a[0] + " were added after betas had already been declared."
            },
            108: function(a) {
                return "Beta keys cannot be cleared. clearTargeting() was called on " + a[0] + "."
            },
            123: function(a) {
                return "Refresh was throttled for slot: " + a[0] + "."
            },
            113: function(a) {
                return a[0] + " ad slot ineligible as page is not mobile optimized: " + a[1] + "."
            },
            116: function(a) {
                return 'The unique SafeFrame domain setting in Google Ad Manager conflicts with the "useUniqueDomain" setting passed to the setSafeFrameConfig API method. GPT will use useUniqueDomain=' + a[0] + " based on the API call."
            },
            114: function() {
                return 'setCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            115: function() {
                return 'updateCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            132: function(a) {
                return "Taxonomy with id " + a[0] + " has reached the limit of " + a[1] + " values."
            },
            133: function() {
                return "No taxonomy values were cleared, either due to an invalid taxonomy or no values present."
            },
            134: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: Format already created on the page."
            },
            135: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: Frequency cap of 1 has been exceeded."
            },
            136: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: The viewport exceeds the current maximum width of 2500px."
            },
            137: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: Format currently only supported on mobile."
            },
            138: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: Format currently only supports portrait orientation."
            },
            139: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: GPT is not running in the top-level window."
            },
            140: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: Detected browser is currently unsupported."
            },
            142: function(a) {
                return "A google product ad tag with click url " + a[0] + " does not contain any elements enabled for clicking."
            },
            145: function(a) {
                return ro(a[0]) + " " + a[1] + " not requested: Unable to access local storage to determine if the frequency cap has been exceeded due to insufficient user consent."
            },
            143: function() {
                return "getName on googletag.Slot is deprecated and will be removed. Use getAdUnitPath instead."
            },
            147: function() {
                return "GPT must be loaded from the limited ads URL to enable limited ads functionality."
            },
            148: function() {
                return "CommerceAdsConfig must contain a valid value for either categories or queries."
            },
            150: function() {
                return "Legacy browser does not support intersection observer causing lazy render/fetch as well as viewability events not to work properly."
            }
        },
        PL = {
            26: function(a) {
                return "Div ID passed to googletag.display() does not match any defined slots: " + a[0] + "."
            },
            28: function(a) {
                return "Error in googletag.defineSlot: Cannot create slot " + a[1] + '. Div element "' + a[0] + '" is already associated with another slot: ' + a[2] + "."
            },
            149: function(a) {
                return "Error in googletag.defineSlot: Invalid ad unit path provided " + a[0] + ", see https://support.google.com/admanager/answer/10477476 for more information."
            },
            92: function(a) {
                return "Exception in " + a[1] + ' event listener: "' + a[0] + '".'
            },
            30: function(a) {
                return "Exception in googletag.cmd function: " + a[0] + "."
            },
            125: function(a) {
                return "google-product-ad element is invalid: " + a[0] + "."
            },
            126: function() {
                return "Attempted to collect prebid data but window.pbjs is undefined."
            },
            127: function(a) {
                return "Encountered the following error while attempting to collect prebid metadata: " + a[0] + "."
            },
            144: function() {
                return "ContentService is no longer available. Use the browser's built-in DOM APIs to directly add content to div elements instead."
            }
        };
    var QL = function(a) {
            this.context = a;
            this.m = this.H = this.j = 0;
            this.B = window;
            this.o = [];
            this.o.length = 1E3
        },
        lK = function(a) {
            return [].concat(_.ve(a.o.slice(a.j)), _.ve(a.o.slice(0, a.j))).filter(function(b) {
                return !!b
            })
        },
        mK = function(a, b) {
            return lK(a).filter(function(c) {
                return c.getSlot() === b
            })
        },
        nK = function(a, b) {
            return lK(a).filter(function(c) {
                return c.getLevel() >= b
            })
        };
    QL.prototype.log = function(a, b, c, d) {
        var e = this;
        d = void 0 === d ? !1 : d;
        var f, g;
        c = new NL(a, b, null != (g = null == (f = void 0 === c ? null : c) ? void 0 : f.j) ? g : null);
        this.o[this.j] = c;
        this.j = (this.j + 1) % 1E3;
        g = _.Kf(Ky) && 100 > this.H;
        f = 2 === a || 3 === a;
        var h = b.getMessageArgs(),
            k = b.getMessageId(),
            l = OL[k] || PL[k];
        g && f && (b = _.Kf(Ky), Cj("gpt_eventlog_messages", function(m) {
            ++e.H;
            Ij(m, e.context);
            K(m, "level", a);
            K(m, "messageId", k);
            K(m, "args", h.join("|"));
            l || K(m, "noMsg", !0);
            var n = Error(),
                p;
            K(m, "stack", _.oB(null != (p = n.stack) ? p : "", n.message))
        }, b));
        if (l) {
            b = "[GPT] " + l(h);
            if (d) throw new Bm(b);
            d = this.m < _.Kf(Ly) && f && _.q.console;
            if (this.B === top && d || _.u(_.q.navigator.userAgent, "includes").call(_.q.navigator.userAgent, "Lighthouse"))(function(m) {
                var n, p, r, t;
                return void(2 === a ? null == (p = (n = _.q.console).warn) ? void 0 : p.call(n, m) : null == (t = (r = _.q.console).error) ? void 0 : t.call(r, m))
            })(b), this.m++
        }
        return c
    };
    QL.prototype.info = function(a, b) {
        return this.log(1, a, void 0 === b ? null : b)
    };
    var ql = function(a, b, c) {
        a.log(2, b, c, !1)
    };
    QL.prototype.error = function(a, b, c) {
        return this.log(3, a, b, void 0 === c ? !1 : c)
    };
    var RL = function() {
            var a = this;
            var b = void 0 === b ? vj().j : b;
            this.H = "";
            this.j = this.storage = null;
            this.B = this.l = this.m = !1;
            this.o = function() {
                return !1
            };
            var c = {},
                d = {},
                e = {};
            this.I = (e[3] = (c[13] = function() {
                return _.xb.apply(0, arguments).some(function(f) {
                    return 0 == a.H.lastIndexOf(f, 0)
                })
            }, c[12] = function() {
                return !!J(b, 6)
            }, c[15] = function(f) {
                return a.o(f)
            }, c[48] = function() {
                return !!a.storage
            }, c[51] = function() {
                return a.m
            }, c[66] = function() {
                try {
                    return !!HTMLScriptElement.supports("webbundle")
                } catch (f) {
                    return !1
                }
            }, c[67] = function() {
                return a.l
            }, c[68] = function() {
                return a.B
            }, c), e[4] = (d[8] = function(f) {
                var g;
                return null != (g = Xe(a.storage, Number(f))) ? g : void 0
            }, d[10] = function(f) {
                return a.j ? _.xi(f + a.j) % 1E3 : void 0
            }, d), e[5] = {}, e)
        },
        SL = function(a, b) {
            b && !a.j && (a.j = _.u(b.split(":"), "find").call(b.split(":"), function(c) {
                return 0 === c.indexOf("ID=")
            }) || null)
        };
    var TL = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
        UL = function(a, b, c, d, e, f, g, h, k, l, m, n) {
            Z.call(this, a, 920);
            this.L = b;
            this.U = c;
            this.Bb = d;
            this.D = V(this);
            this.G = V(this);
            this.l = V(this);
            this.N = [];
            this.A = new _.v.Map;
            this.la = W(this, e);
            f && (this.ca = new JB(f));
            g && (this.P = W(this, g));
            h && (this.ba = Y(this, h));
            k && (this.W = W(this, k));
            l && (this.ra = W(this, l));
            m && (this.ma = Y(this, m));
            n && (this.ga = Y(this, n))
        };
    _.L(UL, Z);
    UL.prototype.j = function() {
        if (VL(this)) {
            var a, b = null == (a = this.ca) ? void 0 : a.value;
            b && b.libLoaded ? "function" !== typeof b.getEvents ? (this.L.error(RJ()), WL(this)) : (a = XL(this, b)) ? (DB(this.l, a), N(this.D, this.A), N(this.G, this.N)) : WL(this) : WL(this)
        } else WL(this)
    };
    UL.prototype.I = function(a) {
        this.m(a)
    };
    UL.prototype.m = function(a) {
        this.L.error(SJ(a.message));
        WL(this)
    };
    var WL = function(a) {
            EB(a.l);
            EB(a.D);
            EB(a.G)
        },
        XL = function(a, b) {
            var c = (0, B.K)(b.getEvents)(),
                d = c.filter(function(g) {
                    var h = g.args;
                    return "auctionEnd" === g.eventType && h.auctionId
                }),
                e = !1,
                f = a.la.value.map(function(g) {
                    var h = new xv,
                        k = function(la) {
                            return la === g.getDomId() || la === g.getAdUnitPath()
                        },
                        l, m = null != (l = YL.get(g)) ? l : 0,
                        n;
                    l = null != (n = d.filter(function(la) {
                        var va, na, ya;
                        return Number(null == (va = la.args) ? void 0 : va.timestamp) > m && (null == (na = la.args) ? void 0 : null == (ya = na.adUnitCodes) ? void 0 : _.u(ya, "find").call(ya, k))
                    })) ? n : [];
                    if (!l.length) return a.N.push(g), [g, h];
                    var p;
                    n = null == (p = l.reduce(function(la, va) {
                        return Number(va.args.timestamp) > Number(la.args.timestamp) ? va : la
                    })) ? void 0 : p.args;
                    if (!n) return [g, h];
                    var r = void 0 === n.bidderRequests ? [] : n.bidderRequests;
                    p = void 0 === n.bidsReceived ? [] : n.bidsReceived;
                    var t = n.auctionId;
                    n = n.timestamp;
                    if (!t || null == n || !r.length) return [g, h];
                    YL.has(g) || _.qo(g, function() {
                        return YL.delete(g)
                    });
                    YL.set(g, n);
                    n = yv(h);
                    Math.random() < _.Kf(Ay) && b.version && TL.test(b.version) && _.z(n, 6, b.version);
                    var w;
                    uv(n, null == (w = a.ma) ? void 0 : w.value);
                    w = mj(function() {
                        return Oo(c, t)
                    });
                    l = rl(a.U[g.getDomId()]);
                    var D = {};
                    r = _.x(r);
                    for (var F = r.next(); !F.done; D = {
                            Hc: D.Hc,
                            Jd: D.Jd
                        }, F = r.next()) {
                        var I = F.value;
                        D.Hc = I.bidderCode;
                        var S = I.bids;
                        F = I.timeout;
                        D.Jd = I.src;
                        I = I.auctionStart;
                        var M = {};
                        S = _.x(S);
                        for (var R = S.next(); !R.done; M = {
                                Xb: M.Xb
                            }, R = S.next()) {
                            var T = R.value;
                            M.Xb = T.bidId;
                            var X = T.transactionId;
                            R = T.adUnitCode;
                            var ka = T.getFloor;
                            T = T.mediaTypes;
                            if (M.Xb && k(R)) {
                                e = !0;
                                Co(n, g, R);
                                X && (_.dg(n, 4) || _.z(n, 4, X), a.A.has(X) || a.A.set(X, I));
                                null != go(n, 8) || _.z(n, 8, F);
                                var ca = _.u(p, "find").call(p, function(la) {
                                    return function(va) {
                                        return va.requestId === la.Xb
                                    }
                                }(M));
                                X = to(n, function(la) {
                                    return function() {
                                        var va = wo(new xo, la.Hc);
                                        _.E(yo) && zo(la.Hc, b, va);
                                        switch (la.Jd) {
                                            case "client":
                                                _.z(va, 7, 1);
                                                break;
                                            case "s2s":
                                                _.z(va, 7, 2)
                                        }
                                        return va
                                    }
                                }(D)());
                                Fo(n, X, R, (0, B.K)(a.ba).value, (0, B.K)(a.W).value, (0, B.K)(a.ra).value, ka);
                                ca ? (vo(X, 1), "number" === typeof ca.timeToRespond && Ao(X, ca.timeToRespond), R = so(ca, l, T), uo(X, R)) : (R = w().get(M.Xb)) && !R.nf ? Ao(vo(X, 2), Math.round(R.latency)) : Ao(vo(X, 3), F)
                            }
                        }
                    }
                    var oa;
                    (null == (oa = b.getConfig) ? 0 : oa.call(b).useBidCache) && Bo(n, g, t, l, b);
                    return [g, h]
                });
            return e ? new _.v.Map(f) : null
        },
        VL = function(a) {
            var b;
            if (null == (b = a.ga) ? 0 : b.value) return !0;
            var c, d = null == (c = a.P) ? void 0 : c.value;
            if (!d) return !1;
            var e;
            return (null == (e = d["*"]) ? void 0 : e.vc) || a.Bb.split(",").some(function(f) {
                var g;
                return !(null == (g = d[f]) || !g.vc)
            })
        },
        YL = new _.v.Map;
    var ZL, $L = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1019);
        this.U = g;
        b && (this.l = new JB(b));
        c && (this.D = new JB(c));
        d && (this.G = new JB(d));
        this.A = Y(this, e);
        this.L = Y(this, f)
    };
    _.L($L, Z);
    $L.prototype.j = function() {
        aM(this);
        bM(this)
    };
    var bM = function(a) {
            if (!(Math.random() >= _.Kf(yy))) {
                var b = (a.L.value || []).filter(function(n) {
                    return rl(a.U[n.getDomId()]).some(function(p) {
                        return "hb_pb" === y(p, 1)
                    })
                });
                if (b.length) {
                    var c, d, e, f, g, h, k, l, m = (null == (c = a.l) ? 0 : null == (d = c.value) ? 0 : null == (e = d.adUnits) ? 0 : e.length) ? [].concat(_.ve(new _.v.Set(null == (f = a.l) ? void 0 : null == (g = f.value) ? void 0 : g.adUnits.map(function(n) {
                        return n.code
                    })))) : _.u(Object, "keys").call(Object, (null == (h = a.l) ? void 0 : null == (k = h.value) ? void 0 : null == (l = k.getAdserverTargeting) ? void 0 : l.call(k)) || {});
                    c = new fl("haux");
                    K(c, "ius", b.map(function(n) {
                        return n.getAdUnitPath()
                    }).join("~"));
                    K(c, "dids", b.map(function(n) {
                        return n.getDomId()
                    }).join("~"));
                    K(c, "paucs", m.join("~"));
                    Ij(c, a.context);
                    hl(c)
                }
            }
        },
        aM = function(a) {
            Cj("ppc_hrc", function(b) {
                var c;
                null != ZL || (ZL = (0, B.ua)(null == (c = (_.C = window.google_js_reporting_queue = window.google_js_reporting_queue || [], _.u(_.C, "find")).call(_.C, function(k) {
                    return "1" === k.label
                })) ? void 0 : c.value));
                var d = lf("navigationStart", window);
                ZL && K(b, "lt", ZL);
                var e;
                K(b, "tids", [].concat(_.ve((null == (e = a.A.value) ? void 0 : _.u(e, "keys").call(e)) || [])).join());
                var f;
                K(b, "asts", [].concat(_.ve((null == (f = a.A.value) ? void 0 : _.u(f, "values").call(f)) || [])).map(function(k) {
                    return k - d
                }).join());
                var g;
                if (null == (g = a.D) ? 0 : g.value) K(b, "ht", a.D.value - d);
                else {
                    var h;
                    (null == (h = a.G) ? 0 : h.value) && K(b, "ht", 0)
                }
                Ij(b, a.context)
            }, a.A.value ? _.Kf(xy) : 0)
        };
    var Qq = function(a, b, c, d, e) {
        Z.call(this, a, 982);
        this.l = Y(this, b);
        c && (this.D = new JB(c));
        this.G = W(this, d);
        this.A = W(this, e)
    };
    _.L(Qq, Z);
    Qq.prototype.j = function() {
        var a = this,
            b, c = null == (b = this.D) ? void 0 : b.value;
        if (this.l.value && null != c && c.onEvent) {
            b = {};
            for (var d = _.x(["bidWon", "staleRender", "adRenderFailed", "adRenderSucceeded"]), e = d.next(); !e.done; b = {
                    Yb: b.Yb,
                    Jc: b.Jc
                }, e = d.next()) b.Yb = e.value, b.Jc = function(f) {
                return function(g) {
                    if (a.l.value === g.adId) {
                        var h = new fl("hbm_brt");
                        Ij(h, a.context);
                        K(h, "et", f.Yb);
                        K(h, "sf", a.G.value);
                        K(h, "qqid", a.A.value);
                        var k, l, m;
                        K(h, "bc", String(null != (m = null != (l = g.bidderCode) ? l : null == (k = g.bid) ? void 0 : k.bidder) ? m : ""));
                        hl(h)
                    }
                }
            }(b), c.onEvent(b.Yb, b.Jc), _.qo(this, function(f) {
                return function() {
                    return void ei(a.context, a.id, function() {
                        var g;
                        return void(null == (g = c.offEvent) ? void 0 : g.call(c, f.Yb, f.Jc))
                    }, !0)
                }
            }(b))
        }
    };
    Qq.prototype.m = function() {};
    var vr = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 682);
        this.M = b;
        this.format = c;
        this.slotId = d;
        this.F = e;
        this.l = Y(this, f);
        this.A = W(this, g);
        this.G = W(this, h);
        this.D = Y(this, k)
    };
    _.L(vr, Z);
    vr.prototype.j = function() {
        var a = this;
        if ((2 === this.format || 3 === this.format) && this.l.oc() && _.Uf(this.l.value, 12, !1)) {
            var b = (0, B.K)(this.D.value).Eg,
                c = _.Fq(this.M, this.slotId),
                d = this.G.value,
                e = this.A.value;
            _.xj(e, {
                "max-height": "30vh",
                overflow: "hidden"
            });
            if (cM) cM.ei(e);
            else {
                cM = new b(this.context, this.format, e, this.F, d, this.M, this.slotId);
                b = {};
                d = _.x(Qe(this.l.value, jw, 13));
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, b[y(f, 1)] = y(f, 2);
                cM.ki(b);
                cM.jc();
                CI(this.M, this.slotId, function() {
                    cM && (cM.Da(), cM = null);
                    c && _.GI(a.M, a.slotId)
                })
            }
            _.qo(this, function() {
                return _.qx(e)
            })
        }
    };
    var cM = null;
    var wr = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 683);
        this.slotId = b;
        this.format = c;
        this.W = d;
        this.l = Y(this, e);
        this.G = W(this, f);
        this.P = W(this, g);
        this.L = Y(this, h);
        this.N = Y(this, k);
        this.D = W(this, l);
        this.A = rI(b, Ro, function(m) {
            m = m.detail;
            try {
                var n = JSON.parse(m.data);
                return "sth" === n.googMsgType && "i-adframe-load" === n.msg_type
            } catch (p) {
                return !1
            }
        })
    };
    _.L(wr, Z);
    wr.prototype.j = function() {
        var a = this,
            b, c, d, e, f, g, h, k, l, m, n;
        return _.Bb(function(p) {
            if (1 == p.j) {
                b = _.Kf(Zy);
                c = a.l.value;
                if (!c || 5 !== a.format) return p.return();
                Math.random() < _.Kf($y) && _.v.Promise.race([a.A.then(function() {
                    return !1
                }), new _.v.Promise(function(r) {
                    OI(a, a.id, window, "pagehide", function(t) {
                        t && r(!0)
                    })
                })]).then(function(r) {
                    var t = new fl("int_pm");
                    K(t, "ts", Date.now());
                    K(t, "flg", b);
                    K(t, "qem", a.D.value);
                    K(t, "ph", Number(r));
                    hl(t)
                });
                d = a.P.value;
                e = a.G.value;
                f = (0, B.K)(a.N.value);
                g = f.Ug;
                h = new _.cH(a.context);
                m = (null == (k = a.l.value) ? 0 : null != oi(k, 14)) ? 60 * (0, B.K)(null == (l = a.l.value) ? void 0 : oi(l, 14)) : 604800;
                n = new g(window, e, d, h, a.W, Po(Qe(c, jw, 13)), Pm(a.slotId), function() {
                    return void a.Da()
                }, m, a.L.value);
                _.Vn(a, n);
                switch (b) {
                    case 0:
                        n.P();
                        break;
                    case 1:
                        p.j = 2;
                        return
                }
            } else {
                if (4 != p.j) return Cb(p, a.A, 4);
                if (a.H) return p.return();
                n.P(!0)
            }
            p.j = 0
        })
    };
    var qr = function(a, b, c, d, e, f) {
        Z.call(this, a, 846);
        this.D = b;
        this.format = c;
        this.C = V(this);
        this.l = Y(this, d);
        this.A = Y(this, e);
        f && SB(this, f)
    };
    _.L(qr, Z);
    qr.prototype.j = function() {
        var a, b = (2 === this.format || 3 === this.format) && !(null == (a = this.l.value) || !_.Uf(a, 12, !1));
        a = 5 === this.format && this.A.value;
        b || a ? FB(this.C, this.D.load(_.BL)) : EB(this.C)
    };
    var dM = function(a, b) {
            this.serviceName = b;
            this.slot = (0, B.K)(a.j)
        },
        eM = function(a, b) {
            dM.call(this, a, b);
            this.isEmpty = !1;
            this.slotContentChanged = !0;
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.labelIds = this.creativeTemplateId = this.creativeId = this.campaignId = this.advertiserId = this.size = null;
            this.isBackfill = !1;
            this.companyIds = this.yieldGroupIds = null
        };
    _.L(eM, dM);
    var fM = function() {
        dM.apply(this, arguments)
    };
    _.L(fM, dM);
    var gM = function(a, b, c) {
        dM.call(this, a, b);
        this.inViewPercentage = c
    };
    _.L(gM, dM);
    var hM = function() {
        dM.apply(this, arguments)
    };
    _.L(hM, dM);
    var iM = function() {
        dM.apply(this, arguments)
    };
    _.L(iM, dM);
    var jM = function() {
        dM.apply(this, arguments)
    };
    _.L(jM, dM);
    var kM = function() {
        dM.apply(this, arguments)
    };
    _.L(kM, dM);
    var lM = function(a, b, c, d) {
        dM.call(this, a, b);
        this.makeRewardedVisible = c;
        this.payload = d
    };
    _.L(lM, dM);
    var mM = function(a, b, c) {
        dM.call(this, a, b);
        this.payload = c
    };
    _.L(mM, dM);
    var nM = function() {
        dM.apply(this, arguments)
    };
    _.L(nM, dM);
    var oM = function(a, b, c, d, e, f) {
        Z.call(this, a, 696);
        this.slotId = b;
        this.qa = c;
        SB(this, d);
        UB(this, [e, f])
    };
    _.L(oM, Z);
    oM.prototype.j = function() {
        this.qa.dispatchEvent("rewardedSlotClosed", 703, new nM(this.slotId, "publisher_ads"))
    };
    var pM = function(a, b, c, d, e) {
        Z.call(this, a, 694);
        this.slotId = b;
        this.qa = c;
        SB(this, d);
        this.l = Y(this, e)
    };
    _.L(pM, Z);
    pM.prototype.j = function() {
        var a, b = null == (a = this.l.value) ? void 0 : a.payload;
        this.qa.dispatchEvent("rewardedSlotGranted", 702, new mM(this.slotId, "publisher_ads", null != b ? b : null))
    };
    var qM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        rM = function(a, b, c, d, e, f) {
            Z.call(this, a, 693);
            this.F = b;
            this.G = f;
            this.C = QB(this);
            this.l = W(this, c);
            this.A = W(this, d);
            SB(this, e);
            this.D = new _.IG(this.F)
        };
    _.L(rM, Z);
    rM.prototype.j = function() {
        var a = this;
        if (!this.G.Wa) {
            var b = 0 === (0, _.Vm)() ? "rgba(1,1,1,0.5)" : "white";
            _.xj(this.A.value, _.u(Object, "assign").call(Object, {
                "background-color": b,
                opacity: "1",
                position: "fixed",
                margin: "0",
                padding: "0",
                "z-index": "2147483647",
                display: "block"
            }, qM));
            _.qo(this, _.SG(this.F.document, this.F));
            pe(this.l.value).postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            if (this.F === this.F.top) {
                this.F.location.hash = "goog_rewarded";
                var c = _.KG(this.D, 2147483646);
                _.NG(c);
                _.qo(this, function() {
                    _.OG(c);
                    "goog_rewarded" === a.F.location.hash && (a.F.location.hash = "")
                })
            }
            this.C.notify()
        }
    };
    var sM = function(a, b, c, d) {
        Z.call(this, a, 695);
        this.F = b;
        this.l = W(this, c);
        SB(this, d)
    };
    _.L(sM, Z);
    sM.prototype.j = function() {
        if (this.F === this.F.top) var a = (0, B.K)(pe(this.l.value)),
            b = OI(this, 503, this.F, "hashchange", function(c) {
                kt(c.oldURL, "#goog_rewarded") && (a.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "back_button"
                }), "*"), b())
            })
    };
    var tM = function(a, b, c, d) {
        Z.call(this, a, 692);
        this.slotId = b;
        this.qa = c;
        this.C = QB(this);
        this.l = W(this, d)
    };
    _.L(tM, Z);
    tM.prototype.j = function() {
        var a = this.l.value,
            b = new _.oh,
            c = b.promise,
            d;
        this.qa.dispatchEvent("rewardedSlotReady", 701, new lM(this.slotId, "publisher_ads", b.resolve, null != (d = a.payload) ? d : null));
        LB(this.C, c)
    };
    var uM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        vM = {
            width: "60%",
            height: "60%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        wM = function(a, b, c, d, e) {
            Z.call(this, a, 691);
            this.D = V(this);
            this.A = QB(this);
            this.G = W(this, c);
            this.l = UB(this, [d, e])
        };
    _.L(wM, Z);
    wM.prototype.j = function() {
        "ha_before_make_visible" === this.l.value.message ? this.A.notify() : (_.xj(this.G.value, _.u(Object, "assign").call(Object, {
            position: "absolute"
        }, 0 === (0, _.Vm)() ? vM : uM)), N(this.D, this.l.value))
    };
    var xr = function(a, b, c, d, e, f) {
        jg.call(this);
        var g = So(b, "granted", a);
        G(this, g);
        var h = So(b, "prefetched", a);
        G(this, h);
        var k = So(b, "closed", a);
        G(this, k);
        var l = So(b, "ha_before_make_visible", a);
        G(this, l);
        var m = new wM(a, b, e, h.C, l.C);
        G(this, m);
        h = new tM(a, b, c, m.D);
        G(this, h);
        f = new rM(a, d, e, f, h.C, m.A);
        G(this, f);
        G(this, new sM(a, d, e, f.C));
        G(this, new pM(a, b, c, h.C, g.C));
        G(this, new oM(a, b, c, h.C, k.C, l.C))
    };
    _.L(xr, jg);
    var Yp = function(a, b) {
        Z.call(this, a, 1031);
        this.F = b
    };
    _.L(Yp, Z);
    Yp.prototype.j = function() {
        this.F === this.F.top && rk(this.F)
    };
    var Wp = function(a, b, c) {
        c = void 0 === c ? sh : c;
        Z.call(this, a, 1063);
        this.F = b;
        this.A = c;
        this.l = V(this)
    };
    _.L(Wp, Z);
    Wp.prototype.j = function() {
        var a = this;
        if (_.E(Ry) && th(this.F)) {
            var b = null,
                c = 0,
                d = Zh(this.context, this.id, function() {
                    var f, g, h, k;
                    return _.Bb(function(l) {
                        switch (l.j) {
                            case 1:
                                return f = a.A(a.F), g = "0", l.m = 2, Cb(l, f, 4);
                            case 4:
                                g = null != (h = l.o) ? h : "0";
                                1E4 < g.length && (ci(a.context, a.id, new Bm("ML:" + g.length)), g = "0");
                                Eb(l, 3);
                                break;
                            case 2:
                                k = Fb(l), ci(a.context, a.id, k);
                            case 3:
                                b = g, c = _.jf(a.F) + 3E5, l.j = 0
                        }
                    })
                });
            var e = (_.C = d(), _.u(_.C, "finally")).call(_.C, function() {
                e = void 0
            });
            CB(this.l, function() {
                var f, g;
                return _.Bb(function(h) {
                    if (1 == h.j) {
                        f = _.jf(a.F) >= c;
                        g = null === b || "0" === b;
                        if (!f && !g) {
                            h.j = 2;
                            return
                        }
                        e || (e = (_.C = d(), _.u(_.C, "finally")).call(_.C, function() {
                            e = void 0
                        }));
                        return Cb(h, e, 2)
                    }
                    return h.return((0, B.K)(b))
                })
            })
        } else CB(this.l, function() {
            return _.v.Promise.resolve("")
        })
    };
    Wp.prototype.m = function() {
        CB(this.l, function() {
            return _.v.Promise.resolve("")
        })
    };
    var xM = function(a, b) {
        Z.call(this, a, 1091);
        this.C = V(this);
        b && (this.l = Y(this, b))
    };
    _.L(xM, Z);
    xM.prototype.j = function() {
        var a;
        null != (a = this.l) && a.value ? FB(this.C, this.l.value()) : N(this.C, "")
    };
    xM.prototype.m = function() {
        N(this.C, "")
    };
    var Up = function(a) {
        Z.call(this, a, 1104);
        this.C = V(this)
    };
    _.L(Up, Z);
    Up.prototype.j = function() {
        for (var a = [], b = _.x(Mf(bg)), c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = null;
            try {
                d = cg(c)
            } catch (e) {
                c = void 0;
                uf(44, "UNKNOWN_ID", null == (c = e) ? void 0 : c.message);
                continue
            }
            a.push(d)
        }
        N(this.C, a)
    };
    Up.prototype.m = function() {
        N(this.C, [])
    };
    var sr = function(a, b, c, d) {
        Z.call(this, a, 1101);
        this.F = b;
        this.A = Y(this, d);
        this.l = Y(this, c)
    };
    _.L(sr, Z);
    sr.prototype.j = function() {
        if (Mg("browsing-topics", this.F.document) && this.A.value && this.l.value) {
            var a = this.l.value,
                b = ck(this.F);
            b.setTopicsCalled ? _.v.Promise.resolve() : (b.setTopicsCalled = !0, a({
                message: "goog:topics:frame:get:topics",
                skipTopicsObservation: !1
            }))
        }
    };
    var Vp = function(a, b) {
        Z.call(this, a, 979);
        this.F = b;
        this.C = V(this)
    };
    _.L(Vp, Z);
    Vp.prototype.j = function() {
        var a = this,
            b = "function" !== typeof this.F.document.browsingTopics,
            c = !Mg("browsing-topics", this.F.document);
        b = b || c;
        Mg("shared-storage", this.F.document) && _.E(Gy) || !b ? ek(this.F).then(function(d) {
            N(a.C, d)
        }) : EB(this.C)
    };
    Vp.prototype.m = function() {
        EB(this.C)
    };
    var yM = function(a, b, c, d, e, f) {
        Z.call(this, a, 978);
        this.l = b;
        this.V = c;
        this.F = d;
        this.localStorage = e;
        this.C = V(this);
        f && (this.A = Y(this, f))
    };
    _.L(yM, Z);
    yM.prototype.j = function() {
        var a;
        if (null != (a = this.A) && a.value)
            if (_.E(vz) && !Mg("browsing-topics", this.F.document)) EB(this.C);
            else {
                var b, c, d, e, f, g;
                (null == (b = this.l) ? 0 : J(b, 8)) || _.E(iz) && (null == (c = this.l) ? 0 : J(c, 13)) || (null == (d = this.l) ? 0 : J(d, 1)) || 1 === (null == (e = this.l) ? void 0 : _.Se(e, 6, 2)) || 1 === (null == (f = this.l) ? void 0 : y(f, 5)) || (null == (g = this.l) ? 0 : J(g, 9)) || !cf(this.V) || J(this.V, 9) ? N(this.C, 5) : (a = kk(this.A.value, this.F, new _.cH(this.context), this.localStorage), FB(this.C, a))
            }
        else EB(this.C)
    };
    yM.prototype.m = function() {
        EB(this.C)
    };
    var zM = function() {
            var a = this;
            this.promise = new _.v.Promise(function(b, c) {
                a.reject = c;
                a.resolve = b
            })
        },
        AM = function() {
            this.auctionSignals = new zM;
            this.topLevelSellerSignals = new zM;
            this.j = new zM;
            this.perBuyerSignals = new zM;
            this.perBuyerTimeouts = new zM
        },
        BM = function(a, b, c) {
            this.j = a;
            this.Xd = b;
            this.Md = c
        };
    var CM = navigator,
        DM = function(a, b, c, d) {
            Z.call(this, a, 1089);
            this.l = b;
            this.V = c;
            this.C = V(this);
            this.A = W(this, d)
        };
    _.L(DM, Z);
    DM.prototype.j = function() {
        if (!_.E(xz) && (_.E(Bz) || 0 !== _.Kf(zz)) && "runAdAuction" in navigator && Mg("run-ad-auction", document) && (!cf(this.V) || J(this.V, 9) ? 0 : this.l ? !(J(this.l, 8) || _.E(iz) && J(this.l, 13) || J(this.l, 1) || 1 === _.Se(this.l, 6, 2) || 1 === y(this.l, 5) || J(this.l, 9)) : 1)) {
            for (var a = {}, b = _.x(this.A.value), c = b.next(); !c.done; c = b.next()) a[c.value.getId()] = EM();
            N(this.C, a)
        } else EB(this.C)
    };
    var EM = function() {
        var a = new AM,
            b = new AbortController,
            c = To({
                Xd: a,
                Md: b,
                Of: _.E(yz)
            });
        c = CM.runAdAuction(c).catch(function(d) {
            return d instanceof DOMException && "TimeoutError" === d.name ? 2 : 3
        });
        return new BM(c, a, b)
    };
    var ar = function(a, b, c) {
        Z.call(this, a, 881);
        this.fb = b;
        this.C = V(this);
        this.l = Y(this, c)
    };
    _.L(ar, Z);
    ar.prototype.j = function() {
        if (_.E(xz) || !this.l.value) EB(this.C);
        else {
            for (var a = this.l.value, b = [], c = _.x((_.C = FK(this.fb), _.u(_.C, "values")).call(_.C)), d = c.next(); !d.done; d = c.next()) {
                d = d.value;
                try {
                    b.push(JSON.parse(d))
                } catch (m) {
                    ci(this.context, 1023, m)
                }
            }
            c = this.C;
            d = {};
            for (var e = _.x(Qe(a, Iw, 7)), f = e.next(); !f.done; f = e.next()) f = f.value, d[_.Tf(f, 1)] = JSON.parse(_.Tf(f, 2));
            if (e = Bf(a, Hw, 6)) d["https://googleads.g.doubleclick.net"] = e.toJSON(), d["https://td.doubleclick.net"] = e.toJSON();
            e = {};
            f = _.x(Qe(a, Jw, 11));
            for (var g = f.next(); !g.done; g = f.next()) g = g.value, e[_.Tf(g, 1)] = Te(g, 2);
            var h = {};
            Ku(a, 18) && (h["https://googleads.g.doubleclick.net"] = Ku(a, 18), h["https://td.doubleclick.net"] = Ku(a, 18));
            f = _.Tf(a, 1).split("/td/")[0];
            g = _.Tf(a, 19);
            g = "" !== g ? f + g : void 0;
            var k, l = _.u(Object, "assign").call(Object, {}, {
                seller: f,
                decisionLogicUrl: _.Tf(a, 1),
                trustedScoringSignalsUrl: _.Tf(a, 2),
                interestGroupBuyers: _.hn(a, 3),
                sellerExperimentGroupId: Ku(a, 17),
                auctionSignals: JSON.parse(_.Tf(a, 4) || "{}"),
                sellerSignals: (null == (k = Bf(a, Lw, 5)) ? void 0 : k.toJSON()) || [],
                sellerTimeout: Te(a, 15) || 50,
                perBuyerExperimentGroupIds: h,
                perBuyerSignals: d,
                perBuyerTimeouts: e
            }, g ? {
                directFromSellerSignals: g
            } : {});
            k = new Lw;
            "0" !== kd(y(Op(Op(a, Lw, 5), Kw, 5), 2), "0") && (d = new Kw, e = kd(y(Op(Op(a, Lw, 5), Kw, 5), 2), "0"), yc(d), null != e && 0 !== +e ? Wc(d, 2, e) : Wc(d, 2, void 0, !1), _.Th(k, 5, d));
            a = _.u(Object, "assign").call(Object, {}, {
                seller: f,
                decisionLogicUrl: _.Tf(a, 1),
                sellerExperimentGroupId: Ku(a, 17),
                sellerSignals: k.toJSON(),
                sellerTimeout: Te(a, 15) || 50,
                interestGroupBuyers: [],
                auctionSignals: {},
                perBuyerExperimentGroupIds: {},
                perBuyerSignals: {},
                perBuyerTimeouts: {}
            }, g ? {
                directFromSellerSignals: g
            } : {}, {
                componentAuctions: [l].concat(_.ve(null != b ? b : []))
            });
            N(c, a)
        }
    };
    ar.prototype.m = function() {
        EB(this.C)
    };
    var Vo = navigator,
        Wo = /(\$\{GDPR})/gi,
        Xo = /(\$\{GDPR_CONSENT_[0-9]+\})/gi,
        Yo = /(\$\{ADDTL_CONSENT})/gi,
        Zo = /(\$\{AD_WIDTH})/gi,
        $o = /(\$\{AD_HEIGHT})/gi;
    var FM = navigator,
        br = function(a, b, c, d, e, f, g, h, k, l) {
            Z.call(this, a, 882);
            this.M = b;
            this.V = c;
            this.ga = d;
            this.L = l;
            this.Ka = V(this);
            this.l = V(this);
            this.A = V(this);
            this.N = Y(this, e);
            this.P = Y(this, f);
            this.W = W(this, g);
            this.ca = W(this, h);
            this.ba = W(this, k)
        };
    _.L(br, Z);
    br.prototype.j = function() {
        var a = this,
            b, c, d, e, f, g, h, k, l, m, n, p, r, t;
        return _.Bb(function(w) {
            switch (w.j) {
                case 1:
                    if (GM(a)) return HM(a), w.return();
                    b = (0, B.K)(a.N.value);
                    c = b.getWidth();
                    d = b.getHeight();
                    if (!c || !d) return HM(a), w.return();
                    e = Op(b, Lw, 5);
                    a.D = e.getEscapedQemQueryId();
                    a.G = _.Tf(e, 6);
                    f = _.Uf(e, 9);
                    if (g = _.Uf(e, 10))
                        if (HM(a), _.Uf(e, 17)) return cp(0, 0, e), w.return();
                    Cj("pre_run_ad_auction_ping", function(D) {
                        Ij(D, a.context);
                        var F;
                        K(D, "winner_qid", null != (F = a.D) ? F : "");
                        var I;
                        K(D, "xfpQid", null != (I = a.G) ? I : "");
                        K(D, "publisher_tag", "gpt")
                    }, 1);
                    h = performance.now();
                    k = Te(b, 8) || 1E3;
                    return Cb(w, IM(a, (0, B.K)(a.P.value), e, k, h), 2);
                case 2:
                    l = w.o;
                    m = Math.round(performance.now() - h);
                    n = 3 === l;
                    p = 2 === l;
                    r = 1 === l;
                    t = "string" === typeof l;
                    Cj("run_ad_auction_stats", function(D) {
                        Ij(D, a.context);
                        K(D, "duration_ms", m);
                        K(D, "applied_timeout_ms", k);
                        K(D, "timed_out", p ? 1 : 0);
                        K(D, "error", n ? 1 : 0);
                        K(D, "auction_skipped", r ? 1 : 0);
                        K(D, "auction_winner", t ? 1 : 0);
                        K(D, "thread_release_only", _.Uf(e, 15) ? 1 : 0);
                        var F;
                        K(D, "winner_qid", null != (F = a.D) ? F : "");
                        var I;
                        K(D, "xfpQid", null != (I = a.G) ? I : "");
                        K(D, "publisher_tag", "gpt");
                        a.L && K(D, "parallel", "1")
                    }, 1);
                    if (!t) return cp(m, p ? k : 0, e), g || HM(a), w.return();
                    if (g) return Cb(w, FM.deprecatedURNToURL(l, !0), 7);
                    if (!f) {
                        w.j = 4;
                        break
                    }
                    return Cb(w, FM.deprecatedURNToURL(l, !0), 6);
                case 6:
                    return HM(a), w.return();
                case 7:
                    return w.return();
                case 4:
                    return _.E(cA) ? Cb(w, ap(l, {
                        gdprApplies: Rl(a.V, 3) ? J(a.V, 3) ? "1" : "0" : null,
                        hf: y(a.V, 2),
                        Ne: y(a.V, 4),
                        Xf: b.getWidth() ? b.getWidth().toString() : null,
                        Vf: b.getHeight() ? b.getHeight().toString() : null
                    }), 9) : Cb(w, ap(l, {
                        gdprApplies: Rl(a.V, 3) ? J(a.V, 3) ? "1" : "0" : null,
                        hf: y(a.V, 2),
                        Ne: y(a.V, 4)
                    }), 9);
                case 9:
                    a.ba.value.style.display = "", CB(a.Ka, {
                        kind: 2,
                        Je: l
                    }), CB(a.l, new _.bj(c, d)), N(a.A, !1), w.j = 0
            }
        })
    };
    br.prototype.m = function() {
        HM(this)
    };
    var IM = function(a, b, c, d, e) {
            var f = Te(c, 14) || -1;
            if (0 < f && a.M.m >= f) return 1;
            f = Te(c, 13) || -1;
            if (0 < f && a.M.H >= f) return 1;
            ++a.M.m;
            ++a.M.H;
            b.signal = AbortSignal.timeout(d);
            b = a.L ? JM(a, b, d, e, a.L, _.Uf(c, 15)) : KM(a, b, d, e, _.Uf(c, 15));
            --a.M.m;
            return b
        },
        KM = function(a, b, c, d, e) {
            if (e) return dp();
            var f;
            return null == (f = FM.runAdAuction) ? void 0 : f.call(FM, b).then(function(g) {
                LM(a, g, c, d);
                return g
            }).catch(function(g) {
                return g instanceof DOMException && "TimeoutError" === g.name ? 2 : 3
            })
        },
        JM = function(a, b, c, d, e, f) {
            if (f) return dp();
            Uo(b, e.Xd);
            setTimeout(function() {
                e.Md.abort(new DOMException("runAdAuction", "TimeoutError"))
            }, c);
            return e.j.then(function(g) {
                null !== g && "string" !== typeof g || LM(a, g, c, d);
                return g
            })
        },
        LM = function(a, b, c, d) {
            Cj("run_ad_auction_complete", function(e) {
                Ij(e, a.context);
                K(e, "duration_ms", Math.round(performance.now() - d));
                K(e, "applied_timeout_ms", c);
                K(e, "auction_has_winner", !!b);
                a.D && K(e, "winner_qid", a.D);
                a.G && K(e, "xfpQid", a.G)
            }, 1)
        },
        GM = function(a) {
            var b = !!FM.runAdAuction && Mg("run-ad-auction", document);
            return _.E(xz) || !b || !a.N.value || !a.P.value
        },
        HM = function(a) {
            N(a.A, a.ga);
            N(a.Ka, a.W.value);
            N(a.l, a.ca.value)
        };
    var ep = "3rd party ad content";
    var MM = function(a, b, c) {
        _.Q.call(this);
        this.context = a;
        this.B = b;
        this.m = c;
        a = c.slotId;
        b = c.size;
        this.j = "height" === c.Fg ? "fluid" : [b.width, b.height];
        this.qc = sj(a);
        this.rc = ep
    };
    _.L(MM, _.Q);
    MM.prototype.render = function() {
        var a = this.B,
            b = this.m,
            c = b.slotId,
            d = b.O.U,
            e = b.X,
            f = b.size,
            g = b.Rb,
            h = b.yg,
            k = b.isBackfill;
        b = b.Gc;
        g && vh(g, _.nx(e), null != h ? h : "", !1);
        Dq(_.of(ai), "5", (0, B.K)(oi(d[c.getDomId()], 20)));
        c.dispatchEvent(Eq, 801, {
            Xe: 0 === a.kind ? a.Ta : "",
            isBackfill: k
        });
        a = this.I();
        b && a && a.setAttribute("data-google-container-id", b);
        c.dispatchEvent(Gq, 825, {
            size: f,
            isEmpty: !1
        });
        return a
    };
    MM.prototype.loaded = function(a) {
        var b = this.m,
            c = b.slotId,
            d = b.qa;
        b = b.O.U;
        c.dispatchEvent(xI, 844, void 0);
        a && a.setAttribute("data-load-complete", !0);
        d.dispatchEvent("slotOnload", 710, new hM(c, "publisher_ads"));
        Dq(_.of(ai), "6", (0, B.K)(oi(b[c.getDomId()], 20)))
    };
    var NM = function(a, b) {
        if (b) return null;
        a = a.B;
        a = 0 === a.kind ? a.Ta : "";
        b = "";
        var c = !0,
            d = "sf";
        b = void 0 === b ? "" : b;
        c = void 0 === c ? !1 : c;
        d = void 0 === d ? "" : d;
        if (a) {
            var e = a.toLowerCase(); - 1 < e.indexOf("<!doctype") || -1 < e.indexOf("<html") ? c && Mh(d, 2) : (c && Mh(d, 3), a = _.E(Nz) ? a : "<!doctype html><html><head>" + b + "</head><body>" + a + "</body></html>")
        } else c && Mh(d, 1);
        return a
    };
    MM.prototype.o = function() {
        _.Q.prototype.o.call(this);
        var a;
        null == (a = this.m.Rb) || a.removeAttribute("data-google-query-id")
    };
    MM.prototype.J = function(a, b) {
        var c = this,
            d = OM(this, function() {
                return void c.loaded((0, B.K)(d.j))
            }, a, b);
        _.qo(this, function() {
            100 != d.status && (2 == d.ha && (KH(d.m), d.ha = 0), window.clearTimeout(d.R), d.R = -1, d.J = 3, d.o && (d.o.Da(), d.o = null), _.Ae(window, "resize", d.D), _.Ae(window, "scroll", d.D), d.l && d.j && d.l == _.rx(d.j) && d.l.removeChild(d.j), d.j = null, d.l = null, d.status = 100)
        });
        return d
    };
    var OM = function(a, b, c, d) {
        var e = a.m,
            f = e.Hf,
            g = e.isBackfill,
            h = e.Vg,
            k = e.Gc,
            l = e.bd,
            m = e.Qd,
            n = e.Fa,
            p = Array.isArray(a.j) ? new _.bj(Number(a.j[0]), Number(a.j[1])) : 1;
        return new SH({
            Be: e.Ue,
            qc: a.qc,
            rc: a.rc,
            content: NM(a, d),
            size: p,
            wg: !!h,
            uf: b,
            If: null != f ? f : void 0,
            permissions: {
                Yc: Rl(c, 1) ? !!J(c, 1) : !g,
                Zc: Rl(c, 2) ? !!J(c, 2) : !1
            },
            tc: !!$k().fifWin,
            Jh: pK ? pK : pK = Gl(),
            hg: Kl(),
            hostpageLibraryTokens: n.hostpageLibraryTokens,
            Ma: function(r, t) {
                return void ci(a.context, r, t)
            },
            uniqueId: (0, B.K)(k),
            Gf: ij(),
            bd: null != l ? l : void 0,
            hd: null != d ? d : void 0,
            Qd: null != m ? m : void 0
        })
    };
    var PM = function() {
        MM.apply(this, arguments)
    };
    _.L(PM, MM);
    var QM = function(a, b) {
            var c = _.ze(b ? "fencedframe" : "IFRAME");
            b && (c.mode = "opaque-ads");
            c.id = a.qc;
            c.name = a.qc;
            c.title = a.rc;
            Array.isArray(a.j) ? null != a.j[0] && null != a.j[1] && (c.width = String(a.j[0]), c.height = String(a.j[1])) : (c.width = "100%", c.height = "0");
            c.allowTransparency = "true";
            c.scrolling = "no";
            c.marginWidth = "0";
            c.marginHeight = "0";
            c.frameBorder = "0";
            c.style.border = "0";
            c.style.verticalAlign = "bottom";
            c.setAttribute("role", "region");
            c.setAttribute("aria-label", "Advertisement");
            c.tabIndex = 0;
            return c
        },
        RM = function(a, b) {
            "string" !== typeof a.j && (b.width = String(a.j[0]), b.height = String(a.j[1]));
            var c = Zh(a.context, 774, function() {
                a.loaded(b);
                _.Ae(b, "load", c)
            });
            _.zb(b, "load", c);
            _.qo(a, function() {
                return _.Ae(b, "load", c)
            });
            a.m.Ue.appendChild(b)
        };
    var Aq = function() {
        PM.apply(this, arguments)
    };
    _.L(Aq, PM);
    Aq.prototype.I = function() {
        var a = QM(this, !this.m.Uh);
        Vj(a, this.B.Je);
        RM(this, a);
        return a
    };
    Aq.prototype.l = function() {
        return !1
    };
    var $p = function(a) {
        Z.call(this, a, 1083);
        this.C = V(this)
    };
    _.L($p, Z);
    $p.prototype.j = function() {
        var a = Jk();
        a ? FB(this.C, a) : EB(this.C)
    };
    var Ip = new _.v.Set,
        SM = function(a, b, c) {
            var d = 0,
                e = function() {
                    d = 0
                };
            return function(f) {
                d || (d = _.q.setTimeout(e, b), a.apply(c, arguments))
            }
        }(function() {
            throw new Bm("Reached Limit for addEventListener");
        }, 3E5),
        TM = function(a, b) {
            _.Q.call(this);
            this.j = a;
            this.l = b;
            this.m = [];
            this.B = !1;
            this.D = 0;
            this.J = new _.v.Map;
            Ip.add(this);
            this.j.info(hJ(this.getName()))
        };
    _.L(TM, _.Q);
    var Kp = function(a) {
        a.B || (a.B = !0, rf(6), a.R())
    };
    TM.prototype.slotAdded = function(a, b) {
        this.m.push(a);
        var c = new iM(a, this.getName());
        this.l.dispatchEvent("slotAdded", 818, c);
        this.j.info(jJ(this.getName(), a.getAdUnitPath()), a);
        a = this.getName();
        Pu(b, 4, a)
    };
    TM.prototype.destroySlots = function(a) {
        var b = this;
        return a.filter(function(c) {
            return ia(b.m, c)
        })
    };
    TM.prototype.addEventListener = function(a, b, c) {
        var d = this;
        c = void 0 === c ? window : c;
        if (this.D >= _.Kf(Jy) && 0 < _.Kf(Jy)) return SM(), !1;
        if (_.E(Jq) && !c.IntersectionObserver && (_.C = ["impressionViewable", "slotVisibilityChanged"], _.u(_.C, "includes")).call(_.C, a)) return ql(this.j, dK()), !1;
        var e;
        if (null == (e = this.J.get(a)) ? 0 : e.has(b)) return !1;
        this.J.has(a) || this.J.set(a, new _.v.Map);
        c = function(f) {
            f = f.detail;
            try {
                b(f)
            } catch (k) {
                d.j.error(AJ(String(k), a));
                var g, h;
                null == (g = window.console) || null == (h = g.error) || h.call(g, k)
            }
        };
        (0, B.K)(this.J.get(a)).set(b, c);
        this.l.Z(a, c);
        this.D++;
        return !0
    };
    TM.prototype.removeEventListener = function(a, b) {
        var c, d = null == (c = this.J.get(a)) ? void 0 : c.get(b);
        if (!d || !qI(this.l, a, d)) return !1;
        this.D--;
        return (0, B.K)(this.J.get(a)).delete(b)
    };
    var Ap = function(a) {
        for (var b = _.x(Ip), c = b.next(); !c.done; c = b.next()) c.value.destroySlots(a)
    };
    var Ep = function(a, b, c, d) {
        TM.call(this, a, c);
        this.I = b;
        this.ads = new _.v.Map;
        this.A = this.Db = !1;
        d.m = !0
    };
    _.L(Ep, TM);
    Ep.prototype.slotAdded = function(a, b) {
        var c = this;
        a.Z(tI, function(d) {
            J(d.detail, 11) && (UM(c, a).uh = !0)
        });
        TM.prototype.slotAdded.call(this, a, b)
    };
    Ep.prototype.R = function() {};
    Ep.prototype.setRefreshUnfilledSlots = function(a) {
        "boolean" === typeof a && (this.Db = a)
    };
    var hK = function(a, b) {
            b && !a.A && Cj("ima_sdk_v", function(c) {
                a.A = !0;
                K(c, "v", b)
            });
            return String(Lu())
        },
        fK = function(a, b) {
            var c = vj().j,
                d = vj().o;
            if (a.I.B) {
                var e = {
                    ob: 3
                };
                a.G && (e.Tb = a.G);
                a.L && (e.Ub = a.L);
                b = null != b ? b : a.m;
                c = ej(c, d);
                d = e.Tb;
                var f = e.Ub;
                d && "number" !== typeof d || f && "number" !== typeof f || a.I.refresh(c, b, e)
            } else(null == b ? 0 : b[0]) && a.j.error(pJ(b[0].getDomId()))
        },
        iK = function(a, b) {
            var c;
            return a.I.B && !(null == (c = a.ads.get(b)) || !c.uh)
        },
        gK = function(a, b) {
            return a.m.filter(function(c) {
                return _.u(b, "includes").call(b, c.toString())
            })
        };
    Ep.prototype.getName = function() {
        return "companion_ads"
    };
    var jK = function(a, b, c, d) {
            b = new eM(b, a.getName());
            null != c && null != d && (b.size = [c, d]);
            a.l.dispatchEvent("slotRenderEnded", 67, b)
        },
        UM = function(a, b) {
            var c = a.ads.get(b);
            c || (c = {}, a.ads.set(b, c), _.qo(b, function() {
                return a.ads.delete(b)
            }));
            return c
        };
    var Fp = function(a, b) {
        TM.call(this, a, b)
    };
    _.L(Fp, TM);
    Fp.prototype.getName = function() {
        return "content"
    };
    Fp.prototype.R = function() {};
    var VM = function() {
            this.o = [];
            this.hostpageLibraryTokens = [];
            this.j = {}
        },
        WM = function(a, b) {
            if (!_.u(a.o, "includes").call(a.o, b) && (_.C = [1, 2, 3], _.u(_.C, "includes")).call(_.C, b)) {
                var c = jC[b];
                if (c) {
                    var d = b + "_hostpage_library";
                    if (c = il(document, c)) c.id = d
                }
                a.o.push(b);
                b = new kC(b);
                a.hostpageLibraryTokens.push(b);
                a = $k();
                a.hostpageLibraryTokens || (a.hostpageLibraryTokens = {});
                a.hostpageLibraryTokens[b.j] = b.o
            }
        },
        XM = function(a, b, c) {
            var d;
            a.j[b] = null != (d = a.j[b]) ? d : new _.v.Set;
            a.j[b].add(c)
        },
        Lp = function(a, b) {
            var c, d;
            a = null != (d = null == (c = a.j[b]) ? void 0 : _.u(c, "values").call(c)) ? d : [];
            return [].concat(_.ve(a))
        };
    var YM = _.O(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        ZM = _.O(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", "_", ".js"]),
        $M = _.O(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        aN = _.O(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", "_", ".js"]),
        bN = new _.v.Map([
            [2, {
                sf: "page_level_ads"
            }],
            [5, {
                sf: "shoppit"
            }]
        ]),
        cN = function(a) {
            var b = void 0 === b ? bN : b;
            this.context = a;
            this.j = b;
            this.o = new _.v.Map;
            this.loaded = new _.v.Set
        },
        eN;
    cN.prototype.load = function(a) {
        var b = _.dN(this, a),
            c, d = (null != (c = this.j.get(a.module)) ? c : {}).sf;
        if (!d) throw Error("cannot load invalid module: " + d);
        if (!this.loaded.has(a.module)) {
            c = (c = _.Qh(172)) && "pagead2.googlesyndication.com" === ux((c.src || "").match(_.tx)[3] || null) ? this.context.bb ? _.A($M, this.context.bb, d) : _.A(aN, d, this.context.Na) : this.context.bb ? _.A(YM, this.context.bb, d) : _.A(ZM, d, this.context.Na);
            d = {};
            var e = _.Kf(kz),
                f = _.Kf(Py);
            e && (d.cb = e);
            f && (d.mcb = f);
            _.u(Object, "keys").call(Object, d).length ? (c = it.exec(_.kb(c).toString()), e = c[3] || "", d = se(c[1] + jt("?", c[2] || "", d) + jt("#", e))) : d = c;
            eN(this, a);
            il(document, d);
            this.loaded.add(a.module)
        }
        return b.promise
    };
    _.dN = function(a, b) {
        b = b.module;
        a.o.has(b) || a.o.set(b, new _.oh);
        return (0, B.K)(a.o.get(b))
    };
    eN = function(a, b) {
        var c = b.module;
        b = "_gpt_js_load_" + c + "_";
        var d = Zh(a.context, 340, function(e) {
            if (a.j.has(c) && "function" === typeof e) {
                var f = (0, B.K)(a.j.get(c));
                f = (void 0 === f.pg ? [] : f.pg).map(function(g) {
                    return _.dN(a, g).promise
                });
                _.v.Promise.all(f).then(function() {
                    e.call(window, _, a)
                })
            }
        });
        Object.defineProperty($k(), b, {
            value: function(e) {
                if (d) {
                    var f = d;
                    d = null;
                    f(e)
                }
            },
            writable: !1,
            enumerable: !1
        })
    };
    new Rq;
    new Rq;
    new Rq;
    new Rq;
    var fN = function() {
        this.resources = {}
    };
    var uq = new _.v.Map([
        [1, 5],
        [2, 2],
        [3, 3]
    ]);
    var Fr = function(a, b, c, d, e) {
        var f = _.xb.apply(5, arguments);
        Z.call(this, a, 912);
        this.googletag = b;
        this.T = c;
        this.G = d;
        this.D = e;
        this.l = V(this);
        this.Oa = V(this);
        this.A = [];
        f = _.x(f);
        for (var g = f.next(); !g.done; g = f.next()) this.A.push(W(this, g.value))
    };
    _.L(Fr, Z);
    Fr.prototype.j = function() {
        if (_.E(jz)) {
            for (var a = [], b = _.x(this.A), c = b.next(); !c.done; c = b.next()) {
                c = _.x(c.value.value);
                for (var d = c.next(); !d.done; d = c.next()) switch (d = d.value, mk(d, gw)) {
                    case 5:
                        var e = void 0,
                            f = void 0;
                        vq(this.context, this.googletag, (0, B.K)(eo(d, Vv, 5, gw)), null != (e = Bf(d, Tv, 4)) ? e : null, null != (f = this.T) ? f : vj().j, this.G, this.D);
                        break;
                    case 6:
                        e = (0, B.K)(eo(d, Zv, 6, gw));
                        Do(e, Xv, 2) && ao((0, B.K)(Bf(e, Xv, 2))) && (f = void 0, mo(document, this.googletag, (0, B.K)(eo(d, Zv, 6, gw)), null != (f = this.T) ? f : vj().j, Bf(d, Tv, 4)), (d = Te(e, 1)) && a.push(d));
                        break;
                    case 8:
                        Do(d, Tv, 4) && (d = (0, B.K)(Bf(d, Tv, 4)), N(this.Oa, d))
                }
            }
            N(this.l, a)
        } else N(this.l, []);
        EB(this.Oa)
    };
    Fr.prototype.I = function(a) {
        this.m(a)
    };
    Fr.prototype.m = function() {
        N(this.l, [])
    };
    var xq = function() {
        MM.apply(this, arguments)
    };
    _.L(xq, MM);
    xq.prototype.I = function() {
        var a = this.m,
            b = a.O,
            c = b.T;
        a = b.U[a.slotId.getDomId()];
        b = new Ll;
        c = Sl([b, c.Za(), null == a ? void 0 : a.Za()]);
        c = MM.prototype.J.call(this, c);
        return (0, B.K)(c.j)
    };
    xq.prototype.l = function() {
        return !1
    };
    var yq = function() {
        PM.apply(this, arguments)
    };
    _.L(yq, PM);
    yq.prototype.I = function() {
        var a = this,
            b = this.m,
            c = b.Hf;
        b = b.bd;
        var d = QM(this);
        if (null == c ? 0 : c.length)
            if (_.Xt) {
                c = _.x(c);
                for (var e = c.next(); !e.done; e = c.next()) d.sandbox.add(e.value)
            } else d.sandbox.add.apply(d.sandbox, _.ve(c));
        b && (d.allow = b);
        RM(this, d);
        ei(this.context, 653, function() {
            var f;
            if (f = _.Jt(a.B.Ta)) {
                var g = f.toString().toLowerCase(); - 1 < g.indexOf("<!doctype") || -1 < g.indexOf("<html") ? wq(2) : (wq(3), f = _.E(Nz) ? f : _.Jt("<!doctype html><html><head><script>var inDapIF=true,inGptIF=true;\x3c/script></head><body>" + f + "</body></html>"))
            } else wq(1);
            var h, k;
            g = null != (k = null == (h = d.contentWindow) ? void 0 : h.document) ? k : d.contentDocument;
            Wa() && g.open("text/html", "replace");
            ob(g, f);
            var l, m, n;
            if (kt(null != (n = null == (l = d.contentWindow) ? void 0 : null == (m = l.location) ? void 0 : m.href) ? n : "", "#")) {
                var p, r;
                null == (p = d.contentWindow) || null == (r = p.history) || r.replaceState(null, "", "#" + Math.random())
            }
            g.close()
        }, !0);
        return d
    };
    yq.prototype.l = function() {
        return !0
    };
    var zq = function() {
        PM.apply(this, arguments)
    };
    _.L(zq, PM);
    zq.prototype.I = function() {
        var a = this.B.url,
            b = this.m,
            c = b.O,
            d = c.T;
        b = c.U[b.slotId.getDomId()];
        d = Sl([d.Za(), null == b ? void 0 : b.Za()]);
        var e = QM(this);
        Vj(e, a);
        PM.prototype.J.call(this, d, e);
        var f = function() {
            e.removeEventListener("load", f);
            gN(a)
        };
        e.addEventListener("load", f);
        Rx(e, function() {
            return void gN(a)
        });
        return e
    };
    var gN = function(a) {
        var b = document.querySelectorAll("script[type=webbundle]");
        if (b.length) {
            a: {
                for (var c = 0; c < b.length; c++) {
                    var d = void 0;
                    if (null == (d = b[c].textContent) ? 0 : d.match(a)) {
                        b = b[c];
                        break a
                    }
                }
                b = null
            }
            b && b.textContent && (c = JSON.parse(b.textContent)) && "object" === typeof c && (d = c.resources, a = d.indexOf(a, 0), -1 < a && d.splice(a, 1), 0 === d.length ? document.head.removeChild(b) : (a = _.ze("SCRIPT"), a.setAttribute("type", "webbundle"), a.textContent = JSON.stringify(c), document.head.removeChild(b), document.head.appendChild(a)))
        }
    };
    zq.prototype.l = function() {
        return !1
    };
    var tr = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w, D, F, I, S, M, R, T, X, ka, ca) {
        Z.call(this, a, 680);
        this.slotId = b;
        this.M = c;
        this.O = d;
        this.qa = e;
        this.Fa = f;
        this.F = g;
        this.l = V(this);
        this.D = V(this);
        this.A = QB(this);
        this.L = W(this, h);
        this.xa = W(this, k);
        SB(this, l);
        this.ca = W(this, m);
        this.G = W(this, n);
        this.ba = W(this, p);
        SB(this, S);
        this.N = W(this, r);
        this.P = Y(this, t);
        this.Ia = Y(this, w);
        this.W = W(this, D);
        this.ra = Y(this, F);
        this.gb = Y(this, I);
        SB(this, M);
        this.ma = W(this, R);
        SB(this, T);
        ca && SB(this, ca);
        this.ga = Y(this, X);
        this.la = Y(this, ka)
    };
    _.L(tr, Z);
    tr.prototype.j = function() {
        var a = this,
            b = this.L.value;
        if (0 === b.kind && null == b.Ta) throw new pB("invalid html");
        var c;
        b = Bq(this.context, b, {
            X: document,
            slotId: this.slotId,
            M: this.M,
            O: this.O,
            qa: this.qa,
            size: this.ba.value,
            Rb: this.ca.value,
            Ue: this.G.value,
            yg: this.N.value,
            Fg: this.P.value,
            Hf: this.Ia.value,
            isBackfill: this.W.value,
            Vg: this.ra.value,
            Gc: this.gb.value,
            bd: this.ma.value,
            Uh: null == (c = this.ga.value) ? void 0 : _.Uf(c, 14),
            Qd: this.la.value,
            Fa: this.Fa
        }, {
            Vh: this.xa.value
        });
        _.Vn(this, b);
        var d = b.render();
        OI(this, this.id, this.F, "message", function(e) {
            d.contentWindow === e.source && a.slotId.dispatchEvent(Ro, 824, e)
        });
        this.A.notify();
        N(this.l, d);
        N(this.D, b.l())
    };
    var zr = function(a, b, c, d, e) {
        Z.call(this, a, 863);
        this.l = c;
        this.Ib = Number(b);
        this.A = W(this, d);
        this.D = W(this, e);
        this.G = hN(this)
    };
    _.L(zr, Z);
    var hN = function(a) {
        return _.Bb(function(b) {
            return b.return(new _.v.Promise(function(c) {
                try {
                    OI(a, a.id, a.l, "message", function(d) {
                        var e;
                        "asmreq" === (null == (e = d.data) ? void 0 : e.type) && Ku(tG(d.data.payload), 1) === a.Ib && c(d)
                    })
                } catch (d) {}
            }))
        })
    };
    zr.prototype.j = function() {
        var a = this,
            b, c, d, e, f, g;
        return _.Bb(function(h) {
            if (1 == h.j) return b = Cq(a.l), c = a.A.value, d = a.D.value, Cb(h, a.G, 2);
            e = h.o;
            var k = a.l,
                l = Cq(k);
            var m = c.getBoundingClientRect();
            var n = _.oe(k) ? Yi(c, k) : {
                x: 0,
                y: 0
            };
            k = n.x;
            n = n.y;
            m = new _.Tx(n, k + m.right, n + m.bottom, k);
            k = new uG;
            k = _.z(k, 1, m.top);
            k = _.z(k, 3, m.bottom);
            k = _.z(k, 2, m.left);
            m = _.z(k, 4, m.right);
            k = new vG;
            k = _.z(k, 1, a.Ib);
            k = _.z(k, 2, !d);
            m = _.Th(k, 3, m);
            m = _.z(m, 4, b);
            f = _.z(m, 5, l);
            g = {
                type: "asmres",
                payload: Ne(f)
            };
            e.ports[0].postMessage(g);
            h.j = 0
        })
    };
    var lr = function(a, b, c, d, e, f, g, h, k, l, m, n, p) {
        Z.call(this, a, 699);
        this.X = b;
        this.slotId = c;
        this.l = d;
        this.Vb = e;
        this.C = QB(this);
        this.L = Y(this, f);
        this.P = W(this, g);
        this.D = W(this, h);
        this.N = W(this, k);
        this.A = Y(this, l);
        this.W = W(this, m);
        this.G = W(this, n);
        p && SB(this, p)
    };
    _.L(lr, Z);
    lr.prototype.j = function() {
        var a = this.P.value,
            b = this.D.value;
        b.style.width = "";
        b.style.height = "";
        if ("height" !== this.L.value) {
            var c, d = null != (c = this.A.value) ? c : 0;
            c = this.N.value;
            var e = this.W.value,
                f = this.G.value,
                g = !1;
            switch (d) {
                case 1:
                case 2:
                    g = this.context;
                    var h = this.X,
                        k = this.slotId,
                        l = this.l,
                        m = this.Vb;
                    var n = c.width,
                        p = c.height,
                        r = 0;
                    var t = 0;
                    var w = vi(l);
                    w = _.x(w);
                    for (var D = w.next(); !D.done; D = w.next()) {
                        var F = D.value;
                        Array.isArray(F) && (D = (0, B.ua)(F[0]), F = (0, B.ua)(F[1]), r < D && (r = D), t < F && (t = F))
                    }
                    t = [r, t];
                    r = t[0] < n;
                    p = t[1] < p;
                    if (r || p) {
                        t = n + "px";
                        w = {
                            "max-height": "none",
                            "max-width": t,
                            padding: "0px",
                            width: t
                        };
                        p && (w.height = "auto");
                        yj(b, a, w);
                        b = {};
                        r && (r = wj(e.width), n > r && (b.width = t, b["max-width"] = t));
                        p && (b.height = "auto", b["max-height"] = "none");
                        c: {
                            for (I in b)
                                if (Object.prototype.hasOwnProperty.call(b, I)) {
                                    var I = !1;
                                    break c
                                }
                            I = !0
                        }
                        I ? b = !1 : (b["padding-" + ("ltr" === e.direction ? "left" : "right")] = "0px", _.xj(a, b), b = !0)
                    } else b = !1;
                    b: switch (t = c.width, I = h.defaultView || h.parentWindow || _.q, d) {
                        case 2:
                            a = zj(a, I, t, e, m);
                            break b;
                        case 1:
                            if (e = a.parentElement)
                                if (m = cj(e)) {
                                    D = m.width;
                                    m = lj(k, I.document);
                                    n = (0, B.K)(nj(m, I));
                                    p = n.position;
                                    F = wj(n.width) || 0;
                                    r = nj(e, I);
                                    w = "rtl" === r.direction ? "Right" : "Left";
                                    m = w.toLowerCase();
                                    I = "absolute" === p ? 0 : wj(r["padding" + w]);
                                    r = wj(r["border" + w + "Width"]);
                                    t = Math.max(Math.round((D - Math.max(F, t)) / 2), 0);
                                    D = {};
                                    F = 0;
                                    var S = Jx(n);
                                    S && (F = S[4] * ("Right" === w ? -1 : 1), w = S[3] || 1, 1 !== (S[0] || 1) || 1 !== w) && (S[0] = 1, S[3] = 1, D.transform = "matrix(" + S.join(",") + ")");
                                    w = 0;
                                    switch (p) {
                                        case "fixed":
                                            var M, R = null != (M = Number(oj(n.getPropertyValue(m)))) ? M : 0,
                                                T;
                                            M = null != (T = e.getBoundingClientRect().left) ? T : 0;
                                            w = R - M;
                                            break;
                                        case "relative":
                                            w = null != (R = Number(oj(n.getPropertyValue(m)))) ? R : 0;
                                            break;
                                        case "absolute":
                                            D[m] = "0"
                                    }
                                    D["margin-" + m] = t - I - r - w - F + "px";
                                    _.xj(a, D);
                                    a = !0
                                } else a = !1;
                            else a = !1;
                            break b;
                        default:
                            a = !1
                    }
                    b || a ? (Bj(g, h, k, l, d, c.width, c.height, "gpt_slotexp", f), g = !0) : g = !1;
                    break;
                case 3:
                    d = this.context, g = this.X, h = this.slotId, k = this.l, M = this.Vb, l = c.width, T = c.height, R = wj(e.height) || 0, T >= R || "none" === e.display || "hidden" === e.visibility || !M || -12245933 === M.width || a.getBoundingClientRect().bottom <= M.height ? g = !1 : (M = {
                        height: T + "px"
                    }, yj(b, a, M), _.xj(a, M), Bj(d, g, h, k, 3, l, T, "gpt_slotred", f), g = !0)
            }!g && _.E(wy) && Bj(this.context, this.X, this.slotId, this.l, 0, c.width, c.height, "gpt_pgbrk", f)
        }
        this.C.notify()
    };
    var pr = function(a, b) {
        Z.call(this, a, 1020);
        this.F = b;
        this.C = V(this)
    };
    _.L(pr, Z);
    pr.prototype.j = function() {
        var a = this.F;
        a = _.E(Dz) && void 0 !== a.credentialless && (_.E(Ez) || a.crossOriginIsolated);
        N(this.C, a)
    };
    var Uq = function(a, b, c, d, e) {
        Z.call(this, a, 720);
        this.format = b;
        this.D = c;
        this.C = V(this);
        this.l = Y(this, d);
        this.A = Y(this, e)
    };
    _.L(Uq, Z);
    Uq.prototype.j = function() {
        var a = this.A.value;
        if (null == a) EB(this.C);
        else {
            var b = Math.round(.3 * this.D),
                c;
            2 !== this.format && 3 !== this.format || null == (c = this.l.value) || !_.Uf(c, 12, !1) || 0 >= b || a <= b ? N(this.C, a) : N(this.C, b)
        }
    };
    var er = function(a, b, c) {
        Z.call(this, a, 1054);
        this.l = b;
        this.C = QB(this);
        this.A = W(this, c)
    };
    _.L(er, Z);
    er.prototype.j = function() {
        this.A.value || this.l();
        this.C.notify()
    };
    var gr = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 674);
        this.slotId = b;
        this.T = c;
        this.A = d;
        this.X = f;
        this.M = g;
        this.C = V(this);
        this.G = 2 === e || 3 === e;
        this.l = W(this, h);
        this.N = W(this, k);
        this.L = Y(this, l);
        this.D = Y(this, m);
        n && SB(this, n)
    };
    _.L(gr, Z);
    gr.prototype.j = function() {
        var a = Vi(this.T, this.A),
            b = kj(this.slotId, this.X) || Xm(this.l.value, tj(this.slotId), a);
        this.N.value && !a && (b.style.display = "inline-block");
        this.G ? CI(this.M, this.slotId, function() {
            return void _.qx(b)
        }) : _.qo(this, function() {
            return void _.qx(b)
        });
        a = iN(this);
        0 < a && (b.style.paddingTop = a + "px");
        N(this.C, b)
    };
    var iN = function(a) {
        var b = a.l.value,
            c, d = null == (c = a.L.value) ? void 0 : c.height;
        if (b && !a.D.value && d) {
            var e;
            c = (null != (e = Ui(a.A, 23)) ? e : J(a.T, 31)) ? Math.floor((b.offsetHeight - d) / 2) : 0
        } else c = 0;
        return c
    };
    var Pq = function(a, b) {
        Z.call(this, a, 859);
        this.F = b;
        this.C = V(this)
    };
    _.L(Pq, Z);
    Pq.prototype.j = function() {
        var a = !_.oe(this.F.top);
        N(this.C, a)
    };
    var jr = function(a, b, c) {
        Z.call(this, a, 698);
        this.F = b;
        this.C = V(this);
        this.l = W(this, c)
    };
    _.L(jr, Z);
    jr.prototype.j = function() {
        DB(this.C, nj(this.l.value, this.F))
    };
    var or = function(a, b, c) {
        Z.call(this, a, 840);
        this.format = b;
        this.X = c;
        this.C = V(this)
    };
    _.L(or, Z);
    or.prototype.j = function() {
        var a = [],
            b = this.X;
        b = void 0 === b ? document : b;
        var c;
        null != (c = b.featurePolicy) && (_.C = c.features(), _.u(_.C, "includes")).call(_.C, "attribution-reporting") && a.push("attribution-reporting");
        5 !== this.format && 4 !== this.format || !_.E(ty) || a.push("autoplay");
        a.length ? N(this.C, a.join(";")) : N(this.C, "")
    };
    var ur = function(a, b, c, d, e) {
        Z.call(this, a, 934);
        this.F = b;
        this.slotId = c;
        SB(this, d);
        this.l = W(this, e)
    };
    _.L(ur, Z);
    ur.prototype.j = function() {
        var a = this;
        this.slotId.Z(Ro, function(b) {
            b = b.detail.data;
            try {
                var c = JSON.parse(b);
                if ("gpi-uoo" === c.googMsgType) {
                    var d = c.userOptOut,
                        e = c.clearAdsData,
                        f = a.l.value,
                        g = new Cw;
                    var h = _.z(g, 1, d ? "1" : "0");
                    var k = _.z(h, 2, 2147483647);
                    var l = _.z(k, 3, "/");
                    var m = _.z(l, 4, a.F.location.hostname);
                    var n = new _.dC(a.F);
                    gC(n, "__gpi_opt_out", m, f);
                    if (d || e) hC(n, "__gads", f), hC(n, "__gpi", f)
                }
            } catch (p) {}
        })
    };
    var dr = function(a, b, c, d, e, f) {
        Z.call(this, a, 1053);
        this.slotId = b;
        this.O = c;
        this.M = d;
        this.l = V(this);
        this.A = W(this, e);
        this.D = W(this, f)
    };
    _.L(dr, Z);
    dr.prototype.j = function() {
        this.D.value ? (Hq(this.slotId, this.M, this.O, this.A.value), N(this.l, !1)) : N(this.l, !0)
    };
    var Cr = function(a, b, c, d, e, f) {
        Z.call(this, a, 721);
        this.F = b;
        this.G = Y(this, c);
        this.A = W(this, d);
        this.l = W(this, e);
        this.D = W(this, f)
    };
    _.L(Cr, Z);
    Cr.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c, d = null == b ? void 0 : null == (c = y(b, 1)) ? void 0 : c.toUpperCase(),
            e;
        b = null == b ? void 0 : null == (e = y(b, 2)) ? void 0 : e.toUpperCase();
        if (d && b) {
            e = this.A.value;
            c = this.l.value;
            var f = this.D.value,
                g = f.style.height,
                h = f.style.width,
                k = f.style.display,
                l = f.style.position,
                m = Iq(e.id + "_top", d),
                n = Iq(e.id + "_bottom", b);
            _.xj(n, {
                position: "relative",
                top: "calc(100vh - 48px)"
            });
            f.appendChild(m);
            f.appendChild(n);
            _.xj(c, {
                position: "absolute",
                top: "24px",
                clip: "rect(0, auto, auto, 0)",
                width: "100vw",
                height: "calc(100vh - 48px)"
            });
            _.xj(e, {
                position: "fixed",
                top: "0",
                height: "100vh"
            });
            var p;
            _.xj(f, {
                position: "relative",
                display: (null == (p = this.F.screen.orientation) ? 0 : p.angle) ? "none" : "block",
                width: "100vw",
                height: "100vh"
            });
            OI(this, 722, this.F, "orientationchange", function() {
                var r;
                (null == (r = a.F.screen.orientation) ? 0 : r.angle) ? _.xj(f, {
                    display: "none"
                }): _.xj(f, {
                    display: "block"
                })
            });
            _.qo(this, function() {
                _.qx(m);
                _.qx(n);
                f.style.position = l;
                f.style.height = g;
                f.style.width = h;
                f.style.display = k
            })
        }
    };
    var yr = function(a, b, c, d, e, f) {
        f = void 0 === f ? Lq : f;
        Z.call(this, a, 783);
        var g = this;
        this.slotId = b;
        this.X = d;
        this.qa = e;
        this.L = f;
        this.G = !1;
        this.l = null;
        this.D = this.A = -1;
        this.P = _.Zs(function() {
            g.qa.dispatchEvent("impressionViewable", 715, new fM(g.slotId, "publisher_ads"))
        });
        this.W = $s(function() {
            g.qa.dispatchEvent("slotVisibilityChanged", 716, new gM(g.slotId, "publisher_ads", g.D))
        }, 200);
        this.N = W(this, c);
        var h = new KB;
        rI(this.slotId, xI).then(function() {
            return void h.notify()
        });
        SB(this, h)
    };
    _.L(yr, Z);
    yr.prototype.j = function() {
        var a = this,
            b = this.L(Zh(this.context, this.id, function(c) {
                c = _.x(c);
                for (var d = c.next(); !d.done; d = c.next()) a.A = 100 * d.value.intersectionRatio, _.u(Number, "isFinite").call(Number, a.A) && jN(a)
            }));
        b ? (b.observe(this.N.value), OI(this, this.id, this.X, "visibilitychange", function() {
            jN(a)
        }), _.qo(this, function() {
            b.disconnect()
        })) : _.E(Jq)
    };
    var jN = function(a) {
            var b = !yG(a.X);
            kN(a, 50 <= a.A && b);
            b = Math.floor(b ? a.A : 0);
            if (0 > b || 100 < b || b === a.D ? 0 : -1 !== a.D || 0 !== b) a.D = b, a.W()
        },
        kN = function(a, b) {
            a.G || (b ? null === a.l && (a.l = setTimeout(function() {
                yG(a.X) || (a.P(), a.G = !0);
                a.l = null
            }, 1E3)) : null !== a.l && (clearTimeout(a.l), a.l = null))
        };
    var lN = _.O(["https://td.doubleclick.net/td/kb?kbli=", ""]),
        mN = _.O(["https://googleads.g.doubleclick.net/td/kb?kbli=", ""]),
        rr = function(a, b, c) {
            Z.call(this, a, 1007);
            this.l = Y(this, b);
            c && SB(this, c)
        };
    _.L(rr, Z);
    rr.prototype.j = function() {
        var a = this.l.value;
        if (null != a && a.length && null === document.getElementById("koelBirdIGRegisterIframe")) {
            var b = document.createElement("iframe");
            a = _.E(Az) ? yb(lN, encodeURIComponent(a.join())) : yb(mN, encodeURIComponent(a.join()));
            b.removeAttribute("srcdoc");
            if (a instanceof _.ft) throw new Tt("TrustedResourceUrl", 2);
            a = _.fb(a);
            void 0 !== a && (b.src = a);
            for (a = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" "); 0 < b.sandbox.length;) b.sandbox.remove(b.sandbox.item(0));
            for (var c = 0; c < a.length; c++) b.sandbox.supports && !b.sandbox.supports(a[c]) || b.sandbox.add(a[c]);
            b.id = "koelBirdIGRegisterIframe";
            document.head.appendChild(b)
        }
    };
    var Yq = function(a, b, c) {
        Z.call(this, a, 666);
        this.A = b;
        this.l = V(this);
        this.D = Y(this, c)
    };
    _.L(Yq, Z);
    Yq.prototype.j = function() {
        var a = new Zq;
        this.D.oc() && hH(_.z(a, 2, this.D.value), 1);
        if (this.A) {
            a = [this.A, a];
            var b = new Zq;
            a = _.x(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, null != go(c, 1) && _.z(b, 1, go(c, 1)), null != go(c, 2) && _.z(b, 2, go(c, 2)), null != Mq(c, 3) && hH(b, Mq(c, 3));
            a = b
        }
        b = this.l;
        a = null != go(a, 2) ? null != Mq(a, 3) && 0 !== (0, _.Vm)() ? (0, B.ua)(go(a, 2)) * (0, B.ua)(Mq(a, 3)) : go(a, 2) : null;
        DB(b, a)
    };
    var kr = function(a, b, c, d, e, f, g) {
        f = void 0 === f ? Oq : f;
        Z.call(this, a, 666);
        this.A = f;
        this.C = QB(this);
        SB(this, b);
        g && SB(this, g);
        this.l = W(this, c);
        this.G = Y(this, d);
        this.D = Y(this, e)
    };
    _.L(kr, Z);
    kr.prototype.j = function() {
        var a = this.D.value,
            b = this.G.value,
            c = this.l.value;
        null == a || 0 > a || 0 === b || !pj(c) ? this.C.notify() : nN(this, a, b, c)
    };
    var nN = function(a, b, c, d) {
        var e = a.A(b, Zh(a.context, 291, function(f, g) {
            f = _.x(f);
            for (var h = f.next(); !h.done; h = f.next())
                if (h = h.value, !(0 >= h.intersectionRatio)) {
                    g.unobserve(h.target);
                    a.C.notify();
                    break
                }
        }));
        e ? (null != c && setTimeout(function() {
            a.C.notify();
            e.disconnect()
        }, c), e.observe(d), _.qo(a, function() {
            e.disconnect()
        })) : (_.E(Jq), a.C.notify())
    };
    var ir = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 664);
        this.slotId = b;
        this.Vb = c;
        this.M = d;
        this.C = QB(this);
        this.A = W(this, e);
        this.l = Y(this, f);
        g && SB(this, g)
    };
    _.L(ir, Z);
    ir.prototype.j = function() {
        var a = this,
            b, c = null != (b = this.l.value) ? b : 0;
        if (0 !== (0, _.Vm)() || 0 < c) {
            var d = document;
            b = xG(d);
            if (yG(d) && b && (0 < II(this.M, this.slotId) || !oN(this)) && b) {
                var e = OI(this, 324, d, b, function() {
                    yG(d) || (e && e(), a.C.notify())
                });
                if (e) return
            }
        }
        this.C.notify()
    };
    var oN = function(a) {
        var b = a.A.value;
        try {
            var c, d = null != (c = top) ? c : void 0;
            if (void 0 === d) return !0;
            var e = on(null == d ? void 0 : d.document, d).y,
                f = e + a.Vb.height;
            return b.y >= e && b.y <= f
        } catch (g) {
            return !0
        }
    };
    var fr = function(a, b, c) {
        Z.call(this, a, 1055);
        this.C = QB(this);
        SB(this, c);
        this.l = W(this, b)
    };
    _.L(fr, Z);
    fr.prototype.j = function() {
        this.l.value && this.C.notify()
    };
    var Xq = function(a, b, c, d, e) {
        Z.call(this, a, 669);
        this.T = b;
        this.U = c;
        this.C = V(this);
        this.A = Y(this, d);
        this.l = W(this, e)
    };
    _.L(Xq, Z);
    Xq.prototype.j = function() {
        if (Lf(uy)) N(this.C, !0);
        else {
            var a, b = !(null == (a = this.A.value) || !y(a, 1)) && (J(this.U, 12) || J(this.T, 13)) || this.l.value;
            N(this.C, !!b)
        }
    };
    var mr = function(a, b, c, d, e, f) {
        Z.call(this, a, 719);
        this.T = b;
        this.A = c;
        this.C = V(this);
        this.l = W(this, d);
        this.D = W(this, e);
        this.G = Y(this, f)
    };
    _.L(mr, Z);
    mr.prototype.j = function() {
        var a = this.l.value.kind;
        switch (a) {
            case 0:
                this.l.value.Ta ? this.D.value ? pN(this) : EB(this.C) : EB(this.C);
                break;
            case 1:
                pN(this);
                break;
            case 2:
                EB(this.C);
                break;
            default:
                gb(a)
        }
    };
    var pN = function(a) {
        var b = a.G.value,
            c = new Ll;
        b = _.z(c, 3, b);
        J(Sl([b, a.T.Za(), a.A.Za()]), 3) ? N(a.C, XH) : EB(a.C)
    };
    var $q = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 681);
        this.adUnitPath = b;
        this.ca = c;
        this.N = d;
        this.G = e;
        this.Ka = V(this);
        this.L = V(this);
        this.Pc = V(this);
        this.l = Lf(uy).split(",");
        this.A = Mf(vy);
        this.P = Y(this, f);
        this.ga = Y(this, g);
        this.W = Y(this, h);
        this.D = W(this, k);
        this.ba = W(this, l)
    };
    _.L($q, Z);
    $q.prototype.j = function() {
        if (this.G) qN(this);
        else {
            var a;
            if (a = this.l.length) {
                b: if (this.l.length) {
                    if (this.A.length && (a = this.adUnitPath.split("/"), !_.u(this.A, "includes").call(this.A, a[a.length - 1]))) {
                        a = !1;
                        break b
                    }
                    a = !0
                } else a = !1;
                var b = a;a = b ? rN(this) : null;
                if (b && a) {
                    b = this.ba.value;
                    var c, d, e = null != (d = null == (c = cj(b.parentElement)) ? void 0 : c.width) ? d : 0;
                    c = "p" === this.l[0];
                    d = Number(this.l[0]);
                    if (c = "f" === this.l[0] ? this.N : d && 0 < d ? d : c ? Math.min(e, this.N) : null) {
                        d = a.width;
                        var f = a.height,
                            g = this.l[1],
                            h = Number(g);
                        d = "ratio" === g && d ? Math.floor(f / d * c) : h && 0 < h ? f * h : f;
                        sN(this, c, d, {
                            kind: 0,
                            Ta: '<html><body style="height:' + (d - 2 + "px;width:" + (c - 2 + 'px;background-color:#ddd;color:#000;border:1px solid #f00;margin:0;"><p>Requested size:')) + (a.width + "x" + a.height + "</p><p>Rendered size:") + (c + "x" + d + "</p></body></html>")
                        }, c <= e ? 1 : 2, b);
                        a = !0
                    } else a = !1
                } else a = !1
            }
            a || qN(this)
        }
    };
    var rN = function(a) {
            a = vi(a.ca)[0];
            return Array.isArray(a) && a.every(function(b) {
                return "number" === typeof b
            }) ? new _.bj(a[0], a[1]) : null
        },
        sN = function(a, b, c, d, e, f) {
            e = void 0 === e ? a.P.value : e;
            N(a.L, new _.bj(b, c));
            N(a.Ka, d);
            DB(a.Pc, e);
            f && _.$x(f, "opacity", .5)
        },
        qN = function(a) {
            var b = a.ga.value,
                c = a.W.value;
            if (a.G) sN(a, null != b ? b : 0, null != c ? c : 0, a.D.value);
            else {
                if (null == b) throw new Bm("Missing 'width'.");
                if (null == c) throw new Bm("Missing 'height'.");
                sN(a, b, c, a.D.value)
            }
        };
    var Vq = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 673);
        this.slotId = b;
        this.Rb = c;
        this.G = d;
        this.D = e;
        this.X = f;
        this.l = g;
        this.M = h;
        this.A = k;
        this.C = V(this)
    };
    _.L(Vq, Z);
    Vq.prototype.j = function() {
        var a = this,
            b, c;
        return _.Bb(function(d) {
            if (1 == d.j) {
                if (a.Rb) {
                    tN(a, a.Rb);
                    N(a.C, a.Rb);
                    d.j = 0;
                    return
                }
                if (zi(a.l)) {
                    var e = uN(a);
                    N(a.C, e);
                    d.j = 0;
                    return
                }
                return Cb(d, rI(a.slotId, sI), 4)
            }
            b = d.o;
            c = b.detail;
            if (a.H) return d.return();
            tN(a, c);
            N(a.C, c);
            d.j = 0
        })
    };
    var uN = function(a) {
            var b = _.ze("INS");
            b.id = a.G;
            _.xj(b, {
                display: "none"
            });
            a.X.documentElement.appendChild(b);
            var c = function() {
                return void _.qx(b)
            };
            2 === a.l || 3 === a.l ? CI(a.M, a.slotId, c) : _.qo(a, c);
            return b
        },
        tN = function(a, b) {
            if (2 !== a.l && 3 !== a.l) {
                for (var c = _.x(_.u(Array, "from").call(Array, b.childNodes)), d = c.next(); !d.done; d = c.next()) d = d.value, 1 === d.nodeType && d.id !== a.D && _.qx(d);
                a.A || (b.style.display = "")
            }
        };
    var hr = function(a, b) {
        Z.call(this, a, 676);
        this.C = V(this);
        this.l = W(this, b)
    };
    _.L(hr, Z);
    hr.prototype.j = function() {
        var a = $i(this.l.value);
        N(this.C, a)
    };
    var nr = function(a, b, c, d, e) {
        Z.call(this, a, 807);
        this.F = b;
        this.C = QB(this);
        this.l = Y(this, c);
        this.A = W(this, d);
        e && SB(this, e)
    };
    _.L(nr, Z);
    nr.prototype.j = function() {
        var a = this.l.value;
        if (a && !this.A.value) {
            var b = Sx(this.F);
            lI(new kI(b, a)) || this.R(new Bm("Cannot create top window frame"))
        }
        this.C.notify()
    };
    var vN = function(a, b) {
            var c = _.E(Dr) ? vj() : void 0;
            this.context = a;
            this.M = b;
            this.j = c
        },
        wN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w, D) {
            var F = document,
                I = window;
            e || f || _.E(cr) || MI(a.M, d);
            var S = Gr(a.context, b, a.j, c, d, e, f, g, h, k, l, m, F, n, p, r, t, function() {
                MI(a.M, d);
                LI(a.M, d, S)
            }, w, D);
            f || _.E(cr) || LI(a.M, d, S);
            _.qo(d, function() {
                MI(a.M, d)
            });
            I.top !== I && I.addEventListener("pagehide", function(M) {
                M.persisted || MI(a.M, d)
            });
            ug(S)
        };
    var xN = function(a, b, c) {
        Z.call(this, a, 944);
        this.F = b;
        this.l = new _.dC(this.F);
        this.A = W(this, c)
    };
    _.L(xN, Z);
    xN.prototype.j = function() {
        var a = this.A.value;
        if (fC(this.l, a)) {
            var b = _.eC(this.l, "__gpi_opt_out", a);
            if (b) {
                var c = new Cw;
                b = _.z(c, 1, b);
                b = _.z(b, 2, 2147483647);
                b = _.z(b, 3, "/");
                b = _.z(b, 4, this.F.location.hostname);
                gC(this.l, "__gpi_opt_out", b, a)
            }
        }
    };
    var yN = function(a, b, c, d) {
        d = void 0 === d ? Jr : d;
        Z.call(this, a, 883);
        this.vb = b;
        this.D = d;
        this.l = QB(this);
        this.A = W(this, c)
    };
    _.L(yN, Z);
    yN.prototype.j = function() {
        !cf(this.A.value) || _.E(Wy) ? this.l.notify() : (_.E(Vy) || hG(this.vb), this.D() ? LB(this.l, new _.v.Promise(function(a) {
            return void iG(a)
        })) : (iG(null), this.l.notify()))
    };
    var zN = function(a, b, c, d, e) {
        Z.call(this, a, 884);
        this.Aa = b;
        this.l = c;
        this.A = V(this);
        this.G = Y(this, d);
        this.D = W(this, e)
    };
    _.L(zN, Z);
    zN.prototype.j = function() {
        this.l.storage = this.G.value;
        SL(this.l, _.eC(this.Aa, "__gads", this.D.value));
        rf(20);
        rf(2);
        var a = _.of(pf).j();
        N(this.A, a)
    };
    var AN = function(a, b, c) {
        Z.call(this, a, 873);
        this.F = b;
        this.l = W(this, c)
    };
    _.L(AN, Z);
    AN.prototype.j = function() {
        var a = this.context,
            b = this.l.value,
            c = this.F;
        !$k()._pubconsole_disable_ && (b = gf("google_pubconsole", b, c)) && (b = b.split("|"), "1" !== b[0] && "0" !== b[0] || cl(a, c))
    };
    var BN = function(a, b, c, d, e) {
        Z.call(this, a, 1058);
        this.F = b;
        this.V = c;
        d && (this.l = Y(this, d));
        SB(this, e)
    };
    _.L(BN, Z);
    BN.prototype.j = function() {
        var a;
        if (Mg("shared-storage", this.F.document) && (null == (a = this.l) ? 0 : a.value) && cf(this.V)) {
            a = {
                message: "goog:spam:client_age",
                pvsid: this.context.pvsid,
                clientAgeIframe: _.E(Fy)
            };
            var b = this.l.value;
            b(a)
        }
    };
    var CN = function(a, b, c) {
        Z.call(this, a, 798);
        this.C = V(this);
        this.l = Y(this, b);
        this.A = W(this, c)
    };
    _.L(CN, Z);
    CN.prototype.j = function() {
        var a = this,
            b = new _.v.Map;
        if (this.l.value) {
            var c = this.l.value,
                d = c.da.Ja,
                e = c.Nc.Oc;
            c = _.x(c.aa.Y);
            for (var f = c.next(); !f.done; f = c.next()) {
                f = f.value;
                var g = void 0,
                    h = null == (g = e) ? void 0 : g.get(f);
                b.set(f, d ? DN(this, f, h) : function() {
                    return a.A.value
                })
            }
        }
        N(this.C, b)
    };
    var DN = function(a, b, c) {
        return mj(function() {
            var d = _.u(Object, "assign").call(Object, {}, a.l.value);
            d.aa.pe = !0;
            d.aa.Y = [b];
            c && (d.Nc.Oc = new _.v.Map, d.Nc.Oc.set(b, c));
            return an(_.E(Cy) ? xn(d) : QK(d)).url
        })
    };
    var EN = function(a, b, c, d, e, f) {
        f = void 0 === f ? Kr : f;
        Z.call(this, a, 886);
        this.Y = b;
        this.M = c;
        this.l = d;
        this.X = e;
        this.A = f;
        this.C = QB(this)
    };
    _.L(EN, Z);
    EN.prototype.j = function() {
        var a = this,
            b, c;
        return _.Bb(function(d) {
            if (1 == d.j) return 3 !== wG(a.X) ? (d.j = 2, d = void 0) : d = Cb(d, new _.v.Promise(function(e) {
                return void AG(e, a.X)
            }), 2), d;
            if (4 != d.j) return b = a.l ? Nq(a.l) : null, null == b || (c = a.Y.some(function(e) {
                return !pj(lj(e))
            })) ? (a.C.notify(), d.return()) : Cb(d, FN(a, b), 4);
            a.C.notify();
            d.j = 0
        })
    };
    var FN = function(a, b) {
        return new _.v.Promise(function(c) {
            var d = a.A(function(h, k) {
                h.some(function(l) {
                    return 0 < l.intersectionRatio
                }) && (k.disconnect(), c())
            }, b + "%");
            if (d) {
                _.qo(a, function() {
                    return void d.disconnect()
                });
                for (var e = {}, f = _.x(a.Y), g = f.next(); !g.done; e = {
                        ac: e.ac
                    }, g = f.next()) {
                    g = g.value;
                    e.ac = lj(g);
                    if (!e.ac) break;
                    d.observe(e.ac);
                    DI(a.M, g, function(h) {
                        return function() {
                            return void d.unobserve(h.ac)
                        }
                    }(e))
                }
            } else _.E(Jq), c()
        })
    };
    var GN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        Z.call(this, a, 866);
        this.G = b;
        this.l = c;
        this.D = d;
        this.wc = e;
        this.ec = f;
        this.V = g;
        this.X = h;
        this.C = QB(this);
        this.A = W(this, k);
        this.N = Y(this, l);
        this.P = W(this, m);
        this.W = W(this, n);
        SB(this, p);
        this.L = W(this, r)
    };
    _.L(GN, Z);
    GN.prototype.j = function() {
        var a, b, c, d = this,
            e, f, g, h, k, l, m, n, p, r, t, w, D;
        return _.Bb(function(F) {
            switch (F.j) {
                case 1:
                    e = d.P.value;
                    if (!e) return d.C.notify(), F.return();
                    f = Hb(d.W.value, {
                        uuid: d.ec
                    });
                    g = document.createElement("script");
                    h = {
                        source: e,
                        credentials: d.L.value ? "include" : "omit",
                        resources: [f.toString()]
                    };
                    g.setAttribute("type", "webbundle");
                    jb(g, new _.wp(JSON.stringify(h).replace(/</g, "\\u003C"), xp));
                    d.X.head.appendChild(g);
                    d.C.notify();
                    F.m = 2;
                    return Cb(F, HN(f), 4);
                case 4:
                    k = F.o;
                    Eb(F, 3);
                    break;
                case 2:
                    l = Fb(F);
                    if (l instanceof qB) return d.l(l), F.return();
                    throw l;
                case 3:
                    a = _.hn(k, 1);
                    b = _.hn(k, 2);
                    c = _.hn(k, 3);
                    m = a;
                    n = b;
                    p = c;
                    if (m.length !== n.length) return d.l(new pB("Received " + m.length + " ad URLs but " + n.length + " metadatas")), F.return();
                    h.resources = [].concat(_.ve(m.filter(function(I) {
                        return I
                    })), _.ve(p.map(function(I) {
                        return "https://securepubads.g.doubleclick.net" + I
                    })));
                    h.resources.length ? (r = _.ze("SCRIPT"), r.setAttribute("type", "webbundle"), jb(r, new _.wp(JSON.stringify(h).replace(/</g, "\\u003C"), xp)), d.X.head.removeChild(g), d.X.head.appendChild(r)) : d.X.head.removeChild(g);
                    for (t = 0; t < m.length; t++) w = m[t], D = n[t], d.G(t, D, {
                        kind: 1,
                        url: w
                    }, d.A.value, d.V, d.N.value);
                    d.D(m.length - 1, d.A.value, d.V);
                    F.j = 0
            }
        })
    };
    var HN = function(a) {
        var b, c;
        return _.Bb(function(d) {
            if (1 == d.j) return Cb(d, fetch(a.toString()).catch(function() {
                throw new qB("Failed to fetch bundle index.");
            }), 2);
            if (3 != d.j) return b = d.o, Cb(d, b.text(), 3);
            c = d.o;
            return d.return(Uw(c))
        })
    };
    var IN = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 810);
        this.D = b;
        this.Ja = c;
        this.O = d;
        this.A = e;
        this.F = f;
        this.V = g;
        this.l = V(this)
    };
    _.L(IN, Z);
    IN.prototype.j = function() {
        var a = this,
            b = this.D;
        !this.Ja && 1 < this.D.length && (b = [b[0]]);
        b = b.filter(function(c) {
            if (c.H) return !1;
            var d = a.O.U[c.getDomId()],
                e;
            if (e = !(no(Om(d)) && (_.C = Mf(cz), _.u(_.C, "includes")).call(_.C, String(Om(d))))) yh(a.F) && 4 === Om(d) ? (ql(a.A, JJ("googletag.enums.OutOfPageFormat.REWARDED", String(c.getAdUnitPath()))), e = !0) : e = !1, e = !e;
            return e && !Rm(a.context, a.A, c, d, a.F, a.V)
        });
        30 < b.length && (ql(this.A, FJ("30", String(b.length), String(b.length - 30))), b = b.slice(0, 30));
        N(this.l, b)
    };
    var JN = function(a, b, c) {
        Z.call(this, a, 919);
        this.l = b;
        this.V = c;
        this.C = V(this)
    };
    _.L(JN, Z);
    JN.prototype.j = function() {
        var a, b = !(null == (a = this.l) ? 0 : J(a, 9)) && !!cf(this.V);
        N(this.C, b)
    };
    var KN = function(a, b, c, d, e, f) {
        Z.call(this, a, 935);
        this.M = b;
        this.O = c;
        this.X = d;
        this.C = QB(this);
        this.l = W(this, e);
        SB(this, f)
    };
    _.L(KN, Z);
    KN.prototype.j = function() {
        var a = this.O,
            b = a.T;
        a = a.U;
        for (var c = _.x(this.l.value), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = a[d.getDomId()],
                f = this.X;
            zn(e, b) && !this.M.wb(d) && An(d, f, e, b)
        }
        this.C.notify()
    };
    var LN = function(a, b, c, d, e, f) {
        f = void 0 === f ? Xj : f;
        Z.call(this, a, 939);
        this.A = b;
        this.F = c;
        this.V = d;
        this.l = f;
        SB(this, e)
    };
    _.L(LN, Z);
    LN.prototype.j = function() {
        var a = this.l,
            b = this.F,
            c = new iq;
        var d = new hq;
        d = _.jd(d, 1, String(this.A));
        c = _.Th(c, 5, d);
        c = _.fd(c, 4, 1, 0);
        c = _.fd(c, 2, 2, 0);
        c = _.jd(c, 3, this.context.bb || this.context.Na);
        c = _.hd(c, 6, cf(this.V));
        a.call(this, b, c)
    };
    var MN = function(a, b, c, d, e) {
        Z.call(this, a, 905);
        this.O = b;
        this.l = c;
        this.C = QB(this);
        this.A = W(this, d);
        SB(this, e)
    };
    _.L(MN, Z);
    MN.prototype.j = function() {
        for (var a = _.x(this.A.value), b = a.next(); !b.done; b = a.next()) {
            var c = void 0;
            switch (null == (c = this.O.U[b.value.getDomId()]) ? void 0 : Om(c)) {
                case 2:
                case 3:
                case 5:
                    this.l.load(_.BL);
                    return
            }
        }
        this.C.notify()
    };
    var NN = function(a, b, c, d) {
        Z.call(this, a, 833);
        this.l = b;
        this.F = c;
        this.C = QB(this);
        SB(this, d)
    };
    _.L(NN, Z);
    NN.prototype.j = function() {
        if (!_.E(lz)) {
            var a = this.l,
                b = this.F,
                c = ij();
            c = {
                version: pK ? pK : pK = Gl(),
                Fd: c
            };
            c = ZH.fh(c);
            var d = GH(b);
            c = d ? te(c, new _.v.Map([
                ["n", String(d)]
            ])) : c;
            d = Mf(Il);
            for (var e = new _.v.Map, f = 0; f < d.length; f += 2) e.set(d[f], d[f + 1]);
            c = te(c, e);
            var g;
            a.resources[c.toString()] || (null == (g = $k()) ? 0 : g.fifWin) || (a.resources[c.toString()] = 1, b = b.document, a = _.ze("IFRAME"), a.src = _.kb(c).toString(), a.style.visibility = "hidden", a.style.display = "none", b = b.getElementsByTagName("script"), b.length && (b = b[b.length - 1], b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)))
        }
        this.C.notify()
    };
    var ON = function(a, b, c, d) {
        Z.call(this, a, 928);
        this.requestId = b;
        this.C = QB(this);
        this.l = W(this, c);
        SB(this, d)
    };
    _.L(ON, Z);
    ON.prototype.j = function() {
        var a = this.context,
            b = this.requestId,
            c = this.l.value.length;
        if (a.Dc) {
            var d = a.Eb;
            a = Uh(a);
            var e = new hy;
            b = _.id(e, 2, b);
            c = _.fd(b, 1, c, 0);
            c = _.Wh(a, 7, Xh, c);
            xe(d, c)
        }
        this.C.notify()
    };
    var PN = function(a, b, c, d) {
        Z.call(this, a, 867);
        this.qa = b;
        this.O = c;
        this.C = QB(this);
        this.l = W(this, d)
    };
    _.L(PN, Z);
    PN.prototype.j = function() {
        for (var a = _.x(this.l.value), b = a.next(); !b.done; b = a.next()) {
            var c = _.x(b.value);
            b = c.next().value;
            c = c.next().value;
            var d = oi(this.O.U[b.getDomId()], 20);
            b.dispatchEvent(uI, 808, {
                og: c,
                Ih: d
            });
            this.qa.dispatchEvent("slotRequested", 705, new jM(b, "publisher_ads"))
        }
        this.C.notify()
    };
    var QN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w, D, F, I, S, M, R, T, X, ka, ca, oa, la, va, na, ya, Ka) {
        Z.call(this, a, 785, _.Kf(rz));
        this.Ja = b;
        this.M = c;
        this.Aa = d;
        this.O = e;
        this.wc = f;
        this.ob = g;
        this.Ub = h;
        this.Tb = k;
        this.he = l;
        this.ec = m;
        this.Fb = n;
        this.V = p;
        this.isSecureContext = r;
        this.ab = t;
        this.F = w;
        this.l = V(this);
        this.D = V(this);
        this.P = V(this);
        SB(this, T);
        this.la = RB(this, D);
        this.G = RB(this, F);
        this.L = W(this, I);
        this.A = RB(this, M);
        R && (this.N = RB(this, R));
        SB(this, T);
        SB(this, X);
        ka && (this.ra = W(this, ka));
        ca && (this.W = new JB(ca));
        oa && (this.ma = Y(this, oa));
        la && (this.ca = W(this, la));
        va && SB(this, va);
        na && (this.ga = W(this, na));
        Ka && (this.xa = W(this, Ka));
        ya && (this.Ia = RB(this, ya));
        this.ba = Y(this, S)
    };
    _.L(QN, Z);
    QN.prototype.j = function() {
        if (this.L.value.length) {
            var a = !_.E(Wy);
            if (a) {
                fh();
                var b = hh[1]
            } else b = "";
            if (a) {
                fh();
                var c = hh[4]
            } else c = "";
            a ? (fh(), a = hh[6]) : a = "";
            var d;
            var e = _.E(wz) ? (d = this.A.value) ? d : this.N && !this.N.Wa() ? 9 : this.A.Wa() ? null : 1 : null != (d = this.A.value) ? d : this.A.Wa() ? null : 1;
            this.G.value && (this.M.Wc = this.G.value);
            var f, g, h, k, l, m, n, p, r;
            d = {
                da: {
                    F: this.F,
                    context: this.context,
                    M: this.M,
                    Aa: this.Aa,
                    V: this.V,
                    Ja: this.Ja,
                    he: this.he,
                    isSecureContext: this.isSecureContext,
                    Yh: null == (f = this.Ia) ? void 0 : f.value,
                    ab: this.ab
                },
                aa: {
                    Y: this.L.value,
                    O: this.O,
                    ob: this.ob,
                    pe: !1
                },
                bi: {
                    Ub: this.Ub,
                    Tb: this.Tb
                },
                mh: {
                    Zf: b,
                    gh: c,
                    Bh: a
                },
                th: {
                    Og: null != (p = this.la.value) ? p : "0"
                },
                Qf: {
                    wc: this.wc,
                    ec: this.ec
                },
                Nc: {
                    Oc: this.ba.value
                },
                Qh: {
                    Rh: e
                },
                Lh: {
                    nh: null != (r = null == (g = this.ra) ? void 0 : g.value) ? r : void 0,
                    xh: null == (h = this.W) ? void 0 : h.value,
                    zg: null == (k = this.ca) ? void 0 : k.value,
                    vh: null == (l = this.xa) ? void 0 : l.value
                },
                zh: {
                    Rg: null == (m = this.ma) ? void 0 : m.value,
                    Lg: null == (n = this.ga) ? void 0 : n.value
                }
            };
            N(this.D, d);
            f = an(_.E(Cy) ? xn(d) : QK(d));
            g = f.url;
            nB(this.Fb, (9).toString(), 9, f.Se);
            N(this.l, g);
            f = _.E(Cy) ? vn(d) ? Ws("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : Ws("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}") : PK(d) ? Ws("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : Ws("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}");
            N(this.P, f)
        } else N(this.l, ""), EB(this.D)
    };
    var RN = function(a, b, c, d, e, f) {
        Z.call(this, a, 878);
        this.l = b;
        this.X = c;
        this.O = d;
        this.F = e;
        this.C = QB(this);
        SB(this, f)
    };
    _.L(RN, Z);
    RN.prototype.j = function() {
        for (var a = _.x(this.l), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = lj(b, this.X);
            if (!kj(b, this.X) && c) {
                a: {
                    var d = c;
                    var e = this.O.U[b.getDomId()],
                        f = 0,
                        g = 0;e = _.x(vi(e));
                    for (var h = e.next(); !h.done; h = e.next())
                        if (h = h.value, Array.isArray(h)) {
                            var k = _.x(h);
                            h = k.next().value;
                            k = k.next().value;
                            if (!("number" !== typeof h || "number" !== typeof k || 1 >= h || 1 >= k || (f = f || h, g = Math.min(g || Infinity, k), Ym(nj(d, this.F)) || !d.parentElement || Ym(nj(d.parentElement, this.F))))) {
                                d = [f, 0];
                                break a
                            }
                        }
                    d = f || g ? [f, g] : null
                }
                g = this.O;f = g.T;g = g.U[b.getDomId()];Xm(c, tj(b), Vi(f, g), d)
            }
        }
        this.C.notify()
    };
    var SN = function(a, b, c, d, e, f) {
            this.l = a;
            this.I = b;
            this.B = c;
            this.Y = d;
            this.V = e;
            this.J = f;
            this.H = "";
            this.m = -1;
            this.j = 1;
            this.o = ""
        },
        UN = function(a, b) {
            if (b)
                if (1 !== a.j && 2 !== a.j) TN(a, new pB("state err: (" + ([a.j, a.o.length].join() + ")")));
                else {
                    a.o && (b = a.o + b);
                    var c = 0;
                    do {
                        var d = b.indexOf("\n", c);
                        var e = -1 !== d;
                        if (!e) break;
                        var f = a;
                        c = b.substr(c, d - c);
                        if (1 === f.j) f.H = c, ++f.m, f.j = 2;
                        else {
                            try {
                                f.l(f.m, f.H, {
                                    kind: 0,
                                    Ta: Px(c)
                                }, f.Y, f.V, f.J), f.H = ""
                            } catch (g) {}
                            f.j = 1
                        }
                        c = d + 1
                    } while (e && c < b.length);
                    a.o = b.substr(c)
                }
        },
        TN = function(a, b) {
            a.j = 4;
            try {
                a.I(b)
            } catch (c) {}
        },
        VN = function(a) {
            1 !== a.j || a.o ? TN(a, new pB("state err (" + ([a.j, a.o.length].join() + ")"))) : (a.j = 3, a.B(a.m, a.Y, a.V))
        };
    var WN = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 788);
        this.N = b;
        this.L = c;
        this.G = d;
        this.V = e;
        this.C = QB(this);
        this.D = 0;
        this.A = !1;
        this.l = null != m ? m : new XMLHttpRequest;
        this.W = W(this, f);
        this.ba = Y(this, g);
        this.ca = W(this, h);
        SB(this, k);
        this.P = W(this, l)
    };
    _.L(WN, Z);
    WN.prototype.j = function() {
        var a = this,
            b = this.ca.value;
        if (b) {
            var c = new SN(this.N, this.L, this.G, this.W.value, this.V, this.ba.value);
            this.l.open("GET", b);
            this.l.withCredentials = this.P.value;
            this.l.onreadystatechange = function() {
                XN(a, c, !1)
            };
            this.l.onload = function() {
                XN(a, c, !0)
            };
            this.l.onerror = function() {
                TN(c, new qB("XHR error"))
            };
            this.l.send()
        }
        this.C.notify()
    };
    var XN = function(a, b, c) {
        try {
            if (3 === a.l.readyState || 4 === a.l.readyState)
                if (300 <= a.l.status) a.A || (TN(b, new qB("xhr_err-" + a.l.status)), a.A = !0);
                else {
                    var d = a.l.responseText.substr(a.D);
                    d && UN(b, d);
                    a.D = a.l.responseText.length;
                    c && 4 === a.l.readyState && VN(b)
                }
        } catch (e) {
            TN(b, e)
        }
    };
    var YN = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 1078);
        this.D = b;
        this.A = c;
        this.l = d;
        this.V = e;
        this.C = QB(this);
        this.L = W(this, f);
        this.N = Y(this, g);
        this.P = W(this, h);
        SB(this, k);
        this.G = W(this, l)
    };
    _.L(YN, Z);
    YN.prototype.j = function() {
        var a = this.P.value;
        a && ZN(this, a);
        this.C.notify()
    };
    var ZN = function(a, b) {
        var c, d, e, f, g, h, k, l, m, n, p, r, t;
        _.Bb(function(w) {
            switch (w.j) {
                case 1:
                    return c = new SN(a.D, a.A, a.l, a.L.value, a.V, a.N.value), e = a.G.value ? "include" : "same-origin", w.m = 2, Cb(w, fetch(b, {
                        credentials: e
                    }), 4);
                case 4:
                    d = w.o;
                    Eb(w, 3);
                    break;
                case 2:
                    f = Fb(w), TN(c, new qB("fetch error: " + (f instanceof Error ? f.message : void 0)));
                case 3:
                    if (!d) return w.return();
                    if (300 <= d.status) return TN(c, new qB("fetch_status-" + d.status)), w.return();
                    h = null == (g = d.body) ? void 0 : g.getReader();
                    if (!h) return w.return();
                    k = new TextDecoder;
                    l = !1;
                case 5:
                    if (l) {
                        w.j = 6;
                        break
                    }
                    w.m = 7;
                    return Cb(w, h.read(), 9);
                case 9:
                    p = w.o;
                    n = p.value;
                    l = p.done;
                    Eb(w, 8);
                    break;
                case 7:
                    m = r = Fb(w), l = !0;
                case 8:
                    t = k.decode(n, {
                        stream: !l
                    });
                    UN(c, t);
                    w.j = 5;
                    break;
                case 6:
                    m && TN(c, new qB("fetch read error: " + (m instanceof Error ? m.message : void 0))), VN(c), w.j = 0
            }
        })
    };
    var $N = function(a, b, c, d, e) {
        Z.call(this, a, 918);
        this.O = b;
        this.Fb = c;
        this.C = QB(this);
        this.l = W(this, e);
        SB(this, d)
    };
    _.L($N, Z);
    $N.prototype.j = function() {
        var a = this.l.value;
        a.length && Dq(this.Fb, "3", (0, B.K)(oi(this.O.U[a[0].getDomId()], 20)));
        this.C.notify()
    };
    var aO = function(a, b) {
        Z.call(this, a, 820);
        this.F = b;
        this.C = V(this)
    };
    _.L(aO, Z);
    aO.prototype.j = function() {
        var a = this,
            b, c, d, e;
        return _.Bb(function(f) {
            if (1 == f.j) return Cb(f, ak(a.F), 2);
            b = f.o;
            c = b.Wc;
            d = b.status;
            c || Cj("gpt_etu", function(g) {
                Ij(g, a.context);
                K(g, "rsn", d)
            });
            CB(a.C, null != (e = c) ? e : "");
            f.j = 0
        })
    };
    var cO = function(a, b, c) {
        Z.call(this, a, 804);
        this.l = c;
        this.G = [];
        this.A = {
            Sg: bO(this, function(d) {
                return go(d, 6)
            }),
            fi: bO(this, function(d) {
                return go(d, 7)
            }),
            Yg: bO(this, function(d) {
                return !!J(d, 8)
            }),
            Gg: bO(this, function(d) {
                return y(d, 10)
            }),
            df: bO(this, function(d) {
                var e;
                return null != (e = d.getEscapedQemQueryId()) ? e : ""
            }),
            bg: bO(this, function(d) {
                return Bf(d, Dw, 43)
            }),
            Xg: bO(this, function(d) {
                return !!J(d, 9)
            }),
            Wh: bO(this, function(d) {
                return !!J(d, 12)
            }),
            Mg: bO(this, function(d) {
                return eo(d, nw, 48, Qw)
            }),
            Dg: bO(this, function(d) {
                return eo(d, lw, 39, Qw)
            }),
            Pc: bO(this, function(d) {
                return y(d, 36)
            }),
            Xh: bO(this, function(d) {
                return J(d, 13)
            }),
            Wg: bO(this, function(d) {
                return J(d, 3)
            }),
            Th: bO(this, function(d) {
                return y(d, 49)
            }),
            ci: bO(this, function(d) {
                return go(d, 29)
            }),
            di: bO(this, function(d) {
                return go(d, 30)
            }),
            Tg: bO(this, function(d) {
                return Bf(d, Fw, 51)
            }),
            xg: bO(this, function(d) {
                return y(d, 61)
            }),
            Ka: V(this),
            Mf: bO(this, function(d) {
                return Bf(d, Nw, 58)
            }),
            gi: bO(this, function(d) {
                var e, f;
                return null != (f = null == (e = Bf(d, Ew, 56)) ? void 0 : qg(e, 1)) ? f : null
            }),
            yc: bO(this, function(d) {
                return Qe(d, fw, 62)
            }),
            hh: bO(this, function(d) {
                return Yc(d, 63, Ec)
            }),
            ig: bO(this, function(d) {
                return J(d, 64)
            })
        };
        this.D = W(this, b)
    };
    _.L(cO, Z);
    var bO = function(a, b) {
        var c = V(a);
        a.G.push({
            C: c,
            Ag: b
        });
        return c
    };
    cO.prototype.j = function() {
        for (var a = _.x(this.G), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = b.Ag;
            DB(b.C, c(this.D.value))
        }
        0 === this.l.kind || 1 === this.l.kind && this.l.url ? N(this.A.Ka, this.l) : N(this.A.Ka, {
            kind: 0,
            Ta: y(this.D.value, 4) || ""
        })
    };
    var dO = function(a, b, c, d) {
        Z.call(this, a, 822);
        this.slotId = b;
        this.Fa = c;
        this.l = QB(this);
        this.A = W(this, d)
    };
    _.L(dO, Z);
    dO.prototype.j = function() {
        for (var a = this, b = ho(this.A.value, 23), c = _.x(b), d = c.next(); !d.done; d = c.next()) d = d.value, WM(this.Fa, d), XM(this.Fa, d, this.slotId);
        this.l.notify();
        b.length && Cj("gpt_hp", function(e) {
            Ij(e, a.context);
            K(e, "ls", b.join())
        }, _.Kf(Iy))
    };
    var eO = function(a, b, c) {
        Z.call(this, a, 803);
        this.l = b;
        this.slotId = c;
        this.C = V(this);
        this.A = V(this)
    };
    _.L(eO, Z);
    eO.prototype.j = function() {
        var a = JSON.parse(this.l),
            b = Kk(a, Xs);
        if (!b) throw Error("missing ad unit path");
        if (null == a || !a[b]) throw Error("invalid ad unit path: " + b);
        a = a[b];
        if (!Array.isArray(a)) throw Error("dictionary not an array: " + this.l);
        a = _.E(Uy) ? Hd(Pw, a) : new Pw(a.slice());
        var c;
        b = _.x(null != (c = Yc(a, 27, Bc)) ? c : []);
        for (c = b.next(); !c.done; c = b.next()) c = c.value, _.of(pf).o(c);
        rf(4);
        this.slotId.dispatchEvent(tI, 800, a);
        N(this.C, a);
        var d;
        DB(this.A, null != (d = Bf(a, Bw, 54)) ? d : null)
    };
    var fO = function(a, b, c, d) {
        Z.call(this, a, 823);
        this.slotId = b;
        this.M = c;
        this.l = QB(this);
        this.A = W(this, d)
    };
    _.L(fO, Z);
    fO.prototype.j = function() {
        var a = this;
        J(this.A.value, 11) && (_.FI(this.M, this.slotId), CI(this.M, this.slotId, function() {
            _.GI(a.M, a.slotId)
        }));
        this.l.notify()
    };
    var gO = function(a, b, c, d) {
        Z.call(this, a, 821);
        this.V = b;
        this.Aa = c;
        this.l = QB(this);
        this.A = W(this, d)
    };
    _.L(gO, Z);
    gO.prototype.j = function() {
        if (cf(this.V))
            for (var a = new _.v.Set, b = _.x(Qe(this.A.value, Cw, 14)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = void 0,
                    e = null != (d = Ru(c, 5)) ? d : 1;
                a.has(e) || (gC(this.Aa, 2 === e ? "__gpi" : "__gads", c, this.V), a.add(e))
            }
        this.l.notify()
    };
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var hO = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""),
        iO = function() {
            for (var a = Array(36), b = 0, c, d = 0; 36 > d; d++) 8 == d || 13 == d || 18 == d || 23 == d ? a[d] = "-" : 14 == d ? a[d] = "4" : (2 >= b && (b = 33554432 + 16777216 * Math.random() | 0), c = b & 15, b >>= 4, a[d] = hO[19 == d ? c & 3 | 8 : c]);
            return a.join("")
        };
    var jO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w, D, F, I, S, M, R, T, X, ka, ca) {
        Z.call(this, a, 973);
        this.la = b;
        this.G = c;
        this.N = d;
        this.D = e;
        this.O = f;
        this.M = g;
        this.Aa = h;
        this.ca = k;
        this.P = l;
        this.A = m;
        this.zc = n;
        this.ga = p;
        this.Bb = r;
        this.isSecureContext = t;
        this.ab = w;
        this.Fa = D;
        this.F = F;
        this.X = I;
        this.zb = S;
        this.ra = T;
        this.l = X;
        this.W = ka;
        this.ma = ca;
        this.L = Y(this, S);
        this.ba = W(this, M);
        this.xa = W(this, R);
        this.l && SB(this, this.l.mg)
    };
    _.L(jO, Z);
    jO.prototype.j = function() {
        var a = this,
            b = new jg;
        _.Vn(this, b);
        var c = this.ba.value,
            d = yn(this.O.T);
        this.L.value && N(this.ma, this.L.value);
        _.E(Kz) || G(b, new fL(this.context, console, this.zb));
        var e = new EN(this.context, this.N, this.M, Bf(this.O.T, Zq, 5), this.X);
        G(b, e);
        var f = new RN(this.context, this.N, this.X, this.O, this.F, e.C);
        G(b, f);
        var g = !!J(this.O.T, 6),
            h = new IN(this.context, this.N, g, this.O, this.G, this.F, c);
        G(b, h);
        var k = new DM(this.context, d, c, h.l);
        G(b, k);
        var l = new aO(this.context, this.F);
        G(b, l);
        var m = this.W,
            n = m.Pg;
        e = m.Lf;
        var p = m.Zh;
        m = m.wh;
        var r, t = null != (r = this.l) ? r : {};
        r = t.nb;
        var w = t.sb,
            D = t.Kb,
            F = t.Jb,
            I = t.Pb,
            S = t.zd,
            M = t.Bd,
            R = t.cg,
            T = t.oh,
            X = t.Oa,
            ka = t.tb,
            ca = t.cd;
        t = t.Kg;
        n = new xM(this.context, n);
        G(b, n);
        w = new UL(this.context, this.G, this.O.U, this.Bb, h.l, r, w, D, F, I, R, X);
        G(b, w);
        G(b, new $L(this.context, r, S, M, w.D, w.G, this.O.U));
        D = new yM(this.context, d, c, this.F, this.L.value, e);
        G(b, D);
        S = window.isSecureContext && _.E(Cz) ? "wbn" : "ldjh";
        var oa = ++this.M.l;
        M = "wbn" === S ? iO().toLowerCase() : void 0;
        F = this.zc;
        f = new QN(this.context, g, this.M, this.Aa, this.O, S, F.ob, F.Ub, F.Tb, this.xa.value, M, _.of(ai), c, this.isSecureContext, this.ab, this.F, n.C, l.C, h.l, w.l, D.C, _.E(wz) ? e : void 0, f.C, this.ra, T, r, X, ka, ca, t, p, m);
        G(b, f);
        g = new $N(this.context, this.O, _.of(ai), f.l, h.l);
        G(b, g);
        d = new JN(this.context, d, c);
        G(b, d);
        l = Zh(this.context, 646, function(va, na, ya, Ka, Zb, Kb) {
            var $b = function() {
                return void kO(a, Zb, va, na, ya, Ka, Kb)
            };
            va && _.E(Ey) ? setTimeout(Zh(a.context, 646, $b), 0) : $b()
        });
        p = Zh(this.context, 647, function(va, na, ya) {
            var Ka = function() {
                return void lO(a, oa, ya, na, va)
            };
            _.E(Ey) ? setTimeout(Zh(a.context, 646, Ka), 0) : Ka()
        });
        var la;
        "ldjh" === S ? (m = mO(this, 289, "strm_err"), _.E(Ny) && window.fetch || _.E(Oy) && Gx(window.fetch) ? la = new YN(this.context, l, m, p, c, h.l, k.C, f.l, g.C, d.C) : la = new WN(this.context, l, m, p, c, h.l, k.C, f.l, g.C, d.C)) : la = new GN(this.context, l, mO(this, 1042, "Unknown web bundle error."), p, S, (0, B.K)(M), c, this.X, h.l, k.C, f.l, f.P, g.C, d.C);
        G(b, la);
        k = new ON(this.context, oa, h.l, la.C);
        G(b, k);
        k = new CN(this.context, f.D, f.l);
        G(b, k);
        k = new PN(this.context, this.A.qa, this.O, k.C);
        G(b, k);
        k = new NN(this.context, this.ca, this.F, k.C);
        G(b, k);
        k = new MN(this.context, this.O, this.P, h.l, k.C);
        G(b, k);
        h = new KN(this.context, this.M, this.O, this.X, h.l, k.C);
        G(b, h);
        h = new LN(this.context, tf(this.F), this.F, c, la.C);
        G(b, h);
        _.E(Gy) && 1 === oa && (c = new BN(this.context, this.F, c, e, la.C), G(b, c));
        ug(b)
    };
    var kO = function(a, b, c, d, e, f, g) {
            var h, k, l;
            return _.Bb(function(m) {
                h = f[c];
                if (!h) return ci(a.context, 646, Error("missing slot")), m.return();
                0 === c && (k = (0, B.K)(oi(a.O.U[h.getDomId()], 20)), Dq(_.of(ai), "4", k));
                return Cb(m, nO(a, h, d, e, b, null == (l = g) ? void 0 : l[h.getId()]), 0)
            })
        },
        lO = function(a, b, c, d, e) {
            var f, g, h;
            return _.Bb(function(k) {
                switch (k.j) {
                    case 1:
                        var l = a.context,
                            m = e + 1,
                            n = d.length;
                        if (l.Dc) {
                            var p = l.Eb;
                            l = Uh(l);
                            var r = new iy;
                            r = _.id(r, 3, b);
                            m = _.fd(r, 1, m, 0);
                            n = _.fd(m, 2, n, 0);
                            n = _.Wh(l, 8, Xh, n);
                            xe(p, n)
                        }
                        f = e + 1;
                    case 2:
                        if (!(f < d.length)) {
                            k.j = 4;
                            break
                        }
                        if (!d[f]) {
                            k.j = 3;
                            break
                        }
                        p = new Pw;
                        p = _.z(p, 8, !0);
                        g = Ne(p);
                        h = '{"empty":' + g + "}";
                        return Cb(k, kO(a, c, f, h, {
                            kind: 0,
                            Ta: ""
                        }, d, null), 3);
                    case 3:
                        ++f;
                        k.j = 2;
                        break;
                    case 4:
                        JI(a.M, a.D) || a.A.ke.dispatchEvent(yI, 965, a.D), k.j = 0
                }
            })
        },
        nO = function(a, b, c, d, e, f) {
            var g, h, k, l, m, n, p, r, t, w, D, F, I, S, M, R, T, X, ka, ca, oa, la, va, na;
            return _.Bb(function(ya) {
                switch (ya.j) {
                    case 1:
                        return g = new jg, h = new eO(a.context, c, b), G(g, h), k = new dL(a.context, h.A), G(g, k), l = new gO(a.context, e, a.Aa, h.C), G(g, l), m = new dO(a.context, b, a.Fa, h.C), G(g, m), n = new fO(a.context, b, a.M, h.C), G(g, n), p = new cO(a.context, h.C, d), G(g, p), r = [l.l.promise, m.l.promise, n.l.promise], ug(g), Cb(ya, _.v.Promise.all(r), 2);
                    case 2:
                        if (b.H) return ya.return();
                        t = p;
                        D = w = t.A;
                        F = D.Mf;
                        I = D.Yg;
                        S = D.df;
                        return Cb(ya, F.promise, 3);
                    case 3:
                        return M = ya.o, R = !!M, X = null == (T = M) ? void 0 : Bf(T, Lw, 5), Cb(ya, I.promise, 4);
                    case 4:
                        return ka = ya.o, R && Cj("gpt_td_init", function(Ka) {
                            Ij(Ka, a.context);
                            var Zb, Kb;
                            K(Ka, "winner_qid", null != (Kb = null == (Zb = X) ? void 0 : Zb.getEscapedQemQueryId()) ? Kb : "");
                            var $b, Mb;
                            K(Ka, "xfpQid", null != (Mb = null == ($b = X) ? void 0 : _.Tf($b, 6)) ? Mb : "");
                            K(Ka, "noFill", ka ? "1" : "0");
                            K(Ka, "publisher_tag", "gpt")
                        }, 1), ca = B, oa = ca.K, Cb(ya, S.promise, 5);
                    case 5:
                        la = oa.call(ca, ya.o), va = Om(a.O.U[b.getDomId()]), ((na = cn("google_norender") || 5 === va && _.E(dz)) || ka && !R) && !_.E(cr) ? Hq(b, a.M, a.O, la) : wN(a.ga, a.la, a.G, b, ka || na, R, a.M, a.O, a.Fa, w, k.l, e, f, a.A.qa, a.P, a.l, a.W), g.Da(), ya.j = 0
                }
            })
        },
        mO = function(a, b, c) {
            return Zh(a.context, b, function(d) {
                d = d instanceof Error ? d : Error();
                d.message = d.message || c;
                ci(a.context, b, d);
                JI(a.M, a.D) || a.A.ke.dispatchEvent(yI, 965, a.D)
            })
        };
    var oO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w, D, F, I, S, M, R, T, X, ka) {
        Z.call(this, a, 885);
        this.ga = b;
        this.D = c;
        this.O = d;
        this.M = e;
        this.Aa = f;
        this.zc = g;
        this.ba = h;
        this.N = k;
        this.l = l;
        this.G = m;
        this.ca = n;
        this.isSecureContext = p;
        this.L = r;
        this.W = t;
        this.ab = w;
        this.Fa = D;
        this.vb = F;
        this.F = I;
        this.X = S;
        this.A = T;
        this.P = X;
        this.la = ka;
        this.ma = W(this, M);
        SB(this, R)
    };
    _.L(oO, Z);
    oO.prototype.j = function() {
        var a = this.ma.value;
        if (a.length) {
            var b = this.M,
                c = this.l,
                d = a.length;
            b.o.has(c);
            b.o.set(c, d);
            a = _.x(a);
            for (b = a.next(); !b.done; b = a.next()) {
                c = b.value;
                var e = void 0,
                    f = void 0;
                b = c.Bb;
                d = c.Y;
                c = new jg;
                _.Vn(this, c);
                var g = Yn(this.context, this.W, null == (f = this.A) ? void 0 : f.vd);
                f = g.Lb;
                var h = g.gf;
                _.Vn(c, g.nc);
                f = Gn(this.context, this.D, this.M, yn(this.O.T), this.F, f, h);
                g = f.hb;
                _.Vn(c, f.nc);
                f = new AN(this.context, this.F, g);
                G(c, f);
                f = new xN(this.context, this.F, g);
                G(c, f);
                f = new yN(this.context, null != (e = this.vb) ? e : _.Qh(150), g);
                G(c, f);
                e = new Sq(this.context, this.F, g);
                G(c, e);
                h = new zN(this.context, this.Aa, this.L, e.C, g);
                G(c, h);
                b = new jO(this.context, this.ga, this.D, d, this.l, this.O, this.M, this.Aa, this.ba, this.N, this.G, this.zc, this.ca, b, this.isSecureContext, this.ab, this.Fa, this.F, this.X, e.C, g, h.A, f.l, this.A, this.P, this.la);
                G(c, b);
                ug(c)
            }
        } else this.G.ke.dispatchEvent(yI, 965, this.l)
    };
    var pO = new _.v.Map,
        qO = function(a, b, c, d) {
            d = void 0 === d ? pO : d;
            Z.call(this, a, 834);
            this.D = b;
            this.Y = c;
            this.l = d;
            this.A = V(this);
            this.G = _.v.Promise.all(this.Y.map(this.L, this))
        };
    _.L(qO, Z);
    qO.prototype.j = function() {
        var a = this,
            b;
        return _.Bb(function(c) {
            if (1 == c.j) return Cb(c, a.G, 2);
            b = c.o;
            CB(a.A, b.filter(function(d) {
                return null != d && !d.H
            }));
            c.j = 0
        })
    };
    qO.prototype.L = function(a) {
        var b = this,
            c, d;
        return _.Bb(function(e) {
            if (1 == e.j) {
                if (a.H) return e.return();
                b.l.has(a) || (b.l.set(a, Lr(a)), _.qo(a, function() {
                    return void b.l.delete(a)
                }));
                c = (0, B.K)(b.l.get(a));
                return Cb(e, c(), 2)
            }
            d = e.o;
            if (b.H) return e.return();
            if (d) return e.return(a);
            ql(b.D, QJ(a.getAdUnitPath()));
            return e.return()
        })
    };
    var rO = function(a, b, c, d, e) {
        Z.call(this, a, 847);
        this.M = b;
        this.Ja = c;
        this.A = d;
        this.l = V(this);
        this.D = W(this, e)
    };
    _.L(rO, Z);
    rO.prototype.j = function() {
        var a = this.D.value;
        if (a.length) {
            for (var b = _.x(a), c = b.next(); !c.done; c = b.next()) KI(this.M, c.value);
            this.A ? CB(this.l, []) : this.Ja ? (b = Nh(a[0].getAdUnitPath()), a = sO(a, b), N(this.l, a)) : (a = a.map(function(d) {
                return {
                    Bb: Nh(d.getAdUnitPath()),
                    Y: [d]
                }
            }), N(this.l, a))
        } else CB(this.l, [])
    };
    var sO = function(a, b) {
        var c = [];
        a = Ca(a, function(f) {
            return Nh(f.getAdUnitPath())
        });
        a = _.x(_.u(Object, "entries").call(Object, a));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = _.x(d.value);
            d = e.next().value;
            e = e.next().value;
            d === b ? c.unshift({
                Bb: d,
                Y: e
            }) : c.push({
                Bb: d,
                Y: e
            })
        }
        return c
    };
    var tO = function(a, b, c) {
        Z.call(this, a, 845);
        this.U = b;
        this.l = V(this);
        this.A = V(this);
        this.D = W(this, c)
    };
    _.L(tO, Z);
    tO.prototype.j = function() {
        var a = this,
            b = function(d) {
                return !!vi(a.U[d.getDomId()]).length
            },
            c = this.D.value;
        CB(this.l, c.filter(b));
        CB(this.A, c.filter(Ys(b)))
    };
    var uO = function(a, b, c, d, e) {
        Z.call(this, a, 864);
        this.M = b;
        this.O = c;
        this.X = d;
        this.l = QB(this);
        this.A = W(this, e)
    };
    _.L(uO, Z);
    uO.prototype.j = function() {
        for (var a = _.x(this.A.value), b = a.next(); !b.done; b = a.next())
            if (b = b.value, _.Fq(this.M, b)) {
                var c = this.O,
                    d = c.T;
                c = c.U[b.getDomId()];
                zn(c, d) && An(b, this.X, c, d);
                KI(this.M, b);
                var e = void 0,
                    f = void 0;
                null != (e = null != (f = Ui(c, 10)) ? f : J(d, 11)) && e && An(b, this.X, c, d)
            }
        this.l.notify()
    };
    var vO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w, D, F, I, S) {
        _.Q.call(this);
        var M = this;
        this.context = a;
        this.L = b;
        this.B = c;
        this.M = d;
        this.Aa = e;
        this.qa = f;
        this.R = g;
        this.J = h;
        this.G = k;
        this.isSecureContext = l;
        this.I = m;
        this.D = n;
        this.ab = p;
        this.Fa = r;
        this.vb = t;
        this.X = w;
        this.F = D;
        this.l = F;
        this.A = I;
        this.N = S;
        this.j = new _.v.Map;
        this.m = new pI(a);
        _.Vn(this, this.m);
        this.m.Z(yI, function(R) {
            R = R.detail;
            var T = M.j.get(R);
            T && (M.j.delete(R), T.Da())
        })
    };
    _.L(vO, _.Q);
    var wO = function(a, b, c, d) {
        var e = ++a.M.B;
        a.j.has(e);
        var f = new jg;
        a.j.set(e, f);
        b = new qO(a.context, a.B, b);
        G(f, b);
        var g = new tO(a.context, d.U, b.A);
        G(f, g);
        b = new rO(a.context, a.M, !!J(d.T, 6), cn("google_nofetch"), g.l);
        G(f, b);
        g = new uO(a.context, a.M, d, document, g.A);
        G(f, g);
        a = new oO(a.context, a.L, a.B, d, a.M, a.Aa, c, a.R, a.J, e, {
            ke: a.m,
            qa: a.qa
        }, a.G, a.isSecureContext, a.I, a.D, a.ab, a.Fa, a.vb, a.F, a.X, b.l, g.l, a.l, a.A, a.N);
        G(f, a);
        ug(f)
    };
    var xO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, t, w) {
        TM.call(this, c, h);
        this.context = a;
        this.M = d;
        this.I = new _.v.Set;
        this.A = {};
        this.G = new vN(a, d);
        this.L = new vO(a, b, c, d, new _.dC(window, _.E(Qy)), this.l, m, e, this.G, f, g, k, l, n, p, document, window, r, t, w);
        _.Vn(this, this.L)
    };
    _.L(xO, TM);
    xO.prototype.getName = function() {
        return "publisher_ads"
    };
    xO.prototype.display = function(a, b, c, d, e) {
        d = void 0 === d ? "" : d;
        e = void 0 === e ? "" : e;
        var f = "";
        if (d)
            if (_.pa(d) && 1 == d.nodeType) {
                var g = d;
                f = g.id
            } else f = d;
        Kp(this);
        var h = km(c, this.context, this.j, a, b, f),
            k = h.slotId;
        h = h.fb;
        if (k && h) {
            g && !f && (g.id = k.getDomId());
            this.slotAdded(k, h);
            h.setClickUrl(e);
            var l;
            Dp(this, null != (l = g) ? l : k.getDomId(), c)
        } else ql(this.j, Uk("PubAdsService.display", [a, b, d]))
    };
    var Dp = function(a, b, c) {
            var d = yO(b, c);
            c = d.slotId;
            var e = d.rg;
            d = d.sg;
            if (c) {
                if (b = vj(), (d = jo(b, c.getDomId())) && !J(d, 19))
                    if (e && b.m.set(c, e), lj(c) || zi(Om(d))) {
                        if (_.z(d, 19, !0), e = ej(b.j, b.o), a.B) {
                            Kp(a);
                            a.B && EI(a.M, c);
                            a.j.info(lJ());
                            b = e.T;
                            d = e.U;
                            var f = J(b, 6);
                            if (f || !a.M.wb(c)) f && (f = lj(c)) && c.dispatchEvent(sI, 778, f), J(b, 4) && (d = d[c.getDomId()], zn(d, b) && !a.M.wb(c) && An(c, document, d, b)), zO(a, e, c)
                        }
                    } else ql(a.j, aJ(String(y(d, 1)), String(y(d, 2))), c)
            } else d ? a.j.error(bJ(d)) : a.j.error(Uk("googletag.display", [String(b)]))
        },
        oK = function(a, b, c) {
            var d = void 0 === d ? document : d;
            var e;
            null != (e = c.U[b.getDomId()]) && _.z(e, 19, !0);
            e = {
                id: ax(b.getDomId())
            };
            ob(d, eh(e));
            lj(b, d) ? (Kp(a), EI(a.M, b), zO(a, c, b)) : Cj("gpt_pb_write", function(f) {
                Ij(f, a.context)
            })
        };
    xO.prototype.slotAdded = function(a, b) {
        var c = this;
        J(b, 17) || this.B && EI(this.M, a);
        this.l.dispatchEvent(vI, 724, {
            Ie: a.getDomId(),
            U: b
        });
        var d = 0;
        a.Z(Gq, function(e) {
            var f = e.detail;
            e = f.size;
            f = f.isEmpty;
            var g = new eM(a, "publisher_ads");
            f && (g.isEmpty = !0);
            var h = a.j.getResponseInformation();
            e && h && (g.size = [e.width, e.height], g.sourceAgnosticCreativeId = h.sourceAgnosticCreativeId, g.sourceAgnosticLineItemId = h.sourceAgnosticLineItemId, g.isBackfill = h.isBackfill, g.creativeId = h.creativeId, g.lineItemId = h.lineItemId, g.creativeTemplateId = h.creativeTemplateId, g.advertiserId = h.advertiserId, g.campaignId = h.campaignId, g.yieldGroupIds = h.yieldGroupIds, g.companyIds = h.companyIds);
            _.E(Sy) && (e = new fl("gpt_sree"), Ij(e, c.context), K(e, "sid", c.context.pvsid), K(e, "adk", Ar(c.M, a)), K(e, "nf", f), K(e, "rc", II(c.M, a)), K(e, "sret", ((_.kf(_.q) || 0) - d).toFixed(3)), hl(e));
            c.l.dispatchEvent("slotRenderEnded", 708, g)
        });
        a.Z(tI, function(e) {
            var f, g;
            d = null != (g = null != (f = e.timeStamp) ? f : _.kf(_.q)) ? g : 0;
            c.l.dispatchEvent("slotResponseReceived", 709, new kM(a, c.getName()))
        });
        TM.prototype.slotAdded.call(this, a, b)
    };
    var zO = function(a, b, c) {
            var d = AO(a, b, c);
            BO(a, d, b, {
                ob: 1
            });
            b = c.getAdUnitPath();
            if (c = a.A[b]) {
                c = _.x(c);
                for (d = c.next(); !d.done; d = c.next()) d = d.value, BO(a, d.Y, d.O, d.zc);
                delete a.A[b]
            }
        },
        AO = function(a, b, c) {
            var d = b.T;
            b = b.U;
            if (J(d, 4)) return [];
            var e;
            return !J(d, 6) || (null == (e = b[c.getDomId()]) ? 0 : J(e, 17)) ? (a.I.add(c), _.qo(c, function() {
                return void a.I.delete(c)
            }), [c]) : a.m.filter(function(f) {
                if (a.I.has(f)) return !1;
                a.I.add(f);
                _.qo(f, function() {
                    return void a.I.delete(f)
                });
                return !0
            })
        },
        BO = function(a, b, c, d) {
            a.j.info(sJ());
            if (CO(a, b, d, c) && 1 !== d.ob)
                for (b = _.x(b), d = b.next(); !d.done; d = b.next()) d = d.value.getDomId(), a.l.dispatchEvent(wI, 725, {
                    Ie: d,
                    U: c.U[d]
                })
        },
        CO = function(a, b, c, d) {
            b = b.filter(function(e) {
                if (!_.Fq(a.M, e)) return !1;
                var f = d.U[e.getDomId()];
                5 !== Om(f) && 4 !== Om(f) || _.FI(a.M, e);
                return !0
            });
            if (!b.length) return null;
            wO(a.L, b, c, d);
            return b
        };
    xO.prototype.refresh = function(a, b, c) {
        b = DO(this, b);
        if (!b.length) return !1;
        EO(this, a, b, null != c ? c : {
            ob: 2
        });
        return !0
    };
    var DO = function(a, b) {
            return b.filter(function(c, d) {
                if (!c.H) return !0;
                ql(a.j, vJ(String(d)));
                return !1
            })
        },
        EO = function(a, b, c, d) {
            var e = c[0],
                f, g = null != (f = null == e ? void 0 : e.getDomId()) ? f : "";
            if (a.B) {
                var h = {};
                e = _.x(c);
                for (f = e.next(); !f.done; h = {
                        bc: h.bc
                    }, f = e.next()) h.bc = f.value, a.I.add(h.bc), _.qo(h.bc, function(k) {
                    return function() {
                        return void a.I.delete(k.bc)
                    }
                }(h));
                BO(a, c, b, d)
            } else c.length && J(b.T, 6) ? (ql(a.j, rJ(g), e), e = e.getAdUnitPath(), f = null != (h = a.A[e]) ? h : [], f.push({
                Y: c,
                O: b,
                zc: d
            }), a.A[e] = f) : ql(a.j, pJ(g), e)
        };
    xO.prototype.R = function() {
        var a = this,
            b = vj().j;
        if (J(b, 6))
            for (var c = _.x(this.m), d = c.next(); !d.done; d = c.next()) this.B && EI(this.M, d.value);
        vK(this, b);
        this.l.Z("rewardedSlotClosed", function(e) {
            var f = e.detail.slot;
            e = _.u(a.m, "find").call(a.m, function(g) {
                return f === g.j
            });
            FO(a, [e], vj().j, vj().o, a.M)
        });
        al()
    };
    xO.prototype.destroySlots = function(a) {
        a = TM.prototype.destroySlots.call(this, a);
        if (a.length && this.B) {
            var b = vj();
            GO(this, a, b.j, b.o)
        }
        return a
    };
    var xK = function(a, b, c, d) {
            if (!a.B) return ql(a.j, qJ(), d[0]), !1;
            var e = DO(a, d);
            if (!e.length) return ql(a.j, Uk("PubAdsService.clear", [d].filter(function(f) {
                return void 0 !== f
            }))), !1;
            a.j.info(tJ());
            GO(a, e, b, c);
            return !0
        },
        GO = function(a, b, c, d) {
            for (var e = _.x(b), f = e.next(); !f.done; f = e.next()) BI(a.M, f.value);
            FO(a, b, c, d, a.M)
        };
    xO.prototype.forceExperiment = function(a) {
        a = Number(a);
        0 < a && _.of(pf).o(a)
    };
    var FO = function(a, b, c, d, e) {
            var f = void 0 === f ? window : f;
            b = _.x(b);
            for (var g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                MI(a.G.M, g);
                var h = d[g.getDomId()];
                zn(h, c) && An(g, f.document, h, c);
                KI(e, g)
            }
        },
        wK = function(a, b, c, d) {
            if ("string" !== typeof b || "string" !== typeof c) ql(a.j, Uk("PubAdsService.setVideoContent", [b, c]));
            else {
                var e = _.z(d, 21, !0);
                b = _.z(e, 22, b);
                _.z(b, 23, c);
                vK(a, d)
            }
        },
        yK = function(a, b) {
            if (!a.B) return null;
            var c, d;
            return {
                vid: null != (c = y(b, 22)) ? c : "",
                cmsid: null != (d = y(b, 23)) ? d : ""
            }
        },
        vK = function(a, b) {
            J(b, 21) && a.B && _.z(b, 29, Qx())
        },
        yO = function(a, b) {
            var c = "";
            if ("string" === typeof a) c = a, b = TK(b, c);
            else if (_.pa(a) && 1 == a.nodeType) {
                var d = a;
                c = d.id;
                b = TK(b, c)
            } else b = (_.C = [].concat(_.ve(b.Y)), _.u(_.C, "find")).call(_.C, function(e) {
                return e.j === a
            });
            return {
                slotId: b,
                rg: d,
                sg: c
            }
        };
    var HO = _.O(["https://securepubads.g.doubleclick.net/pagead/js/rum_debug.js"]),
        IO = _.O(["https://securepubads.g.doubleclick.net/pagead/js/rum.js"]);
    var JO = is(["^[-p{L}p{M}p{N}_,.!*<>():/]*$"], ["^[-\\p{L}\\p{M}\\p{N}_,\\.!*<>():/]*$"]),
        KO = _.Zs(function() {
            Mx("The googletag.pubads().definePassback function has been deprecated. The function may break in certain contexts, see https://developers.google.com/publisher-tag/guides/passback-tags#construct_passback_tags for how to correctly create a passback.")
        }),
        MO = function(a, b) {
            var c = this;
            var d = void 0 === d ? _.u(String, "raw").call(String, JO) : d;
            this.M = a;
            this.o = d;
            this.j = new _.v.Map;
            this.Y = new _.v.Set;
            b.o = function(e) {
                return LO(c, e)
            }
        };
    MO.prototype.defineSlot = function(a, b, c, d, e) {
        a = km(this, a, b, c, d, e);
        var f = a.slotId;
        if (f) return f.j;
        a.Xc || b.error(Uk("googletag.defineSlot", [c, d, e]));
        return null
    };
    var km = function(a, b, c, d, e, f, g) {
        return "string" === typeof d && 0 < d.length && e && (void 0 === f || "string" === typeof f) ? a.add(b, c, d, e, {
            ib: f,
            wf: void 0 === g ? !1 : g
        }) : {}
    };
    MO.prototype.add = function(a, b, c, d, e) {
        var f = this,
            g = void 0 === e ? {} : e;
        e = g.ib;
        var h = void 0 === g.format ? 0 : g.format,
            k = void 0 === g.wf ? !1 : g.wf;
        g = void 0 === g.jb ? !1 : g.jb;
        try {
            var l = new RegExp(this.o, "u");
            if (l.test("/1") && !l.test(c)) return b.error(dJ(c)), {
                Xc: !0
            }
        } catch (n) {}
        if (l = Wm(h, g)) return Im(b, l, h, c), {};
        k && KO();
        h = this.j.get(c) || Number(k);
        b = NO(this, a, b, c, h, d, e || "gpt_unit_" + c + "_" + h);
        a = b.fb;
        var m = b.slotId;
        b = b.Xc;
        if (!m) return {
            Xc: b
        };
        this.j.set(c, h + 1);
        this.Y.add(m);
        _.qo(m, function() {
            return void f.Y.delete(m)
        });
        ZG(c);
        return {
            slotId: m,
            fb: a
        }
    };
    var TK = function(a, b) {
            a = _.x(a.Y);
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, c.getDomId() === b) return c
        },
        Bp = function(a) {
            a = _.x(a);
            for (var b = a.next(); !b.done; b = a.next()) b.value.Da()
        },
        NO = function(a, b, c, d, e, f, g) {
            var h = TK(a, g);
            if (h) return c.error(cJ(g, d, h.getAdUnitPath())), {
                Xc: !0
            };
            var k = new CK;
            DK(_.z(k, 1, d), g);
            EK(k, wm(f));
            pH(k);
            var l = new Ee(b, d, e, g);
            qK(l, Em(b, c, l));
            _.qo(l, function() {
                var m = vj(),
                    n = l.getDomId();
                delete m.o[n];
                m.m.delete(l);
                m = l.getAdUnitPath();
                m = Nh(m);
                var p;
                n = (null != (p = li.get(m)) ? p : 0) - 1;
                0 >= n ? li.delete(m) : li.set(m, n);
                c.info(CJ(l.toString()), l);
                (p = Mk.get(l)) && Nk.delete(p);
                Mk.delete(l)
            });
            c.info(RI(l.toString()), l);
            l.Z(uI, function(m) {
                m = m.detail.Ih;
                c.info(SI(l.getAdUnitPath()), l);
                nB(_.of(ai), "7", 9, II(a.M, l), 0, m)
            });
            l.Z(tI, function(m) {
                var n = m.detail;
                c.info(TI(l.getAdUnitPath()), l);
                var p;
                m = _.of(ai);
                var r = oi(k, 20);
                n = null != (p = n.getEscapedQemQueryId()) ? p : "";
                m.j && (_.q.google_timing_params = _.q.google_timing_params || {}, _.q.google_timing_params["qqid." + r] = n)
            });
            l.Z(Eq, function() {
                return void c.info(UI(l.getAdUnitPath()), l)
            });
            l.Z(Gq, function() {
                return void c.info(VI(l.getAdUnitPath()), l)
            });
            return {
                fb: k,
                slotId: l
            }
        },
        LO = function(a, b) {
            var c = new RegExp("(^|,|/)" + b + "($|,|/)");
            return [].concat(_.ve(a.Y)).some(function(d) {
                return c.test(Nh(d.getAdUnitPath()))
            })
        };
    var Ur = "1";
    (function(a, b) {
        var c = null != a ? a : {
            Na: Vr(),
            bb: "m202303210101",
            Eb: new _.Zr(0),
            Jf: !0,
            bf: 1
        };
        try {
            var d = $k();
            (0, B.yf)(!_.of(Oh).j);
            _.u(Object, "assign").call(Object, Ph, d._vars_);
            d._vars_ = Ph;
            if (d.evalScripts) d.evalScripts();
            else {
                MH();
                try {
                    $g()
                } catch (na) {
                    ci(c, 408, na)
                }
                tn();
                var e = new RL;
                try {
                    Wg(e.I), rf(13), rf(3)
                } catch (na) {
                    ci(c, 408, na)
                }
                var f = Xr(e),
                    g = null != a ? a : $r(f),
                    h = null != b ? b : new QL(g);
                Yh(g);
                Cj("gpt_fifwin", function(na) {
                    Ij(na, g)
                }, d.fifWin ? .01 : 0);
                var k = new AI,
                    l = new MO(k, e),
                    m = new cN(g),
                    n = _.Qh(260),
                    p = new KL(g, l, vj(), h, k, n, e, m),
                    r = Ax(),
                    t = aq(g),
                    w = new pI(g),
                    D = new pI(g),
                    F = new pI(g),
                    I;
                n && (I = LL(p, w));
                var S = _.Qh(221),
                    M = new fN,
                    R = new VM,
                    T, X, ka = null != (X = null == (T = I) ? void 0 : T.zb) ? X : new Rq,
                    ca;
                _.E(Yy) && (ca = _.Qh(150));
                var oa = new xO(g, l, h, k, m, r, e, w, n, S, M, R, ca, I, t, ka);
                _.E(Mz) && new UK(g, w, k, l);
                var la = vj().j;
                Sp(g, h, oa, la, l, D, F, e, R, ka);
                var va = Zh(g, 77, function() {
                    var na = d.cmd;
                    if (!na || Array.isArray(na)) {
                        var ya = new VK(h);
                        d.cmd = Qk(g, ya);
                        null != na && na.length && ya.push.apply(ya, na)
                    }
                });
                d.fifWin && "complete" !== document.readyState ? _.zb(window, "load", function() {
                    return window.setTimeout(va, 0)
                }) : va();
                yp();
                if (_.E(Mz) || _.of(ai).j) Tr(), il(document, _.E(Oz) ? _.A(HO) : _.A(IO));
                tq(g, h);
                dl(g)
            }
        } catch (na) {
            ci(c, 106, na)
        }
    })();
    var QO = function(a, b) {
        var c = this;
        this.m = a;
        this.j = !1;
        this.H = b;
        this.o = this.H.pa(264, function(d) {
            c.j && (OO || (d = Date.now()), c.m(d), OO ? PO.call(_.q, c.o) : _.q.setTimeout(c.o, 17))
        })
    };
    QO.prototype.start = function() {
        this.j || (this.j = !0, OO ? PO.call(_.q, this.o) : this.o(0))
    };
    QO.prototype.stop = function() {
        this.j = !1
    };
    var PO = _.q.requestAnimationFrame || _.q.webkitRequestAnimationFrame,
        OO = !!PO && !/'iPhone'/.test(_.q.navigator.userAgent);
    var RO = function(a, b, c, d) {
        this.o = a;
        this.ha = b;
        this.L = c;
        this.progress = 0;
        this.H = null;
        this.B = !1;
        this.j = [];
        this.m = null;
        this.l = new QO((0, _.Ps)(this.D, this), d)
    };
    RO.prototype.D = function(a) {
        if (this.B) this.l.stop();
        else {
            null === this.H && (this.H = a);
            this.progress = (a - this.H) / this.L;
            1 <= this.progress && (this.progress = 1);
            a = this.m ? this.m(this.progress) : this.progress;
            this.j = [];
            for (var b = 0; b < this.o.length; b++) this.j.push((this.ha[b] - this.o[b]) * a + this.o[b]);
            this.A();
            1 == this.progress && (this.l.stop(), this.I())
        }
    };
    RO.prototype.I = function() {};
    RO.prototype.A = function() {};
    _.SO = function(a) {
        a.B = !1;
        a.l.start()
    };
    RO.prototype.stop = function() {
        this.B = !0
    };
    _.TO = function(a) {
        return a * a * a
    };
    _.UO = function(a) {
        a = 1 - a;
        return 1 - a * a * a
    };
    _.VO = function(a, b, c, d, e, f, g, h) {
        RO.call(this, [b], [c], d, f);
        this.R = a;
        this.G = e;
        this.J = g ? g : null;
        this.m = h || null
    };
    _.L(_.VO, RO);
    _.VO.prototype.A = function() {
        var a = {};
        a[this.G] = this.j[0] + "px";
        _.$x(this.R, a)
    };
    _.VO.prototype.I = function() {
        this.J && this.J()
    };
}).call(this, {});