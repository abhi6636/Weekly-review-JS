(function(sttc) {
    var window = this;
    if (window.googletag && googletag.evalScripts) {
        googletag.evalScripts();
    }
    if (window.googletag && googletag._loaded_) return;
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var m, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        ea = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        q = {},
        fa = {},
        r = function(a, b, c) {
            if (!c || null != a) {
                c = fa[b];
                if (null == c) return a[b];
                c = a[c];
                return void 0 !== c ? c : a[b]
            }
        },
        u = function(a, b, c) {
            if (b) a: {
                var d = a.split(".");a = 1 === d.length;
                var e = d[0],
                    f;!a && e in q ? f = q : f = da;
                for (e = 0; e < d.length - 1; e++) {
                    var g = d[e];
                    if (!(g in f)) break a;
                    f = f[g]
                }
                d = d[d.length - 1];c = ea && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? ba(q, d, {
                    configurable: !0,
                    writable: !0,
                    value: b
                }) : b !== c && (void 0 === fa[d] && (a = 1E9 * Math.random() >>> 0, fa[d] = ea ? da.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, fa[d], {
                    configurable: !0,
                    writable: !0,
                    value: b
                })))
            }
        };
    u("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.h = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.h
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    u("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, q.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ha(aa(this))
                }
            })
        }
        return a
    }, "es6");
    var ha = function(a) {
            a = {
                next: a
            };
            a[r(q.Symbol, "iterator")] = function() {
                return this
            };
            return a
        },
        ja = function(a) {
            return a.raw = a
        },
        v = function(a) {
            var b = "undefined" != typeof q.Symbol && r(q.Symbol, "iterator") && a[r(q.Symbol, "iterator")];
            if (b) return b.call(a);
            if ("number" == typeof a.length) return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        w = function(a) {
            if (!(a instanceof Array)) {
                a = v(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        x = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ka = ea && "function" == typeof r(Object, "assign") ? r(Object, "assign") : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) x(d, e) && (a[e] = d[e])
            }
            return a
        };
    u("Object.assign", function(a) {
        return a || ka
    }, "es6");
    var la = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ma;
    if (ea && "function" == typeof Object.setPrototypeOf) ma = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                pa = {};
            try {
                pa.__proto__ = oa;
                na = pa.a;
                break a
            } catch (a) {}
            na = !1
        }
        ma = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var qa = ma,
        y = function(a, b) {
            a.prototype = la(b.prototype);
            a.prototype.constructor = a;
            if (qa) qa(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Ta = b.prototype
        },
        ra = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    u("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.h = (e += Math.random() + 1).toString();
                if (g) {
                    g = v(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!x(g, d)) {
                var k = new b;
                ba(g, d, {
                    value: k
                })
            }
            if (!x(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.h] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && x(g, d) ? g[d][this.h] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && x(g, d) && x(g[d], this.h)
        };
        f.prototype.delete = function(g) {
            return c(g) && x(g, d) && x(g[d], this.h) ? delete g[d][this.h] : !1
        };
        return f
    }, "es6");
    u("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(v([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = k.entries(),
                        n = l.next();
                    if (n.done || n.value[0] != h || "s" != n.value[1]) return !1;
                    n = l.next();
                    return n.done || 4 != n.value[0].x || "t" != n.value[1] || !l.next().done ? !1 : !0
                } catch (t) {
                    return !1
                }
            }()) return a;
        var b = new q.WeakMap,
            c = function(h) {
                this.i = {};
                this.h = f();
                this.size = 0;
                if (h) {
                    h = v(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this.i[l.id] = []);
            l.o ? l.o.value = k : (l.o = {
                next: this.h,
                C: this.h.C,
                head: this.h,
                key: h,
                value: k
            }, l.list.push(l.o), this.h.C.next = l.o, this.h.C = l.o, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.o && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.i[h.id], h.o.C.next = h.o.next, h.o.next.C = h.o.C, h.o.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this.i = {};
            this.h = this.h.C = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).o
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).o) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = this.entries(), n; !(n = l.next()).done;) n = n.value, h.call(k, n[1], n[0], this)
        };
        c.prototype[r(q.Symbol, "iterator")] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var n = h.i[l];
                if (n && x(h.i, l))
                    for (h = 0; h < n.length; h++) {
                        var t = n[h];
                        if (k !== k && t.key !== t.key || k === t.key) return {
                            id: l,
                            list: n,
                            index: h,
                            o: t
                        }
                    }
                return {
                    id: l,
                    list: n,
                    index: -1,
                    o: void 0
                }
            },
            e = function(h, k) {
                var l = h.h;
                return ha(function() {
                    if (l) {
                        for (; l.head != h.h;) l = l.C;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.C = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    var sa = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[r(q.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    u("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return sa(this, function(b) {
                return b
            })
        }
    }, "es6");
    u("Array.prototype.values", function(a) {
        return a ? a : function() {
            return sa(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    u("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(v([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.h = new q.Map;
            if (c) {
                c = v(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.h.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.h.set(c, c);
            this.size = this.h.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.h.delete(c);
            this.size = this.h.size;
            return c
        };
        b.prototype.clear = function() {
            this.h.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.h.has(c)
        };
        b.prototype.entries = function() {
            return this.h.entries()
        };
        b.prototype.values = function() {
            return r(this.h, "values").call(this.h)
        };
        b.prototype.keys = r(b.prototype, "values");
        b.prototype[r(q.Symbol, "iterator")] = r(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.h.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    var ta = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    u("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ta(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    u("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = ta(this, null, "repeat");
            if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    u("globalThis", function(a) {
        return a || da
    }, "es_2020");
    u("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = ta(this, null, "padStart");
            b -= d.length;
            c = void 0 !== c ? String(c) : " ";
            return (0 < b && c ? r(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    u("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    u("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || r(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    u("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== ta(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    var z = this || self,
        ua = function(a) {
            a = a.split(".");
            for (var b = z, c = 0; c < a.length; c++)
                if (b = b[a[c]], null == b) return null;
            return b
        },
        va = function(a, b) {
            a = a.split(".");
            var c = z;
            a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        };
    var wa = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        Ea = function(a) {
            if (!xa.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(ya, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(za, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Aa, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Ba, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Ca, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Da, "&#0;"));
            return a
        },
        ya = /&/g,
        za = /</g,
        Aa = />/g,
        Ba = /"/g,
        Ca = /'/g,
        Da = /\x00/g,
        xa = /[\x00&<>"']/,
        Ga = function(a, b) {
            var c = 0;
            a = wa(String(a)).split(".");
            b = wa(String(b)).split(".");
            for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
                var f = a[e] || "",
                    g = b[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    c = Fa(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Fa(0 == f[2].length, 0 == g[2].length) || Fa(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (0 == c)
            }
            return c
        },
        Fa = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var Ha, Ia = ua("CLOSURE_FLAGS"),
        Ja = Ia && Ia[610401301];
    Ha = null != Ja ? Ja : !1;

    function Ka() {
        var a = z.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var A, La = z.navigator;
    A = La ? La.userAgentData || null : null;

    function Ma(a) {
        return Ha ? A ? A.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function B(a) {
        return -1 != Ka().indexOf(a)
    };

    function Na() {
        return Ha ? !!A && 0 < A.brands.length : !1
    }

    function Oa() {
        return Na() ? Ma("Chromium") : (B("Chrome") || B("CriOS")) && !(Na() ? 0 : B("Edge")) || B("Silk")
    };
    var Pa = function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        },
        Qa = function(a, b) {
            return Array.prototype.filter.call(a, b, void 0)
        },
        Sa = function(a, b) {
            return Array.prototype.map.call(a, b, void 0)
        };

    function Ta(a, b) {
        a: {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Ua(a, b) {
        a: {
            for (var c = "string" === typeof a ? a.split("") : a, d = a.length - 1; 0 <= d; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Va(a, b) {
        return 0 <= Array.prototype.indexOf.call(a, b, void 0)
    };
    var Wa = function(a) {
        Wa[" "](a);
        return a
    };
    Wa[" "] = function() {};
    var Xa = Na() ? !1 : B("Trident") || B("MSIE");
    !B("Android") || Oa();
    Oa();
    B("Safari") && (Oa() || (Na() ? 0 : B("Coast")) || (Na() ? 0 : B("Opera")) || (Na() ? 0 : B("Edge")) || (Na() ? Ma("Microsoft Edge") : B("Edg/")) || Na() && Ma("Opera"));
    var Ya = {},
        Za = null,
        ab = function(a) {
            var b = [];
            $a(a, function(c) {
                b.push(c)
            });
            return b
        },
        $a = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        n = Za[l];
                    if (null != n) return n;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            bb();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        bb = function() {
            if (!Za) {
                Za = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    Ya[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === Za[f] && (Za[f] = e)
                    }
                }
            }
        };
    var cb = "undefined" !== typeof Uint8Array,
        eb = !Xa && "function" === typeof z.btoa;
    var C = "function" === typeof q.Symbol && "symbol" === typeof(0, q.Symbol)() ? (0, q.Symbol)() : void 0;

    function fb(a, b) {
        if (C) return a[C] |= b;
        if (void 0 !== a.h) return a.h |= b;
        Object.defineProperties(a, {
            h: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return b
    }

    function E(a) {
        var b;
        C ? b = a[C] : b = a.h;
        return null == b ? 0 : b
    }

    function F(a, b) {
        C ? a[C] = b : void 0 !== a.h ? a.h = b : Object.defineProperties(a, {
            h: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return a
    }

    function gb(a) {
        fb(a, 1);
        return a
    }

    function hb(a) {
        fb(a, 16);
        return a
    }

    function ib(a, b) {
        F(b, (a | 0) & -51)
    }

    function jb(a, b) {
        F(b, (a | 18) & -41)
    };
    var kb = {};

    function lb(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    var mb, nb = Object.freeze(F([], 23));

    function ob(a) {
        if (E(a.l) & 2) throw Error();
    }

    function pb(a) {
        var b = a.length;
        (b = b ? a[b - 1] : void 0) && lb(b) ? b.g = 1 : (b = {}, a.push((b.g = 1, b)))
    };

    function qb(a) {
        if (null == a) return a;
        switch (typeof a) {
            case "string":
                return +a;
            case "number":
                return a
        }
    }

    function rb(a) {
        return a
    }

    function sb(a) {
        return a
    }

    function tb(a, b) {
        var c = E(a),
            d = c;
        0 === d && (d |= b & 16);
        d |= b & 2;
        d !== c && F(a, d)
    }
    var ub = "function" === typeof q.Symbol && "symbol" === typeof(0, q.Symbol)() ? (0, q.Symbol)() : "di";
    var vb = function(a) {
            var b = a.i + a.D;
            return a.A || (a.A = a.l[b] = {})
        },
        G = function(a, b, c) {
            return -1 === b ? null : b >= a.i ? a.A ? a.A[b] : void 0 : c && a.A && (c = a.A[b], null != c) ? c : a.l[b + a.D]
        },
        I = function(a, b, c, d) {
            ob(a);
            return H(a, b, c, d)
        },
        H = function(a, b, c, d) {
            a.j && (a.j = void 0);
            if (b >= a.i || d) return vb(a)[b] = c, a;
            a.l[b + a.D] = c;
            (c = a.A) && b in c && delete c[b];
            return a
        };

    function wb(a, b, c, d) {
        var e = G(a, b);
        Array.isArray(e) || (e = nb);
        var f = E(e);
        f & 1 || gb(e);
        if (d) f & 2 || fb(e, 18), c & 1 || Object.freeze(e);
        else {
            d = !(c & 2);
            var g = f & 2;
            c & 1 || !g ? d && f & 16 && !g && (a = e, C ? a[C] && (a[C] &= -17) : void 0 !== a.h && (a.h &= -17)) : (e = gb(Array.prototype.slice.call(e)), H(a, b, e))
        }
        return e
    }
    var xb = function(a, b) {
        a = G(a, b);
        return J(null == a ? a : !!a, !1)
    };

    function zb(a, b, c, d) {
        if (null == c) return I(a, b, nb);
        var e = E(c);
        if (!(e & 4)) {
            if (e & 2 || Object.isFrozen(c)) c = Array.prototype.slice.call(c);
            for (var f = 0; f < c.length; f++) c[f] = d(c[f]);
            F(c, e | 5)
        }
        return I(a, b, c)
    }

    function K(a, b, c, d) {
        ob(a);
        c !== d ? H(a, b, c) : H(a, b, void 0, !1);
        return a
    }
    var Bb = function(a, b, c, d) {
            ob(a);
            (c = Ab(a, c)) && c !== b && null != d && H(a, c, void 0, !1);
            return H(a, b, d)
        },
        L = function(a, b, c) {
            return Ab(a, b) === c ? c : -1
        },
        Ab = function(a, b) {
            for (var c = 0, d = 0; d < b.length; d++) {
                var e = b[d];
                null != G(a, e) && (0 !== c && H(a, c, void 0, !1), c = e)
            }
            return c
        },
        Cb = function(a, b, c, d) {
            var e = G(a, c, d);
            var f = !1;
            null == e || "object" !== typeof e || (f = Array.isArray(e)) || e.T !== kb ? f ? (tb(e, E(a.l)), b = new b(e)) : b = void 0 : b = e;
            b !== e && null != b && H(a, c, b, d);
            return b
        },
        M = function(a, b, c) {
            var d = void 0 === d ? !1 : d;
            b = Cb(a, b, c, d);
            if (null == b) return b;
            if (!(E(a.l) & 2)) {
                var e = Db(b);
                e !== b && (b = e, H(a, c, b, d))
            }
            return b
        },
        N = function(a, b, c) {
            var d = E(a.l),
                e = !!(d & 2);
            var f = e ? 1 : 2;
            var g = !!(d & 2);
            a.h || (a.h = {});
            var h = a.h[c],
                k = wb(a, c, 3, g);
            if (h) 3 === f || g || ((g = Object.isFrozen(h), 1 !== f || g) ? 2 === f && g && (h = Array.prototype.slice.call(h), a.h[c] = h) : Object.freeze(h)), f = h;
            else {
                var l = k;
                h = [];
                g = !!(d & 2);
                k = !!(E(l) & 2);
                var n = l;
                !g && k && (l = Array.prototype.slice.call(l));
                var t = d | (k ? 2 : 0);
                d = k;
                for (var p = 0; p < l.length; p++) {
                    var D = l[p];
                    var db = b;
                    Array.isArray(D) ? (tb(D, t), D = new db(D)) : D = void 0;
                    void 0 !== D && (d || (d = !!(2 & E(D.l))), h.push(D))
                }
                a.h[c] = h;
                t = E(l);
                b = t | 33;
                b = d ? b & -9 : b | 8;
                t != b && (d = l, Object.isFrozen(d) && (d = Array.prototype.slice.call(d)), F(d, b), l = d);
                n !== l && H(a, c, l);
                (g || 1 === f && k) && fb(h, 18);
                (g || 1 === f) && Object.freeze(h);
                f = h
            }
            a = wb(a, c, 3, e);
            if (!(e || E(a) & 8)) {
                for (e = 0; e < f.length; e++) c = f[e], h = Db(c), c !== h && (f[e] = h, a[e] = h.l);
                fb(a, 8)
            }
            return f
        },
        Eb = function(a, b, c) {
            ob(a);
            null == c && (c = void 0);
            return H(a, b, c)
        },
        Fb = function(a, b, c, d) {
            ob(a);
            null == d && (d = void 0);
            return Bb(a, b, c, d)
        },
        Gb = function(a, b, c, d) {
            ob(a);
            var e = null == c ? nb : gb([]);
            if (null != c) {
                for (var f = !!c.length, g = 0; g < c.length; g++) {
                    var h = c[g];
                    f = f && !(E(h.l) & 2);
                    e[g] = h.l
                }
                f = (f ? 8 : 0) | 1;
                g = E(e);
                (g & f) !== f && (Object.isFrozen(e) && (e = Array.prototype.slice.call(e)), F(e, g | f));
                a.h || (a.h = {});
                a.h[b] = c
            } else a.h && (a.h[b] = void 0);
            return H(a, b, e, d)
        },
        Hb = function(a, b) {
            var c = !!(E(a.l) & 2),
                d = wb(a, b, 1, c),
                e = E(d);
            if (!(e & 4)) {
                Object.isFrozen(d) && (d = gb(d.slice()), H(a, b, d));
                for (var f = 0, g = 0; f < d.length; f++) {
                    var h = d[f];
                    null != h && (d[g++] = h)
                }
                g < f && (d.length = g);
                e |= 5;
                c && (e |= 18);
                F(d, e);
                e & 2 && Object.freeze(d)
            }!c && (e & 2 || Object.isFrozen(d)) && (d = Array.prototype.slice.call(d), fb(d, 5), H(a, b, d));
            return d
        };

    function J(a, b) {
        return null == a ? b : a
    }
    var Ib = function(a, b) {
            return J(G(a, b), "")
        },
        Jb = function(a, b) {
            var c = void 0 === c ? 0 : c;
            var d = G(a, b);
            var e = null == d ? d : "number" === typeof d || "NaN" === d || "Infinity" === d || "-Infinity" === d ? Number(d) : void 0;
            null != e && e !== d && H(a, b, e);
            return J(e, c)
        },
        O = function(a, b) {
            return J(G(a, b), 0)
        };
    var Kb;

    function Lb(a, b) {
        Kb = b;
        a = new a(b);
        Kb = void 0;
        return a
    };

    function Mb(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (0 !== (E(a) & 128)) return a = Array.prototype.slice.call(a), pb(a), a
                    } else if (cb && null != a && a instanceof Uint8Array) {
                    if (eb) {
                        for (var b = ""; 10240 < a.length;) b += String.fromCharCode.apply(null, a.subarray(0, 10240)), a = a.subarray(10240);
                        b += String.fromCharCode.apply(null, a);
                        a = btoa(b)
                    } else {
                        void 0 === b && (b = 0);
                        bb();
                        b = Ya[b];
                        for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                            var g = a[e],
                                h = a[e + 1],
                                k = a[e + 2],
                                l = b[g >> 2];
                            g = b[(g & 3) << 4 | h >> 4];
                            h = b[(h & 15) << 2 | k >> 6];
                            k = b[k & 63];
                            c[f++] = l + g + h + k
                        }
                        l = 0;
                        k = d;
                        switch (a.length - e) {
                            case 2:
                                l = a[e + 1], k = b[(l & 15) << 2] || d;
                            case 1:
                                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
                        }
                        a = c.join("")
                    }
                    return a
                }
        }
        return a
    };

    function Nb(a, b, c, d, e) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && E(a) & 1 ? void 0 : Ob(a, b, c, void 0 !== d, e);
            else if (lb(a)) {
                var f = {},
                    g;
                for (g in a) Object.prototype.hasOwnProperty.call(a, g) && (f[g] = Nb(a[g], b, c, d, e));
                a = f
            } else a = b(a, d);
            return a
        }
    }

    function Ob(a, b, c, d, e) {
        var f = E(a);
        d = d ? !!(f & 16) : void 0;
        a = Array.prototype.slice.call(a);
        for (var g = 0; g < a.length; g++) a[g] = Nb(a[g], b, c, d, e);
        c(f, a);
        return a
    }

    function Pb(a) {
        return a.T === kb ? a.toJSON() : Mb(a)
    }

    function Qb(a, b) {
        a & 128 && pb(b)
    };

    function Rb(a, b, c) {
        c = void 0 === c ? jb : c;
        if (null != a) {
            if (cb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = E(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return F(a, d | 18), a;
                a = Ob(a, Rb, d & 4 ? jb : c, !0, !1);
                b = E(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            return a.T === kb ? Sb(a) : a
        }
    }

    function Tb(a, b, c, d, e, f, g) {
        (a = a.h && a.h[c]) ? (d = E(a), d & 2 ? d = a : (f = Sa(a, Sb), jb(d, f), Object.freeze(f), d = f), Gb(b, c, d, e)) : I(b, c, Rb(d, f, g), e)
    }

    function Sb(a) {
        if (E(a.l) & 2) return a;
        a = Ub(a, !0);
        fb(a.l, 18);
        return a
    }

    function Ub(a, b) {
        var c = a.l,
            d = hb([]),
            e = a.constructor.messageId;
        e && d.push(e);
        e = a.A;
        if (e) {
            d.length = c.length;
            var f = {};
            d[d.length - 1] = f
        }
        0 !== (E(c) & 128) && pb(d);
        b = b || E(a.l) & 2 ? jb : ib;
        d = Lb(a.constructor, d);
        a.ka && (d.ka = a.ka.slice());
        f = !!(E(c) & 16);
        for (var g = e ? c.length - 1 : c.length, h = 0; h < g; h++) Tb(a, d, h - a.D, c[h], !1, f, b);
        if (e)
            for (var k in e) Tb(a, d, +k, e[k], !0, f, b);
        return d
    }

    function Db(a) {
        if (!(E(a.l) & 2)) return a;
        var b = Ub(a, !1);
        b.j = a;
        return b
    };
    var P = function(a, b, c, d) {
        null == a && (a = Kb);
        Kb = void 0;
        var e = this.constructor.messageId;
        if (null == a) {
            a = e ? [e] : [];
            var f = 48;
            var g = !0;
            d && (f |= 128);
            F(a, f)
        } else {
            if (!Array.isArray(a)) throw Error();
            if (e && e !== a[0]) throw Error();
            f = fb(a, 0) | 32;
            g = 0 !== (16 & f);
            if (d) {
                if (f |= 128, 0 < a.length) {
                    var h = a[a.length - 1];
                    if (lb(h) && "g" in h) {
                        delete h.g;
                        var k = !0,
                            l;
                        for (l in h) {
                            k = !1;
                            break
                        }
                        k && a.pop()
                    }
                }
            } else if (128 & f) throw Error();
            F(a, f)
        }
        this.D = e ? 0 : -1;
        this.h = void 0;
        this.l = a;
        a: {
            f = this.l.length;e = f - 1;
            if (f && (f = this.l[e], lb(f))) {
                this.A = f;
                this.i = e - this.D;
                break a
            }
            void 0 !== b && -1 < b ? (this.i = Math.max(b, e + 1 - this.D), this.A = void 0) : this.i = Number.MAX_VALUE
        }
        if (!d && this.A && "g" in this.A) throw Error('Unexpected "g" flag in sparse object of message that is not a group type.');
        if (c) {
            b = g && !0;
            d = this.i;
            var n;
            for (g = 0; g < c.length; g++) e = c[g], e < d ? (e += this.D, (f = a[e]) ? Vb(f, b) : a[e] = nb) : (n || (n = vb(this)), (f = n[e]) ? Vb(f, b) : n[e] = nb)
        }
    };
    P.prototype.toJSON = function() {
        var a = this.l,
            b;
        mb ? b = a : b = Ob(a, Pb, Qb, void 0, !1);
        return b
    };

    function Vb(a, b) {
        if (Array.isArray(a)) {
            var c = E(a),
                d = 1;
            !b || c & 2 || (d |= 16);
            (c & d) !== d && F(a, c | d)
        }
    }
    P.prototype.T = kb;

    function Wb(a, b) {
        return Mb(b)
    };
    var Xb = void 0;

    function Yb(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = Lb(a, hb(b))
            }
            return b
        }
    };
    var ac = function(a, b) {
        this.i = a === Zb && b || "";
        this.j = $b
    };
    ac.prototype.H = !0;
    ac.prototype.h = function() {
        return this.i
    };
    var bc = function(a) {
            return a instanceof ac && a.constructor === ac && a.j === $b ? a.i : "type_error:Const"
        },
        Q = function(a) {
            return new ac(Zb, a)
        },
        $b = {},
        Zb = {};
    var cc = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var dc = function(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    };

    function ec(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    var fc = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var R = function(a, b) {
        this.i = b === gc ? a : ""
    };
    R.prototype.toString = function() {
        return this.i + ""
    };
    R.prototype.H = !0;
    R.prototype.h = function() {
        return this.i.toString()
    };
    var kc = function(a, b) {
            a = hc.exec(ic(a).toString());
            var c = a[3] || "";
            return new R(a[1] + jc("?", a[2] || "", b) + jc("#", c), gc)
        },
        ic = function(a) {
            return a instanceof R && a.constructor === R ? a.i : "type_error:TrustedResourceUrl"
        },
        hc = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        lc = function(a) {
            for (var b = "", c = 0; c < a.length; c++) b += bc(a[c]);
            return new R(b, gc)
        },
        gc = {},
        jc = function(a, b, c) {
            if (null == c) return b;
            if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
            for (var d in c)
                if (Object.prototype.hasOwnProperty.call(c, d)) {
                    var e = c[d];
                    e = Array.isArray(e) ? e : [e];
                    for (var f = 0; f < e.length; f++) {
                        var g = e[f];
                        null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                    }
                }
            return b
        };
    var S = function(a, b) {
        this.i = b === mc ? a : ""
    };
    S.prototype.toString = function() {
        return this.i.toString()
    };
    S.prototype.H = !0;
    S.prototype.h = function() {
        return this.i.toString()
    };
    var nc = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
        oc = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        mc = {},
        pc = new S("about:invalid#zClosurez", mc);
    var qc = {},
        rc = function(a, b) {
            this.i = b === qc ? a : "";
            this.H = !0
        };
    rc.prototype.h = function() {
        return this.i.toString()
    };
    rc.prototype.toString = function() {
        return this.i.toString()
    };
    var sc = function(a) {
            return a instanceof rc && a.constructor === rc ? a.i : "type_error:SafeHtml"
        },
        tc = function(a) {
            return a instanceof rc ? a : new rc(Ea("object" == typeof a && a.H ? a.h() : String(a)), qc)
        },
        xc = function(a, b) {
            var c = {
                    src: a
                },
                d = {};
            a = {};
            for (var e in c) Object.prototype.hasOwnProperty.call(c, e) && (a[e] = c[e]);
            for (var f in d) Object.prototype.hasOwnProperty.call(d, f) && (a[f] = d[f]);
            if (b)
                for (var g in b)
                    if (Object.prototype.hasOwnProperty.call(b, g)) {
                        e = g.toLowerCase();
                        if (e in c) throw Error("");
                        e in d && delete a[e];
                        a[g] = b[g]
                    }
            var h;
            b = "";
            if (a)
                for (k in a)
                    if (Object.prototype.hasOwnProperty.call(a, k)) {
                        if (!uc.test(k)) throw Error("");
                        c = a[k];
                        if (null != c) {
                            g = k;
                            if (c instanceof ac) c = bc(c);
                            else {
                                if ("style" == g.toLowerCase()) throw Error("");
                                if (/^on/i.test(g)) throw Error("");
                                if (g.toLowerCase() in vc)
                                    if (c instanceof R) c = ic(c).toString();
                                    else if (c instanceof S) c = c instanceof S && c.constructor === S ? c.i : "type_error:SafeUrl";
                                else if ("string" === typeof c) c instanceof S || (c = "object" == typeof c && c.H ? c.h() : String(c), oc.test(c) ? c = new S(c, mc) : (c = String(c), c = c.replace(/(%0A|%0D)/g, ""), c = c.match(nc) ? new S(c, mc) : null)), c = (c || pc).h();
                                else throw Error("");
                            }
                            c.H && (c = c.h());
                            g = g + '="' + Ea(String(c)) + '"';
                            b += " " + g
                        }
                    }
            var k = "<script" + b;
            null == h ? h = [] : Array.isArray(h) || (h = [h]);
            !0 === fc.script ? k += ">" : (h = wc(h), k += ">" + sc(h).toString() + "\x3c/script>");
            return new rc(k, qc)
        },
        zc = function(a) {
            var b = tc(yc),
                c = [],
                d = function(e) {
                    Array.isArray(e) ? e.forEach(d) : (e = tc(e), c.push(sc(e).toString()))
                };
            a.forEach(d);
            return new rc(c.join(sc(b).toString()), qc)
        },
        wc = function(a) {
            return zc(Array.prototype.slice.call(arguments))
        },
        uc = /^[a-zA-Z0-9-]+$/,
        vc = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        yc = new rc(z.trustedTypes && z.trustedTypes.emptyHTML || "", qc);
    var Bc = function() {
            a: {
                var a = z.document;
                if (a.querySelector && (a = a.querySelector("script[nonce]")) && (a = a.nonce || a.getAttribute("nonce")) && Ac.test(a)) break a;a = ""
            }
            return a
        },
        Ac = /^[\w+/_-]+[=]{0,2}$/;
    var Cc = function() {
        return Ha && A ? !A.mobile && (B("iPad") || B("Android") || B("Silk")) : B("iPad") || B("Android") && !B("Mobile") || B("Silk")
    };
    var Dc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Ec = function(a) {
            return a ? decodeURI(a) : a
        },
        Fc = /#|$/,
        Gc = function(a, b) {
            var c = a.search(Fc);
            a: {
                var d = 0;
                for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                    var f = a.charCodeAt(d - 1);
                    if (38 == f || 63 == f)
                        if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                    d += e + 1
                }
                d = -1
            }
            if (0 > d) return null;
            e = a.indexOf("&", d);
            if (0 > e || e > c) e = c;
            d += b.length + 1;
            return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
        };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function Hc(a) {
        var b, c, d = null == (c = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : c.call(b, "script[nonce]");
        (b = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };

    function Ic(a, b) {
        a.write(sc(b))
    };
    var Jc = function(a) {
            try {
                var b;
                if (b = !!a && null != a.location.href) a: {
                    try {
                        Wa(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        },
        Kc = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = void 0 === c ? z : c;
            for (var d = 0; c && 40 > d++ && (!b && !Jc(c) || !a(c));) a: {
                try {
                    var e = c.parent;
                    if (e && e != c) {
                        c = e;
                        break a
                    }
                } catch (f) {}
                c = null
            }
        },
        Lc = function(a) {
            var b = a;
            Kc(function(c) {
                b = c;
                return !1
            });
            return b
        },
        Mc = function(a) {
            return Jc(a.top) ? a.top : null
        },
        Qc = function(a, b) {
            if (!Nc() && !Oc()) {
                var c = Math.random();
                if (c < b) return c = Pc(), a[Math.floor(c * a.length)]
            }
            return null
        },
        Pc = function() {
            if (!q.globalThis.crypto) return Math.random();
            try {
                var a = new Uint32Array(1);
                q.globalThis.crypto.getRandomValues(a);
                return a[0] / 65536 / 65536
            } catch (b) {
                return Math.random()
            }
        },
        Rc = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        },
        Sc = function(a) {
            var b = a.length;
            if (0 == b) return 0;
            for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
            return 0 < c ? c : 4294967296 + c
        },
        Oc = cc(function() {
            return Array.prototype.some.call(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Tc, void 0) || 1E-4 > Math.random()
        }),
        Nc = cc(function() {
            return Tc("MSIE")
        }),
        Tc = function(a) {
            return -1 != Ka().indexOf(a)
        },
        Uc = /^(-?[0-9.]{1,30})$/;

    function Vc(a) {
        if (!Uc.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }
    var Wc = cc(function() {
            return (Ha && A ? A.mobile : !Cc() && (B("iPod") || B("iPhone") || B("Android") || B("IEMobile"))) ? 2 : Cc() ? 1 : 0
        }),
        Xc = function(a) {
            if ("number" !== typeof a.goog_pvsid) try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Math.floor(Math.random() * Math.pow(2, 52)),
                    configurable: !1
                })
            } catch (b) {}
            return Number(a.goog_pvsid) || -1
        },
        Yc = function(a, b) {
            b = void 0 === b ? document : b;
            return b.createElement(String(a).toLowerCase())
        };

    function Zc(a) {
        var b = ra.apply(1, arguments);
        if (0 === b.length) return new R(a[0], gc);
        for (var c = [a[0]], d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
        return new R(c.join(""), gc)
    };
    var $c = {
        Ja: 0,
        Ia: 1,
        Fa: 2,
        Aa: 3,
        Ga: 4,
        Ba: 5,
        Ha: 6,
        Da: 7,
        Ea: 8,
        za: 9,
        Ca: 10
    };
    var ad = {
        La: 0,
        Ma: 1,
        Ka: 2
    };
    var bd = "a".charCodeAt(),
        cd = ec($c),
        dd = ec(ad);
    var ed = function(a) {
            if (/[^01]/.test(a)) throw Error("Input bitstring " + a + " is malformed!");
            this.i = a;
            this.h = 0
        },
        hd = function(a) {
            var b = T(a, 16);
            return !0 === !!T(a, 1) ? (a = fd(a), a.forEach(function(c) {
                if (c > b) throw Error("ID " + c + " is past MaxVendorId " + b + "!");
            }), a) : gd(a, b)
        },
        fd = function(a) {
            for (var b = T(a, 12), c = []; b--;) {
                var d = !0 === !!T(a, 1),
                    e = T(a, 16);
                if (d)
                    for (d = T(a, 16); e <= d; e++) c.push(e);
                else c.push(e)
            }
            c.sort(function(f, g) {
                return f - g
            });
            return c
        },
        gd = function(a, b, c) {
            for (var d = [], e = 0; e < b; e++)
                if (T(a, 1)) {
                    var f = e + 1;
                    if (c && -1 === c.indexOf(f)) throw Error("ID: " + f + " is outside of allowed values!");
                    d.push(f)
                }
            return d
        },
        T = function(a, b) {
            if (a.h + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
            var c = a.i.substring(a.h, a.h + b);
            a.h += b;
            return parseInt(c, 2)
        };
    var jd = function(a, b) {
            try {
                var c = ab(a.split(".")[0]).map(function(e) {
                        return (m = e.toString(2), r(m, "padStart")).call(m, 8, "0")
                    }).join(""),
                    d = new ed(c);
                c = {};
                c.tcString = a;
                c.gdprApplies = !0;
                d.h += 78;
                c.cmpId = T(d, 12);
                c.cmpVersion = T(d, 12);
                d.h += 30;
                c.tcfPolicyVersion = T(d, 6);
                c.isServiceSpecific = !!T(d, 1);
                c.useNonStandardStacks = !!T(d, 1);
                c.specialFeatureOptins = id(gd(d, 12, dd), dd);
                c.purpose = {
                    consents: id(gd(d, 24, cd), cd),
                    legitimateInterests: id(gd(d, 24, cd), cd)
                };
                c.purposeOneTreatment = !!T(d, 1);
                c.publisherCC = String.fromCharCode(bd + T(d, 6)) + String.fromCharCode(bd + T(d, 6));
                c.vendor = {
                    consents: id(hd(d), b),
                    legitimateInterests: id(hd(d), b)
                };
                return c
            } catch (e) {
                return null
            }
        },
        id = function(a, b) {
            var c = {};
            if (Array.isArray(b) && 0 !== b.length) {
                b = v(b);
                for (var d = b.next(); !d.done; d = b.next()) d = d.value, c[d] = -1 !== a.indexOf(d)
            } else
                for (a = v(a), d = a.next(); !d.done; d = a.next()) c[d.value] = !0;
            delete c[0];
            return c
        };

    function kd(a) {
        return JSON.stringify([a.map(function(b) {
            var c = {};
            return [(c[b.ma] = b.message.toJSON(), c)]
        })])
    };
    var ld = function(a, b) {
        if (q.globalThis.fetch) q.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var md = function(a) {
        P.call(this, a)
    };
    y(md, P);
    var nd = function(a, b) {
            return K(a, 1, b, 0)
        },
        od = function(a, b) {
            return K(a, 2, b, 0)
        };
    var pd = function(a) {
        P.call(this, a)
    };
    y(pd, P);
    var qd = [1, 2];
    var sd = function(a) {
        P.call(this, a, -1, rd)
    };
    y(sd, P);
    var td = function(a, b) {
            return Eb(a, 1, b)
        },
        ud = function(a, b) {
            return Gb(a, 2, b)
        },
        vd = function(a, b) {
            return zb(a, 4, b, rb)
        },
        wd = function(a, b) {
            return Gb(a, 5, b)
        },
        xd = function(a, b) {
            return K(a, 6, b, 0)
        },
        rd = [2, 4, 5];
    var zd = function(a) {
        P.call(this, a, -1, yd)
    };
    y(zd, P);
    var yd = [5],
        Ad = [1, 2, 3, 4];
    var Cd = function(a) {
        P.call(this, a, -1, Bd)
    };
    y(Cd, P);
    var Bd = [2, 3];
    var Dd = function(a) {
        P.call(this, a)
    };
    y(Dd, P);
    Dd.prototype.getTagSessionCorrelator = function() {
        return J(G(this, 2), 0)
    };
    var Fd = function(a) {
            var b = new Dd;
            return Fb(b, 4, Ed, a)
        },
        Ed = [4, 5, 7];
    var Hd = function(a) {
        P.call(this, a, -1, Gd)
    };
    y(Hd, P);
    var Gd = [3];
    var Jd = function(a) {
        P.call(this, a, -1, Id)
    };
    y(Jd, P);
    var Id = [4, 5];
    var Ld = function(a) {
        P.call(this, a, -1, Kd)
    };
    y(Ld, P);
    Ld.prototype.getTagSessionCorrelator = function() {
        return J(G(this, 1), 0)
    };
    var Kd = [2];
    var Md = function(a) {
        P.call(this, a)
    };
    y(Md, P);
    var Nd = [4];

    function Od(a) {
        a.la.apply(a, w(ra.apply(1, arguments).map(function(b) {
            return {
                ma: 2,
                message: b
            }
        })))
    }

    function Pd(a) {
        a.la.apply(a, w(ra.apply(1, arguments).map(function(b) {
            return {
                ma: 4,
                message: b
            }
        })))
    };
    var Qd = function() {
        this.j = this.j;
        this.m = this.m
    };
    Qd.prototype.j = !1;
    Qd.prototype.U = function() {
        if (this.m)
            for (; this.m.length;) this.m.shift()()
    };
    var Rd = function(a, b, c, d, e) {
            this.F = a;
            this.u = b;
            this.G = c;
            this.j = d;
            this.m = e;
            this.h = [];
            this.i = null
        },
        Sd = function(a) {
            null !== a.i && (clearTimeout(a.i), a.i = null);
            if (a.h.length) {
                var b = kd(a.h);
                a.u(a.F + "?e=1", b);
                a.h = []
            }
        };
    Rd.prototype.la = function() {
        var a = ra.apply(0, arguments),
            b = this;
        this.m && 65536 <= kd(this.h.concat(a)).length && Sd(this);
        this.h.push.apply(this.h, w(a));
        this.h.length >= this.j && Sd(this);
        this.h.length && null === this.i && (this.i = setTimeout(function() {
            Sd(b)
        }, this.G))
    };
    var Td = function(a, b, c) {
        Rd.call(this, "https://pagead2.googlesyndication.com/pagead/ping", ld, void 0 === a ? 1E3 : a, void 0 === b ? 100 : b, (void 0 === c ? !1 : c) && !!q.globalThis.fetch)
    };
    y(Td, Rd);
    var Ud = function(a) {
            this.h = a;
            this.defaultValue = !1
        },
        Vd = function(a) {
            this.h = a;
            this.defaultValue = 0
        };
    var Wd = new Ud(501898423),
        Xd = new Ud(427549339),
        Yd = new Vd(428094087),
        Zd = new Ud(494337909),
        $d = new Vd(24),
        ae = new function(a, b) {
            b = void 0 === b ? [] : b;
            this.h = a;
            this.defaultValue = b
        }(1934, ["Az6AfRvI8mo7yiW5fLfj04W21t0ig6aMsGYpIqMTaX60H+b0DkO1uDr+7BrzMcimWzv/X7SXR8jI+uvbV0IJlwYAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "A+USTya+tNvDPaxUgJooz+LaVk5hPoAxpLvSxjogX4Mk8awCTQ9iop6zJ9d5ldgU7WmHqBlnQB41LHHRFxoaBwoAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "A7FovoGr67TUBYbnY+Z0IKoJbbmRmB8fCyirUGHavNDtD91CiGyHHSA2hDG9r9T3NjUKFi6egL3RbgTwhhcVDwUAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ=="]),
        be = new Ud(203);
    var ce = function() {
        this.h = {}
    };
    var de = function(a) {
        P.call(this, a)
    };
    y(de, P);
    var ee = function(a) {
        P.call(this, a)
    };
    y(ee, P);
    var fe = function(a) {
        P.call(this, a)
    };
    y(fe, P);
    var ge = [8, 11, 12, 13, 15, 17, 18, 19, 20, 21, 22, 25, 26, 27];
    var he = function() {};
    var ie = function(a) {
        P.call(this, a)
    };
    y(ie, P);
    var je = function(a) {
        P.call(this, a)
    };
    y(je, P);
    var le = function(a) {
        P.call(this, a, -1, ke)
    };
    y(le, P);
    var me = Yb(le),
        ke = [7];
    var ne = function(a) {
        this.h = a || {
            cookie: ""
        }
    };
    ne.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.Ra;
            d = c.Sa || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.va
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.h.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    ne.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.h.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = wa(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    ne.prototype.isEmpty = function() {
        return !this.h.cookie
    };
    ne.prototype.clear = function() {
        for (var a = (this.h.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = wa(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) c = b[a], this.get(c), this.set(c, "", {
            va: 0,
            path: void 0,
            domain: void 0
        })
    };
    var oe = new function(a, b) {
        this.key = a;
        this.defaultValue = void 0 === b ? !1 : b;
        this.valueType = "boolean"
    }("45369554");
    var pe = function() {
            this.h = {};
            var a = z.__fcexpdef || "";
            try {
                var b = JSON.parse(a)[0];
                a = "";
                for (var c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
                this.h = JSON.parse(a)
            } catch (d) {}
        },
        qe;
    y(pe, ce);

    function re(a) {
        return (a = se(a)) ? M(a, je, 4) : null
    }

    function se(a) {
        if (a = (new ne(a)).get("FCCDCF", ""))
            if (r(a, "startsWith").call(a, "%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                te(1), b = null
            } else b = a;
            else b = null;
        try {
            return b ? me(b) : null
        } catch (c) {
            return te(2), null
        }
    }

    function te(a) {
        new he;
        var b = new de;
        a = I(b, 7, a);
        b = new ee;
        a = Eb(b, 1, a);
        b = new fe;
        Fb(b, 22, ge, a);
        qe || (qe = new pe);
        a = qe.h[oe.key];
        if ("proto" === oe.valueType) try {
            JSON.parse(a)
        } catch (c) {}
    };
    ec($c).map(function(a) {
        return Number(a)
    });
    ec(ad).map(function(a) {
        return Number(a)
    });
    var ue = function(a) {
            this.h = a;
            this.i = null
        },
        we = function(a) {
            a.__tcfapiPostMessageReady || ve(new ue(a))
        },
        ve = function(a) {
            a.i = function(b) {
                var c = "string" == typeof b.data;
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__tcfapiCall;
                !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.h.__tcfapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__tcfapiReturn = "removeEventListener" === e.command ? {
                        success: f,
                        callId: e.callId
                    } : {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                    return f
                }, e.parameter)
            };
            a.h.addEventListener("message", a.i);
            a.h.__tcfapiPostMessageReady = !0
        };
    var xe = function(a, b) {
        var c = a.document,
            d = function() {
                if (!a.frames[b])
                    if (c.body) {
                        var e = Yc("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var ye = function(a) {
            this.h = a;
            this.i = a.document;
            this.u = (a = (a = se(this.i)) ? M(a, ie, 5) || null : null) ? G(a, 2) : null;
            this.j = (a = re(this.i)) && null != G(a, 1) ? G(a, 1) : null;
            this.m = (a = re(this.i)) && null != G(a, 2) ? G(a, 2) : null
        },
        Be = function(a) {
            a.__uspapi || a.frames.__uspapiLocator || (a = new ye(a), ze(a), Ae(a))
        },
        ze = function(a) {
            !a.u || a.h.__uspapi || a.h.frames.__uspapiLocator || (a.h.__uspapiManager = "fc", xe(a.h, "__uspapiLocator"), va("__uspapi", function() {
                return a.G.apply(a, w(ra.apply(0, arguments)))
            }))
        };
    ye.prototype.G = function(a, b, c) {
        "function" === typeof c && "getUSPData" === a && c({
            version: 1,
            uspString: this.u
        }, !0)
    };
    var Ae = function(a) {
        !a.j || a.h.__tcfapi || a.h.frames.__tcfapiLocator || (a.h.__tcfapiManager = "fc", xe(a.h, "__tcfapiLocator"), a.h.__tcfapiEventListeners = a.h.__tcfapiEventListeners || [], va("__tcfapi", function() {
            return a.F.apply(a, w(ra.apply(0, arguments)))
        }), we(a.h))
    };
    ye.prototype.F = function(a, b, c, d) {
        d = void 0 === d ? null : d;
        if ("function" === typeof c)
            if (b && 2 !== b) c(null, !1);
            else switch (b = this.h.__tcfapiEventListeners, a) {
                case "getTCData":
                    !d || Array.isArray(d) && d.every(function(e) {
                        return "number" === typeof e
                    }) ? c(Ce(this, d, null), !0) : c(null, !1);
                    break;
                case "ping":
                    c({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.0",
                        cmpVersion: 1,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    a = b.push(c);
                    c(Ce(this, null, a - 1), !0);
                    break;
                case "removeEventListener":
                    b[d] ? (b[d] = null, c(!0)) : c(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    c(null, !1)
            }
    };
    var Ce = function(a, b, c) {
        if (!a.j) return null;
        b = jd(a.j, b);
        b.addtlConsent = null != a.m ? a.m : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    };
    var De = function(a) {
        return "string" === typeof a
    };
    var Ee = function(a, b) {
        var c = void 0 === c ? {} : c;
        this.error = a;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror";
        this.meta = c
    };
    var Fe = null,
        Ge = function() {
            if (null === Fe) {
                Fe = "";
                try {
                    var a = "";
                    try {
                        a = z.top.location.hash
                    } catch (c) {
                        a = z.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        Fe = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return Fe
        };
    var Ie = function(a) {
        P.call(this, a, -1, He)
    };
    y(Ie, P);
    var He = [2, 8],
        Je = [3, 4, 5],
        Ke = [6, 7];

    function Le(a) {
        return null != a ? !a : a
    }

    function Me(a, b) {
        for (var c = !1, d = 0; d < a.length; d++) {
            var e = a[d]();
            if (e === b) return e;
            null == e && (c = !0)
        }
        if (!c) return !b
    }

    function Ne(a, b) {
        var c = N(a, Ie, 2);
        if (!c.length) return Oe(a, b);
        a = O(a, 1);
        if (1 === a) return Le(Ne(c[0], b));
        c = Sa(c, function(d) {
            return function() {
                return Ne(d, b)
            }
        });
        switch (a) {
            case 2:
                return Me(c, !1);
            case 3:
                return Me(c, !0)
        }
    }

    function Oe(a, b) {
        var c = Ab(a, Je);
        a: {
            switch (c) {
                case 3:
                    var d = O(a, L(a, Je, 3));
                    break a;
                case 4:
                    d = O(a, L(a, Je, 4));
                    break a;
                case 5:
                    d = O(a, L(a, Je, 5));
                    break a
            }
            d = void 0
        }
        if (d && (b = (b = b[c]) && b[d])) {
            try {
                var e = b.apply(null, w(Hb(a, 8)))
            } catch (f) {
                return
            }
            b = O(a, 1);
            if (4 === b) return !!e;
            if (5 === b) return null != e;
            if (12 === b) a = Ib(a, L(a, Ke, 7));
            else a: {
                switch (c) {
                    case 4:
                        a = Jb(a, L(a, Ke, 6));
                        break a;
                    case 5:
                        a = Ib(a, L(a, Ke, 7));
                        break a
                }
                a = void 0
            }
            if (null != a) {
                if (6 === b) return e === a;
                if (9 === b) return null != e && 0 === Ga(String(e), a);
                if (null != e) switch (b) {
                    case 7:
                        return e < a;
                    case 8:
                        return e > a;
                    case 12:
                        return De(a) && De(e) && (new RegExp(a)).test(e);
                    case 10:
                        return null != e && -1 === Ga(String(e), a);
                    case 11:
                        return null != e && 1 === Ga(String(e), a)
                }
            }
        }
    }

    function Pe(a, b) {
        return !a || !(!b || !Ne(a, b))
    };
    var Re = function(a) {
        P.call(this, a, -1, Qe)
    };
    y(Re, P);
    var Qe = [4];
    var Se = function(a) {
        P.call(this, a)
    };
    y(Se, P);
    var Ue = function(a) {
        P.call(this, a, -1, Te)
    };
    y(Ue, P);
    var Ve = Yb(Ue),
        Te = [5],
        We = [1, 2, 3, 6, 7];
    var Xe = function(a, b, c) {
            var d = void 0 === d ? new Td(b) : d;
            this.u = a;
            this.m = c;
            this.i = d;
            this.h = [];
            this.j = 0 < a && Pc() < 1 / a
        },
        Ze = function(a, b, c, d, e, f) {
            if (a.j) {
                var g = od(nd(new md, b), c);
                b = xd(ud(td(wd(vd(new sd, d), e), g), a.h.slice()), f);
                b = Fd(b);
                Pd(a.i, Ye(a, b));
                if (1 === f || 3 === f || 4 === f && !a.h.some(function(h) {
                        return O(h, 1) === O(g, 1) && O(h, 2) === c
                    })) a.h.push(g), 100 < a.h.length && a.h.shift()
            }
        },
        $e = function(a, b, c, d) {
            if (a.j && a.m) {
                var e = new Cd;
                b = Gb(e, 2, b);
                c = Gb(b, 3, c);
                d && K(c, 1, d, 0);
                d = new Dd;
                d = Fb(d, 7, Ed, c);
                Pd(a.i, Ye(a, d))
            }
        },
        Ye = function(a, b) {
            b = K(b, 1, Date.now(), 0);
            var c = Xc(window);
            b = K(b, 2, c, 0);
            return K(b, 6, a.u, 0)
        };
    var U = function(a) {
        var b = "R";
        if (a.R && a.hasOwnProperty(b)) return a.R;
        b = new a;
        return a.R = b
    };
    var af = function() {
        var a = {};
        this.s = (a[3] = {}, a[4] = {}, a[5] = {}, a)
    };
    var bf = /^true$/.test("false");

    function cf(a, b) {
        switch (b) {
            case 1:
                return O(a, L(a, We, 1));
            case 2:
                return O(a, L(a, We, 2));
            case 3:
                return O(a, L(a, We, 3));
            case 6:
                return O(a, L(a, We, 6));
            default:
                return null
        }
    }

    function df(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return xb(a, 1);
            case 7:
                return Ib(a, 3);
            case 2:
                return Jb(a, 2);
            case 3:
                return Ib(a, 3);
            case 6:
                return Hb(a, 4);
            default:
                return null
        }
    }
    var ef = cc(function() {
        if (!bf) return {};
        try {
            var a = window.sessionStorage && window.sessionStorage.getItem("GGDFSSK");
            if (a) return JSON.parse(a)
        } catch (b) {}
        return {}
    });

    function ff(a, b, c, d) {
        var e = d = void 0 === d ? 0 : d,
            f, g;
        U(V).j[e] = null != (g = null == (f = U(V).j[e]) ? void 0 : f.add(b)) ? g : (new q.Set).add(b);
        e = ef();
        if (null != e[b]) return e[b];
        b = gf(d)[b];
        if (!b) return c;
        b = Ve(JSON.stringify(b));
        b = hf(b);
        a = df(b, a);
        return null != a ? a : c
    }

    function hf(a) {
        var b = U(af).s;
        if (b) {
            var c = Ua(N(a, Se, 5), function(f) {
                return Pe(M(f, Ie, 1), b)
            });
            if (c) {
                var d;
                return null != (d = M(c, Re, 2)) ? d : null
            }
        }
        var e;
        return null != (e = M(a, Re, 4)) ? e : null
    }
    var V = function() {
        this.i = {};
        this.m = [];
        this.j = {};
        this.h = new q.Map
    };

    function jf(a, b, c) {
        return !!ff(1, a, void 0 === b ? !1 : b, c)
    }

    function kf(a, b, c) {
        b = void 0 === b ? 0 : b;
        a = Number(ff(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function lf(a, b, c) {
        b = void 0 === b ? "" : b;
        a = ff(3, a, b, c);
        return "string" === typeof a ? a : b
    }

    function mf(a, b, c) {
        b = void 0 === b ? [] : b;
        a = ff(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function gf(a) {
        return U(V).i[a] || (U(V).i[a] = {})
    }

    function nf(a, b) {
        var c = gf(b);
        Rc(a, function(d, e) {
            return c[e] = d
        })
    }

    function of (a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = [],
            g = [];
        Pa(b, function(h) {
            var k = gf(h);
            Pa(a, function(l) {
                var n = Ab(l, We),
                    t = cf(l, n);
                if (t) {
                    var p, D, db;
                    var yb = null != (db = null == (p = U(V).h.get(h)) ? void 0 : null == (D = p.get(t)) ? void 0 : D.slice(0)) ? db : [];
                    a: {
                        p = new zd;
                        switch (n) {
                            case 1:
                                Bb(p, 1, Ad, t);
                                break;
                            case 2:
                                Bb(p, 2, Ad, t);
                                break;
                            case 3:
                                Bb(p, 3, Ad, t);
                                break;
                            case 6:
                                Bb(p, 4, Ad, t);
                                break;
                            default:
                                n = void 0;
                                break a
                        }
                        zb(p, 5, yb, rb);n = p
                    }
                    if (yb = n) {
                        var Ra;
                        yb = !(null == (Ra = U(V).j[h]) || !Ra.has(t))
                    }
                    yb && f.push(n);
                    if (Ra = n) {
                        var ia;
                        Ra = !(null == (ia = U(V).h.get(h)) || !ia.has(t))
                    }
                    Ra && g.push(n);
                    e || (ia = U(V), ia.h.has(h) || ia.h.set(h, new q.Map), ia.h.get(h).has(t) || ia.h.get(h).set(t, []), d && ia.h.get(h).get(t).push(d));
                    k[t] = l.toJSON()
                }
            })
        });
        (f.length || g.length) && $e(c, f, g, null != d ? d : void 0)
    }

    function pf(a, b) {
        var c = gf(b);
        Pa(a, function(d) {
            var e = Ve(JSON.stringify(d)),
                f = Ab(e, We);
            (e = cf(e, f)) && (c[e] || (c[e] = d))
        })
    }

    function qf() {
        return Sa(r(Object, "keys").call(Object, U(V).i), function(a) {
            return Number(a)
        })
    }

    function rf(a) {
        Va(U(V).m, a) || nf(gf(4), a)
    };

    function W(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function X(a, b, c) {
        return b[a] || c
    }

    function sf(a) {
        W(5, jf, a);
        W(6, kf, a);
        W(7, lf, a);
        W(8, mf, a);
        W(13, pf, a);
        W(15, rf, a)
    }

    function tf(a) {
        W(4, function(b) {
            U(af).s = b
        }, a);
        W(9, function(b, c) {
            var d = U(af);
            null == d.s[3][b] && (d.s[3][b] = c)
        }, a);
        W(10, function(b, c) {
            var d = U(af);
            null == d.s[4][b] && (d.s[4][b] = c)
        }, a);
        W(11, function(b, c) {
            var d = U(af);
            null == d.s[5][b] && (d.s[5][b] = c)
        }, a);
        W(14, function(b) {
            for (var c = U(af), d = v([3, 4, 5]), e = d.next(); !e.done; e = d.next()) e = e.value, r(Object, "assign").call(Object, c.s[e], b[e])
        }, a)
    }

    function uf(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };
    var vf = function() {};
    vf.prototype.i = function() {};
    vf.prototype.h = function() {
        return []
    };
    var wf = function(a, b, c) {
        a.i = function(d) {
            X(2, b, function() {
                return []
            })(d, c)
        };
        a.h = function() {
            return X(3, b, function() {
                return []
            })(c)
        }
    };

    function xf(a, b) {
        if (a.length && b.head) {
            a = v(a);
            for (var c = a.next(); !c.done; c = a.next())
                if ((c = c.value) && b.head) {
                    var d = Yc("META");
                    b.head.appendChild(d);
                    d.httpEquiv = "origin-trial";
                    d.content = c
                }
        }
    };

    function yf(a, b) {
        try {
            var c = a.split(".");
            a = z;
            for (var d = 0, e; null != a && d < c.length; d++) e = a, a = a[c[d]], "function" === typeof a && (a = e[c[d]]());
            var f = a;
            if (typeof f === b) return f
        } catch (g) {}
    }
    var zf = {},
        Af = {},
        Bf = {},
        Cf = {},
        Df = (Cf[3] = (zf[8] = function(a) {
            try {
                return null != ua(a)
            } catch (b) {}
        }, zf[9] = function(a) {
            try {
                var b = ua(a)
            } catch (c) {
                return
            }
            if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
            return a
        }, zf[10] = function() {
            return window === window.top
        }, zf[6] = function(a) {
            return Va(U(vf).h(), Number(a))
        }, zf[27] = function(a) {
            a = yf(a, "boolean");
            return void 0 !== a ? a : void 0
        }, zf[60] = function(a) {
            try {
                return !!z.document.querySelector(a)
            } catch (b) {}
        }, zf[69] = function(a) {
            var b = z.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(m = c.features(), r(m, "includes")).call(m, a))
        }, zf[70] = function(a) {
            var b = z.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(m = c.allowedFeatures(), r(m, "includes")).call(m, a))
        }, zf), Cf[4] = (Af[3] = function() {
            return Wc()
        }, Af[6] = function(a) {
            a = yf(a, "number");
            return void 0 !== a ? a : void 0
        }, Af), Cf[5] = (Bf[2] = function() {
            return window.location.href
        }, Bf[3] = function() {
            try {
                return window.top.location.hash
            } catch (a) {
                return ""
            }
        }, Bf[4] = function(a) {
            a = yf(a, "string");
            return void 0 !== a ? a : void 0
        }, Bf), Cf);

    function Ef() {
        var a = void 0 === a ? z : a;
        return a.ggeac || (a.ggeac = {})
    };
    var Gf = function(a) {
        P.call(this, a, -1, Ff)
    };
    y(Gf, P);
    Gf.prototype.getId = function() {
        return J(G(this, 1), 0)
    };
    var Ff = [2];
    var If = function(a) {
        P.call(this, a, -1, Hf)
    };
    y(If, P);
    var Hf = [2];
    var Kf = function(a) {
        P.call(this, a, -1, Jf)
    };
    y(Kf, P);
    var Jf = [2];
    var Lf = function(a) {
        P.call(this, a)
    };
    y(Lf, P);
    var Nf = function(a) {
        P.call(this, a, -1, Mf)
    };
    y(Nf, P);
    var Mf = [1, 4, 2, 3];
    var Of = [12, 13, 20],
        Pf = function(a, b, c, d) {
            var e = this,
                f = void 0 === d ? {} : d,
                g = void 0 === f.P ? !1 : f.P;
            d = void 0 === f.xa ? [] : f.xa;
            f = void 0 === f.I ? {} : f.I;
            this.B = c;
            this.j = a.slice();
            this.m = {};
            this.P = g;
            this.I = f;
            a = {};
            this.h = (a[b] = [], a[4] = [], a);
            this.i = {};
            (b = Ge()) && Pa(b.split(",") || [], function(h) {
                (h = Number(h)) && (e.i[h] = !0)
            });
            Pa(d, function(h) {
                e.i[h] = !0
            })
        },
        Tf = function(a, b, c) {
            var d = [],
                e = Qf(a.j, b),
                f;
            if (f = 9 !== b) a.m[b] ? f = !0 : (a.m[b] = !0, f = !1);
            if (f) return Ze(a.B, b, c, d, [], 4), d;
            if (!e.length) return Ze(a.B, b, c, d, [], 3), d;
            var g = Va(Of, b),
                h = [];
            Pa(e, function(k) {
                var l = new pd;
                if (k = Rf(a, k, c, l)) 0 !== Ab(l, qd) && h.push(l), l = k.getId(), d.push(l), Sf(a, l, g ? 4 : c), (k = N(k, Ue, 2)) && (g ? of (k, qf(), a.B, l) : of (k, [c], a.B, l))
            });
            Ze(a.B, b, c, d, h, 1);
            return d
        },
        Sf = function(a, b, c) {
            a.h[c] || (a.h[c] = []);
            a = a.h[c];
            Va(a, b) || a.push(b)
        },
        Uf = function(a, b) {
            a.j.push.apply(a.j, w(Qa(Sa(b, function(c) {
                return new Kf(c)
            }), function(c) {
                return !Va(Of, O(c, 1))
            })))
        },
        Rf = function(a, b, c, d) {
            var e = U(af).s;
            if (!Pe(M(b, Ie, 3), e)) return null;
            var f = N(b, Gf, 2),
                g = O(b, 6);
            if (g) {
                Bb(d, 1, qd, g);
                f = e[4];
                switch (c) {
                    case 2:
                        var h = f[8];
                        break;
                    case 1:
                        h = f[7]
                }
                c = void 0;
                if (h) try {
                    c = h(g), K(d, 3, c, 0)
                } catch (k) {}
                return (b = Vf(b, c)) ? Wf(a, [b], 1) : null
            }
            if (g = O(b, 10)) {
                Bb(d, 2, qd, g);
                h = null;
                switch (c) {
                    case 1:
                        h = e[4][9];
                        break;
                    case 2:
                        h = e[4][10];
                        break;
                    default:
                        return null
                }
                c = h ? h(String(g)) : void 0;
                if (void 0 === c && 1 === O(b, 11)) return null;
                void 0 !== c && K(d, 3, c, 0);
                return (b = Vf(b, c)) ? Wf(a, [b], 1) : null
            }
            d = e ? Qa(f, function(k) {
                return Pe(M(k, Ie, 3), e)
            }) : f;
            if (!d.length) return null;
            c = d.length * J(qb(G(b, 1)), 0);
            return (b = O(b, 4)) ? Xf(a, b, c, d) : Wf(a, d, c / 1E3)
        },
        Xf = function(a, b, c, d) {
            var e = null != a.I[b] ? a.I[b] : 1E3;
            if (0 >= e) return null;
            d = Wf(a, d, c / e);
            a.I[b] = d ? 0 : e - c;
            return d
        },
        Wf = function(a, b, c) {
            var d = a.i,
                e = Ta(b, function(f) {
                    return !!d[f.getId()]
                });
            return e ? e : a.P ? null : Qc(b, c)
        },
        Yf = function(a, b) {
            W(1, function(c) {
                a.i[c] = !0
            }, b);
            W(2, function(c, d) {
                return Tf(a, c, d)
            }, b);
            W(3, function(c) {
                return (a.h[c] || []).concat(a.h[4])
            }, b);
            W(12, function(c) {
                return void Uf(a, c)
            }, b);
            W(16, function(c, d) {
                return void Sf(a, c, d)
            }, b)
        };

    function Qf(a, b) {
        return (a = Ta(a, function(c) {
            return O(c, 1) === b
        })) && N(a, If, 2) || []
    }

    function Vf(a, b) {
        var c = N(a, Gf, 2),
            d = c.length,
            e = J(qb(G(a, 8)), 0);
        a = d * J(qb(G(a, 1)), 0) - 1;
        b = void 0 !== b ? b : Math.floor(1E3 * Pc());
        d = (b - e) % d;
        if (b < e || b - e - d >= a) return null;
        c = c[d];
        e = U(af).s;
        return !c || e && !Pe(M(c, Ie, 3), e) ? null : c
    };
    var Zf = function() {
        var a = {};
        this.i = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.h = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.u = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.j = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.m = function() {}
    };

    function $f(a) {
        return U(Zf).i(a.h, a.defaultValue)
    };
    var ag = function() {
            this.h = function() {}
        },
        bg = function(a, b) {
            a.h = X(14, b, function() {})
        };

    function cg(a) {
        U(ag).h(a)
    };
    var dg, eg, fg, gg, hg, ig;

    function jg(a) {
        var b = a.qa,
            c = a.s,
            d = a.Na,
            e = void 0 === a.na ? Ef() : a.na,
            f = void 0 === a.ha ? 0 : a.ha;
        a = void 0 === a.B ? new Xe(null != (gg = null == (dg = M(b, Lf, 5)) ? void 0 : J(G(dg, 2), 0)) ? gg : 0, null != (hg = null == (eg = M(b, Lf, 5)) ? void 0 : J(G(eg, 4), 0)) ? hg : 0, null != (ig = null == (fg = M(b, Lf, 5)) ? void 0 : xb(fg, 3)) ? ig : !1) : a.B;
        e.hasOwnProperty("init-done") ? (X(12, e, function() {})(Sa(N(b, Kf, 2), function(g) {
            return g.toJSON()
        })), X(13, e, function() {})(Sa(N(b, Ue, 1), function(g) {
            return g.toJSON()
        }), f), c && X(14, e, function() {})(c), kg(f, e)) : (Yf(new Pf(N(b, Kf, 2), f, a, d), e), sf(e), tf(e), uf(e), kg(f, e), of (N(b, Ue, 1), [f], a, void 0, !0), bf = bf || !(!d || !d.Oa), cg(Df), c && cg(c))
    }

    function kg(a, b) {
        var c = b = void 0 === b ? Ef() : b;
        wf(U(vf), c, a);
        lg(b, a);
        a = b;
        bg(U(ag), a);
        U(Zf).m()
    }

    function lg(a, b) {
        var c = U(Zf);
        c.i = function(d, e) {
            return X(5, a, function() {
                return !1
            })(d, e, b)
        };
        c.h = function(d, e) {
            return X(6, a, function() {
                return 0
            })(d, e, b)
        };
        c.u = function(d, e) {
            return X(7, a, function() {
                return ""
            })(d, e, b)
        };
        c.j = function(d, e) {
            return X(8, a, function() {
                return []
            })(d, e, b)
        };
        c.m = function() {
            X(15, a, function() {})(b)
        }
    };
    var mg = ja(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
        ng = function() {
            var a = void 0 === a ? "jserror" : a;
            var b = void 0 === b ? .01 : b;
            var c = void 0 === c ? Zc(mg) : c;
            this.j = a;
            this.i = b;
            this.h = c
        };

    function og(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = Yc("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Array.prototype.indexOf.call(g, e, void 0);
                    0 <= h && Array.prototype.splice.call(g, h, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, !1);
                e.removeEventListener && e.removeEventListener("error", f, !1)
            };
            dc(e, "load", f);
            dc(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }
    var qg = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=gpt_inv_ver";
            Rc(a, function(d, e) {
                if (d || 0 === d) c += "&" + e + "=" + encodeURIComponent("" + d)
            });
            pg(c, b)
        },
        pg = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : og(c, a, void 0 === b ? !1 : b, void 0 === d ? !1 : d)
        };
    var rg = Q("gpt/pubads_impl_"),
        sg = Q("pagead/managed/js/gpt/");

    function tg(a) {
        a = void 0 === a ? z : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    var ug = function(a, b) {
            b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
            2048 > b.length && b.push(a)
        },
        vg = function(a, b) {
            var c = tg(b);
            c && ug({
                label: a,
                type: 9,
                value: c
            }, b)
        },
        wg = function(a, b, c) {
            var d = !1;
            d = void 0 === d ? !1 : d;
            var e = window,
                f = "undefined" !== typeof queueMicrotask;
            return function() {
                d && f && queueMicrotask(function() {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                var g = tg(),
                    h = 3;
                try {
                    var k = b.apply(this, arguments)
                } catch (l) {
                    h = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    e.google_measure_js_timing && g && ug(r(Object, "assign").call(Object, {}, {
                        label: a.toString(),
                        value: g,
                        duration: (tg() || 0) - g,
                        type: h
                    }, d && f && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    }), e)
                }
                return k
            }
        },
        xg = function(a, b) {
            return wg(a, b, function(c, d) {
                var e = new ng;
                var f = void 0 === f ? e.i : f;
                var g = void 0 === g ? e.j : g;
                Math.random() > f || (d.error && d.meta && d.id || (d = new Ee(d, {
                    context: c,
                    id: g
                })), z.google_js_errors = z.google_js_errors || [], z.google_js_errors.push(d), z.error_rep_loaded || (f = z.document, c = Yc("SCRIPT", f), c.src = ic(e.h), Hc(c), (e = f.getElementsByTagName("script")[0]) && e.parentNode && e.parentNode.insertBefore(c, e), z.error_rep_loaded = !0))
            })
        };

    function Y(a, b) {
        return null == b ? "&" + a + "=null" : "&" + a + "=" + Math.floor(b)
    }

    function yg(a, b) {
        return "&" + a + "=" + b.toFixed(3)
    }

    function zg() {
        var a = new q.Set;
        var b = void 0 === b ? window : b;
        b = b.googletag;
        b = (null == b ? 0 : b.apiReady) ? b : void 0;
        try {
            if (!b) return a;
            for (var c = b.pubads(), d = v(c.getSlots()), e = d.next(); !e.done; e = d.next()) a.add(e.value.getSlotId().getDomId())
        } catch (f) {}
        return a
    }

    function Ag(a) {
        a = a.id;
        return null != a && (zg().has(a) || r(a, "startsWith").call(a, "google_ads_iframe_") || r(a, "startsWith").call(a, "aswift"))
    }

    function Bg(a, b, c) {
        if (!a.sources) return !1;
        switch (Cg(a)) {
            case 2:
                var d = Dg(a);
                if (d) return c.some(function(f) {
                    return Eg(d, f)
                });
            case 1:
                var e = Fg(a);
                if (e) return b.some(function(f) {
                    return Eg(e, f)
                })
        }
        return !1
    }

    function Cg(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(function(b) {
            return b.previousRect && b.currentRect
        });
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function Fg(a) {
        return Gg(a, function(b) {
            return b.currentRect
        })
    }

    function Dg(a) {
        return Gg(a, function(b) {
            return b.previousRect
        })
    }

    function Gg(a, b) {
        return a.sources.reduce(function(c, d) {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }
    var Hg = function() {
        Qd.call(this);
        this.i = this.h = this.L = this.K = this.G = 0;
        this.da = this.aa = Number.NEGATIVE_INFINITY;
        this.W = this.Y = this.Z = this.ba = this.ga = this.u = this.fa = this.O = 0;
        this.X = !1;
        this.M = this.J = this.F = 0;
        var a = document.querySelector("[data-google-query-id]");
        this.ea = a ? a.getAttribute("data-google-query-id") : null;
        this.N = null;
        this.ca = !1;
        this.V = function() {}
    };
    y(Hg, Qd);
    var Jg = function() {
        var a = new Hg;
        if ($f(be)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = v(["layout-shift", "largest-contentful-paint", "first-input", "longtask"]);
                for (var c = b.next(); !c.done; c = b.next()) c = c.value, a.B().observe({
                    type: c,
                    buffered: !0
                });
                Ig(a)
            }
        }
    };
    Hg.prototype.B = function() {
        var a = this;
        this.N || (this.N = new PerformanceObserver(xg(640, function(b) {
            var c = Kg !== window.scrollX || Lg !== window.scrollY ? [] : Mg,
                d = Ng();
            b = v(b.getEntries());
            for (var e = b.next(); !e.done; e = b.next()) switch (e = e.value, e.entryType) {
                case "layout-shift":
                    if (!e.hadRecentInput) {
                        a.G += Number(e.value);
                        Number(e.value) > a.K && (a.K = Number(e.value));
                        a.L += 1;
                        var f = Bg(e, c, d);
                        f && (a.u += e.value, a.ba++);
                        if (5E3 < e.startTime - a.aa || 1E3 < e.startTime - a.da) a.aa = e.startTime, a.h = 0, a.i = 0;
                        a.da = e.startTime;
                        a.h += e.value;
                        f && (a.i += e.value);
                        a.h > a.O && (a.O = a.h, a.ga = a.i, a.fa = e.startTime + e.duration)
                    }
                    break;
                case "largest-contentful-paint":
                    a.Z = Math.floor(e.renderTime || e.loadTime);
                    a.Y = e.size;
                    break;
                case "first-input":
                    a.W = Number((e.processingStart - e.startTime).toFixed(3));
                    a.X = !0;
                    break;
                case "longtask":
                    e = Math.max(0, e.duration - 50), a.F += e, a.J = Math.max(a.J, e), a.M += 1
            }
        })));
        return this.N
    };
    var Ig = function(a) {
        var b = xg(641, function() {
                var d = document;
                2 == (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && Og(a)
            }),
            c = xg(641, function() {
                return void Og(a)
            });
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.V = function() {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            a.B().disconnect()
        }
    };
    Hg.prototype.U = function() {
        Qd.prototype.U.call(this);
        this.V()
    };
    var Og = function(a) {
            if (!a.ca) {
                a.ca = !0;
                a.B().takeRecords();
                var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
                window.LayoutShift && (b += yg("cls", a.G), b += yg("mls", a.K), b += Y("nls", a.L), window.LayoutShiftAttribution && (b += yg("cas", a.u), b += Y("nas", a.ba)), b += yg("wls", a.O), b += yg("tls", a.fa), window.LayoutShiftAttribution && (b += yg("was", a.ga)));
                window.LargestContentfulPaint && (b += Y("lcp", a.Z), b += Y("lcps", a.Y));
                window.PerformanceEventTiming && a.X && (b += Y("fid", a.W));
                window.PerformanceLongTaskTiming && (b += Y("cbt", a.F), b += Y("mbt", a.J), b += Y("nlt", a.M));
                for (var c = 0, d = v(document.getElementsByTagName("iframe")), e = d.next(); !e.done; e = d.next()) Ag(e.value) && c++;
                b += Y("nif", c);
                c = window.google_unique_id;
                b += Y("ifi", "number" === typeof c ? c : 0);
                c = U(vf).h();
                b += "&eid=" + encodeURIComponent(c.join());
                b += "&top=" + (z === z.top ? 1 : 0);
                b += a.ea ? "&qqid=" + encodeURIComponent(a.ea) : Y("pvsid", Xc(z));
                window.googletag && (b += "&gpt=1");
                window.fetch(b, {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                });
                a.j || (a.j = !0, a.U())
            }
        },
        Eg = function(a, b) {
            var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
            a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
            return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
        },
        Ng = function() {
            var a = [].concat(w(document.getElementsByTagName("iframe"))).filter(Ag),
                b = [].concat(w(zg())).map(function(c) {
                    return document.getElementById(c)
                }).filter(function(c) {
                    return null !== c
                });
            Kg = window.scrollX;
            Lg = window.scrollY;
            return Mg = [].concat(w(a), w(b)).map(function(c) {
                return c.getBoundingClientRect()
            })
        },
        Kg = void 0,
        Lg = void 0,
        Mg = [];
    var Pg = function(a) {
        P.call(this, a)
    };
    y(Pg, P);
    Pg.prototype.getVersion = function() {
        return Ib(this, 2)
    };
    var Rg = function(a) {
        P.call(this, a, -1, Qg)
    };
    y(Rg, P);
    var Sg = function(a, b) {
            return I(a, 2, b)
        },
        Tg = function(a, b) {
            return I(a, 3, b)
        },
        Ug = function(a, b) {
            return I(a, 4, b)
        },
        Vg = function(a, b) {
            return I(a, 5, b)
        },
        Wg = function(a, b) {
            return I(a, 9, b)
        },
        Xg = function(a, b) {
            return Gb(a, 10, b)
        },
        Yg = function(a, b) {
            return I(a, 11, b)
        },
        Zg = function(a, b) {
            return I(a, 1, b)
        },
        $g = function(a, b) {
            return I(a, 7, b)
        },
        Qg = [10, 6];
    var ah = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function bh(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function ch(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function dh(a) {
        if (!ch(a)) return null;
        var b = bh(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(ah).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function eh(a) {
        var b;
        return Yg(Xg(Vg(Sg(Zg(Ug($g(Wg(Tg(new Rg, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new Pg;
            d = I(d, 1, c.brand);
            return I(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function fh(a) {
        var b, c;
        return null != (c = null == (b = dh(a)) ? void 0 : b.then(function(d) {
            return eh(d)
        })) ? c : null
    };
    var Z = {},
        gh = (Z[23] = .001, Z[253] = !1, Z[246] = [], Z[150] = "", Z[221] = /^true$/.test("false"), Z[36] = /^true$/.test(""), Z[172] = null, Z[260] = void 0, Z[251] = null, Z),
        hh = function() {
            this.h = !1
        };

    function ih(a) {
        U(hh).h = !0;
        return gh[a]
    }

    function jh(a, b) {
        U(hh).h = !0;
        gh[a] = b
    };
    var kh = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;

    function lh(a) {
        var b = a.ia,
            c = a.ta,
            d = a.sa,
            e = a.pa,
            f = b ? !kh.test(b.src) : !0;
        a = {};
        var g = {},
            h = {};
        return h[3] = (a[3] = function() {
            return !f
        }, a[59] = function() {
            var k = ra.apply(0, arguments),
                l = r(k, "includes"),
                n = String,
                t;
            var p = void 0 === p ? window : p;
            var D;
            p = null != (D = null == (t = Ec(p.location.href.match(Dc)[3] || null)) ? void 0 : t.split(".")) ? D : [];
            t = 2 > p.length ? null : "uk" === p[p.length - 1] ? 3 > p.length ? null : Sc(p.splice(p.length - 3).join(".")) : Sc(p.splice(p.length - 2).join("."));
            return l.call(k, n(t))
        }, a[61] = function() {
            return d
        }, a[63] = function() {
            return d || ".google.ch" === ih(150)
        }, a), h[4] = (g[1] = function() {
            return e
        }, g[4] = function() {
            return Vc("0") || 0
        }, g[12] = function() {
            if (b) {
                var k = RegExp("[?&]gmeid=([^&]*)").exec(b.src);
                var l;
                k = k ? null != (l = Vc(k[1])) ? l : -1 : -1
            } else k = -1;
            return k
        }, g[13] = function() {
            return c || 0
        }, g), h[5] = {}, h
    };

    function mh(a, b) {
        var c = new Nf(ih(246));
        if (!N(c, Ue, 1).length && N(a, Ue, 1).length) {
            var d = N(a, Ue, 1);
            Gb(c, 1, d)
        }!N(c, Kf, 2).length && N(a, Kf, 2).length && (d = N(a, Kf, 2), Gb(c, 2, d));
        void 0 === Cb(c, Lf, 5, !1) && void 0 !== Cb(a, Lf, 5, !1) && (a = M(a, Lf, 5), Eb(c, 5, a));
        jg({
            qa: c,
            s: lh(b),
            ha: 2
        })
    };

    function nh(a, b, c, d, e) {
        a = a.location.host;
        var f = Gc(b.src, "domain");
        b = Gc(b.src, "network-code");
        if (a || f || b) {
            var g = {};
            a && (g.ippd = a);
            f && (g.pppd = f);
            b && (g.pppnc = b);
            a = g
        } else a = void 0;
        a ? (c = kc(lc([c ? Q("https://pagead2.googlesyndication.com") : Q("https://securepubads.g.doubleclick.net"), Q("/pagead/ppub_config")]), a), oh(c, d, e)) : e(new q.globalThis.Error("no provided or inferred data"))
    }

    function oh(a, b, c) {
        var d = new q.globalThis.XMLHttpRequest;
        d.open("GET", a.toString(), !0);
        d.withCredentials = !1;
        d.onload = function() {
            300 > d.status ? (vg("13", window), b(204 === d.status ? "" : d.responseText)) : c(new q.globalThis.Error("resp:" + d.status))
        };
        d.onerror = function() {
            return void c(new q.globalThis.Error("s:" + d.status + " rs:" + d.readyState))
        };
        d.send()
    };
    var ph = function() {
            this.h = []
        },
        sh = function(a, b, c, d) {
            Lc(b) === Mc(b) && c && (qh(a), nh(b.top, c, d, function(e) {
                return void rh(a, e)
            }, function(e) {
                rh(a, void 0, e)
            }))
        },
        qh = function(a) {
            ih(260);
            jh(260, function(b) {
                void 0 !== a.i || a.j ? b(a.i, a.j) : a.h.push(b)
            })
        },
        rh = function(a, b, c) {
            a.i = b;
            a.j = c;
            for (var d = v(a.h), e = d.next(); !e.done; e = d.next()) e = e.value, e(b, c);
            a.h.length = 0
        };

    function th() {
        var a;
        return null != (a = z.googletag) ? a : z.googletag = {
            cmd: []
        }
    }

    function uh(a, b) {
        var c = th();
        c.hasOwnProperty(a) || (c[a] = b)
    };
    var wh = function() {
            return [].concat(w(r(vh, "values").call(vh))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        vh = new q.Map;

    function xh(a, b, c) {
        if (a.ya) {
            c = c.error && c.meta && c.id ? c.error : c;
            var d = new Md,
                e = new Ld;
            try {
                var f = Xc(window);
                K(e, 1, f, 0)
            } catch (p) {}
            try {
                var g = U(vf).h();
                zb(e, 2, g, rb)
            } catch (p) {}
            try {
                K(e, 3, window.document.URL, "")
            } catch (p) {}
            f = Eb(d, 2, e);
            g = new Jd;
            b = K(g, 1, b, 0);
            try {
                var h = De(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                K(b, 2, h, "")
            } catch (p) {}
            try {
                var k = De(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                K(b, 3, k, "")
            } catch (p) {}
            try {
                var l = De(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && zb(b, 4, l.split(/\n\s*/), sb)
            } catch (p) {}
            h = Eb(f, 1, b);
            k = new Hd;
            try {
                K(k, 1, a.S || a.ra, "")
            } catch (p) {}
            try {
                var n = wh();
                K(k, 2, n, 0)
            } catch (p) {}
            try {
                var t = [].concat(w(r(vh, "keys").call(vh)));
                zb(k, 3, t, sb)
            } catch (p) {}
            Fb(h, 4, Nd, k);
            K(h, 5, a.oa, 0);
            Od(a.wa, h)
        }
    };

    function yh() {
        var a = zh,
            b = Ah(),
            c = Bh,
            d = {
                sa: xb(Ch, 5),
                ta: J(G(Ch, 2), 0),
                pa: J(G(Ch, 7), 0)
            },
            e, f = null != (e = a.fifWin) ? e : window,
            g = f.document;
        e = a.fifWin ? window : f;
        uh("_loaded_", !0);
        var h = Dh(c);
        uh("cmd", []);
        var k;
        c = null != (k = Eh(g)) ? k : Fh(g);
        Gh(b, f, r(Object, "assign").call(Object, {}, {
            ia: c
        }, d));
        try {
            Jg()
        } catch (D) {}
        vg("1", f);
        b = Hh(h, c);
        d = !1;
        if (!Ih(g)) {
            f = "gpt-impl-" + Math.random();
            try {
                Ic(g, xc(b, {
                    id: f,
                    nonce: Bc()
                }))
            } catch (D) {}
            g.getElementById(f) && ($f(Wd) ? d = !0 : a._loadStarted_ = !0)
        }
        if ($f(Wd) ? !d : !a._loadStarted_) {
            var l = Yc("SCRIPT");
            l.src = ic(b);
            Hc(l);
            l.async = !0;
            g = a.fifWin ? e.document : g;
            b = g.body;
            d = g.documentElement;
            var n, t, p = null != (t = null != (n = g.head) ? n : b) ? t : d;
            "complete" !== e.document.readyState && a.fifWin ? dc(e, "load", function() {
                return void p.appendChild(l)
            }) : p.appendChild(l);
            $f(Wd) || (a._loadStarted_ = !0)
        }
        e === e.top && Be(e);
        sh(new ph, e, c, Jh(c))
    }

    function Kh() {
        var a = Number("2019072601");
        1 > a || Math.floor(a) !== a ? (qg({
            v: "2019072601"
        }), a = "1") : a = "2019072601";
        return {
            ra: a,
            S: "m202303210101",
            wa: new Td,
            ya: .01 > Pc(),
            oa: 100
        }
    }

    function Dh(a) {
        var b = Q("2019072601");
        var c = a.S;
        /m\d+/.test(c) ? c = Number(c.substring(1)) : (c && qg({
            mjsv: c
        }), c = void 0);
        return r(Object, "assign").call(Object, {}, a, {
            ja: b,
            Pa: c,
            ua: Q("m202303210101"),
            Qa: Xc(window)
        })
    }

    function Eh(a) {
        return (a = a.currentScript) ? a : null
    }

    function Fh(a) {
        var b;
        a = v(null != (b = a.scripts) ? b : []);
        for (b = a.next(); !b.done; b = a.next())
            if (b = b.value, r(b.src, "includes").call(b.src, "/tag/js/gpt")) return b;
        return null
    }

    function Hh(a, b) {
        b = Jh(b) ? Q("https://pagead2.googlesyndication.com/") : Q("https://securepubads.g.doubleclick.net/");
        a = a.S ? lc([b, sg, a.ua, Q("/pubads_impl.js")]) : $f(Xd) ? lc([b, sg, Q("m"), a.ja, Q("/pubads_impl.js")]) : lc([b, rg, a.ja, Q(".js")]);
        b = {};
        var c = U(Zf).h($d.h, $d.defaultValue),
            d = U(Zf).h(Yd.h, Yd.defaultValue);
        c && (b.cb = c);
        d && (b.mcb = d);
        return r(Object, "keys").call(Object, b).length ? kc(a, b) : a
    }

    function Gh(a, b, c) {
        jh(172, c.ia);
        mh(a, c);
        U(vf).i(12);
        U(vf).i(5);
        $f(Zd) || (a = fh(b)) && a.then(function(d) {
            a: {
                mb = !0;
                try {
                    var e = JSON.stringify(d.toJSON(), Wb);
                    break a
                } finally {
                    mb = !1
                }
                e = void 0
            }
            return void jh(251, e)
        });
        xf(U(Zf).j(ae.h, ae.defaultValue), b.document)
    }

    function Ih(a) {
        var b = Eh(a);
        return "complete" === a.readyState || "loaded" === a.readyState || !(null == b || !b.async)
    }

    function Jh(a) {
        return !(null == a || !a.src) && "pagead2.googlesyndication.com" === Ec(a.src.match(Dc)[3] || null)
    };
    var Lh = function(a) {
        P.call(this, a)
    };
    y(Lh, P);
    var Ah = function() {
            var a = Cb(Ch, Nf, 1, !1);
            a || (a = Nf[ub], a || (a = new Nf, fb(a.l, 18), a = Nf[ub] = a));
            return a
        },
        Mh = Yb(Lh);
    var Nh = "undefined" === typeof sttc ? void 0 : sttc;
    try {
        var zh = th(),
            Bh = Kh(),
            Oh;
        var Ph = Bh;
        try {
            var Qh = Xb;
            Xb = void 0;
            if (!De(Nh)) {
                var Rh = Qh ? Qh() + "\n" : "";
                throw Error(Rh + String(Nh));
            }
            Oh = Mh(Nh)
        } catch (a) {
            xh(Ph, 838, a), Oh = new Lh
        }
        var Ch = Oh,
            Sh = zh,
            Th = Ch,
            Uh = !U(hh).h,
            Vh = Xb;
        Xb = void 0;
        if (!Uh) {
            if (Vh) throw Error(Vh());
            throw Error(String(Uh));
        }
        r(Object, "assign").call(Object, gh, Sh._vars_);
        Sh._vars_ = gh;
        Th && (xb(Th, 3) && jh(36, !0), xb(Th, 5) && jh(221, !0), Ib(Th, 6) && jh(150, Ib(Th, 6)));
        yh()
    } catch (a) {
        try {
            xh(Kh(), 420, a)
        } catch (b) {}
    };
}).call(this.googletag && googletag.fifWin ? googletag.fifWin.parent : this, "[[[[483374575,null,null,[1]],[null,472785970,null,[null,500]],[null,7,null,[null,0.1]],[514499457,null,null,[1]],[null,448338836,null,[null,0.01]],[null,427198696,null,[null,1]],[510178293,null,null,[1]],[477812799,null,null,[1]],[514091619,null,null,[1]],[null,408380992,null,[null,0.01]],[null,377289019,null,[null,10000]],[null,529,null,[null,20]],[492198798,null,null,[1]],[null,447000223,null,[null,0.01]],[360245597,null,null,[1]],[514858268,null,null,[1]],[null,492,null,[null,0.01]],[437061931,null,null,[1]],[null,398776877,null,[null,60000]],[null,374201269,null,[null,60000]],[null,371364213,null,[null,60000]],[null,376149757,null,[null,0.0025]],[377936516,null,null,[1]],[512710196,null,null,[1]],[null,null,2,[null,null,\"1-0-40\"]],[null,506394061,null,[null,100]],[510521772,null,null,[1]],[null,null,null,[],null,489],[392065905,null,null,null,[[[4,null,68],[1]]]],[null,360245595,null,[null,500]],[null,397316938,null,[null,1000]],[512195429,null,null,[1]],[503991213,null,null,[1]],[null,null,null,[],null,489560439],[null,null,null,[],null,505762507],[null,1921,null,[null,72]],[null,1920,null,[null,12]],[null,426169222,null,[null,1000]],[null,1917,null,[null,300]],[null,1916,null,[null,0.001]],[null,null,null,[null,null,null,[\"A0VQgOQvA+kwCj319NCwgf8+syUgEQ8\/LLpB8RxxlRC3AkJ9xx8IAvVuQ\/dcwy0ok7sGKufLLu6WhsXbQR9\/UwwAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjg4MDgzMTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A6kRo9zXJhOvsR4D\/VeZ9CiApPAxnOGzBkW88d8eIt9ex2oOzlX+AoUk\/BS50Y9Ysy2jwyHR49Mb7XwP+l9yygIAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjg4MDgzMTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A3mbHZoS4VJtJ8j1aE8+Z9vaGf\/oMV1eTNIWMrvGqWgNnOmvaxnRGliqKIZU2eiTzCj5Qpz8B1\/UTTLuony5bAAAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjg4MDgzMTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ\/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX\/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\"]],null,1934],[1957,null,null,[1]],[1971,null,null,[1]],[1975,null,null,[1]],[1974,null,null,[1]],[null,1972,null,[]],[null,501545963,null,[null,1]],[null,1119,null,[null,300]],[null,1193,null,[null,100]],[null,501545962,null,[null,1]],[null,495583959,null,[null,-1]],[null,1116,null,[null,300]],[1203,null,null,[1]],[471262996,null,null,[1]],[469675169,null,null,[1]],[485990406,null,null,[]],[501411886,null,null,[1]]],[[3,[[null,[[1337,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]],[84,null,null,[1]],[188,null,null,[1]]]]]],[1,[[31070955],[31070956],[31070957,[[null,514795754,null,[null,1]]]],[31072833],[31072834,[[null,514795754,null,[null,1]]]],[31072835],[31072836,[[null,514795754,null,[null,1]]]],[31072837],[31072838,[[null,514795754,null,[null,1]]]]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!110)\\\\d{3,})\",[\"navigator.userAgent\"]],[1,[[4,null,63]]]]],59],[10,[[31071432],[31071433]]],[50,[[31073114],[31073115,[[507033477,null,null,[1]]]]]],[50,[[31073203],[31073204,[[45397804,null,null,[1]],[45398607,null,null,[1]]]]]],[100,[[44785728],[44785729,[[491464096,null,null,[1]]]]]],[null,[[44787108]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!110)\\\\d{3,})\",[\"navigator.userAgent\"]],[1,[[4,null,63]]]]],59],[null,[[676982960],[676982998]]]]],[5,[[50,[[21062785,null,[4,null,8,null,null,null,null,[\"_gmptnl\"]]],[21062786,[[23,null,null,[1]]],[4,null,8,null,null,null,null,[\"_gmptnl\"]]]],[12,null,null,null,2,null,\"today\\\\.line\\\\.me\/.+\/(main|article)\"],43],[900,[[21062812,[[23,null,null,[1]]],[4,null,8,null,null,null,null,[\"_gmptnl\"]]]],[12,null,null,null,2,null,\"today\\\\.line\\\\.me\/.+\/(main|article)\"],43],[50,[[21063916,null,[4,null,8,null,null,null,null,[\"webkit.messageHandlers._gmptnl\"]]],[21063917,[[23,null,null,[1]]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers._gmptnl\"]]]],[12,null,null,null,2,null,\"today\\\\.line\\\\.me\/.+\/(main|article)\"],44],[900,[[21064113,[[23,null,null,[1]]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers._gmptnl\"]]]],[12,null,null,null,2,null,\"today\\\\.line\\\\.me\/.+\/(main|article)\"],44],[50,[[31067420],[31067421,[[360245597,null,null,[]]]],[44776073],[44776367],[44779108],[44779905],[44784467],[44785148]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[31071499,[[499996722,null,null,[1]]]],[31071500,[[485209195,null,null,[1]],[499996722,null,null,[1]]]]]],[1,[[31071991],[31071992,[[501898423,null,null,[1]]]]]],[100,[[31072019],[31072020,[[471855283,null,null,[1]]]]]],[100,[[31072028],[31072029,[[503331120,null,null,[1]]]]]],[100,[[31072878],[31072879,[[494337909,null,null,[1]]]]]],[100,[[31073288],[31073289,[[478009624,null,null,[1]]]]]],[1000,[[31073294,null,[2,[[2,[[8,null,null,1,null,0],[7,null,null,1,null,11]]],[4,null,3]]]],[31073295,null,[2,[[2,[[8,null,null,1,null,10],[7,null,null,1,null,21]]],[4,null,3]]]]]],[50,[[31073318],[31073319,[[489217043,null,null,[1]]]],[31073320,[[495013820,null,null,[1]]]]]],[1000,[[31073327,[[null,24,null,[null,31073327]]],[6,null,null,13,null,31073327]],[31073328,[[null,24,null,[null,31073328]]],[6,null,null,13,null,31073328]]],[4,null,3],1],[1000,[[31073370,[[null,24,null,[null,31073370]]],[6,null,null,13,null,31073370]],[31073371,[[null,24,null,[null,31073371]]],[6,null,null,13,null,31073371]]],[4,null,3],1],[100,[[31073380],[31073381,[[516945042,null,null,[1]]]]]],[1000,[[31073384,null,[3,[[2,[[2,[[8,null,null,1,null,0],[7,null,null,1,null,6]]],[4,null,3]]],[2,[[2,[[8,null,null,1,null,10],[7,null,null,1,null,16]]],[4,null,3]]],[2,[[2,[[8,null,null,1,null,20],[7,null,null,1,null,35]]],[4,null,3]]]]]],[31073385,[[514876375,null,null,[1]]],[3,[[2,[[2,[[8,null,null,1,null,5],[7,null,null,1,null,11]]],[4,null,3]]],[2,[[2,[[8,null,null,1,null,15],[7,null,null,1,null,21]]],[4,null,3]]],[2,[[2,[[8,null,null,1,null,34],[7,null,null,1,null,49]]],[4,null,3]]]]]]]],[1000,[[31073450,[[null,24,null,[null,31073450]]],[6,null,null,4,null,4]],[31073451,[[null,24,null,[null,31073451]]],[6,null,null,4,null,5]]],[4,null,3],1],[10,[[31073459],[31073460,[[513922122,null,null,[1]]]]]],[10,[[31073461],[31073462,[[492026992,null,null,[1]]]]]],[10,[[44776366],[44779256]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69]]],[12,[[40,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61],[10,[[44769661],[44769662,[[1973,null,null,[1]]]]]]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[1000,[[31067146,null,[4,null,9,null,null,null,null,[\"document.browsingTopics\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067147,null,[2,[[4,null,9,null,null,null,null,[\"navigator.runAdAuction\"]],[4,null,9,null,null,null,null,[\"navigator.joinAdInterestGroup\"]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067148,null,[4,null,69,null,null,null,null,[\"attribution-reporting\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067672,null,[2,[[4,null,69,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,70,null,null,null,null,[\"browsing-topics\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067673,null,[2,[[4,null,69,null,null,null,null,[\"join-ad-interest-group\"]],[1,[[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067674,null,[2,[[4,null,69,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067675,null,[2,[[4,null,69,null,null,null,null,[\"attribution-reporting\"]],[1,[[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31068556,null,[4,null,8,null,null,null,null,[\"sharedStorage\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31068557,null,[2,[[4,null,69,null,null,null,null,[\"shared-storage\"]],[1,[[4,null,70,null,null,null,null,[\"shared-storage\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[null,[[44768158,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44768159,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[100,[[44776500,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44776501,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[200,[[44776502,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44776503,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[1,[[44783616,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44783617,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44784847,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]],[25,[[10,[[31064132],[31064133,[[null,438663674,null,[null,1]]]]],[2,[[4,null,68],[3,[[6,null,null,null,4,null,\"2g\",[\"navigator.connection.effectiveType\"]],[6,null,null,null,4,null,\"2g\",[\"navigator.mozConnection.effectiveType\"]],[6,null,null,null,4,null,\"2g\",[\"navigator.webkitConnection.effectiveType\"]]]]]],40],[50,[[31068366],[31068367,[[null,455645877,null,[null,0.1]]]]]],[10,[[31068825],[31068826,[[null,462420536,null,[null,0.1]]]]]],[50,[[31070232],[31070233,[[476475256,null,null,[1]]]]]]]],[2,[[10,[[31071324],[31071325,[[null,363650251,null,[null,2]]]],[31071326,[[null,363650251,null,[null,1]]]]],null,null,null,null,null,1,null,102],[1,[[31073055],[31073056,[[501,null,null,[1]]]]],[2,[[4,null,66],[12,null,null,null,4,null,\"Chrome\\\\\/((?!100|101|102|103|104|105)\\\\d{3,})\",[\"navigator.userAgent\"]],[1,[[4,null,8,null,null,null,null,[\"navigator.serviceWorker.controller\"]]]],[4,null,9,null,null,null,null,[\"document.head.appendChild\"]]]],62],[100,[[31073352,null,[3,[[4,null,15,null,null,null,null,[\"424397508\"]],[4,null,15,null,null,null,null,[\"170737076\"]],[4,null,15,null,null,null,null,[\"24132379\"]],[4,null,15,null,null,null,null,[\"21869819039\"]],[4,null,15,null,null,null,null,[\"6556\"]],[4,null,15,null,null,null,null,[\"344101295\"]],[4,null,15,null,null,null,null,[\"62532913\"]],[4,null,15,null,null,null,null,[\"152344380\"]],[4,null,15,null,null,null,null,[\"127641337\"]]]]],[31073353,[[null,null,null,[null,null,null,[\"[\\\"424397508\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"170737076\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"24132379\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"21869819039\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"6556\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"344101295\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"62532913\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"152344380\\\",[[\\\"pubcid.org\\\",null,true]]]\",\"[\\\"127641337\\\",[[\\\"pubcid.org\\\",null,true]]]\"]],null,471270390]],[3,[[4,null,15,null,null,null,null,[\"424397508\"]],[4,null,15,null,null,null,null,[\"170737076\"]],[4,null,15,null,null,null,null,[\"24132379\"]],[4,null,15,null,null,null,null,[\"21869819039\"]],[4,null,15,null,null,null,null,[\"6556\"]],[4,null,15,null,null,null,null,[\"344101295\"]],[4,null,15,null,null,null,null,[\"62532913\"]],[4,null,15,null,null,null,null,[\"152344380\"]],[4,null,15,null,null,null,null,[\"127641337\"]]]]]],null,67],[100,[[31073354,null,[3,[[4,null,15,null,null,null,null,[\"154013155\"]],[4,null,15,null,null,null,null,[\"21658289790\"]]]]],[31073355,[[null,null,null,[null,null,null,[\"[\\\"154013155\\\",[[\\\"id5-sync.com\\\",null,true]]]\",\"[\\\"21658289790\\\",[[\\\"id5-sync.com\\\",null,true]]]\"]],null,471270390]],[3,[[4,null,15,null,null,null,null,[\"154013155\"]],[4,null,15,null,null,null,null,[\"21658289790\"]]]]]],null,67],[10,[[44752585],[44752586,[[392065905,null,null,[1]]]]],null,41],[50,[[44777628],[44777629,[[392065905,null,null,[]]]]],[4,null,68],41],[5,[[44787901],[44787902,[[45388169,null,null,[1]]]]],null,null,null,null,null,301,null,102]]],[4,[[null,[[44714449,[[null,7,null,[null,1]]]],[676982961,[[null,7,null,[null,0.4]],[212,null,null,[1]]]],[676982996,[[null,7,null,[null,1]]]]]]]]],null,null,[null,\"1000\",1,\"1000\"]],null,null,null,null,\".google.co.in\",92,2021]")