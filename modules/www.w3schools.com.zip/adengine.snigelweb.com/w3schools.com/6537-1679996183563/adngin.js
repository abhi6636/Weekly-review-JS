! function(e) {
    var t = {};

    function n(i) {
        if (t[i]) return t[i].exports;
        var r = t[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return e[i].call(r.exports, r, r.exports, n), r.l = !0, r.exports
    }
    n.m = e, n.c = t, n.d = function(e, t, i) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: i
        })
    }, n.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function(e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var i = Object.create(null);
        if (n.r(i), Object.defineProperty(i, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var r in e) n.d(i, r, function(t) {
                return e[t]
            }.bind(null, r));
        return i
    }, n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = 13)
}([function(e, t, n) {
    "use strict";
    n.r(t), n.d(t, "udef", (function() {
        return i
    })), n.d(t, "uuid", (function() {
        return r
    })), n.d(t, "wPerf", (function() {
        return o
    })), n.d(t, "snConfigName", (function() {
        return a
    })), n.d(t, "snPubConfName", (function() {
        return s
    })), n.d(t, "coreObjName", (function() {
        return d
    })), n.d(t, "snConf", (function() {
        return c
    })), n.d(t, "snPubConf", (function() {
        return l
    })), n.d(t, "coreObj", (function() {
        return u
    })), n.d(t, "pbjsObjName", (function() {
        return g
    })), n.d(t, "pbjsObj", (function() {
        return f
    })), n.d(t, "coreEvents", (function() {
        return m
    }));
    var i = void 0,
        r = "10000000-1000-4000-8000-100000000000".replace(/1|0/g, (function() {
            return (0 | 16 * Math.random()).toString(16)
        })),
        o = window.performance,
        a = "_snigelConfig",
        s = "snigelPubConf",
        d = window[a].settings.adngin.objName,
        c = window[a],
        l = window[s],
        u = window[d],
        g = window[a].settings.pbjs.objName,
        f = window[g],
        m = {
            coreLoaded: d + "Loaded",
            coreReady: d + "Ready",
            coreAuctionStart: d + "AuctionStart",
            coreAuctionAdUnitsFiltered: d + "AuctionAdUnitsFiltered",
            coreAuctionAdUnitsSizeMapped: d + "AuctionAdUnitsSizeMapped",
            coreAuctionAdUnitsSet: d + "AuctionAdUnitsSet",
            coreAuctionAdUnitsReady: d + "AuctionAdUnitsReady",
            coreBiddingPhaseStart: d + "BiddingPhaseStart",
            corePbjsBiddingStart: d + "PbjsBiddingStart",
            corePbjsBiddingEnd: d + "PbjsBiddingEnd",
            coreTamBiddingStart: d + "TamBiddingStart",
            coreTamBiddingEnd: d + "TamBiddingEnd",
            coreBiddingPhaseEnd: d + "BiddingPhaseEnd",
            coreAdServerPhaseStart: d + "AdServerPhaseStart",
            coreAdServerStart: d + "AdServerStart",
            coreAdServerEnd: d + "AdServerEnd",
            coreAuctionEnd: d + "AuctionEnd",
            coreLotViewable: d + "LotViewable",
            coreFirstAd: d + "FirstAd"
        }
}, function(e, t, n) {
    var i = n(9),
        r = n(0),
        o = {
            off: 0,
            error: 1,
            warn: 2,
            info: 3,
            debug: 4
        },
        a = o.error,
        s = r.coreObj.log = [];

    function d(e, t) {
        var n = function(e, t) {
            return (e = [].slice.call(e)).unshift("【" + r.coreObjName + "】(" + i.getPerformanceTimeStamp() + ") " + t.toUpperCase() + ":"), e
        }(t, e);
        s.push({
            type: e,
            msg: n
        }), 0 !== a && window.console[e] && a >= o[e] && console[e].apply(console, n)
    }
    t.setLogLevel = function(e) {
        return !!o.hasOwnProperty(e) && (a = o[e], !0)
    }, t.showHistory = function() {
        s.forEach((function(e) {
            console[e.type].apply(console, e.msg)
        }))
    }, t.getHistory = function() {
        return s
    }, t.fatal = function() {
        if (window.argus) {
            var e = 1 === arguments.length && arguments[0] instanceof Error ? {
                stack: arguments[0].stack
            } : {
                log: arguments,
                stack: (new Error).stack
            };
            window.argus.cmd.push((function() {
                window.argus.queueError("adngin", e)
            }))
        }
        d("error", arguments)
    }, t.error = function() {
        d("error", arguments)
    }, t.warn = function() {
        d("warn", arguments)
    }, t.info = function() {
        d("info", arguments)
    }, t.debug = function() {
        d("debug", arguments)
    }
}, function(e, t, n) {
    var i, r = n(10),
        o = r.getValueByPath,
        a = r.cloneValueByPath;

    function s() {
        return void 0 !== i
    }
    e.exports = {
        init: function(e) {
            if (void 0 !== i) throw SyntaxError("Domain configuration was already initialized.");
            i = e
        },
        get: function(e) {
            if (!s()) throw SyntaxError("Can't get '".concat(e, "'. Domain configuration was not initialized."));
            return o(i, e)
        },
        clone: function(e) {
            if (!s()) throw SyntaxError("Can't clone '".concat(e, "'. Domain configuration was not initialized."));
            return a(i, e)
        }
    }
}, function(e, t) {
    e.exports = {
        queueEnabled: !1,
        coreReady: !1,
        window: {
            innerWidth: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
            innerHeight: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
        },
        activeLots: {},
        videoTimeouts: {},
        debugMode: !1,
        availableBidders: [],
        auction: {
            deferredBy: [],
            running: !1,
            activeLabels: [],
            requestedLots: {},
            lots: {},
            adUnits: [],
            pbjsAdUnits: [],
            gracePeriodRunning: !1,
            gracePeriodMs: 25,
            queuedLots: {},
            waitingTimeoutLots: {}
        },
        bidding: {
            deferredBy: []
        },
        adServer: {
            deferredBy: {},
            isManualCall: !1,
            enabled: !0
        }
    }
}, function(e, t, n) {
    var i = n(1),
        r = [],
        o = {},
        a = null;

    function s(e, t, n) {
        for (var o in r) {
            var a = r[o][e];
            if (a) {
                for (var s = n ? "capture" : "noCapture", d = a[s], c = d.cbs, l = c.length - 1; l >= 0; l--) c[l].cb === t && (c.splice(l, 1), i.debug("Removed internal event handler for event '" + e + "', using " + s));
                0 == c.length && d.cb && (r[o].target.removeEventListener(e, d.cb, n), i.debug("Removed browser event listener for event '" + e + "', using " + s))
            }
        }
    }
    e.exports = {
        initMetrics: function(e) {
            if (a) throw SyntaxError("Metrics object was already initialized.");
            a = e
        },
        dispatchEvent: function(e, t) {
            if ((t = t || {}).isUnique && o[e]) i.warn("Unique event '" + e + "' was already dispatched. Cannot dispatch again.");
            else {
                var n = t.eventDetail ? {
                        detail: t.eventDetail
                    } : null,
                    r = t.dispatcher || window;
                o[e] = (o[e] || 0) + 1, a && a.recordTiming(t.metricsAction || e), i.debug("Dispatching Event '" + e + "'."), r.dispatchEvent(new CustomEvent(e, n))
            }
        },
        wasEventAlreadyDispatched: function(e) {
            return o[e] || 0
        },
        addEventListener: function(e, t, n) {
            var o = (n = n || {}).useCapture,
                a = n.eventTarget || window;
            if (a.addEventListener) {
                for (var d = null, c = 0; c < r.length; c++)
                    if (r[c].target === a) {
                        d = r[c];
                        break
                    }
                d || (d = {
                    target: a
                }, r.push(d)), d[e] = d[e] || {
                    capture: {
                        cbs: []
                    },
                    noCapture: {
                        cbs: []
                    }
                };
                var l = o ? "capture" : "noCapture",
                    u = d[e][l];
                0 == u.cbs.length && (i.debug("Added a browser event listener for event '" + e + "', using " + l), u.cb = function(e) {
                    for (var t = 0; t < u.cbs.length; t++) u.cbs[t].execCb(e)
                }, a.addEventListener(e, u.cb, o));
                var g = t,
                    f = "";
                n.polledInMs > 0 ? (g = function(e, t) {
                    var n = null;
                    return function(i) {
                        n || (n = setTimeout((function() {
                            clearTimeout(n), n = null, t(i)
                        }), e))
                    }
                }(n.polledInMs, t), f = "with a polling of " + n.polledInMs + "ms.") : n.gracePeriodInMs > 0 ? (g = function(e, t) {
                    var n = null;
                    return function(i) {
                        n && clearTimeout(n), n = setTimeout((function() {
                            t(i)
                        }), e)
                    }
                }(n.gracePeriodInMs, t), f = "with a grace period of " + n.gracePeriodInMs + "ms.") : n.oneTimeEvent && (g = function(e, t, n) {
                    return function(i) {
                        t(i), s(e, t, n)
                    }
                }(e, t, o), f = "as a one time event."), u.cbs.push({
                    cb: t,
                    execCb: g
                }), i.debug("Added a new internal event handler for event '" + e + "', " + f)
            } else i.error("Unable to set event listener to the given object, it can't handle events")
        },
        removeEventListener: s
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(1),
        a = n(4),
        s = n(2),
        d = n(7),
        c = Object.freeze({
            square: "square",
            vertical: "vertical",
            horizontal: "horizontal"
        }),
        l = {},
        u = {},
        g = {};

    function f(e) {
        var t = e[0] / e[1];
        return 1 === t ? c.square : t < 1 ? c.vertical : t > 1 ? c.horizontal : void 0
    }

    function m(e, t, n) {
        var i = {
            placements: {}
        };
        return n.code.indexOf("-adaptive-group-") >= 0 && o.fatal("Adaptive recursive naming error"), e.forEach((function(e, r) {
            var a = n.code + "-adaptive-group-" + t + "-placement-" + r,
                s = i.placements[a] = {};
            s.sizes = e, s.adUnit = function(e, t, n, i) {
                var r = JSON.parse(JSON.stringify(e));
                return r.code = i, r.mediaTypes = {
                    banner: {
                        sizes: t
                    }
                }, r.activeSizes = n, -1 !== d.getExcludedPlacements().indexOf(e.code) && d.excludePlacement(i), o.debug("Adaptive original ad-unit:", e), o.debug("Adaptive derived ad-unit :", r), r
            }(n, e, t > 0 ? e : n.activeSizes, a)
        })), i
    }

    function v(e, t, n, i) {
        var a = function(e, t, n) {
            if (!e) return null;
            n === r.udef && (n = !0);
            var i, a = f(e);
            if (c[a] === c.vertical) t.sort((function(e, t) {
                return t[1] - e[1]
            })), i = 1;
            else {
                if (c[a] !== c.horizontal) return null;
                ! function(e) {
                    e.sort((function(e, t) {
                        return t[0] - e[0]
                    }))
                }(t), i = 0
            }
            var s = {};
            t.forEach((function(t) {
                var r, o = e[i],
                    a = t[i],
                    d = Math.floor(o / a),
                    c = s[d] = s[d] || [];
                1 !== d && n ? (r = [], c.push(r), s[1][0][0].push(t)) : r = c[0] = c[0] || [];
                for (var l = 0; l < d; l++) {
                    (r[l] = r[l] || []).push(t)
                }
            }));
            var d = Object.keys(s).map((function(e) {
                return "\n\tGroups with " + e + " placement(s):" + s[e].map((function(e, t) {
                    return "\n\t  Group-" + t + ":" + e.map((function(e, t) {
                        return "\n\t    Placement-" + t + ": [" + e.map((function(e) {
                            return e.join("x")
                        })).join(", ") + "]"
                    })).join("")
                })).join("")
            })).join("");
            return o.debug("Ad Space grouping:", d), s
        }(t, n, i);
        if (!a) return o.warn("No adaptive placement groups available."), null;
        var s = [];
        return Object.keys(a).forEach((function(t, n) {
            a[t].forEach((function(t, i) {
                s.push(m(t, n + i, e))
            }))
        })), s
    }

    function p(e) {
        var t = function(e) {
                return e.mediaTypes && e.mediaTypes.banner && e.mediaTypes.banner.sizes ? e.mediaTypes.banner.sizes.concat() : null
            }(e),
            n = function(e) {
                var t = null;
                return e && (t = [0, 0], e.forEach((function(e) {
                    t[0] = Math.max(e[0], t[0]), t[1] = Math.max(e[1], t[1])
                }))), t
            }(t),
            i = e.adaptive.uniformGrouping,
            r = e.adaptive.sizeConstriction;
        o.debug("Available adaptive ad-space size: " + JSON.stringify(n));
        var a = v(e, n, t, i);
        if (!a) return null;
        var d = {
            placementId: e.code,
            pbAdUnitName: e.name,
            size: n,
            uniformGrouping: i,
            sizeConstriction: r,
            placementGroups: a,
            parallaxEnabled: s.get("modules.parallax.enabled") && e.parallax
        };
        return o.debug("Created adaptive ad-space:", d), d
    }

    function b(e) {
        var t = e.code,
            n = e.name;
        i.auction.requestedLots[t] = n, i.auction.lots[t] = n;
        var r = i.activeLots;
        (r[t] = r[t] || {}).adUnit = n, i.auction.adUnits.push(e), (e.bids || []).length > 0 && i.auction.pbjsAdUnits.push(e)
    }

    function h(e) {
        var t = e.code,
            n = e.name,
            r = document.getElementById(t);
        r && (r.remove(), o.debug("Removing unused adaptive Ad-Space group placement '".concat(t, "'.")));
        var a = i.activeLots[t];
        if (a) {
            var s = a.adSlot;
            s && googletag.cmd.push((function() {
                googletag.destroySlots([s]), o.debug("Removing unused GPT Ad-Slot for group placement '".concat(t, "'."))
            })), delete i.activeLots[t], o.debug("Removing unused adaptive Ad-Space lot (".concat(t, ":").concat(n, ")."))
        }
        delete g[t]
    }

    function y(e) {
        u[e.placementId] = e,
            function(e, t) {
                delete i.auction.requestedLots[e], delete i.auction.lots[e], delete i.activeLots[e];
                var n = function(n) {
                    for (var i = n.length - 1; i >= 0; i--) {
                        var r = n[i];
                        r.code === e && r.name == t && n.splice(i, 1)
                    }
                };
                n(i.auction.adUnits), n(i.auction.pbjsAdUnits)
            }(e.placementId, e.pbAdUnitName), e.placementGroups.forEach((function(e) {
                var t = e.placements;
                for (var n in t) b(t[n].adUnit)
            }))
    }

    function A(e) {
        Array.from(e).forEach((function(e) {
            if (e.adaptive && !0 === e.adaptive.enabled)
                if (L(e.code) === e.code) {
                    o.debug("Found adaptive lot in auction: (" + e.code + ":" + e.name + ")");
                    var t = function(e) {
                        var t = p(e);
                        return o.debug("New adaptive ad-space:", t), t
                    }(e);
                    t && (o.debug("New adaptive ad-space:", t), y(t))
                } else ! function(e) {
                    var t = g[e.code];
                    t && (e.mediaTypes = t.adUnit.mediaTypes, e.activeSizes = t.adUnit.activeSizes, t.adUnit = e)
                }(e)
        })), Object.keys(A).length > 0 && o.debug("Active adaptive ad-spaces: ", JSON.parse(JSON.stringify(u)))
    }

    function w(e, t, n, i, r) {
        var o = document.getElementById(e);
        if (!o) return !1;
        o.style.minWidth = t[0] + "px", n || (o.style.minHeight = t[1] + "px"), o.style.display = "flex", o.style.justifyContent = "space-around", o.style.alignItems = "center";
        var a, s = f(t);
        for (var d in c[s] === c.vertical ? a = "column" : c[s] === c.horizontal && (a = "row", i && (o.style.width = t[0] + "px")), o.style.flexDirection = a, r.placements) {
            var l = r.placements[d],
                u = document.getElementById(d);
            g[d] = l, u || ((u = document.createElement("div")).id = d, o.appendChild(u))
        }
    }

    function S(e) {
        var t = {};
        return e.forEach((function(e) {
            t[e.adUnitCode] = t[e.adUnitCode] || 0, t[e.adUnitCode] = Math.max(t[e.adUnitCode], e.cpm)
        })), t
    }

    function E() {
        for (var e in u) {
            var t = u[e];
            t.winningPlacementGroup = t.winningPlacementGroup || t.placementGroups[0];
            var n = t.winningPlacementGroup;
            ((l[e] || {}).placementGroups || []).forEach((function(e) {
                for (var t in e.placements) n.placements[t] || (o.debug("Removing losing placement.", t), h(e.placements[t].adUnit))
            })), w(t.placementId, t.size, t.parallaxEnabled, t.sizeConstriction, n), l[t.placementId] = t
        }
    }

    function L(e) {
        return "string" == typeof e ? e.split("-adaptive-group-")[0] : ""
    }
    e.exports = {
        init: function(e, t) {
            a.addEventListener(r.coreEvents.coreAuctionAdUnitsReady, (function() {
                A(i.auction.adUnits)
            })), r.pbjsObj.que.push((function() {
                r.pbjsObj.onEvent("auctionEnd", (function(e) {
                    ! function(e) {
                        for (var t in u) {
                            var n = u[t],
                                i = 0,
                                o = r.udef;
                            n.placementGroups.forEach((function(t, n) {
                                for (var r in t.cpm = 0, t.placements) {
                                    var a = t.placements[r],
                                        s = e[r] || 0;
                                    a.cpm = 0, a.cpm = Math.max(a.cpm, s), t.cpm += a.cpm
                                }
                                t.cpm > i && (i = t.cpm, o = n)
                            })), o !== r.udef && (n.winningPlacementGroup = n.placementGroups[o])
                        }
                    }(S(e.bidsReceived))
                }))
            })), a.addEventListener(r.coreEvents.coreBiddingPhaseEnd, (function() {
                o.debug("Active Ad-Spaces results:", JSON.parse(JSON.stringify(u)))
            })), a.addEventListener(r.coreEvents.coreAdServerPhaseStart, (function() {
                e.doOnDomReady(E)
            }))
        },
        getAdaptiveBasePlacement: L,
        getAdaptiveSubPlacements: function(e) {
            var t = [e],
                n = u[e];
            if (n && n.winningPlacementGroup)
                for (var i in t = [], n.winningPlacementGroup.placements) t.push(i);
            return t
        },
        isAdaptiveSubPlacement: function(e) {
            return L(e) !== e
        },
        getAdaptivePlacementGroup: function(e) {
            if ("string" == typeof e) {
                var t = e.split("-adaptive-group-");
                if (t.length > 1) return Number(t[1].split("-placement-")[0])
            }
            return r.udef
        }
    }
}, function(e, t, n) {
    var i = n(1),
        r = {
            eventNames: ["impressionViewable", "slotOnload", "slotRenderEnded", "slotRequested", "slotResponseReceived", "slotVisibilityChanged"],
            eventListeners: {},
            activeEvent: void 0,
            addListenerQueue: [],
            removeListenerQueue: []
        };

    function o(e, t) {
        -1 !== r.eventNames.indexOf(e) && (r.activeEvent !== e ? r.eventListeners[e].push(t) : r.addListenerQueue.push({
            event: e,
            function: t
        }))
    }

    function a(e, t) {
        if (-1 !== r.eventNames.indexOf(e))
            if (r.activeEvent !== e)
                for (var n = r.eventListeners[e].length - 1; n >= 0; n--) t === r.eventListeners[e][n] && r.eventListeners[e].splice(n, 1);
            else r.removeListenerQueue.push({
                event: e,
                function: t
            })
    }
    r.eventNames.forEach((function(e) {
        var t;
        i.debug("Registering gpt event system listener for '" + e + "'."), r.eventListeners[e] = [], t = e, googletag.cmd.push((function() {
            googletag.pubads().addEventListener(t, (function(e) {
                r.activeEvent = t, r.eventListeners[t].forEach((function(n) {
                    try {
                        i.debug("Gpt event system triggering '" + n.name + "' on event '" + t + "'."), n(e)
                    } catch (e) {
                        i.error(e)
                    }
                })), r.activeEvent = void 0, r.addListenerQueue.forEach((function(e) {
                    o(e.event, e.function)
                })), r.addListenerQueue = [], r.removeListenerQueue.forEach((function(e) {
                    a(e.event, e.function)
                })), r.removeListenerQueue = []
            }))
        }))
    })), e.exports = {
        addEventListener: o,
        removeEventListener: a
    }
}, function(e, t, n) {
    var i = n(0),
        r = n(6),
        o = n(2);

    function a(e, t) {
        -1 === (e.excludedAdUnits || []).indexOf(t) && (function(e, t) {
            var n = !1;
            return e.length > 0 && i.pbjsObj && "function" == typeof i.pbjsObj.getAllWinningBids && i.pbjsObj.getAllWinningBids().some((function(i) {
                if (i.adUnitCode == t && -1 !== e.indexOf(i.bidderCode)) return n = !0, !0
            })), n
        }(e.excludedBidders || [], t) || function(e, t, n) {
            if (t) {
                var i = e.style,
                    r = e.label || "ADVERTISEMENT";
                if (!document.getElementById(n)) {
                    var o = document.createElement("div");
                    o.id = n, o.setAttribute("class", "sn_ad_label"), o.innerHTML = r, i && o.setAttribute("style", i), t.insertBefore(o, t.children[0])
                }
            }
        }(e, document.getElementById(t), "sn_ad_label_" + t))
    }
    e.exports = {
        init: function(e, t) {
            o.get("modules.adLabeling.enabled") && (e.addStyleToDocument(".sn_ad_label{height:unset !important}"), r.addEventListener("slotRenderEnded", (function(e) {
                a(o.get("modules.adLabeling"), e.slot.getSlotElementId())
            })))
        },
        setLabel: a,
        getExcludedPlacements: function() {
            return (o.get("modules.adLabeling") || {}).excludedAdUnits || []
        },
        excludePlacement: function(e) {
            var t = o.get("modules.adLabeling");
            if (t) {
                var n = t.excludedAdUnits || []; - 1 === n.indexOf(e) && n.push(e), t.excludedAdUnits = n
            }
        }
    }
}, function(e, t, n) {
    function i(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null == n) return;
            var i, r, o = [],
                a = !0,
                s = !1;
            try {
                for (n = n.call(e); !(a = (i = n.next()).done) && (o.push(i.value), !t || o.length !== t); a = !0);
            } catch (e) {
                s = !0, r = e
            } finally {
                try {
                    a || null == n.return || n.return()
                } finally {
                    if (s) throw r
                }
            }
            return o
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return r(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return r(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function r(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, i = new Array(t); n < t; n++) i[n] = e[n];
        return i
    }
    var o = n(3),
        a = n(0),
        s = n(4),
        d = n(6),
        c = n(2),
        l = n(7),
        u = n(5),
        g = {},
        f = window.scrollY,
        m = window.scrollY,
        v = !1;

    function p(e) {
        return !!(e && c.get("modules.parallax.enabled") && e.parallax)
    }

    function b(e) {
        return e + "-parallax"
    }

    function h(e, t, n, i, r, o) {
        var a, s = o.getBoundingClientRect(),
            d = s.top,
            c = s.bottom,
            l = 0;
        if (d <= t && c >= 0) {
            var u = i.config.topOffset,
                g = i.config.bottomOffset,
                f = o.offsetHeight - r.offsetHeight;
            l = function(e, t, n) {
                var i = 0;
                return "left" !== n && (i = "center" === n ? (e.offsetWidth - t.offsetWidth) / 2 : "right" === n ? e.offsetWidth - t.offsetWidth : Number(n) || 0), i
            }(i.elem, r, i.config.hAlign || "center"), a = d < u || window.scrollY >= e - t ? function(e, t) {
                return e ? 0 : t
            }(n, f) : c > t - g || 0 == window.scrollY ? function(e, t) {
                return e ? t : 0
            }(n, f) : function(e, t, n, i, r, o, a) {
                var s = r.bottom,
                    d = r.height,
                    c = s + window.scrollY + a - n,
                    l = c + n - d - o - a;
                c < 0 && (c = 0), l > i - n && (l = i - n);
                var u = (window.scrollY - c) / (l - c);
                return t * (e ? 1 - u : u)
            }(n, f, t, e, s, u, g)
        } else a = -r.offsetHeight;
        return [l, a]
    }

    function y(e, t, n, i, r) {
        var o = e.config.reversed,
            a = window.visualViewport ? window.visualViewport.height : window.innerHeight,
            s = document.documentElement.scrollHeight;
        return e.isSuprallax ? function(e, t, n, i, r, o, a) {
            return a ? i.suprallaxTranslationY = n ? -r.offsetHeight + o.offsetHeight : 0 : (i.suprallaxTranslationY += (n ? 1 : -1) * (f - m) * function(e, t, n, i) {
                return e < t * (1 + i) ? n / (e - t) : n / (t * i)
            }(e, t, r.offsetHeight - o.offsetHeight, i.config.numPagesToScrollAd || 1), i.suprallaxTranslationY > 0 && (i.suprallaxTranslationY = 0), i.suprallaxTranslationY < -r.offsetHeight + o.offsetHeight && (i.suprallaxTranslationY = -r.offsetHeight + o.offsetHeight)), [0, i.suprallaxTranslationY]
        }(s, a, o, e, t, i, r) : h(s, a, o, e, t, i)
    }

    function A(e, t) {
        var n = g[e];
        if (n) {
            var r = b(e);
            if (n.elem = n.elem || document.getElementById(r), n.elem && (n.parallaxElem = n.parallaxElem || document.getElementById(e), n.parallaxElem)) {
                var o = n.parallaxElem;
                n.absElem = n.absElem || document.getElementById(r + "-abs");
                var a, s = n.absElem,
                    d = o.style,
                    c = 0;
                if (o.offsetHeight > s.offsetHeight + 2 * (parseInt(n.config.verticalPadding) || 0)) {
                    var l = i(y(n, o, 0, s, t), 2);
                    c = l[0], a = l[1]
                } else a = (s.offsetHeight - o.offsetHeight) / 2;
                d.transform = "translate(" + c + "px," + a + "px)"
            }
        }
    }

    function w() {
        for (var e in g) A(e)
    }

    function S(e) {
        var t, n = 0,
            i = e.parallax.doNotParallaxHeight || [];
        return (e.activeSizes || []).forEach((function(e) {
            Array.isArray(e) && 2 === e.length && (t = 1, i.indexOf(e[1]) < 0 && (t = e[1] * e[0] >= 242500 ? .3 : .5), n = Math.max(n, e[1] * t))
        })), n
    }

    function E(e, t, n, i, r, o) {
        var d = document.getElementById(n);
        if (d) {
            d.id = i;
            var c = document.createElement("div");
            c.id = i + "-abs";
            var g = document.createElement("div");
            for (g.id = n, t.parallax.verticalPadding && (g.style.paddingTop = t.parallax.verticalPadding, g.style.paddingBottom = g.style.paddingTop, g.style.textAlign = t.parallax.hAlign || "center"); d.children.length > 0;) g.appendChild(d.children[0]);
            c.appendChild(g), d.appendChild(c),
                function(e, t, n, i, r, o, d) {
                    var c = d.id,
                        g = 0;
                    i.enabled && (i.excludedAdUnits = i.excludedAdUnits || [], -1 === i.excludedAdUnits.indexOf(n) && (r > 0 && (r += g = 15, i.excludedAdUnits = i.excludedAdUnits || [], i.excludedAdUnits.push(n), i.moduleHandledAdUnits = i.moduleHandledAdUnits || [], i.moduleHandledAdUnits.push(n)), l.setLabel(i, c)), s.addEventListener(a.coreEvents.coreAdServerStart, (function() {
                        u.getAdaptiveSubPlacements(n).forEach((function(e) {
                            -1 === i.excludedAdUnits.indexOf(e) && i.excludedAdUnits.push(e)
                        }))
                    })));
                    var f = c + "-style";
                    t.adhesive || document.getElementById(f) || e.addStyleToDocument("[id='" + o.id + "']{" + t.parallax.style + "}", f), o.style = "position:absolute;left:0;right:0;bottom:0;top:" + g + "px;clip:rect(0,auto,auto,0);", d.style = "position:relative;contain:none;" + (r > 0 ? "height:" + r + "px;" : "")
                }(e, t, n, o, r, c, d)
        }
    }

    function L(e) {
        var t = c.get("modules.adLabeling");
        s.addEventListener(a.coreEvents.coreAuctionAdUnitsSet, (function() {
            v || (v = (o.auction.adUnits || []).some((function(e) {
                return !!e.parallax
            }))) && function(e) {
                s.addEventListener("scroll", (function() {
                    m = f, f = window.scrollY, w()
                })), s.addEventListener("resize", (function() {
                    w()
                })), window.visualViewport && visualViewport.addEventListener("resize", (function() {
                    w()
                })), s.addEventListener(a.coreEvents.coreAuctionEnd, (function() {
                    e.doOnDomReady((function() {
                        for (var e in g) {
                            (o.activeLots[e] || {}).adSlot || A(e, !0)
                        }
                    }))
                })), d.addEventListener("slotRenderEnded", (function(e) {
                    e.slot && A(e.slot.getSlotElementId(), !0)
                }))
            }(e), v && e.doOnDomReady((function() {
                (o.auction.adUnits || []).forEach((function(n) {
                    if (n.parallax && !u.isAdaptiveSubPlacement(n.code)) {
                        var i = n.code,
                            r = S(n);
                        if (!g[i]) {
                            g[i] = {
                                config: n.parallax,
                                isSuprallax: n.adhesive
                            };
                            var o = b(i);
                            document.getElementById(o) || E(e, n, i, o, r, t)
                        }
                    }
                }))
            }))
        }))
    }
    e.exports = {
        init: function(e, t) {
            c.get("modules.parallax.enabled") && L(e)
        },
        isAdUnitParallax: p,
        getAdUnitPlacement: function(e) {
            return e ? p(e) ? b(u.getAdaptiveBasePlacement(e.code)) : e.code : null
        },
        getParallaxContainerHeight: S
    }
}, function(e, t, n) {
    var i = n(0),
        r = Math.floor(Date.now() - (i.wPerf && i.wPerf.now ? i.wPerf.now() : 0));
    t.startTime = function() {
        return r
    }, t.getTimezoneOffset = function() {
        return (new Date).getTimezoneOffset()
    }, t.getTimezoneString = function() {
        return Intl.DateTimeFormat().resolvedOptions().timeZone
    }, t.now = i.wPerf && i.wPerf.now ? function() {
        return Math.floor(i.wPerf.now())
    } : function() {
        return Date.now() - r
    }, t.getPerformanceTimeStamp = function(e) {
        void 0 === e && (e = 2);
        var n = t.now(),
            i = "ms";
        return n / 1e3 >= 1 && (e += 2, n /= 1e3, i = "s"), n.toFixed(e) + i
    }
}, function(e, t, n) {
    "use strict";

    function i(e, t) {
        if (null != e) {
            var n = (t = t || "").split(".");
            if (1 === n.length && 0 === n[0].length) return e;
            for (var i = e, r = 0; r < n.length; r++) {
                var o = n[r];
                if (!i.hasOwnProperty(o)) return;
                i = i[o]
            }
            return i
        }
    }

    function r(e, t) {
        return JSON.parse(JSON.stringify(i(e, t)))
    }
    n.r(t), n.d(t, "getValueByPath", (function() {
        return i
    })), n.d(t, "cloneValueByPath", (function() {
        return r
    }))
}, function(e, t, n) {
    n(0);
    var i = n(3),
        r = {};
    e.exports = {
        get: function() {
            return r
        },
        add: function(e, t, n, o, a) {
            var s = "debug" + t.charAt(0).toUpperCase() + t.slice(1);
            r[t] = function(t, i) {
                return e.api.executeCommand(s, n, o, t, i)
            }, e.api.commands[s] = a, !0 === i.debugMode && e.debugMode.enableApiCommands()
        }
    }
}, function(e, t, n) {
    var i, r, o = n(3),
        a = n(0),
        s = n(1),
        d = n(4),
        c = n(2),
        l = n(5),
        u = {
            lotsTimeoutFunctions: {},
            activeLots: {},
            lotsWithStatus: {
                0: {
                    status: "Lots pending first view",
                    modes: {}
                },
                1: {
                    status: "Lots pending timeout",
                    modes: {}
                },
                2: {
                    status: "Lots pending viewability",
                    modes: {}
                },
                3: {
                    status: "Lots viewable, pending activity",
                    modes: {}
                },
                4: {
                    status: "Lots ready for refresh",
                    lots: {}
                }
            },
            auctionGracePeriodRunning: !1,
            userActive: !1,
            interactionGracePeriodMs: 5e3,
            windowHasFocus: document.hasFocus()
        };

    function g(e, t) {
        var n = u.lotsTimeoutFunctions[e];
        if (n) {
            var i = function(e, t) {
                e[t] && (clearTimeout(e[t]), delete e[t])
            };
            if (void 0 === t)
                for (var r in n) i(n, r);
            else i(n, t);
            return Object.keys(n) || delete u.lotsTimeoutFunctions[e], !0
        }
        return !1
    }

    function f(e) {
        g(e);
        var t = u.activeLots[e];
        if (t) {
            delete t.adUnit;
            var n = t.modes;
            if (n)
                for (var i in n) {
                    var r = n[i].status,
                        o = u.lotsWithStatus[r];
                    4 === r ? delete o.lots[e] : delete o.modes[i].lots[e]
                }
            delete t.modes, delete u.activeLots[e], s.debug("Canceling smart-refresh for placement: " + e)
        }
    }

    function m(e) {
        var t = 1;
        return e.triggerOnUserActive && e.triggerOnViewable && e.enableOnViewable ? t = 4 : e.triggerOnViewable && e.enableOnViewable ? t = 3 : e.enableOnViewable && (t = 2), t
    }

    function v(e, t, n, a) {
        var d = u.activeLots[e].modes[n],
            l = d.status;
        if (l != a) {
            var g = u.lotsWithStatus[l].modes[n],
                v = g.lots[e];
            if (v) {
                var p = u.lotsWithStatus[a];
                4 === a ? p.lots[e] = v : (p.modes[n] = p.modes[n] || {
                    lots: {}
                }, p.modes[n].lots[e] = v), d.status = a, delete g.lots[e], 4 === a && function(e, t) {
                    u.auctionGracePeriodRunning || (u.auctionGracePeriodRunning = !0, setTimeout((function() {
                        var n, a = [],
                            d = u.lotsWithStatus[4].lots,
                            l = null !== (n = c.get("modules.smartRefresh.blacklistBidders")) && void 0 !== n ? n : ["lasso"];
                        for (var g in d) {
                            var v = d[g];
                            a.push({
                                placement: g,
                                adUnit: v,
                                blacklistBidders: l
                            }), delete d[g], r.lots[g][v].refreshCountTotal++, r.lots[g][v].smartRefresh = r.lots[g][v].smartRefresh || {}, r.lots[g][v].smartRefresh[t] = r.lots[g][v].smartRefresh[t] || {
                                refreshCountTotal: 0
                            }, r.lots[g][v].smartRefresh[t].refreshCountTotal++, o.activeLots[g].smartRefresh = o.activeLots[g].smartRefresh || {}, o.activeLots[g].smartRefresh.isSmartRefreshImpression = !0;
                            var p = m(e);
                            s.info("Triggering smart-refresh mode '" + p + "'. Lot: (" + g + ":" + v + "), Refresh: " + r.lots[g][v].smartRefresh[t].refreshCountTotal + "/" + e.impressionLimit), o.activeLots[g].smartRefresh.mode = p, f(g)
                        }
                        u.currentAuctionIsSmartRefresh = !0, i.startAuction(a), u.auctionGracePeriodRunning = !1
                    }), u.refreshGracePeriodMs))
                }(t, n)
            }
        }
    }

    function p(e, t) {
        var n, i = u.lotsWithStatus[e].modes;
        for (modeIdx in i) {
            var r = i[modeIdx].lots;
            for (var o in r) t(o, n = u.activeLots[o].adUnit, n.smartRefresh[modeIdx], modeIdx)
        }
    }

    function b(e, t, n, a) {
        (!1 === n.enableOnViewable || !1 === n.enableAndTriggerOnViewable || i.isAdUnitInView(t, e)) && (! function(e, t, n, i) {
            var a = t.name,
                d = 6e4,
                c = 0 === n.impressionLimit ? "∞" : n.impressionLimit,
                l = r.lots[e][a].smartRefresh[i].refreshCountTotal;
            if (!n.impressionLimit || n.impressionLimit <= 0 || l < n.impressionLimit) return n.intervalsSec && (d = 1e3 * n.intervalsSec[Math.min(l, n.intervalsSec.length - 1)]), s.info("Starting smart-refresh timeout. Lot: (" + t.code + ":" + t.name + "), Timeout: " + Math.round(d / 1e3) + "s, Refresh: " + (l + 1) + "/" + c), u.lotsTimeoutFunctions[e] = u.lotsTimeoutFunctions[e] || {}, u.lotsTimeoutFunctions[e][i] = function(e, t, n, i, r) {
                return setTimeout((function() {
                    var a = t.placement;
                    if (function(e, t) {
                            var n = (o.activeLots[e] || {}).adSlot;
                            if (!n) return !1;
                            var i = t.campaignIdBlacklist || [],
                                r = t.lineItemIdBlacklist || [],
                                a = n.getResponseInformation();
                            if (a) {
                                var d = a.campaignId,
                                    c = a.lineItemId,
                                    l = -1 !== r.indexOf(c),
                                    u = -1 !== i.indexOf(d),
                                    g = "(" + e + ":" + o.activeLots[e].adUnit + ")";
                                if (l || u) {
                                    var f = "Autorefresh lot " + g + " filled with blacklisted ";
                                    return l && s.debug(f + "lineItemId: " + c), u && s.debug(f + "campaignId: " + d), !0
                                }
                                s.debug("No blacklisted entity detected in autorefresh lot " + g + ".")
                            }
                            return !1
                        }(a, i)) return f(a), !1;
                    g(a, r);
                    var d = !1 === i.triggerOnUserActive || u.userActive,
                        c = A(e, i, a, !0);
                    s.debug("Smart-refresh timeout of " + n + "ms triggered. Lot: (" + a + ":" + t.adUnit + "), Lot viewable: " + c + ", User active: " + d), v(a, i, r, c ? d ? 4 : 3 : 2)
                }), n)
            }(t, {
                adUnit: a,
                placement: e
            }, d, n, i), !0
        }(e, t, n, a), v(e, n, a, 1))
    }

    function h(e, t, n, i) {
        A(t, n, e, !1) && v(e, n, i, !1 === n.triggerOnUserActive || u.userActive ? 4 : 3)
    }

    function y(e, t, n, i) {
        A(t, n, e, !1) || v(e, n, i, 2)
    }

    function A(e, t, n, r) {
        return !1 !== t.enableAndTriggerOnViewable && (t.triggerOnViewable || t.enableAndTriggerOnViewable) ? i.isAdUnitInView(e, n) : t.triggerOnPageViewable ? i.isDocumentVisible() : r
    }

    function w(e, t) {
        try {
            switch (t.context) {
                case "window":
                    d.addEventListener(t.event, E.functions[t.fn], {
                        eventTarget: e ? e.contentWindow : window,
                        polledInMs: t.pollFrequencyMs
                    });
                    break;
                case "document":
                    d.addEventListener(t.event, E.functions[t.fn], {
                        eventTarget: e ? e.contentDocument : document,
                        polledInMs: t.pollFrequencyMs
                    });
                    break;
                default:
                    s.warn("Unkown event context '" + t.context + "' adding user activity events" + (e ? " to iframe." : "."))
            }
        } catch (e) {
            s.error(e)
        }
    }

    function S(e, t, n) {
        var i = r.lots[n][t];
        i.refreshCountTotal = i.refreshCountTotal || 0, i.smartRefresh = i.smartRefresh || {};
        for (var o = e.smartRefresh, a = 0; a < o.length; a++) {
            i.smartRefresh[a] = i.smartRefresh[a] || {
                refreshCountTotal: 0
            };
            var d = o[a],
                c = i.smartRefresh[a].refreshCountTotal,
                l = m(d),
                g = d.impressionLimit;
            (!g || g <= 0) && (g = "unlimited");
            var f = c >= g;
            if (f && "unlimited" !== g) f && s.debug("Smart-refresh stopped for lot (" + n + ":" + t + "). Impression limit reached for mode '" + l + "': " + c + "/" + g);
            else {
                s.debug("Smart-refresh enabled for lot (" + n + ":" + t + "). Mode = " + l), u.activeLots[n] = u.activeLots[n] || {
                    adUnit: e,
                    modes: {}
                }, u.activeLots[n].modes[a] = {
                    status: 0
                };
                var v = u.lotsWithStatus[0];
                v.modes[a] = v.modes[a] || {
                    lots: {}
                }, v.modes[a].lots[n] = t
            }
        }
    }
    var E = {
        config: [{
            eventType: "moduleControl",
            event: a.coreEvents.coreAuctionEnd,
            context: "window",
            fn: "checkLotsAutorefresh",
            pollFrequencyMs: 0
        }, {
            eventType: "moduleControl",
            event: a.coreEvents.coreAdServerStart,
            context: "window",
            fn: "setAdServerTargeting",
            pollFrequencyMs: 0
        }, {
            eventType: "userActivity",
            event: "focus",
            context: "window",
            fn: "documentGotFocus",
            pollingFrequencyMs: 0
        }, {
            eventType: "userActivity",
            event: "blur",
            context: "window",
            fn: "documentLostFocus",
            pollingFrequencyMs: 0
        }, {
            eventType: "userActivity",
            event: "visibilitychange",
            context: "document",
            fn: "checkLotsViewability",
            pollingFrequencyMs: 0
        }, {
            eventType: "userActivity",
            event: "scroll",
            context: "document",
            fn: "checkLotsViewability",
            pollFrequencyMs: 250
        }, {
            eventType: "userActivity",
            event: "resize",
            context: "window",
            fn: "checkLotsViewability",
            pollFrequencyMs: 250
        }, {
            eventType: "userActivity",
            event: "scroll",
            context: "document",
            fn: "checkUserInteraction",
            pollFrequencyMs: 500
        }, {
            eventType: "userActivity",
            event: "resize",
            context: "window",
            fn: "checkUserInteraction",
            pollFrequencyMs: 500
        }, {
            eventType: "userActivity",
            event: "touchstart",
            context: "document",
            fn: "checkUserInteraction",
            pollFrequencyMs: 500
        }, {
            eventType: "userActivity",
            event: "mousemove",
            context: "document",
            fn: "checkUserInteraction",
            pollFrequencyMs: 500
        }, {
            eventType: "userActivity",
            event: "touchmove",
            context: "document",
            fn: "checkUserInteraction",
            pollFrequencyMs: 500
        }],
        init: function(e) {
            for (var t = E.config, n = 0; n < t.length; n++) {
                var i = t[n];
                e || (i.id = n), e && "userActivity" !== i.eventType || w(e, i)
            }
        },
        functions: {
            checkLotsAutorefresh: function(e) {
                var t = {};
                u.currentAuctionIsSmartRefresh = !1, o.auction.adUnits.forEach((function(e) {
                    if (e.smartRefresh) {
                        var n = e.code,
                            i = e.name;
                        if (t[n] !== i) {
                            t[n] = i, u.activeLots[n] && (s.info("Manual auction of active lot (" + n + ":" + i + ") detected. Stopping smart-refresh of placement '" + n + "'."), f(n));
                            var r = o.activeLots[n];
                            if (r) {
                                if ((r.smartRefresh = r.smartRefresh || {}).isSmartRefreshImpression = !1, r.adUnit !== e.name) return;
                                S(e, i, n)
                            }
                        } else s.debug("Unit '" + i + "': '" + n + "' has already been checked by SSR.")
                    }
                })), E.functions.checkLotsViewability()
            },
            setAdServerTargeting: function() {
                o.auction.adUnits.forEach((function(e) {
                    var t = e.name,
                        n = e.code;
                    if (o.activeLots[n] && o.activeLots[n].smartRefresh && o.activeLots[n].smartRefresh.isSmartRefreshImpression && o.activeLots[n].adSlot) {
                        var a = r.lots[n][t].refreshCountTotal;
                        i.addTargetingKeyValueToAdServer(n, "sn_ric", a), i.addTargetingKeyValueToAdServer(n, "sn_rm", o.activeLots[n].smartRefresh.mode), i.addTargetingKeyValueToAdServer(n, "sn_pd", a % 2 ? 1 : "0")
                    }
                }))
            },
            documentGotFocus: function() {
                u.windowHasFocus = !0, E.functions.checkUserInteraction()
            },
            documentLostFocus: function() {
                u.windowHasFocus = !1, E.functions.checkUserInteraction()
            },
            checkLotsViewability: function(e) {
                p(0, b), p(2, h), p(3, y)
            },
            checkUserInteraction: function(e) {
                if (!u.userActive) {
                    d.dispatchEvent(a.coreEvents.userNowActive);
                    var t = u.lotsWithStatus[3].modes;
                    for (var n in t) {
                        var i = t[n].lots;
                        for (var r in i) {
                            var o = u.activeLots[r].adUnit.smartRefresh;
                            4 === m(o[n]) && v(r, o[n], n, 4)
                        }
                    }
                }
                u.userActive = !0, clearTimeout(u.inactivityTimeout), u.inactivityTimeout = setTimeout((function() {
                    u.userActive = !1, d.dispatchEvent(a.coreEvents.userNowInactive)
                }), u.interactionGracePeriodMs)
            }
        }
    };
    e.exports = {
        init: function(e, t) {
            c.get("modules.smartRefresh.enabled") && (i = e, r = t, u.refreshGracePeriodMs = c.get("modules.smartRefresh.gracePeriodMs") || 25, a.coreEvents.userNowActive = a.coreObjName + "UserNowActive", a.coreEvents.userNowInactive = a.coreObjName + "UserNowInactive", E.init(), a.coreObj.cmd.registerSmartRefreshContentIframeById = function(e, t) {
                return i.api.executeCommand("registerSmartRefreshContentIframeById", a.coreObjName + "Ready", null, e, t)
            }, i.api.commands.registerSmartRefreshContentIframeById = function(e, t, n) {
                var r;
                try {
                    if ("string" != typeof e) throw new TypeError("Expecting argument to be an iframe id of type String");
                    if (null === (r = document.getElementById(e))) throw new Error("No iframe with id '" + e + "' found.");
                    if ("IFRAME" !== r.nodeName) throw new TypeError("Element with id '" + e.nodeName + "' is not an iframe.")
                } catch (e) {
                    return i.api.handleError(n, t, e)
                }
                try {
                    u.registeredIframes = u.registeredIframes || [], u.registeredIframes.push(r.id), E.init(r), r.addEventListener("load", (function() {
                        s.debug("Detected load event for iframe id '" + r.id + "'. Reapplying user activity event listeners."), E.init(r)
                    }))
                } catch (e) {
                    return i.api.handleError(n, t, e)
                }
                return i.runCallback(t, {
                    message: n + "Successfully registered iframe with id '" + r.id + "' for smart refresh event listeners.",
                    data: null
                }, !0), !0
            })
        },
        triggerLotSmartRefresh: function(e, t) {
            u.currentAuctionIsSmartRefresh = !1;
            var n = o.activeLots[e];
            n && ((n.smartRefresh = n.smartRefresh || {}).isSmartRefreshImpression = !1, (c.get("adUnits") || []).some((function(i) {
                return !(n.adUnit !== i.name || !i.smartRefresh) && (u.activeLots[e] && (s.info("Manual auction of active lot (" + e + ":" + i.name + ") detected. Stopping smart-refresh of placement '" + e + "'."), f(e)), t > 0 && ((i = JSON.parse(JSON.stringify(i))).smartRefresh || []).forEach((function(e) {
                    if (e.intervalsSec)
                        for (var n = 0; n < e.intervalsSec.length; n++) {
                            var i = e.intervalsSec[n] - t;
                            e.intervalsSec[n] = i > 0 ? i : 0
                        }
                })), S(i, i.name, e), !0)
            })) && E.functions.checkLotsViewability())
        },
        cancelLotSmartRefresh: f,
        setRefreshWithViewabilityOnly: function(e, t) {
            c.get("modules.smartRefresh.enabled") && e && l.getAdaptiveSubPlacements(e.code).forEach((function(n) {
                var i = ((u.activeLots[n] || {}).adUnit || e).smartRefresh;
                i && i.forEach((function(e) {
                    !t && e.triggerOnViewable && (e.triggerOnPageViewable = !0), e.enableAndTriggerOnViewable = t
                }))
            }))
        }
    }
}, function(e, t, n) {
    "use strict";

    function i(e, t) {
        var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (!n) {
            if (Array.isArray(e) || (n = function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return r(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return r(e, t)
                }(e)) || t && e && "number" == typeof e.length) {
                n && (e = n);
                var i = 0,
                    o = function() {};
                return {
                    s: o,
                    n: function() {
                        return i >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[i++]
                        }
                    },
                    e: function(e) {
                        throw e
                    },
                    f: o
                }
            }
            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }
        var a, s = !0,
            d = !1;
        return {
            s: function() {
                n = n.call(e)
            },
            n: function() {
                var e = n.next();
                return s = e.done, e
            },
            e: function(e) {
                d = !0, a = e
            },
            f: function() {
                try {
                    s || null == n.return || n.return()
                } finally {
                    if (d) throw a
                }
            }
        }
    }

    function r(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, i = new Array(t); n < t; n++) i[n] = e[n];
        return i
    }

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }
    var a = n(14),
        s = n(9),
        d = n(1),
        c = n(0),
        l = n(3);
    setTimeout((function() {
        var e = n(15),
            t = c.coreObj.config,
            r = n(2);
        r.init(t);
        var u = c.coreObj.metrics;
        u.auctions = [], u.lots = {}, c.pbjsObj.que = c.pbjsObj.que || [], a.init();
        var g = {
                parameters: {
                    environments: {
                        production: 0,
                        staging: 1,
                        testing: 2,
                        development: 3
                    }
                },
                labels: {
                    matchAny: function(e, t) {
                        "string" == typeof e && (e = [e]), "string" == typeof t && (t = [t]);
                        for (var n = 0; n < e.length; n++) {
                            var i = e[n];
                            if (-1 !== t.indexOf(i)) return !0
                        }
                        return !1
                    },
                    matchAll: function(e, t) {
                        "string" == typeof e && (e = [e]), "string" == typeof t && (t = [t]);
                        for (var n = 0; n < e.length; n++) {
                            var i = e[n];
                            if (-1 === t.indexOf(i)) return !1
                        }
                        return !0
                    },
                    matchNone: function(e, t) {
                        return !this.matchAny(e, t)
                    }
                },
                loadScriptAsync: function(e, t) {
                    var n = document.getElementsByTagName("script")[0],
                        i = document.createElement("script");
                    i.type = "text/javascript", i.src = e, i.async = !0, "function" == typeof t && (i.onload = function() {
                        d.debug("Finish loading: '" + e + "'"), t()
                    }), n.parentNode.insertBefore(i, n), d.info("Loading: '" + e + "'")
                },
                doOnDomReady: function(e) {
                    if ("interactive" === document.readyState || "complete" === document.readyState) e();
                    else {
                        d.info("DOM not ready yet. Queueing callback function."), document.addEventListener("DOMContentLoaded", (function t() {
                            document.removeEventListener("DOMContentLoaded", t, !1), d.info("DOM ready. Executing callback function."), e()
                        }), !1)
                    }
                },
                addTargetingKeyValueToAdServer: function(e, t, n) {
                    var i = e ? l.adServer.targeting[e] : null;
                    i && i.keyValues && (i.keyValues[t] = n)
                },
                getCoreObjName: function() {
                    return c.coreObjName
                },
                getCoreObj: function() {
                    return c.coreObj
                },
                getGeoTier: function(e) {
                    if (l.geoTier === c.udef) {
                        var t = 0;
                        ["IN", "PN", "CX", "MH", "MP", "SJ", "TV", "FK", "NR", "WF", "CF", "UM", "AI", "CC", "NF", "SH", "GL", "IO", "AQ", "SC", "MA", "ME", "MK", "FM", "VU", "NA", "VA", "GW", "PG", "MZ", "SL", "EG", "BA", "GE", "PW", "WS", "UG", "CI", "ML", "BW", "CV", "AD", "NC", "MS", "NG", "LR", "CD", "ID", "JO", "AL", "TM", "KM", "DZ", "AO", "BF", "KG", "AZ", "MW", "TJ", "TN", "CN", "ER", "KE", "TF", "DJ", "SN", "EH", "FO", "NU", "TG", "KH", "GH", "PK", "MN", "CK", "LB", "BJ", "MU", "ZW", "LY", "TZ", "MR", "UZ", "GM", "ZM", "VN", "FJ", "SZ", "PS", "MG", "TL", "TO", "AM", "MM", "NP", "ET", "SB", "RW", "CM", "LA", "LK", "LS", "YE", "BI", "SO", "AF", "BD", "TK", "BT"].indexOf(e) >= 0 && (d.debug("Tier-3 country found (" + e + ")."), t = 3), l.geoTier = t
                    }
                    return l.geoTier
                },
                addStyleToDocument: function(e, t) {
                    if (e) {
                        var n = document.head || document.getElementsByTagName("head")[0],
                            i = document.createElement("style");
                        i.type = "text/css", t && (i.id = t), i.appendChild(document.createTextNode(e)), n.appendChild(i)
                    }
                },
                initAdUnitCode: function(e) {
                    var n = t.elementPrefix;
                    n.length > 0 && (n += "-"), e.code = n + e.name + "-" + e.index
                },
                getAdUnitCode: function(e) {
                    for (var n = 0; n < t.adUnits.length; n++) {
                        var i = t.adUnits[n];
                        if (i.name === e) return i.code
                    }
                },
                removeBidderFromAdUnit: function(e, t) {
                    if (Array.isArray(null == t ? void 0 : t.bidders))
                        for (var n = t.bidders.length - 1; n >= 0; n--) {
                            t.bidders[n].bidder === e && (t.bidders.splice(n, 1), d.debug("Removing bidder '" + e + "' from adunit '" + t.name + "'."))
                        }
                },
                adUnitExistsInArray: function(e, t) {
                    if (Array.isArray(t))
                        for (var n = 0; n < t.length; n++) {
                            if (t[n].name === e) return !0
                        }
                    return !1
                },
                getPerformanceTimeStamp: function(e) {
                    e === c.udef && (e = 2);
                    var t = g.getPerformanceNow(),
                        n = "ms";
                    return t / 1e3 >= 1 && (e += 2, t /= 1e3, n = "s"), t.toFixed(e) + n
                },
                getPerformanceNow: c.wPerf && c.wPerf.now ? function() {
                    return Math.floor(c.wPerf.now())
                } : function() {
                    return -1
                },
                metrics: {
                    recordTiming: function(e, t, n) {
                        t === c.udef && (t = "adngin"), n === c.udef && (n = g.getPerformanceNow()), u.timing[t] = u.timing[t] || {}, u.timing[t][e] = u.timing[t][e] || [], u.timing[t][e].push(n)
                    },
                    getDuration: function(e, t, n, i) {
                        return i === c.udef && (i = 0), u.timing[e] && u.timing[e][t] && u.timing[e][n] && u.timing[e][t][i] && u.timing[e][n][i] ? u.timing[e][n][i] - u.timing[e][t][i] : -1
                    },
                    getTimestamp: function(e, t, n) {
                        return n === c.udef && (n = 0), u.timing[e] && u.timing[e][t] && u.timing[e][t][n] ? u.timing[e][t][n] : -1
                    }
                },
                getElementMarginsAndViewportSize: function(e) {
                    var t = document.getElementById(e);
                    if (null === t) return null;
                    var n = t.getClientRects();
                    if (!n || !n.length) return null;
                    for (var i, r = 1e10, o = -1e10, a = 0; a < n.length; a++) r = r > (i = n[a]).top ? i.top : r, o = o < i.bottom ? i.bottom : o;
                    return {
                        top: r,
                        bottom: o,
                        viewportHeight: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
                    }
                },
                getAbsoluteVerticalViewabilityDistanceForElementId: function(e) {
                    var t = g.getElementMarginsAndViewportSize(e);
                    if (!t) return 1 / 0;
                    var n = (t.bottom + t.top) / 2,
                        i = n - t.viewportHeight;
                    return (n ^ i) >>> 31 ? 0 : ~~Math.min(Math.abs(n), Math.abs(i))
                },
                isElementInsideViewport: function(e) {
                    var t = g.getElementMarginsAndViewportSize(e.placement);
                    if (t) {
                        var n = t.top,
                            i = t.bottom,
                            r = t.viewportHeight;
                        if (i >= n && i > 0 && n < r) {
                            var o = i - n;
                            return 0 == o || ((i = i > r ? r : i) - (n = n < 0 ? 0 : n)) / o >= e.viewPercent
                        }
                    }
                    return !1
                },
                isAdUnitInView: function(e, t) {
                    return !!g.isDocumentVisible() && g.isElementInsideViewport(g.getAdUnitPlacementSettings(e, t))
                },
                getAdUnit: function(e, n) {
                    for (var i = 0; i < (t.adUnits || []).length; i++) {
                        var r = t.adUnits[i];
                        if (r.name === e && r.code === n) return r
                    }
                    return null
                },
                getAdUnitPlacementSettings: function(e, t) {
                    return "string" == typeof e && (e = g.getAdUnit(e, b.adaptive.getAdaptiveBasePlacement(t))), {
                        placement: b.parallax.getAdUnitPlacement(e) || t,
                        viewPercent: b.parallax.isAdUnitParallax(e) ? 1 : .5
                    }
                },
                isDocumentVisible: function() {
                    return !document.visibilityState || "visible" === document.visibilityState
                },
                queue: {
                    pushCallback: function(e, t) {
                        e.push = function(n) {
                            Array.prototype.push.call(e, n), d.debug("Added new element to queue:", n), t(e)
                        }
                    },
                    process: function(e) {
                        if (e === c.udef && (e = []), !e.isProcessing && e.length > 0) {
                            if (e.isProcessing = !0, d.debug("Processing " + c.coreObjName + ".queue. Queue length:", e.length), "function" == typeof e[0]) try {
                                d.debug("Executing queue element:", e[0]), e[0]()
                            } catch (e) {
                                d.error(c.coreObjName + ".queue element error: ", e)
                            } else d.error(c.coreObjName + ".queue element error: detected " + o(e[0]) + " instead of function");
                            e.splice(0, 1), e.isProcessing = !1, e.length > 0 && g.queue.process(e)
                        }
                    }
                },
                runCallback: function(e, t, n) {
                    if (!e) return !1;
                    if (n === c.udef && (n = !0), "function" != typeof e) return d.error("Callback is not a function(): ", e), !1;
                    try {
                        return e(t, n)
                    } catch (e) {
                        return d.error("Callback error: ", e), !1
                    }
                },
                api: {
                    commands: {
                        getConfig: function(e, n, i) {
                            var r = t;
                            return g.runCallback(n, {
                                message: i + "data returned.",
                                data: r
                            }, !0), r
                        },
                        getStatus: function(e, t, n) {
                            var i = l;
                            return g.runCallback(t, {
                                message: n + "data returned.",
                                data: i
                            }, !0), i
                        },
                        getEvents: function(e, t, n) {
                            var i = Object.keys(c.coreEvents).map((function(e) {
                                return c.coreEvents[e]
                            }));
                            return g.runCallback(t, {
                                message: n + "data returned.",
                                data: i
                            }, !0), i
                        },
                        disableAutoRunAuction: function(e, n, i) {
                            return t.auction.autoRun = !1, g.runCallback(n, {
                                message: i + "Autorun auction disabled.",
                                data: null
                            }, !0), !0
                        },
                        startAuction: function(e, t, n) {
                            var i = g.startAuction(e);
                            return g.runCallback(t, {
                                message: n + "Starting auction.",
                                data: null
                            }, i), !0
                        },
                        disableAutoCallAdServer: function(e, n, i) {
                            return t.adServer.autoCall = !1, g.runCallback(n, {
                                message: i + "Autocall ad-server disabled.",
                                data: null
                            }, !0), !0
                        },
                        callAdServer: function(e, t, n) {
                            return l.adServer.isManualCall = !0, g.callAdServer(), g.runCallback(t, {
                                message: n + "Calling ad-server.",
                                data: null
                            }, !0), !0
                        },
                        setCustomAuctionLabels: function(e, t, n) {
                            var i, r, o = l.targetingFilter.customLabels;
                            try {
                                if (!Array.isArray(e)) throw new TypeError("Expecting argument of type Array");
                                for (i = 0; i < e.length; i++)
                                    if ("string" != typeof(r = e[i])) throw new TypeError("Expecting argument array of elements of type String")
                            } catch (e) {
                                return g.api.handleError(n, t, e)
                            }
                            for (i = 0; i < e.length; i++) r = e[i], -1 === o.indexOf(r) && o.push(r);
                            return g.runCallback(t, {
                                message: n + "Custom auction labels for next auction: (" + o.join(", ") + ")",
                                data: o
                            }, !0), !0
                        },
                        addGoogletagAdSlots: function(e, t, n) {
                            d.warn("Function is deprecated. Please replace with 'setGoogletagAdSlots'."), g.api.commands.setGoogletagAdSlots(e, t, n)
                        },
                        setGoogletagAdSlots: function(e, t, n) {
                            try {
                                if (!Array.isArray(e)) throw new TypeError("Expecting argument of type Array");
                                for (var i = [], r = 0; r < e.length; r++) {
                                    if ("function" != typeof e[r].getSlotElementId) throw new TypeError("Expecting argument Array elements of type googletag.Slot");
                                    i.push(e[r].getSlotElementId())
                                }
                            } catch (e) {
                                return g.api.handleError(n, t, e)
                            }
                            l.adServer.additionalAdSlots = e, l.adServer.additionalAdSlotsSetProgramatically = !0;
                            var o = n + "Added existing googletag adSlots for element ids '" + i.join("', '") + "' for ad-server call.";
                            return d.info(o), g.runCallback(t, {
                                message: o,
                                data: i
                            }, !0), !0
                        },
                        setGoogletagAdSlotElementIds: function(e, t, n) {
                            try {
                                if (!Array.isArray(e)) throw new TypeError("Expecting argument of type Array");
                                for (var i = 0; i < e.length; i++)
                                    if ("string" != typeof e[i]) throw new TypeError("Expecting argument Array elements of type String")
                            } catch (e) {
                                return g.api.handleError(n, t, e)
                            }
                            l.adServer.additionalAdSlotsElementIds = e, l.adServer.additionalAdSlotsElementIdsSetProgramatically = !0;
                            var r = n + "Added googletag adSlots element Ids '" + e.join("', '") + "' for ad-server call.";
                            return g.runCallback(t, {
                                message: n + "Added googletag adSlot for element ids " + e.join(", ") + ".",
                                data: e
                            }, !0), d.info(r), !0
                        },
                        getMetrics: function(e, t, n) {
                            var i = JSON.stringify(u),
                                r = JSON.parse(i);
                            return g.runCallback(t, {
                                message: n + "Returning metrics.",
                                data: r
                            }, !0), r
                        },
                        getTimeline: function(e, t, n) {
                            var i = {},
                                r = JSON.parse(JSON.stringify(u.timing));
                            for (var o in r)
                                for (var a in r[o]) r[o][a].forEach((function(e) {
                                    i[e] = {
                                        name: o,
                                        action: a
                                    }
                                }));
                            return g.runCallback(t, {
                                message: n + "Returning timeline.",
                                data: i
                            }, !0), i
                        },
                        getActiveLots: function(e, t, n) {
                            return g.runCallback(t, {
                                message: n + "Returning active lots.",
                                data: l.activeLots
                            }, !0), l.activeLots
                        },
                        getAvailableAdUnitNames: function(e, n, i) {
                            for (var r = [], o = 0; o < t.adUnits.length; o++) r.push(t.adUnits[o].name);
                            return g.runCallback(n, {
                                message: i + "Returning available ad-unit names.",
                                data: r
                            }, !0), r
                        },
                        showLog: function(e, t, n) {
                            var i = d.getHistory();
                            return d.showHistory(), g.runCallback(t, {
                                message: n + "Showing log history.",
                                data: i
                            }, !0), !0
                        },
                        enableDebug: function(e, t, n) {
                            return g.debugMode.enable(), g.runCallback(t, {
                                message: n + "Debug mode enabled.",
                                data: null
                            }, !0), !0
                        },
                        disableDebug: function(e, t, n) {
                            return g.debugMode.disable(), g.runCallback(t, {
                                message: n + "Debug mode disabled.",
                                data: null
                            }, !0), !0
                        }
                    },
                    handleError: function(e, t, n) {
                        var i = e + n.name + ": " + n.message;
                        return g.runCallback(t, {
                            message: i,
                            data: null
                        }, !1), d.error(i), !1
                    },
                    executeCommand: function(e, t, n, i, r) {
                        return d.debug("Calling command '" + c.coreObjName + ".cmd." + e + "()'"), null !== n && m.wasEventAlreadyDispatched(n) ? (d.error("Command '" + c.coreObjName + ".cmd." + e + "()' needs to be called before event '" + n + "'."), !1) : null === t || m.wasEventAlreadyDispatched(t) ? (d.debug("Executing command '" + c.coreObjName + ".cmd." + e + "()'"), g.api.commands[e](i, r, e + "(): ")) : (d.debug("Queuing command '" + c.coreObjName + ".cmd." + e + "()' until event '" + t + "' triggers"), void m.addEventListener(t, (function() {
                            return d.debug("Executing command '" + c.coreObjName + ".cmd." + e + "()'"), g.api.commands[e](i, r, e + "(): ")
                        }), {
                            oneTimeEvent: !0
                        }))
                    }
                },
                init: function() {
                    var e, n, i, o, a, s, v, h = function() {
                        function e() {
                            var e = -1,
                                t = c.wPerf.timing;
                            c.wPerf && (c.wPerf.getEntriesByType && c.wPerf.getEntriesByType("navigation").length ? e = c.wPerf.getEntriesByType("navigation")[0].domContentLoadedEventEnd : t && (e = t.domContentLoadedEventEnd - t.fetchStart)), e = Math.floor(e), u.session.domReady = e, d.info("DOM ready after " + e + "ms."), g.metrics.recordTiming("domReady", "session", e)
                        }
                        if ("interactive" === document.readyState || "complete" === document.readyState) e();
                        else {
                            document.addEventListener("DOMContentLoaded", (function t() {
                                e(), document.removeEventListener("DOMContentLoaded", t)
                            }), !1)
                        }
                    };
                    t.htmlLanguage = document.documentElement.lang, l.availableBidders = g.getAllAvailableBidders(), g.getAdServerDeclarativeSettings(),
                        function() {
                            for (var e in l.subsystems = l.subsystems || {}, p) !1 !== r.get("subsystems.".concat(e, ".enabled")) ? p[e] && p[e].init ? (d.debug("Initializing subsystem '" + e + "'."), p[e].init(g)) : d.warn("Subsystem '" + e + "' can't be inizialised.") : d.warn("Subsystem '" + e + "' is disabled.")
                        }(), e = navigator.userAgent, n = new RegExp("Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune", "i"), i = new RegExp("(?:ipad|playbook|tablet|(?:android(?!.*(nexus|sm-(?:g9|n9|a10)))|bbd+|meego|silk)(?! .+? mobile))", "i"), o = n.test(e), a = i.test(e), s = "otherplatform", v = "otheros", o || a ? (o && (s = "mobile"), a && (s = "tablet"), /iPad|iPhone|iPod/i.test(e) ? v = "ios" : -1 !== e.toLowerCase().indexOf("android") ? v = "android" : -1 !== e.toLowerCase().indexOf(".net") && (v = "windows")) : (s = "desktop", -1 !== e.toLowerCase().indexOf("windows") ? v = "windows" : -1 !== e.toLowerCase().indexOf("macintosh") ? v = "macos" : -1 !== e.toLowerCase().indexOf("linux") && (v = "linux")), t.platform = s, t.os = v,
                        function() {
                            g.targetingFilter.init();
                            var e = g.targetingFilter.getStaticLabels();
                            d.info("Static session targeting labels: '" + e.join("', '") + "'."), g.targetingFilter.filterDomainConfiguration(e)
                        }(),
                        function() {
                            var e = t.modules;
                            if (e) {
                                var n = g.getGeoTier(r.get("country")),
                                    i = {
                                        1: [],
                                        2: [],
                                        3: ["smartRefresh", "adaptive"]
                                    }[n] || [];
                                for (var o in b) d.debug("Initializing module '" + o + "'."), i.indexOf(o) >= 0 ? d.debug("Module '" + o + "' is blacklisted for Tier-" + n + " countries, so is being disabled.") : e[o] ? !0 === e[o].enabled ? b[o] && b[o].init && b[o].init(g, u) : d.debug("Module '" + o + "' is disabled.") : d.debug("Module '" + o + "': Configuration not found.");
                                return !0
                            }
                        }(), c.coreObj.queue = c.coreObj.queue || [], g.queue.pushCallback(c.coreObj.queue, (function(e) {
                            g.queue.process(e)
                        })), c.coreObj.queue.length > 0 && g.queue.process(c.coreObj.queue),
                        function() {
                            function e() {
                                c.pbjsObj.que.push((function() {
                                    var e = g.metrics.getTimestamp("pbjs", "queued").toFixed(0) + "ms",
                                        t = g.metrics.getTimestamp("pbjs", "requested").toFixed(0) + "ms",
                                        n = g.metrics.getDuration("pbjs", "requested", "loaded").toFixed(0) + "ms",
                                        i = g.metrics.getDuration("pbjs", "loaded", "apiReady").toFixed(0) + "ms";
                                    d.info("Pbjs " + c.pbjsObj.version + " ready. Queued at: " + e + ". Requested at: " + t + ". Load in: " + n + ". API ready in: " + i + ".")
                                }))
                            }

                            function n(e) {
                                c.pbjsObj.que.push((function() {
                                    c.pbjsObj.setConfig(e)
                                }))
                            }
                            c.pbjsObj.bidderSettings = c.pbjsObj.bidderSettings || {},
                                function() {
                                    d.debug("Initializing ad-units.");
                                    for (var e = t.adUnits, n = 0; n < e.length; n++) {
                                        var i = e[n];
                                        i.index = 0, (!i.hasOwnProperty("code") || i.hasOwnProperty("code") && 0 === i.code.length) && g.initAdUnitCode(i), t.exp && (i.snigel = i.snigel || {}, i.snigel.exp = t.exp)
                                    }
                                }(), n(t.pbjsConfig),
                                function() {
                                    g.parameters.environments[c.coreObj.config.environment] >= 2 && n({
                                        debug: !0
                                    });
                                    var e = t.bidding.adServerCurrency.toUpperCase();
                                    if (n({
                                            currency: {
                                                adServerCurrency: e,
                                                rates: t.currencyRates
                                            },
                                            improvedigital: {
                                                usePrebidSizes: !0,
                                                singleRequest: !0
                                            }
                                        }), !1 !== t.bidding.bidFloorEnabled) {
                                        var i = t.bidding.floorCpm || .05,
                                            r = t.bidding.videoFloorCpm || .7;
                                        n({
                                            floors: {
                                                enforcement: {
                                                    enforcePBS: !0,
                                                    enforceJS: !0,
                                                    bidAdjustment: !0
                                                },
                                                data: {
                                                    currency: e,
                                                    default: i,
                                                    schema: {
                                                        fields: ["mediaType"]
                                                    },
                                                    values: {
                                                        video: r,
                                                        "*": i
                                                    }
                                                },
                                                floorMin: i,
                                                skipRate: 0
                                            }
                                        })
                                    }
                                    p.consentManagement.executeOnConsentResolved((function() {
                                        l.consent.googleConsent && l.adServer.enabled || (n({
                                            floors: {}
                                        }), d.info("Ad-server disabled, disabling bid floor of ".concat(i, " ").concat(e, ".")))
                                    }))
                                }(), t.pbjsAnalytics && t.pbjsAnalytics.providers && t.pbjsAnalytics.providers.length > 0 && c.pbjsObj.que.push((function() {
                                    c.pbjsObj.enableAnalytics(t.pbjsAnalytics.providers), d.debug("Enabling prebid.js analytics providers: '" + t.pbjsAnalytics.providers.map((function(e) {
                                        return e.provider
                                    })).join("', '") + "'.")
                                })), c.snConf.resources.pbjs.loaded ? e() : c.snConf.resources.pbjs.scriptElement.addEventListener("load", e)
                        }(),
                        function() {
                            if (c.snConf.resources.gpt) {
                                g.parameters.environments[c.coreObj.config.environment] >= 2 && (f.addEventListener("slotOnload", (function(e) {
                                    d.debug("slotOnload: creative's iframe load event fired for '" + e.slot.getSlotElementId() + "'")
                                })), f.addEventListener("impressionViewable", (function(e) {
                                    d.debug("impressionViewable: ad-impression viewable according to active view criteria for '" + e.slot.getSlotElementId() + "'")
                                })), f.addEventListener("slotRenderEnded", (function(e) {
                                    d.debug("adSlotRenderEnded: creative code injected into adslot for '" + e.slot.getSlotElementId() + "'.\n\tSlot response data:", JSON.parse(JSON.stringify(e.slot.getResponseInformation())))
                                }))), googletag.cmd.push((function() {
                                    googletag.pubads().disableInitialLoad(), googletag.pubads().enableAsyncRendering(), googletag.pubads().enableSingleRequest(), googletag.enableServices()
                                }));
                                var e = function() {
                                    googletag.cmd.push((function() {
                                        var e = g.metrics.getTimestamp("gpt", "queued").toFixed(0) + "ms",
                                            t = g.metrics.getTimestamp("gpt", "requested").toFixed(0) + "ms",
                                            n = g.metrics.getDuration("gpt", "requested", "loaded").toFixed(0) + "ms",
                                            i = g.metrics.getDuration("gpt", "loaded", "apiReady").toFixed(0) + "ms";
                                        d.info("Gpt " + googletag.getVersion() + " ready. Queued at: " + e + ". Requested at: " + t + ". Load in: " + n + ". API ready in: " + i + ".")
                                    }))
                                };
                                c.snConf.resources.gpt.loaded ? e() : c.snConf.resources.gpt.scriptElement.addEventListener("load", e)
                            }
                        }(),
                        function() {
                            var e = {
                                uuid: c.uuid,
                                cfwUuid: t.cfwUuid,
                                init: Math.floor(Date.now() - g.getPerformanceNow()),
                                tzOffset: (new Date).getTimezoneOffset(),
                                tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
                                site: window.location.hostname,
                                path: window.location.pathname,
                                country: t.country,
                                region: t.region,
                                userAgent: navigator.userAgent,
                                cfwUserAgent: t.cfwUserAgent,
                                platform: t.platform,
                                os: t.os,
                                environment: t.environment,
                                build: t.build,
                                id: t.id
                            };
                            u.session = e, h(), c.coreObj.info = u.session, l.coreReady = !0, d.debug("Available bidders: '" + l.availableBidders.join("', '") + "'.");
                            var n = [];
                            "otherplatform" === t.platform && n.push("platform"), "otheros" === t.os && n.push("os"), n.length > 0 && d.warn("Could not identify '" + n.join("', ") + "' from UA."), m.dispatchEvent(c.coreEvents.coreReady, {
                                isUnique: !0,
                                eventDetail: e
                            }), g.start()
                        }()
                },
                start: function() {
                    var e;
                    if (c.snPubConf.adengine) {
                        var n, i = !0;
                        if (void 0 !== c.snPubConf.adengine.activeLots)
                            if (n = c.snPubConf.adengine.activeLots, Array.isArray(n) && n.length > 0) {
                                for (var r = 0; r < n.length; r++) {
                                    var o = n[r];
                                    if ("string" != typeof o.adUnit || "string" != typeof o.placement || !o.adUnit.length || !o.placement.length) {
                                        i = !1, d.error("Error: 'window.snigelPubConf.adengine.activeLots' array element is not of type { adUnit: <string>, placement: <string> } . Ignoring property.");
                                        break
                                    }
                                }
                                i && d.info("Detected active lots in snigel publisher configuration:\n\t" + n.map((function(e) {
                                    return "(" + e.placement + ":" + e.adUnit + ")"
                                })).join("\n\t"))
                            } else Array.isArray(n) || null === n ? d.warn("Snigel publisher configuration for auction lots found, but is empty. Auction will skip bidding.") : (i = !1, d.error("Error: 'window.snigelPubConf.adengine.activeLots' is not of type 'Array'. Ignoring property."));
                        else if (void 0 !== c.snPubConf.adengine.activeAdUnits)
                            if (n = c.snPubConf.adengine.activeAdUnits, Array.isArray(n) && n.length > 0) {
                                for (var a = 0; a < n.length; a++)
                                    if ("string" != typeof n[a]) {
                                        i = !1, d.error("Error: 'window.snigelPubConf.adengine.activeAdUnits' array element is not of type 'String'. Ignoring property.");
                                        break
                                    }
                                i && d.info("Detected active ad-units in snigel publisher configuration:\n\t" + n.join("\n\t"))
                            } else Array.isArray(n) || null === n ? d.warn("Snigel publisher configruation for auction ad-units found, but is empty. Auction will skip bidding.") : (i = !1, d.error("Error: 'window.snigelPubConf.adengine.activeAdUnits' is not of type 'Array'. Ignoring property."));
                        i && (e = n)
                    }(t.auction.autoRun || e !== c.udef) && g.startAuction(e)
                },
                auction: {
                    init: function(e) {},
                    start: function() {},
                    end: function() {},
                    bidding: {},
                    adServer: {}
                },
                processInterstitials: function() {
                    var e = [],
                        n = [];
                    if (t.adUnits.forEach((function(t) {
                            t.interstitial && (t.bidders = [], t.sizeMapping = {
                                banner: {
                                    biddingSizes: [
                                        [1, 1]
                                    ]
                                }
                            }, delete t.adaptive, delete t.adhesive, delete t.autoAds, delete t.parallax, delete t.smartRefresh, delete t.snConfig, delete t.sticky, e.push(t), t.interstitial.manual || n.push(t), t.interstitial.manual = !0)
                        })), n.length > 0) {
                        var i = l.auction.requestedLots || {};
                        e.some((function(e) {
                            if (i[e.code]) return !0
                        })) || n.forEach((function(e) {
                            i[e.code] = {
                                placement: e.code,
                                adUnit: e.name
                            }
                        }))
                    }
                },
                getRequestedAdUnits: function() {
                    var e = [],
                        n = t.adUnits,
                        i = l.auction.requestedLots || {};
                    for (var r in i)
                        for (var o = i[r].adUnit, a = 0; a < n.length; a++) {
                            var s = n[a];
                            if (o === s.name) {
                                var d = l.auction.waitingTimeoutLots[r];
                                if (d) d.lot = JSON.parse(JSON.stringify(i[r]));
                                else {
                                    var c = JSON.parse(JSON.stringify(s));
                                    c.code = r, e.push(c)
                                }
                            }
                        }
                    return e
                },
                startAuction: function(e) {
                    if (l.auction.deferredBy.length > 0) return d.info("Starting auction deferred by '" + l.auction.deferredBy.join("', '") + "'."), !1;
                    var n = function() {
                            g.processInterstitials();
                            var e = g.getRequestedAdUnits();
                            d.info("Filtering lots...");
                            var t = g.targetingFilter.getFilteredAdUnits(e, l.auction.activeLabels, {
                                inplace: !0
                            });
                            m.dispatchEvent(c.coreEvents.coreAuctionAdUnitsFiltered), d.info("Size-mapping lots..."), g.sizeMapper.processAdUnits(t), m.dispatchEvent(c.coreEvents.coreAuctionAdUnitsSizeMapped),
                                function(e) {
                                    for (var t = l.auction.adUnits = [], n = l.auction.pbjsAdUnits = [], i = l.auction.requestedLots, r = 0; r < e.length; r++) {
                                        var o, a, u = e[r],
                                            f = i[u.code];
                                        if (u.adUnitPathOverride) {
                                            var v = f.adUnitPath;
                                            if ("string" == typeof v && v.length > 0) {
                                                var p = u.adUnitPathRegex;
                                                "string" == typeof p && p.length > 0 ? new RegExp(p).test(v) ? u.adUnitPath = v : d.warn("Provided adUnitPath '" + v + "' does not match given regex '" + p + "'. Used path will be default '" + u.adUnitPath + "'.") : u.adUnitPath = v
                                            }
                                        }
                                        u.ortb2Imp || (u.ortb2Imp = {}), (o = u.ortb2Imp).ext || (o.ext = {}), (a = u.ortb2Imp.ext).data || (a.data = {}), u.ortb2Imp.ext.gpid = u.name + "#" + u.code, u.ortb2Imp.ext.data.pbadslot = u.ortb2Imp.ext.gpid, (f.blacklistBidders || []).forEach((function(e) {
                                            g.removeBidderFromAdUnit(e, u)
                                        }));
                                        var h = u.bidders;
                                        if (u.bidders.length > 0 && u.snConfig) {
                                            var y, A, w, S = u.mediaTypes.banner && u.mediaTypes.banner.sizes || [
                                                    [300, 225]
                                                ],
                                                E = !!u.snConfig.video,
                                                L = !!u.snConfig.native;
                                            if (L) {
                                                var C = S[Math.floor(Math.random() * S.length)],
                                                    x = C[0] || 1,
                                                    T = C[1] || 1,
                                                    j = x / T,
                                                    O = j < 1 ? 1 : j > 2 ? 2 : 3,
                                                    P = 1;
                                                2 == O && x < 400 || 1 == O && x < 150 ? P = T < 90 ? .4 : .6 : (1 == O && x < 250 || 3 == O) && (P = .8), y = '<style onload=\'var iframes=window.parent.document.getElementsByTagName("iframe");for(var i=0;i<iframes.length;i++){if(iframes[i].contentWindow===window){iframes[i].style.width="' + x + 'px";iframes[i].style.height="' + T + 'px";iframes[i].setAttribute("width",' + x + ');iframes[i].setAttribute("height",' + T + ");}}'>" + ".sponsored-post{background-color:white;width:" + x + "px;height:" + T + "px}.thumbnail{display:inline-block;background-size:contain;background-repeat:no-repeat;" + (2 == O ? "vertical-align:middle;height:100%" : "width:100%") + "}.thumbnail img{" + (2 == O ? "height:100%" : "width:100%") + "}#content{background-color:white;" + (3 == O ? "position:absolute;bottom:0;" : "display:inline-block;") + (2 == O ? "vertical-align:middle;max-height:" + (T - 2) + "px;padding:0" : "padding:15px") + " 15px;" + (2 != O ? "text-align:center" : "") + "}.pb-click{position:absolute;top:0;left:0;right:0;bottom:0;border:1px solid lightgray;color:gray;cursor:pointer;word-break:break-word;font-size:" + P + "rem}.pb-click h1{color:black;margin-top:" + (1 == O ? "1em" : "0") + ";margin-bottom:" + (2 == O && T < 180 ? "0.5em" : "1em") + "}.pb-click p{margin-bottom:" + (2 == O ? "0.5em" : "1em") + "}.attribution{position:absolute;bottom:0;right:0;background-color:gray;color:white;padding:2px}</style><div class='sponsored-post'><div class='pb-click' onclick='window.open(\"##hb_native_linkurl##\")'><div class='thumbnail' style='background-image: url(##hb_native_image##);'><img src='##hb_native_image##' style='visibility:hidden;'" + (2 == O ? ' onload=\'document.getElementById("content").style.maxWidth=(' + (x - 2 - 30 - 2) + '-this.offsetWidth)+"px"\'' : "") + "></div><div id='content'><h1>##hb_native_title##</h1><p>##hb_native_body##</p></div><div class='attribution'>##hb_native_brand##</div></div></div>"
                                            }
                                            E && (A = [0, 0], S.forEach((function(e) {
                                                A[0] < e[0] && (A[0] = e[0]), A[1] < e[1] && (A[1] = e[1])
                                            })), (w = function(e) {
                                                l.videoTimeouts[e] && (clearTimeout(l.videoTimeouts[e]), delete l.videoTimeouts[e])
                                            })(u.code));
                                            var U = function(e, i, r, o, a, c) {
                                                    var u, g = JSON.parse(JSON.stringify(e));
                                                    if (g.mediaTypes = o && g.mediaTypes || {}, c && (g.mediaTypes.native = {
                                                            adTemplate: y,
                                                            title: {
                                                                required: !0,
                                                                len: 80
                                                            },
                                                            body: {
                                                                required: !1,
                                                                len: 400
                                                            },
                                                            image: {
                                                                required: !0,
                                                                aspect_ratios: [{
                                                                    min_width: 300,
                                                                    min_height: 300,
                                                                    ratio_width: 1,
                                                                    ratio_height: 1
                                                                }, {
                                                                    min_width: 400,
                                                                    min_height: 300,
                                                                    ratio_width: 4,
                                                                    ratio_height: 3
                                                                }, {
                                                                    min_width: 300,
                                                                    min_height: 200,
                                                                    ratio_width: 3,
                                                                    ratio_height: 2
                                                                }, {
                                                                    min_width: 480,
                                                                    min_height: 300,
                                                                    ratio_width: 16,
                                                                    ratio_height: 10
                                                                }, {
                                                                    min_width: 480,
                                                                    min_height: 270,
                                                                    ratio_width: 16,
                                                                    ratio_height: 9
                                                                }, {
                                                                    min_width: 400,
                                                                    min_height: 200,
                                                                    ratio_width: 2,
                                                                    ratio_height: 1
                                                                }]
                                                            },
                                                            sponsoredBy: {
                                                                required: !0,
                                                                len: 30
                                                            },
                                                            clickUrl: {
                                                                required: !0,
                                                                len: 4096
                                                            },
                                                            privacyLink: {
                                                                required: !1,
                                                                len: 512
                                                            }
                                                        }), a && (g.mediaTypes.video = {
                                                            context: "outstream",
                                                            playerSize: A,
                                                            mimes: ["video/mp4", "video/webm"],
                                                            minduration: 0,
                                                            maxduration: 300,
                                                            skippable: !0,
                                                            skip: 1,
                                                            playback_method: ["auto_play_sound_off"],
                                                            frameworks: [1],
                                                            playbackmethod: [2],
                                                            placement: 2,
                                                            api: [2],
                                                            protocols: [2, 3, 5, 6, 7, 8],
                                                            linearity: 1
                                                        }, g.mediaTypes.video.renderer = {
                                                            url: "https://acdn.adnxs.com/video/outstream/ANOutstreamVideo.js",
                                                            backupOnly: !1,
                                                            render: (u = g.mediaTypes.video, function(e) {
                                                                var t = (e.vastXml || "").toLowerCase();
                                                                if (t.indexOf("<vast ") >= 0) {
                                                                    var n = u.playerSize[0],
                                                                        i = u.playerSize[1],
                                                                        r = function(e) {
                                                                            var n, i = t.split(e);
                                                                            if (i.length > 1) {
                                                                                var r = -1,
                                                                                    o = !1;
                                                                                for (n = 0, i = i[1]; i[++r] >= "0" && i[r] <= "9" || !o;) i[r] >= "0" && i[r] <= "9" && (o = !0, n = 10 * n + (i[r] - "0"))
                                                                            }
                                                                            return n
                                                                        },
                                                                        o = r("width"),
                                                                        a = r("height"),
                                                                        c = 1.77777778;
                                                                    o > 0 && a > 0 ? c = o / a : d.info("Unable to fetch video dimensions, assuming 16:9 video ratio"), n / i > c && (n = Math.floor(c * i)), d.info("Rendering ad with appnexus player in '" + e.adUnitCode + "' with max size [" + n + ", " + i + "]"), e.renderer.push((function() {
                                                                        for (var r, o = !1, a = function() {
                                                                                var e = 0,
                                                                                    n = t.split("<duration>");
                                                                                if (n.length > 1 && (n = n[1].split("</duration>")[0]).length > 0) {
                                                                                    for (var i = 1, r = (n = n.split(":")).length - 1; r >= 0; r--) e += (Number.parseFloat(n[r]) || 0) * i, i *= 60;
                                                                                    e *= 1e3
                                                                                }
                                                                                return e || 4e4
                                                                            }() / 2, c = (document.getElementById(e.adUnitCode) || {}).children || [], g = 0; g < c.length; g++)(c[g].id || "").startsWith("google_ads_iframe") && (c[g].style.height = 0);
                                                                        window.ANOutstreamVideo.renderAd({
                                                                            tagId: e.adResponse && e.adResponse.tag_id,
                                                                            sizes: [
                                                                                [n, i]
                                                                            ],
                                                                            targetId: e.adUnitCode,
                                                                            uuid: e.adResponse && e.adResponse.uuid,
                                                                            adResponse: {
                                                                                content: e.vastXml || e.ad
                                                                            },
                                                                            rendererOptions: {
                                                                                player_width: n,
                                                                                player_height: i,
                                                                                playback_methods: u.playback_method,
                                                                                disableCollapse: {
                                                                                    enabled: !0,
                                                                                    replay: !1
                                                                                },
                                                                                cbNotification: function(t, n, i, c) {
                                                                                    if (d.debug("Video event: type=" + t + "; event=" + n + "; placement=" + i + "; parameters=", c), "VAST" === t) {
                                                                                        var u = function() {
                                                                                            o && b.smartRefresh && (o = !1, b.smartRefresh.triggerLotSmartRefresh(i, (Date.now() - r) / 1e3))
                                                                                        };
                                                                                        "start" === n ? (r = Date.now(), b.smartRefresh && (b.smartRefresh.cancelLotSmartRefresh(i), o = !0)) : "complete" === n && (w(i), u()), o && (w(i), l.videoTimeouts[i] = setTimeout((function() {
                                                                                            u()
                                                                                        }), a)), window.argus && window.argus.cmd.push((function() {
                                                                                            window.argus.notify && window.argus.notify("video", n, e, s.now())
                                                                                        }))
                                                                                    }
                                                                                }
                                                                            }
                                                                        })
                                                                    }))
                                                                } else if (e.vastUrl) {
                                                                    e.usedVastUrl = e.vastUrl, delete e.vastUrl;
                                                                    var g = new XMLHttpRequest;
                                                                    g.onload = function() {
                                                                        e.vastXml = g.responseText, e.renderer.push((function() {
                                                                            e.renderer.render(e)
                                                                        }))
                                                                    }, g.open("GET", e.usedVastUrl, !0), g.send()
                                                                } else d.fatal("Unable to fetch both vastXml nor vastUrl parameters from bid reply. Video won't render. Received bid was: ", e)
                                                            })
                                                        }, r && Array.isArray(i)))
                                                        for (var f = i.length - 1; f >= 0; f--) {
                                                            var m = r[i[f].bidder].fixedParams;
                                                            if (i[f].params = i[f].params || {}, m || i[f].params.videoTags) {
                                                                i[f] = JSON.parse(JSON.stringify(i[f]));
                                                                var v = i[f].params;
                                                                if (m)
                                                                    for (var p in m) v[p] = m[p];
                                                                if (v.videoTags)
                                                                    for (var h in v.videoTags) v[h] = v.videoTags[h];
                                                                else {
                                                                    var S = i[f].bidder;
                                                                    r[S].needsAdditional && (i.splice(f, 1), l.debugMode && d.warn("Bidder '" + S + "' needs video tags to be defined, but none was found. Removing bidder from video request."))
                                                                }
                                                            }
                                                        }
                                                    i.length > 0 && (g.bids = i, t.push(g), n.push(g))
                                                },
                                                I = E ? {
                                                    "33across": 1,
                                                    amx: 1,
                                                    adagio: 1,
                                                    ix: 1
                                                } : {},
                                                R = L ? {
                                                    amx: 1,
                                                    adagio: 1,
                                                    ix: 1
                                                } : {},
                                                z = E ? {
                                                    openx: {
                                                        needsAdditional: 1
                                                    },
                                                    criteo: 1,
                                                    rubicon: {
                                                        fixedParams: {
                                                            video: {
                                                                size_id: 203
                                                            }
                                                        }
                                                    },
                                                    appnexus: 1,
                                                    onetag: 1,
                                                    smartadserver: 1
                                                } : {},
                                                k = L ? {
                                                    appnexus: 1
                                                } : {};
                                            h = [];
                                            var M = [],
                                                N = [],
                                                B = [],
                                                F = [],
                                                q = [];
                                            u.bidders.forEach((function(e) {
                                                var t = e.bidder,
                                                    n = I[t],
                                                    i = R[t],
                                                    r = z[t],
                                                    o = k[t];
                                                n && i ? M.push(e) : n ? N.push(e) : i ? B.push(e) : h.push(e), r && F.push(e), o && q.push(e)
                                            })), M.length > 0 && (d.info("Found multiformat bidders, creating separate config for them."), U(u, M, null, !0, !0, !0)), N.length > 0 && (d.info("Found banner video bidders, creating separate config for them."), U(u, N, null, !0, !0, !1)), B.length > 0 && (d.info("Found banner native bidders, creating separate config for them."), U(u, B, null, !0, !1, !0)), F.length > 0 && (d.info("Found separate video request bidders, creating config for them."), U(u, F, z, !1, !0, !1)), q.length > 0 && (d.info("Found separate native request bidders, creating config for them."), U(u, q, null, !1, !1, !0))
                                        }(h.length > 0 || 0 === u.bidders.length) && (u.bids = h, t.push(u), h.length > 0 && n.push(u)), l.auction.lots[u.code] = u.name;
                                        var D = l.activeLots[u.code] = l.activeLots[u.code] || {};
                                        D.adUnit = u.name, D.isSticky = u.isSticky || !1
                                    }
                                    m.dispatchEvent(c.coreEvents.coreAuctionAdUnitsSet)
                                }(t), m.dispatchEvent(c.coreEvents.coreAuctionAdUnitsReady)
                        },
                        r = function(e, t, n) {
                            var r = "string" == typeof e ? {
                                adUnit: t,
                                placement: n
                            } : JSON.parse(JSON.stringify(e));
                            if (c.snPubConf && c.snPubConf.adengine && void 0 !== c.snPubConf.adengine.activeLots) {
                                var o, a = i(c.snPubConf.adengine.activeLots);
                                try {
                                    for (a.s(); !(o = a.n()).done;) {
                                        var s = o.value;
                                        if (s.placement === r.placement && s.adUnit === r.adUnit) {
                                            Object.keys(s).forEach((function(e) {
                                                r[e] || (r[e] = s[e])
                                            }));
                                            break
                                        }
                                    }
                                } catch (e) {
                                    a.e(e)
                                } finally {
                                    a.f()
                                }
                            }
                            return r
                        },
                        o = function(e) {
                            var n = {};
                            try {
                                if (e === c.udef) n = function() {
                                    for (var e = {}, n = t.adUnits, i = 0; i < n.length; i++) {
                                        var r = n[i],
                                            o = !0;
                                        if (r.objectTargeting) {
                                            var a = g.targetingFilter.getStaticLabels();
                                            o = g.targetingFilter.getObjectTargetingResolution(r.objectTargeting, a, 0)
                                        }
                                        o && !e[r.code] && (e[r.code] = {
                                            adUnit: r.name,
                                            placement: r.code
                                        })
                                    }
                                    return e
                                }();
                                else {
                                    if (!Array.isArray(e) && null !== e) throw new TypeError("startAuction() expects argument of type Array()");
                                    if (null === e || 0 === e.length) return d.info("No lots requested. Skipping requesting bids."), !0;
                                    for (var i = 0; i < e.length; i++) {
                                        var o, a, s = e[i];
                                        if ("string" == typeof s) o = s, a = g.getAdUnitCode(s);
                                        else {
                                            if (!(s.adUnit && "string" == typeof s.adUnit && s.adUnit.length > 0 && s.placement && "string" == typeof s.placement && s.placement.length > 0)) throw new TypeError("startAuction() expects argument of type Array({adUnit: String, placement: String}) or Array(String)");
                                            o = s.adUnit, a = s.placement
                                        }
                                        if (g.adUnitExistsInArray(o, t.adUnits))
                                            if (n.hasOwnProperty(a)) {
                                                var u = n[a].adUnit,
                                                    f = o;
                                                d.warn("Lot placement conflict detected. Requested lot's (" + a + ":" + f + ") placement already used in lot (" + a + ":" + u + ").");
                                                for (var m = {}, v = 0; v <= t.adUnits.length; v++) {
                                                    var p = t.adUnits[v];
                                                    if (p.name === u && (m.original = p), p.name === f && (m.conflicting = p), m.original && m.conflicting) break
                                                }
                                                var b = m.original.hasOwnProperty("objectTargeting"),
                                                    h = m.conflicting.hasOwnProperty("objectTargeting"),
                                                    y = "(" + a + ":" + u + ")",
                                                    A = "(" + a + ":" + f + ")";
                                                if (b || h) {
                                                    d.debug("Attempting to auto-resolve conflict based on ad-unit object targeting filter.");
                                                    var w = !0,
                                                        S = !0,
                                                        E = g.targetingFilter.getStaticLabels();
                                                    b && (w = g.targetingFilter.getObjectTargetingResolution(m.original.objectTargeting, E, 0)), h && (S = g.targetingFilter.getObjectTargetingResolution(m.conflicting.objectTargeting, E, 0));
                                                    var L = "Conflict successfully resolved";
                                                    w !== S ? w || (n[a] = r(s, o, a)) : L = "Conflict unsuccessfully resolved and ignoring conflicting lot:";
                                                    var C = "(" + a + ":" + n[a].adUnit + ")";
                                                    d.info(L + ":\n\tAd-unit filter resolution: (" + u + ": " + w + "), (" + f + ": " + S + ")\n\tLot resolution: " + y + " => " + C)
                                                } else d.info("Conflict not resolvable. Ignoring conflicting lot " + A + ".")
                                            } else n[a] = r(s, o, a);
                                        else console.warn("Ad unit '" + o + "' doesn't exist in AdEngine configuration. Please correct requested ad units to auction.")
                                    }
                                }
                            } catch (e) {
                                return d.error(e.name + ": " + e.message), !1
                            }
                            var x = "\n\t" + Object.entries(n).map((function(e) {
                                return "(" + e[0] + ":" + e[1].adUnit + ")"
                            })).join("\n\t");
                            for (a in d.info("Requested lots:" + x), n) l.auction.requestedLots.hasOwnProperty(a) && d.warn("Placement '" + a + "' already in auction. Ignoring lot (" + a + ":" + n[a].adUnit + ") in auction."), !1 === l.auction.running ? l.auction.requestedLots[a] = n[a] : !0 === l.auction.running && (l.auction.queuedLots[a] = n[a]);
                            return !0
                        },
                        a = function() {
                            p.consentManagement.executeOnConsentResolved((function() {
                                return setTimeout((function() {
                                    l.window.innerWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth, l.window.innerHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight, l.auction.window = {
                                            width: l.window.innerWidth,
                                            height: l.window.innerHeight
                                        }, !1 !== t.bidding.enabled || l.consent.googleConsent || d.warn("Bidding is disabled and consent requirements for Google are not met. System cannot auction any inventory."), u.auctions.push({
                                            auction: {
                                                reqTs: g.getPerformanceNow()
                                            }
                                        }), m.dispatchEvent(c.coreEvents.coreAuctionStart),
                                        function() {
                                            for (var e = l.auction.activeLabels = l.targetingFilter.staticLabels.slice(), t = l.targetingFilter.customLabels, n = 0; n < t.length; n++) {
                                                var i = t[n]; - 1 === e.indexOf(i) && e.push(i)
                                            }
                                            l.targetingFilter.customLabels = [], d.info("Active auction labels: ['" + e.join("', '") + "'].")
                                        }(), n();
                                    for (var e = 0; e < l.auction.adUnits.length; e++) {
                                        var i = l.auction.adUnits[e];
                                        u.lots[i.code] = u.lots[i.code] || {}, u.lots[i.code][i.name] = u.lots[i.code][i.name] || {};
                                        var r = u.lots[i.code][i.name].auctionCountTotal || 0;
                                        u.lots[i.code][i.name].auctionCountTotal = ++r
                                    }
                                    d.info("Starting bidding phase..."), m.dispatchEvent(c.coreEvents.coreBiddingPhaseStart), !1 === t.bidding.enabled ? (d.warn("Bidding disabled. Skipping requesting bids."), g.callAdServer(c.pbjsObjName)) : 0 === l.auction.pbjsAdUnits.length ? (d.warn("No ad-units found for bidding. Skipping requesting bids."), g.callAdServer(c.pbjsObjName)) : g.callBids()
                                })), !0
                            }))
                        };

                    function f() {
                        l.auction.gracePeriodRunning = !0;
                        var e = t.auction.gracePeriodMs || l.auction.gracePeriodMs;
                        d.debug("Auction grace period of " + e + "ms started..."), l.auction.gracePeriodTimeout = setTimeout((function() {
                            l.auction.gracePeriodRunning = !1, l.auction.running = !0, a()
                        }), e)
                    }
                    if (d.info("Starting new auction."), !1 === l.auction.running && !1 === l.auction.gracePeriodRunning) {
                        if (!o(e)) return !1;
                        f()
                    } else if (!1 === l.auction.running && !0 === l.auction.gracePeriodRunning) {
                        if (d.info("Auction starting grace period active. Requesting to add lots to active auction..."), !o(e)) return !1;
                        clearTimeout(l.auction.gracePeriodTimeout), f()
                    } else if (!0 === l.auction.running && !1 === l.auction.gracePeriodRunning && (d.info("An auction is already running. Queuing lots for next auction..."), !o(e))) return !1;
                    return !0
                },
                callBids: function() {
                    if (l.adServer.deferredBy[c.pbjsObjName] = 1, l.bidding.deferredBy.length > 0) return d.info("Calling '" + c.pbjsObjName + "' bids deferred by '" + l.bidding.deferredBy.join("', '") + "'."), m.dispatchEvent(c.coreEvents.coreBiddingPhaseEnd), !1;
                    var e = t.bidding.timeoutMs,
                        n = !1,
                        i = setTimeout((function() {
                            n = !0, d.warn("Calling bids for Prebid failed. Calling ad-server."), g.callAdServer(c.pbjsObjName)
                        }), e + 2e3);
                    c.pbjsObj.que.push((function() {
                        u.auctions[u.auctions.length - 1].pbjsBidding = {
                            reqTs: g.getPerformanceNow()
                        }, u.auctions[u.auctions.length - 1].window = [l.auction.window.width, l.auction.window.height], m.dispatchEvent(c.coreEvents.corePbjsBiddingStart);
                        var r = l.auction.pbjsAdUnits.map((function(e) {
                            return "(" + e.code + ":" + e.name + ")"
                        })).join("\n\t");
                        d.info("Starting bidding. Calling bids for Prebid with a timeout of " + e + "ms for lots:\n\t" + r), c.pbjsObj.adUnits = l.auction.pbjsAdUnits;
                        c.pbjsObj.requestBids({
                            labels: [],
                            timeout: e,
                            bidsBackHandler: function(e, r, o) {
                                if (n) d.warn("Prebid is returning bids after hitting failsafe timeout. Prebid results are going to be ignored.");
                                else {
                                    clearTimeout(i), u.auctions[u.auctions.length - 1].pbjsBidding.rdyTs = g.getPerformanceNow(), u.auctions[u.auctions.length - 1].pbjsBidding.tmOut = r, m.dispatchEvent(c.coreEvents.corePbjsBiddingEnd), r && d.warn("Prebid bidding closed due to timeout."), d.info("Prebid bidding finished in " + (u.auctions[u.auctions.length - 1].pbjsBidding.rdyTs - u.auctions[u.auctions.length - 1].pbjsBidding.reqTs).toFixed(0) + "ms.");
                                    var a = c.pbjsObj.adUnits.map((function(e) {
                                        return e.code
                                    }));
                                    e !== c.udef && a.forEach((function(n) {
                                        var i = 0;
                                        if (e.hasOwnProperty(n)) {
                                            var r = e[n].bids;
                                            i = Math.max.apply(Math, [0].concat(r.map((function(e) {
                                                return e.cpm
                                            }))))
                                        }
                                        d.debug("Highest PBJS bid for placement '" + n + "': " + i + " " + t.bidding.adServerCurrency.toUpperCase())
                                    })), g.callAdServer(c.pbjsObjName)
                                }
                            }
                        })
                    }))
                },
                getAdServerDeclarativeSettings: function() {
                    c.snPubConf.hasOwnProperty("adengine") && (c.snPubConf.adengine.hasOwnProperty("sensitiveContent") || c.snPubConf.adengine.hasOwnProperty("skipAdServer")) && (!0 === c.snPubConf.adengine.sensitiveContent && d.warn("Declarative flag found that page contains senstive content. Disabling ad-server."), !0 === c.snPubConf.adengine.skipAdServer && d.warn("Declarative flag found disabling ad-server. Disabled."), l.adServer.enabled = !(!0 === c.snPubConf.adengine.sensitiveContent || !0 === c.snPubConf.adengine.skipAdServer)), l.adServer.enabled = !(!l.adServer.enabled || !c.snConf.resources.gpt)
                },
                callAdServer: function(n) {
                    var i = function(e) {
                            var t = document.getElementById(e);
                            null !== t && l.activeLots[e].pbjsAdIframe !== c.udef && (l.activeLots[e].pbjsAdIframe.remove(), delete l.activeLots[e].pbjsAdIframe, t.innerHTML = null)
                        },
                        r = function() {
                            var e = g.getPerformanceNow(),
                                t = u.auctions[u.auctions.length - 1].auction.reqTs;
                            u.auctions[u.auctions.length - 1].auction.ttfaTs = e, d.debug("First ad shown " + (e - t).toFixed(0) + "ms after auction started."), m.dispatchEvent(c.coreEvents.coreFirstAd)
                        },
                        o = l.adServer.deferredBy;
                    n && delete o[n];
                    var a = Object.keys(o);
                    return a.length > 0 ? (d.info("Calling ad-server deferred by '" + a.join("', '") + "'."), !1) : (d.info("Bidding phase ended."), m.dispatchEvent(c.coreEvents.coreBiddingPhaseEnd), !1 === t.adServer.autoCall && !0 !== l.adServer.isManualCall ? (d.info("Automatically calling ad-server for all placements is disabled."), !1) : (l.adServer.isManualCall = !1, d.info("Starting ad-server phase..."), m.dispatchEvent(c.coreEvents.coreAdServerPhaseStart), g.getAdServerDeclarativeSettings(), void(l.consent.googleConsent && l.adServer.enabled ? g.doOnDomReady((function() {
                        googletag.cmd.push((function() {
                            d.info("Consent requirements for Google met.");
                            try {
                                for (var n in l.activeLots) l.activeLots[n].pbjsAdIframe !== c.udef && (d.debug("Removing existing prebid-only iframe in placement '" + n + "'."), i(n));
                                f.addEventListener("slotRenderEnded", (function e(t) {
                                        r(), f.removeEventListener("slotRenderEnded", e)
                                    })),
                                    function() {
                                        var e = function(e, n) {
                                                l.adServer.targeting[n.code] = {
                                                    adSlot: e,
                                                    keyValues: {
                                                        sn_adngin: 1,
                                                        sn_cr: t.gdpr ? "gdpr" : t.ccpa ? "ccpa" : "none",
                                                        sn_ic: u.lots[n.code][n.name].auctionCountTotal,
                                                        sn_adx: 1,
                                                        sn_rm: "0",
                                                        sn_exp: t.exp,
                                                        sn_pd: u.lots[n.code][n.name].auctionCountTotal > 1 ? 1 : "0"
                                                    }
                                                }
                                            },
                                            n = function(t, n) {
                                                var i, r = "(" + t.code + ":" + t.name + ")";
                                                if (0 !== n.length) return t.interstitial ? (d.debug("Creating interstitial adSlot for auction lot " + r + " with path '" + t.adUnitPath + "'."), i = googletag.defineOutOfPageSlot(t.adUnitPath, googletag.enums.OutOfPageFormat.INTERSTITIAL)) : (d.debug("Creating adSlot for auction lot " + r + " supporting sizes: [" + n.join("], [") + "]"), i = googletag.defineSlot(t.adUnitPath, n, t.code)), i && i.addService(googletag.pubads()), e(i, t), l.activeLots[t.code].sizes = n, l.activeLots[t.code].adSlot = i, i;
                                                d.debug("Skipping adSlot creation for auction lot " + r + ". No sizes detected.", n)
                                            },
                                            i = function(e) {
                                                d.debug("Destroying adSlot for auction lot (" + e.code + ":" + e.name + ")"), googletag.destroySlots([l.activeLots[e.code].adSlot]), delete l.activeLots[e.code].sizes, delete l.activeLots[e.code].adSlot
                                            },
                                            r = function(e) {
                                                return e.activeSizes
                                            },
                                            o = function(e) {
                                                for (var t = googletag && googletag.pubads ? googletag.pubads().getSlots() : [], n = 0; n < t.length; n++)
                                                    if (t[n].getSlotElementId() === e) return t[n]
                                            };
                                        l.adServer.targeting = {};
                                        for (var a = l.auction.adUnits, s = {}, f = !1, m = a.length - 1; m >= 0; m--) {
                                            var v = a[m],
                                                p = v.code;
                                            if (!v.interstitial || v.interstitial && !f)
                                                if (v.interstitial && (f = !0), s[p]) d.debug("Ignoring ad slot creation for ad unit with a media type different from 'banner'.");
                                                else if (s[p] = 1, null !== document.getElementById(p) || v.interstitial) {
                                                d.debug((v.interstitial ? "Interstitial" : "DOM element") + " for auction lot (" + p + ":" + v.name + ") detected.");
                                                var b = l.activeLots[p].adSlot,
                                                    h = r(v);
                                                b || (l.activeLots[p].sizes = h);
                                                var y = (b = l.activeLots[p].adSlot = o(p)) !== c.udef;
                                                if (d.debug("Existing AdSlot for auction lot (" + p + ":" + v.name + ") detected:", y), y) {
                                                    var A = !g.sizeMapper.sizeArrays.containSameSizes(l.activeLots[p].sizes, h);
                                                    A ? (d.debug("Required sizes for existing adSlot for auction lot (" + p + ":" + v.name + ") changed:", A), i(v), n(v, h)) : (b.clearTargeting(), e(b, v), d.debug("Using existing adSlot for auction lot (" + p + ":" + v.name + ")."))
                                                } else n(v, h)
                                            } else d.warn("DOM element for auction lot (" + p + ":" + v.name + ") missing. Removing lot from auction and active lots."), delete l.activeLots[p], delete l.auction.lots[p], a.splice(m, 1);
                                            else d.warn("Ignoring ad slot creation for a second interstitial unit coming from adUnit '" + v.name + "'."), delete l.activeLots[p], delete l.auction.lots[p], a.splice(m, 1)
                                        }
                                    }(),
                                    function() {
                                        for (var t in m.dispatchEvent(c.coreEvents.coreAdServerStart), l.adServer.targeting) {
                                            var n = l.adServer.targeting[t];
                                            if (n.adSlot && n.keyValues)
                                                for (var i in n.keyValues) n.adSlot.setTargeting(i, n.keyValues[i])
                                        }
                                        u.auctions[u.auctions.length - 1].adServer = {
                                            reqTs: g.getPerformanceNow()
                                        };
                                        for (var r = [], o = [], a = [], s = googletag.pubads().getSlots(), f = l.auction.adUnits, v = {}, p = 0; p < f.length; p++) {
                                            var b = f[p];
                                            !v[b.code] && l.activeLots[b.code] && l.activeLots[b.code].adSlot && (v[b.code] = !0, r.push(l.activeLots[b.code].adSlot), o.push("(" + b.name + ":" + b.code + ")"), b.interstitial || googletag.display(b.code))
                                        }
                                        if (!0 !== l.adServer.additionalAdSlotsSetProgramatically && c.snPubConf.hasOwnProperty("adengine") && c.snPubConf.adengine.hasOwnProperty("additionalGptAdSlots")) {
                                            var h = c.snPubConf.adengine.additionalGptAdSlots,
                                                y = !0;
                                            if (Array.isArray(h))
                                                for (var A = 0; A < h.length; A++) {
                                                    for (var w = 0; w < s.length; w++) {
                                                        if (h[A] === s[w]) {
                                                            y = !0;
                                                            break
                                                        }
                                                        y = !1
                                                    }
                                                    if (!1 === y) {
                                                        d.error("Error: 'window.snigelPubConf.adengine.additionalGptAdSlots' array element is not of type 'googletag.adSlot'. Ignoring property.");
                                                        break
                                                    }
                                                } else y = !1, d.error("Error: 'window.snigelPubConf.adengine.additionalGptAdSlots' is not of type 'Array'. Ignoring property.");
                                            y && (l.adServer.additionalAdSlots = h, d.info("Detected additional googletag ad-slots in snigel publisher configration. Adding ad-slots for ['" + h.map((function(e) {
                                                return e.getSlotElementId()
                                            })).join("', '") + "'] to ad-server call."))
                                        }
                                        if (l.adServer.hasOwnProperty("additionalAdSlots")) {
                                            var S = l.adServer.additionalAdSlots.length;
                                            if (S > 0)
                                                for (p = 0; p < S; p++) {
                                                    var E = l.adServer.additionalAdSlots[p];
                                                    googletag.display(E), r.push(E), a.push("(" + E.getSlotElementId() + ":" + E.getAdUnitPath() + ")")
                                                }
                                        }
                                        if (!0 !== l.adServer.additionalAdSlotsElementIdsSetProgramatically && c.snPubConf.hasOwnProperty("adengine") && c.snPubConf.adengine.hasOwnProperty("additionalGptAdSlotIds")) {
                                            var L = c.snPubConf.adengine.additionalGptAdSlotIds,
                                                C = !0;
                                            if (Array.isArray(L)) {
                                                for (var x = 0; x < L.length; x++)
                                                    if ("string" != typeof L[x]) {
                                                        d.error("Error: 'window.snigelPubConf.adengine.additionalGptAdSlotIds' array element is not of type 'String'. Ignoring property."), C = !1;
                                                        break
                                                    }
                                            } else C = !1, d.error("Error: 'window.snigelPubConf.adengine.additionalGptAdSlotIds' is not of type 'Array'. Ignoring property.");
                                            C && (l.adServer.additionalAdSlotsElementIds = L, d.info("Detected additional googletag ad-slot element ids in snigel publisher configration. Adding ad-slot ids ['" + L.join("', '") + "'] to ad-server call."))
                                        }
                                        l.adServer.hasOwnProperty("additionalAdSlotsElementIds") && googletag.pubads().getSlots().forEach((function(e) {
                                            var t = e.getSlotElementId(),
                                                n = e.getAdUnitPath(); - 1 !== l.adServer.additionalAdSlotsElementIds.indexOf(t) && (googletag.display(e), r.push(e), a.push("(" + t + ":" + n + ")"))
                                        })), o.length > 0 ? d.info("Lots with associated ad-slots for ad-server call:\n\t" + o.join("\n\t")) : d.info("No lots with associated ad-slots detected for ad-server call."), Object.keys(a).length > 0 ? d.info("Additional ad-slots for ad-server call:\n\t" + a.join("\n\t")) : d.info("No additional ad-slots detected for ad-server call.");
                                        try {
                                            c.pbjsObj && c.pbjsObj.setTargetingForGPTAsync && c.pbjsObj.setTargetingForGPTAsync(Object.keys(l.auction.lots))
                                        } catch (e) {
                                            d.error(e)
                                        }
                                        r.forEach((function(e) {
                                                var t = e.getTargeting("hb_pb");
                                                e.setTargeting("_adngin_ba", t.length > 0 ? "true" : "false");
                                                try {
                                                    d.debug("Ad-server targeting for adSlot '" + e.getSlotElementId() + "':\n\t{ " + Object.entries(e.getTargetingMap()).map((function(e) {
                                                        return '"' + e[0] + '": ' + JSON.stringify(e[1])
                                                    })).join(", ") + " }")
                                                } catch (e) {
                                                    d.error(e)
                                                }
                                            })),
                                            function() {
                                                var t = {
                                                    sn_ct1: "key1"
                                                };
                                                if (!googletag.pubads) return !1;
                                                var n = e.getTargeting();
                                                for (var i in t) {
                                                    var r = 0,
                                                        o = t[i];
                                                    if (n && n.hasOwnProperty(o)) {
                                                        var a = n[o];
                                                        Number.isInteger(a) && a > 0 && a <= 100 ? (d.info("Found declarative targeting for ad-server. Setting targeting '".concat(i, "'='").concat(r, "'.")), r = a) : d.warn("Ignoring invalid value found for declarative targeting key '".concat(t[i], "': Expecting an Integer from 1 to 100."))
                                                    }
                                                    googletag.pubads().setTargeting(i, r.toString())
                                                }
                                            }();
                                        try {
                                            d.info("Ad-server targeting:\n\t{ " + googletag.pubads().getTargetingKeys().map((function(e) {
                                                return '"' + e + '": ' + JSON.stringify(googletag.pubads().getTargeting(e))
                                            })).join(", ") + " }")
                                        } catch (e) {
                                            d.error(e)
                                        }
                                        r.length > 0 ? (d.info("Calling ad-server for ad-slots:\n\t" + r.map((function(e) {
                                            return "(" + e.getSlotElementId() + ":" + e.getAdUnitPath() + ")"
                                        })).join("\n\t")), googletag.pubads().refresh(r)) : d.warn("No active ad-slots found for ad-server call. Skipping calling ad-server."), c.snPubConf && c.snPubConf.adengine && (delete c.snPubConf.adengine.additionalGptAdSlots, delete c.snPubConf.adengine.additionalGptAdSlotIds), l && l.adServer && (delete l.adServer.additionalAdSlots, delete l.adServer.additionalAdSlotsSetProgramatically, delete l.adServer.additionalAdSlotsElementIds, delete l.adServer.additionalAdSlotsElementIdsSetProgramatically), u.auctions[u.auctions.length - 1].adServer.rdyTs = g.getPerformanceNow(), m.dispatchEvent(c.coreEvents.coreAdServerEnd), g.auctionEnd()
                                    }()
                            } catch (e) {
                                d.error(e), g.auctionEnd()
                            }
                        }))
                    })) : (l.adServer.enabled || d.info("Ad-server disabled. Bypassing calling the ad-server."), l.consent.googleConsent || d.warn("Consent requirements for Google not met. Bypassing calling the ad-server."), c.pbjsObj.que.push((function() {
                        var e = c.pbjsObj.getBidResponses();
                        Object.keys(e).forEach((function(t) {
                            (e[t].bids || []).forEach((function(e) {
                                e.status = "targetingSet"
                            }))
                        }));
                        var t = [];
                        for (var n in l.activeLots) l.activeLots[n].adSlot !== c.udef && (d.debug("Destroying existing GPT ad-slot for placement '" + n + "'."), t.push(l.activeLots[n].adSlot));
                        t.length > 0 && googletag.destroySlots(t), c.pbjsObj.getAllPrebidWinningBids().forEach((function(e) {
                            d.debug("Rendering " + e.mediaType + "(" + e.size + ") from '" + e.bidder + "' in '" + e.adUnitCode + "'.");
                            var t = e.adUnitCode,
                                n = document.getElementById(t);
                            if (null === n) {
                                var o = "(" + t + ":" + l.activeLots[t].adUnit + ")";
                                return d.warn("DOM element for lot " + o + " missing. Skipping rendering winning bid."), !1
                            }
                            i(t);
                            var a = function(e, t) {
                                d.debug("Creating iframe for prebid ad.");
                                var n = "snigel_pbjs_iframe/" + e,
                                    i = document.createElement("iframe");
                                return i.style.border = "0pt none", i.style.verticalAlign = "bottom", i.style.display = "block", i.style.margin = "0 auto", i.setAttribute("scrolling", "no"), i.setAttribute("marginwidth", 0), i.setAttribute("marginheight", 0), i.setAttribute("frameborder", 0), i.setAttribute("width", 0), i.setAttribute("height", 0), i.id = n, i.title = "Advertisement", i.onload = function() {
                                    var e = i.contentDocument;
                                    if (e.head.innerHTML += "<style>body{margin:0;overflow:hidden}</style>", "native" === t.mediaType) {
                                        var n = e.createElement("script");
                                        n.type = "text/javascript", n.src = "https://cdn.jsdelivr.net/npm/prebid-universal-creative@latest/dist/native-render.js", n.async = !0, n.onload = function() {
                                            i.contentWindow.pbNativeTag.renderNativeAd({
                                                requestAllAssets: !0,
                                                adId: t.adId
                                            })
                                        }, e.head.appendChild(n)
                                    }
                                }, i
                            }(t, e);
                            n.appendChild(a), l.activeLots[t].pbjsAdIframe = a;
                            var s = a.contentDocument ? a.contentDocument : a.contentWindow.document;
                            "none" === n.style.display && n.style.removeProperty("display"), "native" !== e.mediaType && c.pbjsObj.renderAd(s, e.adId), r()
                        })), g.auctionEnd()
                    }))))))
                },
                auctionEnd: function() {
                    setTimeout((function() {
                        var e = 1e3 * (r.get("auction.minPeriodBetweenRuns") || 10),
                            t = function(t) {
                                var n = l.auction.waitingTimeoutLots[t];
                                n || ((n = l.auction.waitingTimeoutLots[t] = {}).timeout = function(t, n) {
                                    return setTimeout((function() {
                                        delete l.auction.waitingTimeoutLots[t], n.lot && (d.info("Auctioning previously waiting lot " + t + ":" + n.lot.adUnit + "."), g.startAuction([n.lot]))
                                    }), e)
                                }(t, n))
                            };
                        for (var n in l.auction.requestedLots) {
                            t(n);
                            var i = b.adaptive.getAdaptiveBasePlacement(n);
                            i !== n && t(i)
                        }
                        if (l.auction.running = !1, l.auction.requestedLots = {}, l.auction.lots = {}, m.dispatchEvent(c.coreEvents.coreAuctionEnd), u.auctions[u.auctions.length - 1].auction.rdyTs = g.getPerformanceNow(), d.info("Auction finished in " + (u.auctions[u.auctions.length - 1].auction.rdyTs - u.auctions[u.auctions.length - 1].auction.reqTs).toFixed(0) + "ms."), Object.keys(l.auction.queuedLots).length > 0) {
                            d.info("Found queued lots. Starting additional auction...");
                            var o = [];
                            for (var n in l.auction.queuedLots) o.push(l.auction.queuedLots[n]);
                            l.auction.queuedLots = {}, g.startAuction(o)
                        }
                    }), 250)
                },
                targetingFilter: {
                    init: function() {
                        var e = [t.platform, t.os, t.environment];
                        t.country && (e.push(t.country), t.region && e.push(t.country + "-" + t.region));
                        var n = function() {
                                var e = [];
                                if (c.snConf.hasOwnProperty("adengine") && c.snConf.adengine.hasOwnProperty("targeting") && snCon.adengine.targeting.hasOwnProperty("staticLabels") && c.snConf.adengine.targeting.staticLabels.length > 0) {
                                    e = c.snConf.adengine.targeting.staticLabels;
                                    d.info("Detected custom static label(s) in loader configuration. Adding ['" + e.join("', '") + "'] to static labels.")
                                }
                                if (c.snPubConf.hasOwnProperty("adengine") && c.snPubConf.adengine.hasOwnProperty("staticLabels")) {
                                    var t = c.snPubConf.adengine.staticLabels,
                                        n = !0;
                                    if (Array.isArray(t)) {
                                        for (var i = 0; i < t.length; i++)
                                            if ("string" != typeof t[i]) {
                                                n = !1, d.error("Error: 'window.snigelPubConf.adengine.staticLabels' array element is not of type 'String'. Ignoring property.");
                                                break
                                            }
                                    } else n = !1, d.error("Error: 'window.snigelPubConf.adengine.staticLabels' is not of type 'Array'. Ignoring property.");
                                    n && (e = t, d.info("Detected custom static label(s) in snigel publisher configration. Adding ['" + e.join("', '") + "'] to static labels."))
                                }
                                return e
                            }(),
                            i = e.concat(n);
                        l.targetingFilter = l.targetingFilter || {}, l.targetingFilter.staticLabels = l.targetingFilter.staticLabels || [], l.targetingFilter.customLabels = l.targetingFilter.customLabels || [], l.targetingFilter.lastLabels = l.targetingFilter.lastLabels || [], l.targetingFilter.lastFilterResults = l.targetingFilter.lastFilterResults || [], l.targetingFilter.staticLabels = l.targetingFilter.staticLabels.concat(i)
                    },
                    getStaticLabels: function() {
                        return l.targetingFilter.staticLabels
                    },
                    filterDomainConfiguration: function(e) {
                        return d.debug("Applying label targeting filters to domain configuration."), this.filterConfig(t, e, {
                            inplace: !0
                        })
                    },
                    applyVariants: function(e) {
                        (e || []).forEach((function(e) {
                            var t = e.variants;
                            if (delete e.variants, t && t.length > 0) {
                                var n = t[t.length - 1];
                                for (var i in n) e[i] = n[i]
                            }
                        }))
                    },
                    getFilteredAdUnits: function(e, t, n) {
                        d.debug("Applying label targeting filters to Ad-Units configuration.");
                        var i = this.filterConfig(e, t, n);
                        return d.debug("Applying variants to Ad-Units configuration."), this.applyVariants(i), i
                    },
                    labelsChanged: function(e) {
                        if (e.length !== l.targetingFilter.lastLabels.length) return l.targetingFilter.lastFilterResults = {}, !0;
                        for (var t = 0; t < e.length; t++)
                            if (-1 === l.targetingFilter.lastLabels.indexOf(e[t])) return !0;
                        return !1
                    },
                    filterConfig: function(e, t, n) {
                        var i, r = g.getPerformanceNow(),
                            o = !1;
                        if (n !== c.udef && n.inplace && (o = n.inplace), d.debug("Filtering configuration " + (o ? "reference" : "copy") + " with labels: ['" + t.join("', '") + "']"), this.labelsChanged(t) ? (d.debug("Targeting labels have changed. Clearing cached filter results."), l.targetingFilter.lastLabels = t.slice(), l.targetingFilter.lastFilterResults = {}) : d.debug("Targeting labels unchanged. Using cached filter results."), o) i = this.parseConfig(e, t);
                        else {
                            var a = JSON.parse(JSON.stringify(e));
                            delete a.targeting, i = this.parseConfig(a, t)
                        }
                        var s = g.getPerformanceNow() - r;
                        return d.debug("Filtering took " + s.toFixed(2) + "ms."), i
                    },
                    parseConfig: function(e, t, n) {
                        n === c.udef && (n = 0), n += 1;
                        for (var i = Object.keys(e), r = i.length - 1; r >= 0; r--) {
                            var a = i[r];
                            if (e.hasOwnProperty(a) && "object" === o(e[a]) && null !== e[a]) {
                                if ("targeting" === a || "adUnits" === a && Array.isArray(e[a])) continue;
                                var s;
                                this.parseConfig(e[a], t, n), e[a].hasOwnProperty("objectTargeting") ? !1 === (s = this.getObjectTargetingResolution(e[a].objectTargeting, t, n)) ? Array.isArray(e) ? e.splice(r, 1) : delete e[a] : delete e[a].objectTargeting : e[a].hasOwnProperty("primitiveTargeting") ? (s = this.getPrimitiveTargetingResolution(e[a].primitiveTargeting, t, n), e[a] = s) : e[a].hasOwnProperty("arrayTargeting") && (s = this.getArrayTargetingResolution(e[a].arrayTargeting, t, n), e[a] = s)
                            }
                        }
                        return e
                    },
                    getPrimitiveTargetingResolution: function(e, t, n) {
                        var i = e.default;
                        for (var r in e.values) {
                            var o = e.values[r];
                            if (this.getFilterResolution(o, t, n)) {
                                i = o.value;
                                break
                            }
                        }
                        return i
                    },
                    getArrayTargetingResolution: function(e, t, n) {
                        var i = [];
                        for (var r in e.values) {
                            var o = e.values[r];
                            if (!o.hasOwnProperty("filterId") && o.hasOwnProperty("value") || this.getObjectTargetingResolution(o, t, n)) {
                                var a = o.value;
                                Array.isArray(a) ? i = i.concat(a) : i.push(o.value)
                            }
                        }
                        return i
                    },
                    getObjectTargetingResolution: function(e, t, n) {
                        return this.getFilterResolution(e, t, n)
                    },
                    getFilterResolution: function(e, n, i) {
                        i += 1;
                        var r, o, a = null;
                        if (e.hasOwnProperty("filterId") ? (o = e.filterId, l.targetingFilter.lastFilterResults.hasOwnProperty(o) && (r = l.targetingFilter.lastFilterResults[o]), a = t.targeting[o]) : a = e, r === c.udef) {
                            for (var s in a)
                                if (a.hasOwnProperty(s) && null !== a[s]) {
                                    var d = a[s];
                                    if (!1 === (r = this.logicOperatorValid(s, d, n, i))) break
                                }
                            o !== c.udef && (l.targetingFilter.lastFilterResults[o] = r)
                        }
                        return r
                    },
                    logicOperatorValid: function(e, t, n, i) {
                        var r;
                        i === c.udef && (i = 0);
                        for (var a = 0; a < t.length; a++) {
                            var s, d = t[a];
                            if ("object" === o(d) ? r = this.getObjectTargetingResolution(d, n, i) : "string" == typeof d && (r = this.labelMatch(d, n)), "and" === e) {
                                if (!1 === r) {
                                    s = !1;
                                    break
                                }
                                s = !0
                            } else if ("or" === e) {
                                if (!0 === r) {
                                    s = !0;
                                    break
                                }
                                s = !1
                            } else if ("nand" === e) {
                                if (!1 === r) {
                                    s = !0;
                                    break
                                }
                                s = !1
                            } else {
                                if ("nor" !== e) throw new Error("Unknown logical operator '" + e + "'.");
                                if (!0 === r) {
                                    s = !1;
                                    break
                                }
                                s = !0
                            }
                        }
                        return s
                    },
                    labelMatch: function(e, t) {
                        return -1 !== t.indexOf(e)
                    }
                },
                sizeMapper: {
                    processAdUnits: function(e, t, n) {
                        for (var i = t || (l.window.innerWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth), r = n || (l.window.innerHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight), o = l.auction.requestedLots, a = e.length - 1; a >= 0; a--) {
                            var s = e[a],
                                c = (o[s.code] || {}).sizes,
                                u = Array.isArray(c) && c.length > 0,
                                g = s.sizeMapping || {};
                            if (0 !== Object.keys(g).length) {
                                var f = [];
                                for (var m in g) {
                                    var v = g[m],
                                        p = [],
                                        b = [],
                                        h = [],
                                        y = [];
                                    s.mediaTypes = s.mediaTypes || {};
                                    var A = v.dynamicSizes;
                                    if (A)
                                        for (var w = 0; w < A.length; w++) {
                                            var S = A[w];
                                            (this.matchMedia(S.mediaQuery, t, n) || u) && (S.biddingSizes && (p = p.concat(S.biddingSizes)), S.playerSize && ((h[0] + h[1] || 0) < S.playerSize[0] + S.playerSize[1] && (h = S.playerSize), u && y.push(S.playerSize)), S.additionalSizes && (b = b.concat(S.additionalSizes)))
                                        } else p = v.biddingSizes || [], y = (h = v.playerSize || []).length ? [h] : [], b = v.additionalSizes || [];
                                    if (u) {
                                        b = [], h = [];
                                        for (var E, L = [], C = 0; C < c.length; C++) E = c[C], this.sizeArrays.containsSize(p, E) ? L.push(E) : this.sizeArrays.containsSize(y, E) ? h = E : b.push(E);
                                        p = L
                                    }
                                    if (p.length > 0 || 2 === h.length) {
                                        var x = s.mediaTypes = s.mediaTypes || {},
                                            T = x[m] = x[m] || {};
                                        switch (m) {
                                            case "banner":
                                                this.sizeArrays.sanitize(p), T.sizes = p, f = f.concat(p);
                                                break;
                                            case "video":
                                                T.playerSize = h, f = f.concat(h)
                                        }
                                    }
                                    this.sizeArrays.sanitize(b), f = f.concat(b)
                                }
                                s.activeSizes = this.sizeArrays.sanitize(f), d.debug("Sizemapping Ad-Unit '" + s.name + "' for (" + i + "x" + r + "):\n\tAll Sizes: " + JSON.stringify(s.activeSizes))
                            } else d.error("No size mapping configuration found for ad-unit '" + s.name + "'. Removing ad-unit from auction. Please contact our support."), e.splice(a, 1)
                        }
                    },
                    getCssMediaQuery: function(e) {
                        var t = [];
                        for (var n in e) t.push("(" + n + ": " + e[n] + "px)");
                        return t.join(" and ")
                    },
                    matchMedia: function(e, t, n) {
                        if (t || n) {
                            var i = t || window.innerWidth,
                                r = n || window.innerHeight,
                                o = e["min-width"] || 0,
                                a = e["max-width"] || 1e6,
                                s = e["min-height"] || 0,
                                d = e["max-height"] || 1e6;
                            return i >= o && i <= a && r >= s && r <= d
                        }
                        var c = this.getCssMediaQuery(e);
                        return window.matchMedia(c).matches
                    },
                    sizeArrays: {
                        sizesEqual: function(e, t) {
                            return "string" == typeof e && "string" == typeof t && e === t || !(!Array.isArray(e) || !Array.isArray(t) || e[0] !== t[0] || e[1] !== t[1])
                        },
                        sizeValid: function(e) {
                            return !("string" != typeof e && !Array.isArray(e)) && (!Array.isArray(e) || 2 === e.length)
                        },
                        sanitize: function(e) {
                            for (var t = e.length - 1; t >= 0; t--) {
                                var n = e[t];
                                if (this.sizeValid(n))
                                    for (var i = t - 1; i >= 0; i--) {
                                        var r = e[i];
                                        this.sizesEqual(n, r) && e.splice(t, 1)
                                    } else e.splice(t, 1)
                            }
                            return e
                        },
                        containSameSizes: function(e, t) {
                            if (e.length != t.length) return !1;
                            e: for (var n = 0; n < e.length; n++) {
                                for (var i = e[n], r = 0; r < t.length; r++) {
                                    var o = t[r];
                                    if (this.sizesEqual(i, o)) continue e
                                }
                                return !1
                            }
                            return !0
                        },
                        containsSize: function(e, t) {
                            if (Array.isArray(e))
                                for (var n = 0; n < e.length; n++)
                                    if (this.sizesEqual(e[n], t)) return !0;
                            return !1
                        }
                    }
                },
                debugMode: {
                    enable: function() {
                        l.debugMode = !0, window.localStorage.setItem(c.coreObjName + "DebugEnabled", !0), d.setLogLevel("debug"), this.enableApiCommands(), this.enableObjects(), d.info("Debug mode enabled for environment '" + t.environment + "'.")
                    },
                    disable: function() {
                        l.debugMode = !1, window.localStorage.removeItem(c.coreObjName + "DebugEnabled"), this.disableApiCommands(), this.disableObjects(), d.info("Debug mode disabled."), d.setLogLevel("error")
                    },
                    enableApiCommands: function() {
                        var e = v.get();
                        for (var t in e) c.coreObj.cmd[t] = e[t]
                    },
                    disableApiCommands: function() {
                        var e = v.get();
                        for (var t in e) delete c.coreObj.cmd[t]
                    },
                    enableObjects: function() {
                        c.coreObj._dev = {}, c.coreObj._dev.system = g, c.coreObj._dev.subsystems = p, c.coreObj._dev.status = l, c.coreObj._dev.modules = b
                    },
                    disableObjects: function() {
                        delete c.coreObj._dev
                    }
                },
                getAllAvailableBidders: function() {
                    for (var e = [], n = t.adUnits, i = 0; i < n.length; i++)
                        for (var r = n[i], o = 0; o < r.bidders.length; o++) {
                            var a = r.bidders[o].bidder; - 1 === e.indexOf(a) && e.push(a)
                        }
                    return e
                }
            },
            f = n(6),
            m = n(4);
        m.initMetrics(g.metrics), c.coreObj.cmd = {
            startAuction: function(e, t) {
                return g.api.executeCommand("startAuction", c.coreEvents.coreReady, null, e, t)
            },
            callAdServer: function(e, t) {
                return g.api.executeCommand("callAdServer", c.coreEvents.coreReady, c.coreEvents.coreAdServerStart, null, t)
            },
            addGoogletagAdSlots: function(e, t) {
                return g.api.executeCommand("addGoogletagAdSlots", c.coreEvents.coreLoaded, c.coreEvents.coreAdServerStart, e, t)
            },
            setGoogletagAdSlots: function(e, t) {
                return g.api.executeCommand("setGoogletagAdSlots", c.coreEvents.coreLoaded, c.coreEvents.coreAdServerStart, e, t)
            },
            setGoogletagAdSlotElementIds: function(e, t) {
                return g.api.executeCommand("setGoogletagAdSlotElementIds", c.coreEvents.coreLoaded, c.coreEvents.coreAdServerStart, e, t)
            },
            enableDebug: function(e, t) {
                return g.api.executeCommand("enableDebug", c.coreEvents.coreLoaded, null, null, t)
            },
            disableDebug: function(e, t) {
                return g.api.executeCommand("disableDebug", c.coreEvents.coreLoaded, null, null, t)
            },
            showLog: function(e, t) {
                return g.api.executeCommand("showLog", c.coreEvents.coreLoaded, null, null, t)
            },
            disableAutoRunAuction: function(e, t) {
                return g.api.executeCommand("disableAutoRunAuction", c.coreEvents.coreLoaded, c.coreEvents.coreReady, null, t)
            },
            disableAutoCallAdServer: function(e, t) {
                return g.api.executeCommand("disableAutoCallAdServer", c.coreEvents.coreLoaded, c.coreEvents.coreBiddingPhaseEnd, null, t)
            },
            setCustomAuctionLabels: function(e, t) {
                return g.api.executeCommand("setCustomAuctionLabels", c.coreEvents.coreLoaded, c.coreEvents.coreAuctionStart, e, t)
            },
            getConfig: function(e, t) {
                return g.api.executeCommand("getConfig", c.coreEvents.coreReady, null, null, t)
            },
            getStatus: function(e, t) {
                return g.api.executeCommand("getStatus", c.coreEvents.coreReady, null, null, t)
            },
            getEvents: function(e, t) {
                return g.api.executeCommand("getEvents", c.coreEvents.coreReady, null, null, t)
            },
            getMetrics: function(e, t) {
                return g.api.executeCommand("getMetrics", c.coreEvents.coreReady, null, null, t)
            },
            getTimeline: function(e, t) {
                return g.api.executeCommand("getTimeline", c.coreEvents.coreReady, null, null, t)
            },
            getActiveLots: function(e, t) {
                return g.api.executeCommand("getActiveLots", c.coreEvents.coreReady, null, null, t)
            },
            getAvailableAdUnitNames: function(e, t) {
                return g.api.executeCommand("getAvailableAdUnitNames", c.coreEvents.coreReady, null, null, t)
            }
        };
        var v = n(11),
            p = {
                adxOptimizer: n(16),
                bidderAdjustments: n(17),
                bidderPreprocessing: n(18),
                biddingChecker: n(19),
                placementViewability: n(20),
                consentManagement: n(21),
                videoManagement: n(22),
                pubstack: n(23),
                labelGenerator: n(24)
            },
            b = {
                adConsent: n(25),
                adLabeling: n(7),
                autoAds: n(26),
                amazonTam: n(27),
                interstitial: n(28),
                confiant: n(29),
                reauctionResize: n(30),
                smartRefresh: n(12),
                adhesive: n(31),
                sticky: n(32),
                parallax: n(8),
                lazyLoad: n(33),
                videoPlayer: n(34),
                adaptive: n(5)
            },
            h = g.metrics.getTimestamp("adngin", "queued").toFixed(0) + "ms",
            y = g.metrics.getDuration("adngin", "requested", "loaded").toFixed(0) + "ms";
        console.log("%c【AdEngine】(" + t.build + ") queued at " + h + " and loaded in " + y + ". (" + t.id + ")", "color:#2dc9ac;");
        var A = g.parameters.environments[t.environment] >= 2,
            w = -1 !== document.location.href.indexOf("sn_debug=true"),
            S = "true" === window.localStorage.getItem(c.coreObjName + "DebugEnabled");
        (A || w || S) && g.debugMode.enable(), d.info("Loader reqested at " + g.metrics.getTimestamp("loader", "requested").toFixed(0) + "ms and ready in " + g.metrics.getDuration("loader", "requested", "loaded").toFixed(0) + "ms."), d.info("AdEngine (" + t.build + ") was loaded in " + y + "."), m.dispatchEvent(c.coreEvents.coreLoaded, {
            isUnique: !0
        }), c.coreObj.loaded = !0;
        try {
            g.init()
        } catch (e) {
            if (d.fatal(e), !0 === c.snConf.passThroughException) throw e
        }
    }), 0)
}, function(e, t) {
    t.init = function() {
        ! function() {
            if ("function" == typeof window.CustomEvent) return !1;

            function e(e, t) {
                t = t || {
                    bubbles: !1,
                    cancelable: !1,
                    detail: void 0
                };
                var n = document.createEvent("CustomEvent");
                return n.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), n
            }
            e.prototype = window.Event.prototype, window.CustomEvent = e
        }(), Number.isInteger = Number.isInteger || function(e) {
            return "number" == typeof e && isFinite(e) && Math.floor(e) === e
        }, Array.prototype.indexOf || (Array.prototype.indexOf = function(e, t, n) {
            return function(i, r) {
                if (null == this) throw TypeError("Array.prototype.indexOf called on null or undefined");
                var o = e(this),
                    a = o.length >>> 0,
                    s = n(0 | r, a);
                if (s < 0) s = t(0, a + s);
                else if (s >= a) return -1;
                if (void 0 === i) {
                    for (; s !== a; ++s)
                        if (void 0 === o[s] && s in o) return s
                } else if (i != i) {
                    for (; s !== a; ++s)
                        if (o[s] != o[s]) return s
                } else
                    for (; s !== a; ++s)
                        if (o[s] === i) return s;
                return -1
            }
        }(Object, Math.max, Math.min)), Object.entries || (Object.entries = function(e) {
            for (var t = Object.keys(e), n = t.length, i = new Array(n); n--;) i[n] = [t[n], e[t[n]]];
            return i
        })
    }
}, function(e, t, n) {
    var i = n(10).getValueByPath;
    e.exports = {
        getActiveAdUnits: function() {
            return i(window.snigelPubConf, "adengine.activeAdUnits")
        },
        getActiveLots: function() {
            return i(window.snigelPubConf, "adengine.activeLots")
        },
        getAdditionalGptAdSlotIds: function() {
            return i(window.snigelPubConf, "adengine.additionalGptAdSlotIds")
        },
        getStaticLabels: function() {
            return i(window.snigelPubConf, "adengine.staticLabels")
        },
        getSensitiveContent: function() {
            return i(window.snigelPubConf, "adengine.sensitiveContent")
        },
        getTargeting: function() {
            return i(window.snigelPubConf, "adengine.targeting")
        }
    }
}, function(e, t, n) {
    var i = n(0),
        r = n(3),
        o = n(2),
        a = n(4),
        s = n(1),
        d = {};

    function c() {
        return d.utcTime > 0 ? Math.floor((Date.now() - d.utcTime) / (d.hourly ? 36e5 : 864e5)) : -1
    }
    t.init = function(e) {
        var t = o.get("ddds.ao");
        if (t) {
            var n = t.settings || {};
            if (d.fq = n.fq >= 0 ? n.fq : 1, d.fq < 1) {
                var l = t.data && t.data.timestamp;
                if (l && l.length >= 10) {
                    ! function(e, t) {
                        var n, i = "hourly" === t.type,
                            r = e.split("T");
                        if (i) {
                            if (2 == r.length) {
                                var o = r[1].split(":")[0];
                                2 == o.length && (n = "T" + o + ":00:00.000Z")
                            }
                            n || s.error("Adx optimizer is set for hourly estimation, but timestamp doesn't define initial hour of estimation. Ignoring adx optimizer estimations...")
                        } else n = "T00:00:00.000Z";
                        d.hourly = i, d.utcTime = n ? Date.parse(r[0] + n) : 0
                    }(l, n);
                    var u = c();
                    u >= 0 && ((t.data.items || []).forEach((function(e) {
                        d[e.pl] = e.hc
                    })), a.addEventListener(i.coreEvents.coreAdServerStart, (function() {
                        u = c();
                        var t = i.pbjsObj && "function" == typeof i.pbjsObj.getBidResponses ? i.pbjsObj.getBidResponses() : {},
                            n = !1 !== o.get("bidding.bidFloorEnabled") ? o.get("bidding.floorCpm") || .05 : -1;
                        for (var a in r.auction.requestedLots) {
                            var s = r.auction.requestedLots[a].adUnit,
                                l = s && d[s] && d[s].length > u ? d[s][u] : null;
                            l && (Math.random() >= d.fq ? (e.addTargetingKeyValueToAdServer(a, "sn_ao", 1), e.addTargetingKeyValueToAdServer(a, "sn_aotc", l), (t[a] && t[a].bids || []).some((function(t) {
                                if (t.cpm >= n) return e.addTargetingKeyValueToAdServer(a, "sn_aobf", 1), !0
                            }))) : e.addTargetingKeyValueToAdServer(a, "sn_aotcc", l))
                        }
                    })))
                }
            }
        } else s.info("Adx optimizer is disabled by configuration. Exiting adx optimizer subsystem...");
        return !0
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(1),
        a = n(4),
        s = n(2),
        d = {
            adjustmentFunctions: {
                revenueShare: {
                    enabled: !0,
                    adjustmentFunction: function(e, t) {
                        var n = t.bidderCode,
                            i = s.get("bidders.".concat(n, ".factor"));
                        return e * (1 - (i || 0))
                    }
                },
                debugRandomizeBidsInRange: {
                    enabled: !1,
                    adjustmentFunction: function(e, t) {
                        var n = d.adjustmentFunctions.debugRandomizeBidsInRange.range.min,
                            i = d.adjustmentFunctions.debugRandomizeBidsInRange.range.max;
                        return Math.random() * (i - n) + n
                    },
                    range: {
                        min: 0,
                        max: 20
                    }
                }
            }
        };

    function c() {
        for (var e in d.adjustmentFunctions) {
            var t = s.get("subsystems.".concat(e, ".enabled"));
            t !== r.udef && (d.adjustmentFunctions[e].enabled = t)
        }
        var n;
        return n = r.pbjsObj.bidderSettings = r.pbjsObj.bidderSettings || {}, i.availableBidders.forEach((function(e) {
            n[e] = n[e] || {}, n[e].bidCpmAdjustment = function(e, t) {
                var n = e;
                if (t.bidderCode)
                    for (var i in d.adjustmentFunctions)
                        if (!0 === d.adjustmentFunctions[i].enabled) try {
                            n = d.adjustmentFunctions[i].adjustmentFunction(n, t)
                        } catch (e) {
                            o.error(e)
                        }
                return n
            }
        })), !0
    }
    t.init = function(e) {
        var t = n(11);

        function i() {
            o.warn("Debug function enabled to return randomized bid responses from '".concat(d.adjustmentFunctions.debugRandomizeBidsInRange.range.min, "' to '").concat(d.adjustmentFunctions.debugRandomizeBidsInRange.range.max, "'. "))
        }
        return t.add(e, "enableRandomBidResponseRange", r.coreEvents.coreReady, null, (function(t, n, o) {
            return isNaN(t.min) || (d.adjustmentFunctions.debugRandomizeBidsInRange.range.min = t.min), isNaN(t.max) || (d.adjustmentFunctions.debugRandomizeBidsInRange.range.max = t.max), d.adjustmentFunctions.debugRandomizeBidsInRange.enabled = !0, a.addEventListener(r.coreEvents.corePbjsBiddingStart, i), e.runCallback(n, {
                message: o + "Enabled random bid resposes in a renge of: '" + t + "'",
                data: null
            }, !0), !0
        })), t.add(e, "disableRandomBidResponseRange", r.coreEvents.coreReady, null, (function(t, n, o) {
            return d.adjustmentFunctions.debugRandomizeBidsInRange.range.min = 0, d.adjustmentFunctions.debugRandomizeBidsInRange.range.max = 20, d.adjustmentFunctions.debugRandomizeBidsInRange.enabled = !1, a.removeEventListener(r.coreEvents.corePbjsBiddingStart, i), e.runCallback(n, {
                message: o + "Disabled random bid responses.",
                data: null
            }, !0), !0
        })), c()
    }
}, function(e, t, n) {
    var i = n(0),
        r = n(4),
        o = n(1),
        a = i.coreObj.config,
        s = {
            oftmedia: {
                adpt: "appnexus",
                gvlid: 1111,
                scoCfg: {
                    asi: "152media.info",
                    sid: "152M279",
                    hp: 1
                }
            }
        };

    function d(e, t) {
        var n;
        if ((t.cfg || t.scoCfg) && (n = {
                bidders: [e],
                config: t.cfg || {}
            }, t.scoCfg)) {
            n.config.schain = JSON.parse(JSON.stringify(a.pbjsConfig.schain)) || {};
            var i = n.config.schain;
            i.config = i.config || {}, i.config.nodes = i.config.nodes || [], i.config.nodes.push(t.scoCfg)
        }
        return n
    }

    function c() {
        if ("function" == typeof getPlatformUid) {
            var e = {
                bidders: ["doceree"],
                config: {
                    doceree: {
                        context: {
                            data: {}
                        },
                        user: {
                            data: {
                                hashedEmail: "",
                                hashedNPI: "",
                                hashedGMC: "",
                                specialization: i.snPubConf && i.snPubConf.adengine && i.snPubConf.adengine.targeting && i.snPubConf.adengine.targeting.pbjs && i.snPubConf.adengine.targeting.pbjs.specialization || "",
                                platformUid: getPlatformUid()
                            }
                        }
                    }
                }
            };
            i.pbjsObj.setBidderConfig(e), r.removeEventListener(i.coreEvents.coreAuctionStart, c)
        }
    }
    t.init = function(e) {
        var t, n, l;
        return (t = i.pbjsObj) && t.que.push((function() {
                for (var e in s) {
                    var n = s[e];
                    n.adpt && (t.aliasBidder(n.adpt, e, {
                        gvlid: n.gvlid
                    }), o.info("Aliasing '" + e + "' bidder using '" + n.adpt + "' adapter and gvlid: " + n.gvlid));
                    var i = d(e, n);
                    i && (t.setBidderConfig(i), o.info("Setting '" + e + "' specific settings: ", i))
                }
            })), n = !1, (a.adUnits || []).forEach((function(e) {
                for (var t = e.bidders || [], i = t.length - 1; i >= 0; i--) "amazon" === t[i].bidder && (n || (a.modules = a.modules || {}, a.modules.amazonTam = {
                    enabled: !0
                }, n = !0), e.amazonTam = !0, t.splice(i, 1))
            })), (a.adUnits || []).some((function(e) {
                for (var t = e.bidders || [], n = t.length - 1; n >= 0; n--)
                    if ("doceree" === t[n].bidder) return r.addEventListener(i.coreEvents.coreAuctionStart, c), !0
            })), (l = i.pbjsObj.bidderSettings = i.pbjsObj.bidderSettings || {}).criteo = l.criteo || {}, l.criteo.storageAllowed = !0, i.pbjsObj.que.push((function() {
                i.pbjsObj.setConfig({
                    criteo: {
                        fastBidVersion: "latest"
                    }
                })
            })),
            function() {
                var e = i.pbjsObj.bidderSettings = i.pbjsObj.bidderSettings || {};
                e.onetag = e.onetag || {}, e.onetag.storageAllowed = !0
            }(),
            function() {
                var e = i.pbjsObj.bidderSettings = i.pbjsObj.bidderSettings || {};
                e.adagio = e.adagio || {}, e.adagio.storageAllowed = !0
            }(), !0
    }
}, function(e, t, n) {
    var i = n(0),
        r = n(5),
        o = n(1),
        a = n(2);

    function s(e, t, n) {
        var i = e.width,
            o = e.height,
            a = e.adUnitCode;
        if ("video" === e.mediaType || i < 10 && o < 10 && !r.getAdaptivePlacementGroup(a)) return !0;
        var s = t[a];
        if (s || n.some((function(e) {
                return e.code === a && (s = e, t[a] = e, !0)
            })), s) {
            for (var d = s.activeSizes, c = 0; c < d.length; c++) {
                var l = d[c];
                if (Array.isArray(l) && 2 === l.length && i === l[0] && o === l[1]) return !0
            }
            return !1
        }
        return !0
    }
    t.init = function(e) {
        var t = i.pbjsObj;
        return t.que.push((function() {
            t.onEvent("auctionEnd", (function(e) {
                for (var n = e.adUnits, i = e.bidsReceived || [], r = {}, d = {}, c = i.length - 1; c >= 0; c--) {
                    var l, u = i[c];
                    if (s(u, r, n)) d[l = u.adUnitCode] || (d[l] = 0), "banner" === u.mediaType && u.cpm > d[u.adUnitCode] && (d[u.adUnitCode] = u.cpm);
                    else o.warn("Bid received from '" + u.bidderCode + "' does not respect the provided active sizes. Bid is being removed. Received [" + u.width + ", " + u.height + "], provided: ", r[u.adUnitCode].activeSizes), t.markWinningBidAsUsed({
                        adUnitCode: u.adUnitCode,
                        adId: u.adId
                    }), i.splice(c, 1)
                }! function(e, t, n, i) {
                    for (var r = t.length - 1; r >= 0; r--) {
                        var o = t[r];
                        "video" === o.mediaType && o.cpm < i * (n[o.adUnitCode] || 0) && e.markWinningBidAsUsed({
                            adUnitCode: o.adUnitCode,
                            adId: o.adId
                        })
                    }
                }(t, i, d, a.get("bidding.videoCpmDelta") || 2)
            }))
        })), !0
    }
}, function(e, t, n) {
    var i, r = n(3),
        o = n(0),
        a = n(1),
        s = n(4),
        d = o.coreObj.metrics;

    function c() {
        for (var e in r.activeLots) {
            r.activeLots[e].inView = !1
        }
    }

    function l() {
        for (var e in r.activeLots) {
            var t = r.activeLots[e],
                n = d.lots[e][t.adUnit];
            if (n.viewableCountTotal = n.viewableCountTotal || 0, t.isSticky && n.viewableCountTotal >= 1) n.viewableCountTotal = 1;
            else {
                var c = t.inView;
                t.inView = i.isAdUnitInView(t.adUnit, e), c != t.inView && a.debug("Placement " + e + " visible:", t.inView), t.inView && !c && (n.viewableCountTotal++, s.dispatchEvent(o.coreEvents.coreLotViewable, {
                    metricsAction: o.coreEvents.coreLotViewable + "(" + e + ":" + t.adUnit + ")",
                    eventDetail: {
                        placement: e,
                        adUnit: t.adUnit,
                        viewableCountTotal: n.viewableCountTotal
                    }
                }))
            }
        }
    }

    function u() {
        a.debug("Document visible:", i.isDocumentVisible()), l()
    }
    t.init = function(e) {
        return function(e) {
            return i = e, s.addEventListener("resize", l), s.addEventListener("scroll", l), s.addEventListener(o.coreObjName + "AuctionEnd", c), s.addEventListener(o.coreObjName + "AuctionEnd", l), s.addEventListener("visibilitychange", u, {
                eventTarget: document
            }), !0
        }(e)
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(1),
        a = r.coreObj.config,
        s = {
            api: {
                objectName: "__tcfapi",
                version: 2
            },
            googleId: 755
        },
        d = {
            api: {
                objectName: "__uspapi",
                version: 1
            }
        };

    function c(e) {
        o.warn("No compatible consent management platform API '" + e + "' found.")
    }

    function l(e) {
        "function" != typeof e && (e = function() {
            return null
        });
        var t = a.pbjsConfig && a.pbjsConfig.consentManagement || {},
            n = d.api.objectName;
        window[n] === r.udef && t.usp && (c(n), t.allowAuctionsWithNoCMP && delete t.usp);
        var l = s.api,
            u = l.objectName;
        i.consent ? e() : window[u] === r.udef ? (c(u), i.consent = {
            deviceAccessAllowed: !0,
            googleConsent: !0
        }, t.allowAuctionsWithNoCMP && delete t.gdpr, e()) : window[u]("addEventListener", l.version, function(e) {
            return function(t, n) {
                if (!n || !1 !== t.gdprApplies && "tcloaded" !== t.eventStatus && "useractioncomplete" !== t.eventStatus) n && "cmpuishown" === t.eventStatus && o.debug("Waiting for user consent submission.");
                else {
                    if (o.debug("Consent information available.", t), t.gdprApplies) {
                        var r = t.purpose.consents[1] || t.purposeOneTreatment;
                        i.consent = {
                            deviceAccessAllowed: r,
                            googleConsent: !!t.vendor.consents[s.googleId] && r
                        }
                    } else i.consent = {
                        deviceAccessAllowed: !0,
                        googleConsent: !0
                    };
                    i.consent.tcData = t, e();
                    var a = s.api;
                    window[a.objectName]("removeEventListener", a.version, (function(e) {}), t.listenerId)
                }
            }
        }(e)), t.usp || t.gdpr || delete a.pbjsConfig.consentManagement
    }
    e.exports = {
        init: function(e) {
            l((function() {
                o.info("Consent information available: Resuming adsbygoogle delivery."), (window.adsbygoogle = window.adsbygoogle || []).pauseAdRequests = 0
            }))
        },
        executeOnConsentResolved: l
    }
}, function(e, t) {
    e.exports = {
        init: function(e) {}
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(1),
        a = n(4);

    function s() {
        for (var e in i.auction.adUnits) {
            var t = i.auction.adUnits[e];
            t.pubstack = {}, t.pubstack.adUnitPath = t.adUnitPath, t.pubstack.adUnitName = t.name
        }
    }
    e.exports = {
        init: function(e) {
            var t = r.snConf.settings.scripts;
            if (t)
                for (var n in t) {
                    if ("pubstack" === t[n].name) {
                        o.debug("Detected Pubstack, enabling GAM support..."), a.addEventListener(r.coreEvents.coreAuctionAdUnitsReady, s);
                        break
                    }
                }
        }
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(1),
        o = n(2);

    function a(e) {
        return "static" === e.type && (t = e.label, n = e.frequency, !!(t && n && Math.random() < n) && (i.targetingFilter.staticLabels.push(t), !0));
        var t, n
    }
    i.targetingFilter = i.targetingFilter || {}, i.targetingFilter.staticLabels = i.targetingFilter.staticLabels || [], t.init = function(e) {
        return (o.get("subsystems.labelGenerator.generators") || []).forEach((function(e) {
            a(e) && r.info("Setting ".concat(e.type, " targeting label '").concat(e.label, "'. Label frequency: ").concat((100 * e.frequency).toFixed(0), "%."))
        })), !0
    }
}, function(e, t, n) {
    var i = n(0),
        r = n(1),
        o = n(2);
    e.exports = {
        init: function(e, t) {
            var n = o.get("modules.adConsent"),
                a = (i.snConf.settings.adconsent || {}).objName,
                s = window[a];
            if (s) {
                e.addStyleToDocument(n.style);
                var d = n.config,
                    c = (window._snigelCallback || {}).adconsent || {},
                    l = function(e) {
                        var t = "global" === e ? s : s[e],
                            n = d[e];
                        for (var i in n) t(i, n[i], c[i])
                    };
                for (var u in d) l(u);
                var g = {
                    country: o.get("country"),
                    region: o.get("region")
                };
                r.debug("Initializing AdConsent: " + g.country + "/" + g.region), s("start", g)
            } else r.error("AdConsent object '" + a + "' not found.")
        }
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(4),
        a = n(2),
        s = n(5),
        d = n(1),
        c = {},
        l = 0;

    function u(e, t) {
        for (var n = e.cloneNode(!0), i = n; i.children.length;) i.id && (i.id += "-auto-" + t), i = i.children[0];
        return i.id = (i.id ? i.id : "div-ad-") + "-auto-" + t, c[i.id] = 1, {
            adStruct: n,
            placementId: i.id
        }
    }

    function g(e, t, n, i, r) {
        var o = n.autoAds,
            s = !o.atf,
            c = "mobile" === a.get("platform"),
            g = c ? o.densityMobile : o.density,
            f = o.minParagraphs,
            m = o.limit,
            v = [];
        if (t) {
            var p = window.innerHeight,
                b = t.getBoundingClientRect(),
                h = function(e, t) {
                    var n = 0,
                        i = 0;
                    return (e.activeSizes || []).forEach((function(e) {
                        Array.isArray(e) && e.length > 1 && e[1] > 30 && (n += e[1], i++)
                    })), i > 0 ? n / i : t ? 150 : 250
                }(n, c);
            g = (g = g > 50 ? 50 : g) < 5 ? 5 : g, d.debug("Auto ads section size: " + b.width + ", " + b.height);
            var y = r ? r.getBoundingClientRect().y : 0,
                A = b.height - y;
            d.debug("Auto ads going to compute for Y in [" + y + ", " + A + "]");
            for (var w = g / 100 * A, S = [], E = m || -1; w > 0 && E;) {
                var L = h;
                S.push(L), w -= L, E--
            }
            d.debug("Auto ads going to try to add the following ads: ", S);
            var C = [];
            if (S.length > 0) {
                var x = A / (S.length + 1);
                s && x < p && !r ? (C.push(p), x = (b.height - p) / S.length) : C.push(x + y);
                for (var T = 1; T < S.length; T++) C.push(x)
            }
            d.debug("Auto ads proposed ad positions: ", C);
            var j, O = t.children,
                P = 0,
                U = [],
                I = 0,
                R = !r;
            for (T = 0; T < O.length; T++)
                if ((j = O[T]) === r && (R = !0), R) {
                    I++;
                    var z = j.getBoundingClientRect().y - b.y;
                    I >= f && z >= C[P] && (U.push(j), I = 0, C[++P] += z, d.debug("Auto ads ad being created at Y=" + z))
                }
            j = null;
            for (T = 0; T < U.length; T++) {
                j = U[T];
                var k = u(i, l + T);
                v.push({
                    adUnit: n.name,
                    placement: k.placementId,
                    lazyLoad: !0
                }), t.insertBefore(k.adStruct, j)
            }
            return l += U.length, v.length && e.startAuction(v), j || r
        }
        return null
    }
    e.exports = {
        init: function(e, t) {
            a.get("modules.autoAds.enabled") && o.addEventListener(r.coreEvents.coreAuctionAdUnitsSet, (function() {
                var t = [];
                (i.auction.adUnits || []).forEach((function(e) {
                    var n = s.getAdaptiveBasePlacement(e.code);
                    e.autoAds && !c[n] && (c[n] = 1, t.push(e))
                })), t.length > 0 && e.doOnDomReady((function() {
                    t.forEach((function(t) {
                        var n = document.getElementById(t.code);
                        if (n) {
                            var i = function(e) {
                                for (var t = e, n = e.parentElement; n && 1 === n.children.length;) t = n, n = n.parentElement;
                                return t.cloneNode(!0)
                            }(n);
                            if (i) {
                                var r = function(e, t) {
                                    var n;
                                    if (t) n = document.getElementById(t);
                                    else
                                        for (n = e.parentElement; n && 1 === n.children.length;) n = n.parentElement;
                                    return n
                                }(n, t.autoAds.sectionId);
                                r && (t.autoAds.dynamicContent ? function(e, t, n, i) {
                                    var r = null,
                                        a = !1,
                                        s = !1;

                                    function d() {
                                        a = !0, r = g(e, t, n, i, r), a = !1, s && (s = !1, d())
                                    }
                                    o.addEventListener("scroll", (function() {
                                        a ? s = !0 : d()
                                    }), {
                                        polledInMs: 100
                                    }), d()
                                }(e, r, t, i) : g(e, r, t, i))
                            }
                        }
                    }))
                }))
            }))
        }
    }
}, function(e, t, n) {
    var i, r = n(3),
        o = n(0),
        a = n(1),
        s = n(4),
        d = n(2),
        c = {
            amazonGvlId: 793,
            pubID: "3927",
            adServer: "googletag"
        },
        l = {
            activeSlots: []
        };

    function u(e, t) {
        s.addEventListener(o.coreEvents.coreBiddingPhaseStart, (function() {
            if (d.get("bidding.enabled")) {
                if (r.consent.tcData && r.consent.tcData.gdprApplies && (!r.consent.tcData.vendor.consents[c.amazonGvlId] || !r.consent.deviceAccessAllowed)) return a.warn("Consent requirements for Amazon TAM not met. Skipping calling bids for Amazon TAM."), !1;
                l.activeSlots = [], r.auction.adUnits.forEach((function(e) {
                    if (!0 === e.amazonTam) {
                        var t = "(" + e.code + ":" + e.name + ")";
                        a.debug("Amazon TAM enabled for lot " + t + "."), e.mediaTypes.banner ? e.mediaTypes.banner.sizes.length > 0 && l.activeSlots.push({
                            slotID: e.code,
                            slotName: e.adUnitPath,
                            sizes: e.mediaTypes.banner.sizes
                        }) : a.warn("Amazon TAM enabled lot " + t + " has no media type 'banner'. Not adding lot to apstag bidding.")
                    }
                })), l.activeSlots.length > 0 ? function(e, t, n) {
                    r.adServer.deferredBy[i] = 1;
                    var o = !1,
                        s = n + 2e3,
                        d = l.activeSlots.map((function(e) {
                            return e.slotID
                        })).map((function(e) {
                            return "(" + e + ":" + r.activeLots[e].adUnit + ")"
                        })).join("\n\t");
                    a.info("Calling Amazon TAM bids with a timeout of " + n + "ms for lots:\n\t" + d);
                    var c = setTimeout((function() {
                        o = !0, t.auctions[t.auctions.length - 1].apstagBidding.rdyTs = e.getPerformanceNow(), a.warn("Calling bids for Amazon TAM failed. Calling ad-server."), e.callAdServer(i)
                    }), s);
                    t.auctions[t.auctions.length - 1].apstagBidding = {
                        reqTs: e.getPerformanceNow()
                    }, window[i].fetchBids({
                        slots: l.activeSlots,
                        timeout: n
                    }, (function(n) {
                        if (o) a.warn("Amazon TAM is returning bids after hitting failsafe timeout. Results are going to be ignored.");
                        else {
                            clearTimeout(c), t.auctions[t.auctions.length - 1].apstagBidding.rdyTs = e.getPerformanceNow();
                            var r = (t.auctions[t.auctions.length - 1].apstagBidding.rdyTs - t.auctions[t.auctions.length - 1].apstagBidding.reqTs).toFixed(0);
                            a.info("Amazon TAM bidding finished in " + r + "ms. Calling ad-server."), e.callAdServer(i)
                        }
                    }))
                }(e, t, d.get("modules.amazonTam.timeoutMs") || d.get("bidding.timeoutMs")) : a.debug("None of the active auction lots have Amazon TAM activated. Skipping Amazon TAM bidding.")
            } else a.warn("Bidding disabled. Skipping requesting TAM bids.")
        }))
    }
    e.exports = {
        init: function(e, t) {
            if (d.get("modules.amazonTam.enabled")) {
                var n = o.snConf.settings.apstag || {};
                if (i = n.objName, window[i] === o.udef) return a.debug("Amazon TAM module '" + i + "' object not found."), !1;
                if (!d.get("adUnits").some((function(e) {
                        return !!e.amazonTam
                    }))) return a.debug("Current configuration does not contain any Amazon TAM enabled ad-units. Disabling Amazon TAM module."), !1;
                c.schain = d.get("pbjsConfig.schain.config"), c.schain || a.error("Can't replicate schain configuration for Amazon TAM. Prebid SCO not configured."),
                    function(e) {
                        window[i].init(c, (function() {
                            var t = function() {
                                var t = e.metrics.getTimestamp("apstag", "queued").toFixed(0) + "ms",
                                    n = e.metrics.getTimestamp("apstag", "requested").toFixed(0) + "ms",
                                    i = e.metrics.getDuration("apstag", "requested", "loaded").toFixed(0) + "ms";
                                a.info("Apstag ready. Queued at: " + t + ". Requested at: " + n + ". Load in: " + i + ".")
                            };
                            o.snConf.resources.apstag.loaded ? t() : o.snConf.resources.apstag.scriptElement.addEventListener("load", t)
                        }))
                    }(e),
                    function(e, t) {
                        s.addEventListener(o.coreEvents.coreAdServerStart, (function() {
                            window[i].setDisplayBids();
                            var n = t.auctions[t.auctions.length - 1].apstagBidding,
                                r = n && n.rdyTs && n.reqTs ? n.rdyTs - n.reqTs : null;
                            l.activeSlots.map((function(e) {
                                return e.slotID
                            })).forEach((function(t) {
                                e.addTargetingKeyValueToAdServer(t, "sn_tam", 1), r && e.addTargetingKeyValueToAdServer(t, "amznt", r)
                            }))
                        }))
                    }(e, t), u(e, t)
            }
        }
    }
}, function(e, t, n) {
    n(0), n(1), n(4);
    var i = n(2);
    e.exports = {
        init: function(e, t) {
            if (i.get("modules.interstitial.enabled")) {
                var n = i.get("modules.interstitial.adUnitPath"),
                    r = i.get("adUnits") || [],
                    o = !1;
                r.forEach((function(e) {
                    e.adUnitPath === n && e.interstitial && (e.interstitial.manual = !1, o = !0)
                })), o || r.push({
                    name: "interstitialFromModule",
                    adUnitPath: n,
                    interstitial: {
                        manual: !1
                    }
                })
            }
        }
    }
}, function(e, t, n) {
    var i = n(0),
        r = n(1),
        o = n(2);
    e.exports = {
        init: function(e, t) {
            var n = "Malvertising scanner module ",
                a = o.get("modules.confiant");
            if (!a.enabled) return r.debug(n + "disabled."), !1;
            if (function(e, t, n, o) {
                    for (var a in o) {
                        var s, d = o[a];
                        switch (a) {
                            case "platform":
                                s = t;
                                break;
                            case "os":
                                s = n;
                                break;
                            default:
                                r.debug("Unkown label section '" + a + "' in malvertising scanner module configuration.")
                        }
                        if (s !== i.udef && d !== i.udef)
                            for (var c in d) {
                                var l;
                                switch (c) {
                                    case "any":
                                        l = e.labels.matchAny(s, d.any);
                                        break;
                                    case "none":
                                        l = e.labels.matchNone(s, d.none)
                                }
                                if (r.debug("Malvertising scanner label for '" + a + "': (" + s + ") " + c + " of (" + d[c] + "): ", l), !1 === l) return !0
                            }
                    }
                    return !1
                }(e, o.get("platform"), o.get("os"), a.labels || {})) return r.debug(n + "inactive for this page impression due to label filtering."), !1;
            n += "activated ";
            var s, d = a.staticUrl + a.propertyId;
            if (a.scanGpt && a.scanPbjs) d += a.gptPbjsScript, s = "Prebid and GPT.";
            else if (a.scanGpt) d += a.gptScript, s = "GPT.";
            else {
                if (!a.scanPbjs) return r.warn(n + "but no valid configuration was found. Disabling module..."), !1;
                d += a.pbjsScript, s = "Prebid."
            }
            r.debug(n + "for " + s), e.loadScriptAsync(d)
        }
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(1),
        o = n(4),
        a = n(2),
        s = n(5);

    function d() {
        var e = [],
            t = {};
        for (var n in i.activeLots) {
            var r = s.getAdaptiveBasePlacement(n);
            t[r] || (t[r] = !0, e.push({
                placement: r,
                adUnit: i.activeLots[n].adUnit
            }))
        }
        return e
    }

    function c(e, t, n, i, r) {
        var o = function(e, t, n, i, r) {
            var o = [
                [],
                []
            ];
            return t.some((function(t) {
                if (e === t.name) {
                    var a = JSON.parse(JSON.stringify(t));
                    return n.sizeMapper.processAdUnits([a], i, r), o[0] = a.activeSizes.slice(), n.sizeMapper.processAdUnits([a]), o[1] = a.activeSizes.slice(), !0
                }
            })), o
        }(e.adUnit, t, n, i, r);
        return !n.sizeMapper.sizeArrays.containSameSizes(o[0], o[1])
    }

    function l(e, t) {
        return e.length > 0 ? (r.debug("Reauctioning the following lots due to window resizing:\n\t" + e.map((function(e) {
            return "(" + e.placement + ":" + e.adUnit + ")"
        })).join("\n\t")), t.startAuction(e), !0) : (r.debug("Active lot sizes unchanged. No lots require reauctioning due to window resizing."), !1)
    }
    e.exports = {
        init: function(e, t) {
            if (a.get("modules.reauctionResize.enabled")) {
                var n = window.innerWidth,
                    i = window.innerHeight;
                o.addEventListener("resize", (function(t) {
                    r.debug("Window resized to  ".concat(window.innerWidth, "x").concat(window.innerHeight, "."));
                    var o = n,
                        s = i;
                    return n = window.innerWidth, i = window.innerHeight, a.get("modules.reauctionResize.reauctionAllActiveLots") ? l(d(), e) : l(function(e, t, n) {
                        var i = d(),
                            r = a.get("adUnits"),
                            o = [];
                        return i.forEach((function(i) {
                            c(i, r, e, t, n) && o.push(i)
                        })), o
                    }(e, o, s), e)
                }), {
                    gracePeriodInMs: 500
                })
            }
        }
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(4),
        a = n(6),
        s = n(12),
        d = n(2),
        c = n(5),
        l = n(8),
        u = {},
        g = {};

    function f(e, t, n) {
        if (e && (n ? e.classList.remove("adhesive-hidden") : e.classList.add("adhesive-hidden")), t && "bottom" === t.position) {
            var i = document.getElementById("adconsent-usp-link");
            i && (n ? i.classList.add("snigel-adhesive-ccpa") : i.classList.remove("snigel-adhesive-ccpa"))
        }
    }

    function m(e, t, n) {
        n && (e < n.offsetWidth ? n.classList.add(t) : n.classList.remove(t))
    }

    function v(e) {
        a.addEventListener("slotRenderEnded", (function(e) {
            if (e.slot) {
                var t = c.getAdaptiveBasePlacement(e.slot.getSlotElementId()),
                    n = u[t];
                if (n && (g[t] = g[t] || (e.isEmpty ? r.udef : {
                        adWidth: 0
                    }), f(document.getElementById(t + "-adhesive"), n.adhesive, g[t]), !e.isEmpty)) {
                    var o = function(e, t, n) {
                            var i = e;
                            if (1 === i) {
                                var r = document.getElementById(n);
                                r && Array.from(r.children).forEach((function(e) {
                                    -1 === (e.id || "").indexOf("sn_ad_label") && i < e.offsetWidth && (i = e.offsetWidth)
                                }))
                            }
                            return t.adWidth += i, t.adWidth
                        }(e.size[0], g[t], e.slot.getSlotElementId()),
                        a = (i.auction.window.width - o) / 2;
                    m(a, "extern", document.getElementById(t + "-adhesive-close")), m(a, "adhesive-hidden", document.getElementById(t + "-adhesive-logo"))
                }
            }
        })), o.addEventListener(r.coreEvents.coreAuctionEnd, (function() {
            Object.keys(u).length > 0 && e.doOnDomReady((function() {
                for (var e in u) {
                    var t = u[e];
                    c.getAdaptiveSubPlacements(e).forEach((function(n) {
                        var r = i.activeLots[n];
                        r && !r.adSlot && f(document.getElementById(e + "-adhesive"), t.adhesive, r.pbjsAdIframe)
                    }))
                }
            }))
        }))
    }

    function p(e, t) {
        var n = d.get("modules.adLabeling"),
            r = d.get("modules.parallax.enabled"),
            o = [];
        return (i.auction.adUnits || []).forEach((function(i) {
            var a, d, g = i.code;
            if (i.adhesive && !c.isAdaptiveSubPlacement(g)) {
                var f;
                if (s.setRefreshWithViewabilityOnly(i, !1), o.push(i), u[g] = i, r && i.parallax ? f = l.getParallaxContainerHeight(i) : (a = i.activeSizes || [], d = 0, a.forEach((function(e) {
                        Array.isArray(e) && 2 === e.length && d < e[1] && (d = e[1])
                    })), f = d), n && n.enabled) {
                    var m = n.excludedAdUnits || [],
                        v = n.moduleHandledAdUnits || [];
                    (-1 === m.indexOf(g) || v.indexOf(g) >= 0) && (f += 15)
                }
                var p = g + "-adhesive";
                e[p] = function(e, t, n, i) {
                    var r = e.adhesive,
                        o = "[id='" + t + "']{min-height:" + (n ? i : 0) + "px}[id='" + t + "']." + r.position + ".adhesive-hidden{" + r.position + ":-" + (i + 100) + "px}";
                    if (o += r.style || "", r.extendContent) {
                        var a = "snigel-adhesive-contentextension-" + r.position,
                            s = document.getElementById(a);
                        s || ((s = document.createElement("div")).id = a, "bottom" === r.position ? document.body.appendChild(s) : "top" === r.position && document.body.insertBefore(s, document.body.childNodes[0])), o += "#" + a + "{height:" + i + "px}"
                    }
                    return "bottom" === r.position && (o += ".snigel-adhesive-ccpa{bottom:" + (i + 20) + "px !important;transition:all 500ms ease-out}"), o
                }(i, p, t, f)
            }
        })), o
    }

    function b(e) {
        var t = d.get("modules.adhesive.noResize");
        o.addEventListener(r.coreEvents.coreAuctionAdUnitsSet, (function() {
            g = {};
            var n = {},
                i = p(n, t);
            if (i.length > 0) {
                for (var r in n) {
                    var o = r + "-style",
                        a = document.getElementById(o);
                    a && a.parentNode && a.parentNode.removeChild(a), e.addStyleToDocument(n[r], o)
                }
                e.doOnDomReady((function() {
                    i.forEach((function(e) {
                        ! function(e, t) {
                            var n, i, r, o = e.adhesive,
                                a = e.code + "-adhesive",
                                c = document.getElementById(a);
                            if (!c) {
                                (c = document.createElement("div")).id = a;
                                var l = document.getElementById(e.code);
                                if (l || ((l = document.createElement("div")).id = e.code), t) {
                                    l.className = "snigel-adhesive-centered", l.style.top = "50%";
                                    var u = document.createElement("div");
                                    u.className = "snigel-adhesive-center", u.appendChild(l), c.appendChild(u)
                                } else c.appendChild(l);
                                if (!o.hideCloseButton) {
                                    var g = document.createElement("div");
                                    g.id = a + "-close", g.className = "close-adhesive", g.classList.add(o.position), g.innerHTML = '<svg height="100%" width="100%" viewBox="0 0 100 100"><path class="close-adhesive-icon" d="M8 22 L36 50 L8 78 A9.9 9.9 0 1 0 22 92 L50 64 L78 92 A9.9 9.9 0 1 0 92 78 L64 50 L92 22 A9.9 9.9 0 1 0 78 8 L50 36 L22 8 A9.9 9.9 0 1 0 8 22"/>X</svg>', g.addEventListener("click", (n = c, i = o, r = e, function(e) {
                                        f(n, i), s.setRefreshWithViewabilityOnly(r, !0)
                                    })), c.appendChild(g)
                                }
                                if (o.showLogo) {
                                    var m = document.createElement("a");
                                    m.id = a + "-logo", m.className = "logo-adhesive", "mobile" === d.get("platform") && m.classList.add("mobile"), m.href = "https://www.snigel.com", m.target = "_blank", c.appendChild(m)
                                }
                                c.className = "snigel-adhesive", c.classList.add(o.position), f(c, o), document.body.appendChild(c)
                            }
                        }(e, t)
                    }))
                }))
            }
        }))
    }
    e.exports = {
        init: function(e, t) {
            d.get("modules.adhesive.enabled") && (e.addStyleToDocument(".snigel-adhesive{box-sizing:content-box;position:fixed;left:0;right:0;z-index:99999;text-align:center;padding-top:5px;padding-bottom:5px;background-color:#f2f6f7;transition:all 500ms ease-out}.snigel-adhesive.bottom{bottom:0}.snigel-adhesive.top{top:0}.snigel-adhesive-center{position:absolute;top:0;bottom:0;right:0;left:0}.snigel-adhesive-centered{position:absolute;margin:0;transform:translateY(-50%);right:0;left:0}.close-adhesive{box-sizing:content-box;width:16px;height:16px;position:absolute;right:0;padding:5px;background-color:#f2f6f7;text-align:center;cursor:pointer}.close-adhesive.bottom{top:0}.close-adhesive.top{bottom:0}.close-adhesive.bottom.extern{top:-21px;padding-bottom:0}.close-adhesive.top.extern{bottom:-21px;padding-top:0}.close-adhesive>svg{display:block}.close-adhesive-icon{fill:gray;stroke-width:3;stroke:#73d9c6}.logo-adhesive{cursor:pointer;opacity:0.65;position:absolute;left:5px;top:5px;width:24px;height:24px;background:url('https://cdn.snigelweb.com/resources/img/logo/snigel-icon.png') no-repeat 50% 50%/contain}.logo-adhesive:hover{opacity:1}.logo-adhesive.adhesive-hidden{left:-500px}"), b(e), v(e), function(e) {
                o.addEventListener(r.coreEvents.coreAdServerStart, (function() {
                    for (var t in u) {
                        var n = u[t];
                        c.getAdaptiveSubPlacements(t).forEach((function(t) {
                            var r = i.activeLots[t];
                            r && r.adSlot && n.adhesive && e.addTargetingKeyValueToAdServer(t, "sn_stk", n.adhesive.position)
                        }))
                    }
                }))
            }(e))
        }
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(4),
        a = n(2),
        s = n(8),
        d = n(5),
        c = {},
        l = {},
        u = {},
        g = -1,
        f = !1;

    function m(e, t, n) {
        var i = e[t];
        if (i.top >= n) return 0;
        var r = 1;
        for (var o in e) {
            var a = e[o],
                s = c[o] ? c[o].adUnit.sticky.topOffset : n;
            if (!a.isFixed && a.top < s && a.top > i.top && a.right >= i.left && i.right >= a.left) {
                if (1 != r) return 0;
                r = 2
            }
        }
        return r
    }

    function v(e) {
        for (var t in l) {
            var n = l[t],
                i = document.getElementById(n + "-stickypointer") || document.getElementById(n);
            if (i) {
                var r = u[t],
                    o = i.getBoundingClientRect();
                u[t] = o, g > -1 && r && r.top === o.top && g != window.scrollY && (u[t].isFixed = !e || r.isFixed), g = window.scrollY;
                var a = c[n];
                if (a) {
                    var s = a.adUnit.sticky || {},
                        d = document.getElementById(n);
                    s.makeParentSticky && (d = (d || {}).parentNode || i), u[t].height != d.offsetHeight && (u[t].height = d.offsetHeight, a.sticked = !1, a.sticking = !1)
                }
            }
        }
        return u
    }

    function p(e, t, n, i) {
        t.sticked && (t.sticked = !1, t.sticking = !1);
        var r = document.getElementById(i);
        if (n.makeParentSticky && (r = (r || {}).parentNode), r) {
            var o = r.style;
            o.position = "", o.top = "", o.width = "", o.left = "", o.zIndex = "", r.className = ""
        }
        e.style.height = ""
    }

    function b(e, t, n, i, o, a, s) {
        var d = e.getBoundingClientRect(),
            c = document.getElementById(i);
        return n.makeParentSticky && (c = (c || {}).parentNode), t.sticked && !a || (t.sticked || (t.sticked = !0, t.sticking = !1), e.style.height = c.offsetHeight + "px", c && (c.style.width = d.width + "px", c.style.zIndex = n.zIndex !== r.udef ? n.zIndex : 9999, c.className = e.className)), c && function(e, t, n, i, r, o, a) {
            var s = n.topOffset,
                d = n.minSpaceToNextAd,
                c = s;
            if (i.height) {
                for (var l in r) {
                    var u = r[l];
                    !u.isFixed && u.top > i.top && u.top <= i.height + s + d && u.right >= i.left && i.right >= u.left && c > u.top - i.height - d && (c = u.top - i.height - d)
                }
                c < s ? (t.sticking || (t.sticking = !0, e.style.position = "relative", e.style.left = ""), e.style.top = c - i.top + "px") : 1 == a && (t.sticking = !1, e.style.position = "fixed", e.style.left = o.left + "px", e.style.top = s + "px")
            } else e.style.position = "fixed", e.style.top = "-10000px"
        }(c, t, n, o[i], o, d, s), !!o[i].height
    }

    function h(e) {
        var t = v(e),
            n = [];
        for (var i in c) {
            var r = document.getElementById(i + "-stickypointer");
            if (r) {
                var o = c[i],
                    a = o.adUnit.sticky,
                    s = m(t, i, a.topOffset);
                s ? b(r, o, a, i, t, e, s) || n.push(i) : p(r, o, a, i)
            }
        }
        return n
    }

    function y(e) {
        o.addEventListener(r.coreEvents.coreAuctionAdUnitsSet, (function() {
            f || (f = (i.auction.adUnits || []).some((function(e) {
                return !!e.sticky
            }))) && (function() {
                o.addEventListener("resize", (function() {
                    h(!0)
                }), {
                    polledInMs: 30
                }), o.addEventListener("scroll", (function() {
                    h()
                }), {
                    polledInMs: 30
                });
                var e = null;
                o.addEventListener(r.coreEvents.coreAuctionEnd, (function() {
                    var t = 2e3;
                    clearTimeout(e),
                        function n() {
                            var r = h();
                            r.length && t > 0 && (t -= 20, (i.auction.adUnits || []).some((function(e) {
                                return e.sticky && r.indexOf(e.code) > -1
                            })) && (e = setTimeout((function() {
                                n()
                            }), 20)))
                        }()
                }))
            }(), function(e) {
                o.addEventListener(r.coreEvents.coreAdServerStart, (function() {
                    for (var t in c) {
                        var n = c[t];
                        d.getAdaptiveSubPlacements(t).forEach((function(t) {
                            var r = i.activeLots[t];
                            r && r.adSlot && n && n.adUnit && n.adUnit.sticky && e.addTargetingKeyValueToAdServer(t, "sn_stk", "vertical")
                        }))
                    }
                }))
            }(e)), f && e.doOnDomReady((function() {
                var e;
                i.auction.adUnits.forEach((function(e) {
                    l[e.code] || e.adhesive || d.isAdaptiveSubPlacement(e.code) || (l[e.code] = s.getAdUnitPlacement(e), e.sticky && function(e) {
                        var t = e.code;
                        c[t] = {
                            adUnit: e,
                            sticked: !1
                        };
                        var n = t + "-stickypointer";
                        if (!document.getElementById(n)) {
                            var i = document.getElementById(t);
                            if (i) {
                                e.sticky.makeParentSticky && (t = (i = i.parentNode).id), i.id = n;
                                var r = document.createElement("div");
                                for (r.id = t; i.children.length > 0;) r.appendChild(i.children[0]);
                                i.appendChild(r), r.style = i.style, i.style = ""
                            }
                        }
                    }(e))
                })), (e = function(e, t) {
                    Array.isArray(e) && e.forEach((function(e) {
                        var n = t(e);
                        l[n] || (l[n] = n)
                    }))
                })(i.adServer.additionalAdSlots, (function(e) {
                    return e.getSlotElementId()
                })), e(i.adServer.additionalAdSlotsElementIds, (function(e) {
                    return e
                })), e(a.get("modules.sticky.bumpingElements"), (function(e) {
                    return e
                }))
            }))
        }))
    }
    e.exports = {
        init: function(e, t) {
            a.get("modules.sticky.enabled") && y(e)
        }
    }
}, function(e, t, n) {
    function i(e, t) {
        var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (!n) {
            if (Array.isArray(e) || (n = function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return r(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return r(e, t)
                }(e)) || t && e && "number" == typeof e.length) {
                n && (e = n);
                var i = 0,
                    o = function() {};
                return {
                    s: o,
                    n: function() {
                        return i >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[i++]
                        }
                    },
                    e: function(e) {
                        throw e
                    },
                    f: o
                }
            }
            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }
        var a, s = !0,
            d = !1;
        return {
            s: function() {
                n = n.call(e)
            },
            n: function() {
                var e = n.next();
                return s = e.done, e
            },
            e: function(e) {
                d = !0, a = e
            },
            f: function() {
                try {
                    s || null == n.return || n.return()
                } finally {
                    if (d) throw a
                }
            }
        }
    }

    function r(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, i = new Array(t); n < t; n++) i[n] = e[n];
        return i
    }

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }
    var a, s = n(3),
        d = n(0),
        c = n(1),
        l = n(4),
        u = n(2);

    function g(e, t) {
        return Array.isArray(t) ? !!t.some((function(t) {
            return e.adUnit === t.adUnit && e.placement === t.placement
        })) : "object" === o(t) && (t[e.placement] && t[e.placement].adUnit === e.adUnit)
    }

    function f() {
        0 === s.lazyLoad.lazyLoadLots.length ? (l.removeEventListener("resize", f), l.removeEventListener("scroll", f), c.debug("Lazy-load event listener deactivated."), s.lazyLoad.listenerActive = !1) : function() {
            for (var e = s.lazyLoad.lazyLoadLots.length - 1; e >= 0; e--) {
                var t = s.lazyLoad.lazyLoadLots[e],
                    n = t.lot,
                    i = n.placement;
                if (g(n, s.activeLots)) c.error("Trying to lazy load lot '" + n.adUnit + "': '" + i + "' which is already loaded. Removed lot from lazy load module."), s.lazyLoad.lazyLoadLots.splice(e, 1);
                else {
                    var r = a.getAbsoluteVerticalViewabilityDistanceForElementId(i),
                        o = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
                        d = ~~(t.triggerMarginPercent * o / 100);
                    "mobile" === u.get("platform") && (d *= t.mobileScaling), r <= d && (c.debug("Lazy loading lot '" + n.adUnit + "': '" + i + "'."), s.lazyLoad.lazyLoadLots.splice(e, 1), a.startAuction([n]))
                }
            }
        }()
    }

    function m(e) {
        try {
            if ("object" !== o(e) || !e.adUnit || !e.placement) throw new TypeError("Expecting a minimum argument of: { placement: String, adUnit: String }.");
            if (g(e, s.lazyLoad.lazyLoadLots)) c.warn("Lot '" + e.adUnit + "': '" + e.placement + "' was already set to lazy load. Ignoring.");
            else {
                var t, n, r = Math.max(Number.parseInt(u.get("modules.lazyLoad.triggerMarginPercent")) || 100, 100);
                Number.isInteger(e.lazyLoad.triggerMarginPercent) && e.lazyLoad.triggerMarginPercent >= 100 && (r = e.lazyLoad.triggerMarginPercent);
                var a = Math.max(Number.parseInt(u.get("modules.lazyLoad.mobileScaling")) || 1, 1);
                Number.isInteger(e.lazyLoad.mobileScaling) && e.lazyLoad.mobileScaling >= 1 && (a = e.lazyLoad.mobileScaling), !1 === s.lazyLoad.listenerActive && (l.addEventListener("resize", f), l.addEventListener("scroll", f), c.debug("Lazy-load event listener activated."), s.lazyLoad.listenerActive = !0);
                var m, v = i((null === (t = d.snPubConf) || void 0 === t || null === (n = t.adengine) || void 0 === n ? void 0 : n.activeLots) || []);
                try {
                    for (v.s(); !(m = v.n()).done;) {
                        var p = m.value;
                        p.placement === e.placement && p.adUnit === e.adUnit && delete p.lazyLoad
                    }
                } catch (e) {
                    v.e(e)
                } finally {
                    v.f()
                }
                delete e.lazyLoad, s.lazyLoad.lazyLoadLots.push({
                    lot: e,
                    triggerMarginPercent: r,
                    mobileScaling: a
                })
            }
            c.debug("Enabled lazy loading for lot '" + e.adUnit + "': '" + e.placement + "'."), f()
        } catch (e) {
            c.error("Lazy load error: ", e)
        }
    }
    e.exports = {
        init: function(e, t) {
            u.get("modules.lazyLoad.enabled") && (a = e, s.lazyLoad = {
                listenerActive: !1,
                lazyLoadLots: []
            }, l.addEventListener(d.coreEvents.coreAuctionStart, (function() {
                for (var e in s.auction.requestedLots) {
                    var t = s.auction.requestedLots[e];
                    t.lazyLoad && (c.debug("Auction lot (" + t.adUnit + ":" + e + ") is queued for lazy-loading. Removing from current auction..."), delete s.auction.requestedLots[e], m(t))
                }
            })))
        }
    }
}, function(e, t, n) {
    var i = n(3),
        r = n(0),
        o = n(4),
        a = n(2),
        s = [];
    e.exports = {
        init: function(e, t) {
            a.get("modules.videoPlayer.enabled") && (o.addEventListener(r.coreEvents.coreAuctionAdUnitsReady, (function() {
                var e = i.auction.adUnits || [],
                    t = i.auction.requestedLots;
                s = [], e.forEach((function(e) {
                    var n = t[e.code];
                    n && n.contentVideoUrl && s.push(n)
                }))
            })), function(e) {
                o.addEventListener(r.coreEvents.coreAdServerStart, (function() {
                    s.forEach((function(t) {
                        (i.activeLots[t.placement] || {}).adSlot && t.contentVideoUrl && e.addTargetingKeyValueToAdServer(t.placement, "sn_cv", "string" == typeof t.contentVideoUrl ? t.contentVideoUrl : "")
                    }))
                }))
            }(e))
        }
    }
}]);
window[window._snigelConfig.settings.adngin.objName] = window[window._snigelConfig.settings.adngin.objName] || {
    queue: [],
    metrics: {}
};
window[window._snigelConfig.settings.adngin.objName].config = {
    "auction": {
        "autoRun": true
    },
    "adServer": {
        "autoCall": true,
        "policyViolationUrls": []
    },
    "bidders": {
        "rubicon": {
            "factor": 0,
            "currency": "usd"
        },
        "sovrn": {
            "factor": 0,
            "currency": "usd"
        },
        "openx": {
            "factor": 0,
            "currency": "eur"
        },
        "ix": {
            "factor": 0,
            "currency": "usd"
        },
        "conversant": {
            "factor": 0,
            "currency": "usd"
        },
        "onemobile": {
            "factor": 0,
            "currency": "usd"
        },
        "connectad": {
            "factor": 0,
            "currency": "usd"
        },
        "appnexus": {
            "factor": 0,
            "currency": "usd"
        },
        "smartadserver": {
            "factor": 0,
            "currency": "eur"
        },
        "pubmatic": {
            "factor": 0,
            "currency": "usd"
        },
        "triplelift": {
            "factor": 0,
            "currency": "usd"
        },
        "33across": {
            "factor": 0,
            "currency": "usd"
        },
        "sharethrough": {
            "factor": 0,
            "currency": "usd"
        },
        "adagio": {
            "factor": 0,
            "currency": "usd"
        },
        "onetag": {
            "factor": 0,
            "currency": "eur"
        },
        "amx": {
            "factor": 0,
            "currency": "usd"
        },
        "smilewanted": {
            "factor": 0,
            "currency": "eur"
        }
    },
    "bidding": {
        "enabled": true,
        "timeoutMs": 1250,
        "failsafeTimeoutMs": 3000,
        "adServerCurrency": "eur",
        "bidFloorEnabled": true,
        "floorCpm": 0.05,
        "videoFloorCpm": 0.7,
        "videoCpmDelta": 2,
        "defaultBidderCurrency": "usd"
    },
    "pbjsConfig": {
        "consentManagement": {
            "gdpr": {
                "cmpApi": "iab",
                "timeout": 200,
                "defaultGdprScope": true,
                "rules": [{
                    "purpose": "storage",
                    "enforcePurpose": true,
                    "enforceVendor": true
                }]
            },
            "usp": {
                "cmpApi": "iab",
                "timeout": 200
            },
            "allowAuctionsWithNoCMP": false
        },
        "priceGranularity": {
            "buckets": [{
                "precision": 2,
                "max": 20,
                "increment": 0.01
            }, {
                "precision": 2,
                "max": 100,
                "increment": 1
            }]
        },
        "bidderSequence": "random",
        "bidderTimeout": 1250,
        "maxRequestsPerOrigin": 6,
        "useBidCache": true,
        "cache": {
            "url": "https://prebid.adnxs.com/pbc/v1/cache"
        },
        "schain": {
            "validation": "strict",
            "config": {
                "ver": "1.0",
                "complete": 1,
                "nodes": [{
                    "asi": "snigelweb.com",
                    "sid": "7088",
                    "domain": "w3schools.com",
                    "hp": 1
                }]
            }
        },
        "enableSendAllBids": false,
        "targetingControls": {
            "alwaysIncludeDeals": true
        },
        "userSync": {
            "aliasSyncEnabled": true,
            "userIds": [{
                "name": "criteo",
                "storage": {
                    "type": "html5",
                    "name": "_criteo",
                    "expires": 180,
                    "refreshInSeconds": 28800
                }
            }, {
                "name": "sharedId",
                "storage": {
                    "type": "cookie",
                    "name": "_sharedID",
                    "expires": 365,
                    "refreshInSeconds": 28800
                }
            }, {
                "name": "unifiedId",
                "storage": {
                    "type": "html5",
                    "name": "_unifiedId",
                    "expires": 60,
                    "refreshInSeconds": 28800
                },
                "params": {
                    "partner": "8p4qh9l"
                }
            }, {
                "name": "id5Id",
                "storage": {
                    "type": "html5",
                    "name": "id5id",
                    "expires": 180,
                    "refreshInSeconds": 28800
                },
                "params": {
                    "partner": 364
                }
            }, {
                "name": "identityLink",
                "storage": {
                    "type": "html5",
                    "name": "_identityLink",
                    "expires": 90,
                    "refreshInSeconds": 28800
                },
                "params": {
                    "pid": "107"
                }
            }],
            "syncEnabled": true,
            "auctionDelay": 50,
            "syncsPerBidder": 5,
            "syncDelay": 5000,
            "filterSettings": {
                "all": {
                    "bidders": "*",
                    "filter": "include"
                }
            }
        },
        "s2sConfig": {
            "bidders": [],
            "enabled": false,
            "endpoint": "//adserv-sgp1.snigelweb.com/bp/v1/openrtb2/auction",
            "syncEndpoint": "//adserv-sgp1.snigelweb.com/pbs/v1/cookie_sync",
            "timeout": 400,
            "accountId": "1"
        }
    },
    "modules": {
        "sticky": {
            "enabled": true,
            "bumpingElements": ["footer"]
        },
        "adaptive": {
            "enabled": true
        },
        "adhesive": {
            "enabled": false
        },
        "confiant": {
            "enabled": {
                "primitiveTargeting": {
                    "default": true,
                    "values": [{
                        "filterId": 11,
                        "value": true
                    }]
                }
            },
            "scanGpt": false,
            "scanPbjs": true,
            "gptScript": "/gpt/config.js",
            "staticUrl": "https://cdn.confiant-integrations.net/",
            "pbjsScript": "/prebid/config.js",
            "propertyId": "t_Qv_vWzcBDsyn934F1E0MWBb1c",
            "gptPbjsScript": "/gpt_and_prebid/config.js"
        },
        "lazyLoad": {
            "enabled": false,
            "mobileScaling": 5,
            "triggerMarginPercent": 100
        },
        "parallax": {
            "enabled": false
        },
        "adConsent": {
            "style": ".snigel-cmp-framework .sn-inner {background-color:#fffefe!important;}.snigel-cmp-framework .sn-b-def {border-color:#04aa6d!important;color:#04aa6d!important;}.snigel-cmp-framework .sn-b-def.sn-blue {color:#ffffff!important;background-color:#04aa6d!important;border-color:#04aa6d!important;}.snigel-cmp-framework .sn-selector ul li {color:#04aa6d!important;}.snigel-cmp-framework .sn-selector ul li:after {background-color:#04aa6d!important;}.snigel-cmp-framework .sn-footer-tab .sn-privacy a {color:#04aa6d!important;}.snigel-cmp-framework .sn-arrow:after,.snigel-cmp-framework .sn-arrow:before {background-color:#04aa6d!important;}.snigel-cmp-framework .sn-switch input:checked + span::before {background-color:#04aa6d!important;}#adconsent-usp-link {border: 1px solid #04aa6d!important;color:#04aa6d!important;}#adconsent-usp-banner-optout input:checked + .adconsent-usp-slider {background-color:#04aa6d!important;}#adconsent-usp-banner-btn {color:#ffffff;border: solid 1px #04aa6d!important;background-color:#04aa6d!important; }",
            "config": {
                "ccpa": {
                    "setUSPLink": "ccpa",
                    "setSignedLSPA": true,
                    "setPrivacyPolicy": "https://www.w3schools.com/about/about_privacy.asp"
                },
                "gdpr": {
                    "setLogo": "https://www.w3schools.com/images/w3schools_logo_500_04AA6D.png",
                    "setUiMode": 0,
                    "setPrivacyPolicy": "https://www.w3schools.com/about/about_privacy.asp",
                    "enableWelcomeText": true,
                    "reconsiderConsent": 48,
                    "enableWelcomeTitle": true,
                    "disableLegitimateInterest": false
                },
                "global": {
                    "setPublisherCC": "US",
                    "enableGoogleAnalytics": false
                }
            },
            "enabled": true
        },
        "adLabeling": {
            "label": "ADVERTISEMENT",
            "style": "color:#000000;font-size:12px;margin:0;text-align:center;",
            "enabled": true,
            "excludedAdUnits": ["adngin-try_it_leaderboard-0", "adngin-main_leaderboard-0", "adngin-main_leaderboard_courses-0", "adngin-try_it_leaderboard_courses-0", "div-gpt-ad-1428407818244-0", "div-gpt-ad-1422003450156-2", "snhb-w3schools_video-0", "adngin-video2-0"]
        },
        "videoPlayer": {
            "enabled": false
        },
        "smartRefresh": {
            "enabled": true
        },
        "reauctionResize": {
            "enabled": false,
            "reauctionAllActiveLots": false
        }
    },
    "filters": ["labels", "sizeMap"],
    "adUnits": [{
        "name": "outstream",
        "bidders": [],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true,
            "sizeConstriction": false
        },
        "snConfig": {},
        "adUnitPath": "/22152718,16833175/w3schools_outstream",
        "sizeMapping": {
            "banner": {
                "biddingSizes": [],
                "additionalSizes": [
                    [1, 1]
                ]
            }
        },
        "adUnitPathRegex": "",
        "adUnitPathOverride": false
    }, {
        "name": "bottom_right_courses",
        "bidders": [{
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "amx",
            "params": {
                "tagId": "c25pZ2VsLmNvbQ",
                "adUnitId": "w3_bottom_right_courses"
            },
            "objectTargeting": {
                "filterId": "83"
            }
        }, {
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3_bottom_right_courses",
                "organizationId": "1060",
                "adUnitElementId": "adngin-bottom_right_courses-0"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 21709731
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "677772"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a969434017979ae664dc49241a70261"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "544079625",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 2065390,
                "accountId": 14598
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true,
            "sizeConstriction": false
        },
        "adUnitPath": "/22152718,16833175/w3schools_bottom_right_courses",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "min-width": 975
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "main_leaderboard_courses",
        "bidders": [{
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238401
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 21709728
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "677769"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a969434017979ae664dc49107990260"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "544079622",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 2065384,
                "accountId": 14598
            }
        }, {
            "bidder": "amx",
            "params": {
                "tagId": "c25pZ2VsLmNvbQ",
                "adUnitId": "w3schools.com_main_leaderboard_courses"
            },
            "objectTargeting": {
                "filterId": "83"
            }
        }, {
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3_main_leaderboard_courses",
                "organizationId": "1060",
                "adUnitElementId": "w3_main_leaderboard_courses"
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true,
            "sizeConstriction": false
        },
        "adUnitPath": "/22152718,16833175/w3schools_main_leaderboard_courses",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 469
                    },
                    "biddingSizes": [
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 779,
                        "min-width": 470
                    },
                    "biddingSizes": [
                        [468, 60],
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 992,
                        "min-width": 780
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1024,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [468, 60],
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1025
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "mid_content_courses",
        "bidders": [{
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238403
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "amx",
            "params": {
                "tagId": "c25pZ2VsLmNvbQ",
                "adUnitId": "w3_mid_content_courses"
            },
            "objectTargeting": {
                "filterId": "83"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 21709729
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a96917d017979ae6267c49174c9026b"
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "677770"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "544079623",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 2065386,
                "accountId": 14598
            }
        }, {
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3_mid_content_courses",
                "organizationId": "1060",
                "adUnitElementId": "w3_mid_content_courses"
            }
        }],
        "adaptive": {
            "enabled": true,
            "uniformGrouping": true,
            "sizeConstriction": true
        },
        "adUnitPath": "/22152718,16833175/w3schools_mid_content_courses",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 469
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280],
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 779,
                        "min-width": 470
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280],
                        [320, 50],
                        [468, 60]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 992,
                        "min-width": 780
                    },
                    "biddingSizes": [
                        [728, 90],
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1024,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1440,
                        "min-width": 1025
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280],
                        [728, 90]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1441
                    },
                    "biddingSizes": [
                        [728, 90],
                        [970, 250],
                        [970, 90],
                        [300, 250]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "bottom_left_courses",
        "bidders": [{
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "amx",
            "params": {
                "tagId": "c25pZ2VsLmNvbQ",
                "adUnitId": "w3_bottom_left_courses"
            },
            "objectTargeting": {
                "filterId": "83"
            }
        }, {
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3_bottom_left_courses",
                "organizationId": "1060",
                "adUnitElementId": "adngin-bottom_left_courses-0"
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "677771"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a969938017979ae5eb6c491f5f50289"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "544079624",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 21709730
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 2065388,
                "accountId": 14598
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true
        },
        "adUnitPath": "/22152718,16833175/w3schools_bottom_left_courses",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 1239
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1240
                    },
                    "biddingSizes": [
                        [970, 250],
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [360],
            "impressionLimit": 8,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "sidebar_sticky_courses",
        "sticky": {
            "zIndex": 1,
            "topOffset": 0,
            "makeParentSticky": false,
            "minSpaceToNextAd": 0
        },
        "bidders": [{
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238400
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "amx",
            "params": {
                "tagId": "c25pZ2VsLmNvbQ",
                "adUnitId": "w3_sidebar_sticky_courses"
            },
            "objectTargeting": {
                "filterId": "83"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 21709732
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "677773"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a969434017979ae664dc4929d750262"
            }
        }, {
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3_sidebar_sticky_courses",
                "organizationId": "1060",
                "adUnitElementId": "adngin-sidebar_sticky_courses"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "544079626",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 2065392,
                "accountId": 14598
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true,
            "sizeConstriction": false
        },
        "adUnitPath": "/22152718,16833175/w3schools_sidebar_sticky_courses",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 1134,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [120, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1674,
                        "min-width": 1135
                    },
                    "biddingSizes": [
                        [120, 600],
                        [160, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1675
                    },
                    "biddingSizes": [
                        [300, 600],
                        [160, 600]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [360],
            "impressionLimit": 6,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "sidebar_top_courses",
        "bidders": [{
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238402
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "amx",
            "params": {
                "tagId": "c25pZ2VsLmNvbQ",
                "adUnitId": "w3_sidebar_top_courses"
            },
            "objectTargeting": {
                "filterId": "83"
            }
        }, {
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3_sidebar_top_courses",
                "organizationId": "1060",
                "adUnitElementId": "adngin-sidebar_top_courses-0"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 21709733
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "677774"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a96917d017979ae6267c492f4ce026c"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "544079627",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 2065394,
                "accountId": 14598
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true,
            "sizeConstriction": false
        },
        "adUnitPath": "/22152718,16833175/w3schools_sidebar_top_courses",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 729
                    },
                    "biddingSizes": [
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 992,
                        "min-width": 730
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1134,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [120, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1674,
                        "min-width": 1135
                    },
                    "biddingSizes": [
                        [120, 600],
                        [160, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1675
                    },
                    "biddingSizes": [
                        [160, 600],
                        [300, 600]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [360],
            "impressionLimit": 6,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "try_it_leaderboard_courses",
        "bidders": [{
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238404
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "onetag",
            "params": {
                "ext": {
                    "placement_name": "w3schools.com_try_it_leaderboard_courses"
                },
                "pubId": "5f8e06c2cbd2faa"
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true,
            "sizeConstriction": false
        },
        "adUnitPath": "/22152718,16833175/w3schools_try_it_leaderboard_courses",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 467
                    },
                    "biddingSizes": [
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 727,
                        "min-width": 467
                    },
                    "biddingSizes": [
                        [468, 60]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 975,
                        "min-width": 730
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 976
                    },
                    "biddingSizes": [
                        [970, 90],
                        [728, 90]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [240],
            "impressionLimit": 6,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "bottom_left",
        "bidders": [{
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3schools.com_bottom_left",
                "organizationId": "1060",
                "adUnitElementId": "w3schools.com_bottom_left"
            }
        }, {
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "smilewanted",
            "params": {
                "zoneId": "w3schools.com_hb_display_2"
            },
            "objectTargeting": {
                "filterId": "99"
            }
        }, {
            "bidder": "sharethrough",
            "params": {
                "pkey": "yQz3yLaGi7xNbt4ZBGx6fYeH"
            },
            "objectTargeting": {
                "filterId": "18"
            }
        }, {
            "bidder": "smartadserver",
            "params": {
                "pageId": 932547,
                "siteId": 219976,
                "formatId": 62370,
                "networkId": 2967
            },
            "objectTargeting": {
                "filterId": "65"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "sws_hb_w3schools_bottom_970x250"
            }
        }, {
            "bidder": "triplelift",
            "params": {
                "inventoryCode": "w3schools-bottom_medium_rectangle"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 914490,
                "accountId": 14598
            }
        }, {
            "bidder": "pubmatic",
            "params": {
                "adSlot": "sws-hb_w3schools_Bottom_BillboardMPU@970x250",
                "publisherId": "157369"
            },
            "objectTargeting": {
                "filterId": "59"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "539960998",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "277112"
            }
        }, {
            "bidder": "connectad",
            "params": {
                "siteId": 1011573,
                "networkId": 10047
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 13164165
            }
        }, {
            "bidder": "33across",
            "params": {
                "siteId": "bnNnBAFAar6QjTaKlId8sQ",
                "productId": "siab"
            },
            "objectTargeting": {
                "filterId": "56"
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true
        },
        "snConfig": {
            "video": false
        },
        "adUnitPath": "/22152718,16833175/sws-hb//w3schools.com//bottom_medium_rectangle",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 1239
                    },
                    "biddingSizes": [
                        [300, 250]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1240
                    },
                    "biddingSizes": [
                        [970, 250],
                        [300, 250]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [5910239413],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [240],
            "impressionLimit": 8,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [5914180236, 5499771499, 5548095811],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "bottom_right",
        "bidders": [{
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3schools.com_bottom_left",
                "organizationId": "1060",
                "adUnitElementId": "w3schools.com_bottom_left"
            }
        }, {
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "smilewanted",
            "params": {
                "zoneId": "w3schools.com_hb_display_3"
            },
            "objectTargeting": {
                "filterId": "99"
            }
        }, {
            "bidder": "sharethrough",
            "params": {
                "pkey": "LeeZ2TH9yYcYziKAciybTN5L"
            },
            "objectTargeting": {
                "filterId": "44"
            }
        }, {
            "bidder": "sovrn",
            "params": {
                "tagid": "565881"
            },
            "objectTargeting": {
                "filterId": "64"
            }
        }, {
            "bidder": "smartadserver",
            "params": {
                "pageId": 932548,
                "siteId": 219976,
                "formatId": 62361,
                "networkId": 2967
            },
            "objectTargeting": {
                "filterId": "65"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a969548017474931fc795edccd80c71"
            }
        }, {
            "bidder": "33across",
            "params": {
                "siteId": "bqPB9YFAar6QjTaKlId8sQ",
                "productId": "siab"
            },
            "objectTargeting": {
                "filterId": "56"
            }
        }, {
            "bidder": "triplelift",
            "params": {
                "inventoryCode": "w3schools-right_bottom_medium_rectangle"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 914492,
                "accountId": 14598
            }
        }, {
            "bidder": "pubmatic",
            "params": {
                "adSlot": "sws-hb_w3schools_Bottom_Right_MPU@300x250",
                "publisherId": "157369"
            },
            "objectTargeting": {
                "filterId": "59"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "539960999",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "277111"
            }
        }, {
            "bidder": "conversant",
            "params": {
                "site_id": "117726"
            },
            "objectTargeting": {
                "filterId": "43"
            }
        }, {
            "bidder": "connectad",
            "params": {
                "siteId": 1011575,
                "networkId": 10047
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 13164166
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true
        },
        "snConfig": {
            "video": false
        },
        "adUnitPath": "/22152718,16833175/sws-hb//w3schools.com//right_bottom_medium_rectangle",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "min-width": 975
                    },
                    "biddingSizes": [
                        [300, 250]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [240],
            "impressionLimit": 8,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "main_leaderboard",
        "bidders": [{
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3schools.com_main_leaderboard",
                "organizationId": "1060",
                "adUnitElementId": "w3schools.com_main_leaderboard"
            }
        }, {
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "smilewanted",
            "params": {
                "zoneId": "w3schools.com_hb_display"
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "sharethrough",
            "params": {
                "pkey": "qSwaPRfYnKpExSLZYndRfVNM"
            },
            "objectTargeting": {
                "filterId": "44"
            }
        }, {
            "bidder": "smartadserver",
            "params": {
                "pageId": 932544,
                "siteId": 219976,
                "formatId": 62368,
                "networkId": 2967
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "sws_hb_w3schools_leader_728x90"
            }
        }, {
            "bidder": "33across",
            "params": {
                "siteId": "beuMI6FAar6QjTaKlId8sQ",
                "productId": "siab"
            },
            "objectTargeting": {
                "filterId": "56"
            }
        }, {
            "bidder": "pubmatic",
            "params": {
                "adSlot": "sws-hb_w3schools_Main_Leaderboard@728x90",
                "publisherId": "157369"
            },
            "objectTargeting": {
                "filterId": "59"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "539960990",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "triplelift",
            "params": {
                "inventoryCode": "w3schools-main_leaderboard"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 914484,
                "accountId": 14598
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "277108"
            }
        }, {
            "bidder": "connectad",
            "params": {
                "siteId": 1011566,
                "networkId": 10047
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 13164162
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true
        },
        "snConfig": {
            "video": false
        },
        "adUnitPath": "/22152718,16833175/sws-hb//w3schools.com//main_leaderboard",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 469
                    },
                    "biddingSizes": [
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 779,
                        "min-width": 470
                    },
                    "biddingSizes": [
                        [468, 60],
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 992,
                        "min-width": 780
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1024,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [468, 60],
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1440,
                        "min-width": 1025
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1441
                    },
                    "biddingSizes": [
                        [728, 90],
                        [970, 90]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [240],
            "impressionLimit": 12,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "mid_content",
        "bidders": [{
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3schools.com_mid_content",
                "organizationId": "1060",
                "adUnitElementId": "w3schools.com_mid_content"
            }
        }, {
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "smilewanted",
            "params": {
                "zoneId": "w3schools.com_hb_display_1"
            },
            "objectTargeting": {
                "filterId": "99"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238403
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "sharethrough",
            "params": {
                "pkey": "zWrg6ypVT58Wt1pWbTwKqfz3"
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "smartadserver",
            "params": {
                "pageId": 932546,
                "siteId": 219976,
                "formatId": 62361,
                "networkId": 2967
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "sws_hb_w3schools_mid_300x250"
            }
        }, {
            "bidder": "33across",
            "params": {
                "siteId": "bkPA-MFAar6QjTaKlId8sQ",
                "productId": "siab"
            },
            "objectTargeting": {
                "filterId": "56"
            }
        }, {
            "bidder": "pubmatic",
            "params": {
                "adSlot": "sws-hb_w3schools_Mid_Content@300x250",
                "publisherId": "157369"
            },
            "objectTargeting": {
                "filterId": "59"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "539960995",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "triplelift",
            "params": {
                "inventoryCode": "w3schools-mid_content"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 914488,
                "accountId": 14598
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "277109"
            }
        }, {
            "bidder": "connectad",
            "params": {
                "siteId": 1011570,
                "networkId": 10047
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 13164164
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }],
        "adaptive": {
            "enabled": true,
            "uniformGrouping": true,
            "sizeConstriction": true
        },
        "snConfig": {
            "video": false
        },
        "adUnitPath": "/22152718,16833175/sws-hb//w3schools.com//mid_content",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 469
                    },
                    "biddingSizes": [
                        [300, 250],
                        [320, 50],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 779,
                        "min-width": 470
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280],
                        [468, 60],
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 992,
                        "min-width": 780
                    },
                    "biddingSizes": [
                        [728, 90],
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1024,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1440,
                        "min-width": 1025
                    },
                    "biddingSizes": [
                        [728, 90],
                        [300, 250],
                        [336, 280]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1441
                    },
                    "biddingSizes": [
                        [728, 90],
                        [970, 250],
                        [970, 90],
                        [300, 250]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [240],
            "impressionLimit": 9,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "try_it_leaderboard",
        "bidders": [{
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3schools_try_it_leaderboard",
                "organizationId": "1060",
                "adUnitElementId": "w3schools_try_it_leaderboard"
            }
        }, {
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238404
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "sharethrough",
            "params": {
                "pkey": "QDVJeMCDiuG4S6vTEGqqmtpX"
            },
            "objectTargeting": {
                "filterId": "44"
            }
        }, {
            "bidder": "sovrn",
            "params": {
                "tagid": "563928"
            },
            "objectTargeting": {
                "filterId": "64"
            }
        }, {
            "bidder": "smartadserver",
            "params": {
                "pageId": 935090,
                "siteId": 219976,
                "formatId": 62364,
                "networkId": 2967
            },
            "objectTargeting": {
                "filterId": "65"
            }
        }, {
            "bidder": "onetag",
            "params": {
                "ext": {
                    "placement_name": "w3schools.com_try_it_leaderboard"
                },
                "pubId": "5f8e06c2cbd2faa"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "8a969548017474931fc795f05f6b0c72"
            }
        }, {
            "bidder": "33across",
            "params": {
                "siteId": "bud0kcFAar6QjTaKlId8sQ",
                "productId": "siab"
            },
            "objectTargeting": {
                "filterId": "56"
            }
        }, {
            "bidder": "pubmatic",
            "params": {
                "adSlot": "sws-hb_w3schools_try_it_pages_leaderboard@728x90",
                "publisherId": "157369"
            },
            "objectTargeting": {
                "filterId": "59"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "540001628",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "triplelift",
            "params": {
                "inventoryCode": "w3schools-try_it_leaderboard"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 922576,
                "accountId": 14598
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "277113"
            }
        }, {
            "bidder": "conversant",
            "params": {
                "site_id": "124672"
            },
            "objectTargeting": {
                "filterId": "43"
            }
        }, {
            "bidder": "connectad",
            "params": {
                "siteId": 1011576,
                "networkId": 10047
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 13218673
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true
        },
        "adUnitPath": "/22152718,16833175/sws-hb//w3schools.com//try_it_leaderboard",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 467
                    },
                    "biddingSizes": [
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 727,
                        "min-width": 468
                    },
                    "biddingSizes": [
                        [468, 60]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 728
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [180],
            "impressionLimit": 10,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "sidebar_top",
        "bidders": [{
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3schools.com_sidebar_top",
                "organizationId": "1060",
                "adUnitElementId": "w3schools.com_sidebar_top"
            }
        }, {
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "smilewanted",
            "params": {
                "zoneId": "w3schools.com_hb_display_5"
            },
            "objectTargeting": {
                "filterId": "99"
            }
        }, {
            "bidder": "sharethrough",
            "params": {
                "pkey": "W4DqWva41ymo3DwcRAHNkHtd"
            },
            "objectTargeting": {
                "filterId": "44"
            }
        }, {
            "bidder": "sovrn",
            "params": {
                "tagid": "565863"
            },
            "objectTargeting": {
                "filterId": "64"
            }
        }, {
            "bidder": "smartadserver",
            "params": {
                "pageId": 932545,
                "siteId": 219976,
                "formatId": 62362,
                "networkId": 2967
            },
            "objectTargeting": {
                "filterId": "65"
            }
        }, {
            "bidder": "onetag",
            "params": {
                "ext": {
                    "placement_name": "w3schools.com_sidebar_top"
                },
                "pubId": "5f8e06c2cbd2faa"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "sws_hb_w3schools_wide_300x600"
            }
        }, {
            "bidder": "33across",
            "params": {
                "siteId": "bhud6yFAar6QjTaKlId8sQ",
                "productId": "siab"
            },
            "objectTargeting": {
                "filterId": "56"
            }
        }, {
            "bidder": "triplelift",
            "params": {
                "inventoryCode": "w3schools-wide_skyscraper"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 914486,
                "accountId": 14598
            }
        }, {
            "bidder": "pubmatic",
            "params": {
                "adSlot": "sws-hb_w3schools_Wide_Skyscraper@160x600",
                "publisherId": "157369"
            },
            "objectTargeting": {
                "filterId": "59"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "539960993",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "277110"
            }
        }, {
            "bidder": "connectad",
            "params": {
                "siteId": 1011569,
                "networkId": 10047
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 13164163
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true
        },
        "adUnitPath": "/22152718,16833175/sws-hb//w3schools.com//wide_skyscraper",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 729
                    },
                    "biddingSizes": [
                        [320, 50]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 992,
                        "min-width": 730
                    },
                    "biddingSizes": [
                        [728, 90]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1185,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [120, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1674,
                        "min-width": 1185
                    },
                    "biddingSizes": [
                        [160, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1675
                    },
                    "biddingSizes": [
                        [160, 600],
                        [300, 600]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [240],
            "impressionLimit": 14,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": true,
            "campaignIdBlacklist": [2675212261],
            "lineItemIdBlacklist": [],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "sidebar_sticky",
        "sticky": {
            "zIndex": 1,
            "topOffset": 0,
            "makeParentSticky": false,
            "minSpaceToNextAd": 0
        },
        "bidders": [{
            "bidder": "adagio",
            "params": {
                "site": "w3schools-com",
                "placement": "w3schools.com_sidebar_sticky",
                "organizationId": "1060",
                "adUnitElementId": "w3schools.com_sidebar_sticky"
            }
        }, {
            "bidder": "amazon",
            "params": {},
            "objectTargeting": {
                "filterId": "21"
            }
        }, {
            "bidder": "smilewanted",
            "params": {
                "zoneId": "w3schools.com_hb_display_4"
            },
            "objectTargeting": {
                "filterId": "99"
            }
        }, {
            "bidder": "unruly",
            "params": {
                "siteId": 238400
            },
            "objectTargeting": {
                "filterId": "84"
            }
        }, {
            "bidder": "smartadserver",
            "params": {
                "pageId": 917874,
                "siteId": 219976,
                "formatId": 62362,
                "networkId": 2967
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "onemobile",
            "params": {
                "dcn": "8a9694b8017070f8309df8ed25b10036",
                "pos": "sws_hb_w3schools_side_300x600"
            },
            "objectTargeting": {
                "filterId": "22"
            }
        }, {
            "bidder": "conversant",
            "params": {
                "site_id": "117726"
            },
            "objectTargeting": {
                "filterId": "43"
            }
        }, {
            "bidder": "33across",
            "params": {
                "siteId": "a-cFKuFAar6QjTaKlId8sQ",
                "productId": "siab"
            },
            "objectTargeting": {
                "filterId": "56"
            }
        }, {
            "bidder": "triplelift",
            "params": {
                "inventoryCode": "w3schools-sidebar_sticky"
            }
        }, {
            "bidder": "rubicon",
            "params": {
                "siteId": 181004,
                "zoneId": 883812,
                "accountId": 14598
            }
        }, {
            "bidder": "pubmatic",
            "params": {
                "adSlot": "sws-hb_w3schools_right_sidebar_2@160x600",
                "publisherId": "157369"
            },
            "objectTargeting": {
                "filterId": "59"
            }
        }, {
            "bidder": "openx",
            "params": {
                "unit": "539882512",
                "delDomain": "snigel-d.openx.net"
            },
            "objectTargeting": {
                "filterId": "80"
            }
        }, {
            "bidder": "ix",
            "params": {
                "siteId": "259558"
            }
        }, {
            "bidder": "connectad",
            "params": {
                "siteId": 1011567,
                "networkId": 10047
            }
        }, {
            "bidder": "appnexus",
            "params": {
                "placementId": 12987174
            }
        }],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true
        },
        "snConfig": {
            "video": false
        },
        "adUnitPath": "/22152718,16833175/sws-hb//w3schools.com//sidebar_sticky",
        "sizeMapping": {
            "banner": {
                "dynamicSizes": [{
                    "mediaQuery": {
                        "max-width": 1185,
                        "min-width": 993
                    },
                    "biddingSizes": [
                        [120, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "max-width": 1674,
                        "min-width": 1185
                    },
                    "biddingSizes": [
                        [160, 600],
                        [120, 600]
                    ],
                    "additionalSizes": []
                }, {
                    "mediaQuery": {
                        "min-width": 1675
                    },
                    "biddingSizes": [
                        [160, 600],
                        [300, 600],
                        [300, 250]
                    ],
                    "additionalSizes": []
                }]
            }
        },
        "smartRefresh": [{
            "intervalsSec": [240],
            "impressionLimit": 14,
            "enableOnViewable": false,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [2675212261, 2758269534],
            "lineItemIdBlacklist": [5499771499],
            "triggerOnUserActive": false
        }, {
            "intervalsSec": [30],
            "impressionLimit": 0,
            "enableOnViewable": true,
            "triggerOnViewable": false,
            "campaignIdBlacklist": [],
            "lineItemIdBlacklist": [5499771499],
            "triggerOnUserActive": false
        }],
        "adUnitPathRegex": ""
    }, {
        "name": "video2",
        "bidders": [],
        "adaptive": {
            "enabled": false,
            "uniformGrouping": true,
            "sizeConstriction": false
        },
        "adUnitPath": "/22152718,16833175/w3schools_video2",
        "sizeMapping": {
            "banner": {
                "biddingSizes": [],
                "additionalSizes": [
                    [1, 1]
                ]
            }
        },
        "adUnitPathRegex": "",
        "adUnitPathOverride": false
    }],
    "elementPrefix": "adngin",
    "pbjsAnalytics": {
        "providers": [{
            "provider": "adagio"
        }]
    },
    "targeting": {
        "11": {
            "and": [{
                "or": ["mobile"]
            }]
        },
        "18": {
            "and": []
        },
        "21": {
            "and": [{
                "or": ["US", "CA", "AU", "SG", "DE", "GB", "NL", "AT", "SE", "FI", "BR", "SA", "CL", "JP", "HK", "AE", "NZ", "NO", "KW", "MC", "IT", "ES", "FR", "CH", "CZ", "PT", "BE", "IE", "DK", "SK", "LV", "EE", "IS", "BG", "HU", "LT", "LU", "MT", "RO", "SI", "MX", "GR", "HR", "CY", "KR", "PL", "LI"]
            }]
        },
        "22": {
            "and": [{
                "or": ["AT", "BE", "BG", "CH", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HR", "HU", "IE", "IS", "IT", "LI", "LT", "LU", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK", "TR", "AU", "BR", "JP", "MX", "CA", "US", "SG", "AL", "AD", "AM", "AZ", "BY", "GE", "KZ", "MD", "MC", "ME", "MK", "SM", "RS", "UA", "AR", "CL", "CO", "EG", "PE", "TW", "TH", "AE", "CN", "IL", "MY", "NZ", "PH", "RU", "SA", "ZA"]
            }]
        },
        "43": {
            "and": [{
                "or": ["US", "DE", "GB", "CA"]
            }]
        },
        "44": {
            "and": [{
                "or": ["US", "CA", "GB", "AU", "BR", "IT", "MX", "KR", "SG", "PE", "NZ", "CO", "IE", "AE"]
            }]
        },
        "56": {
            "and": [{
                "or": ["US", "CA", "AU", "NZ"]
            }]
        },
        "59": {
            "and": [{
                "nor": ["AL", "BI", "BY", "CF", "CU", "IQ", "IR", "KP", "LB", "LY", "ME", "MK", "SD", "SO", "SY", "UA", "VE", "YE", "ZW", "SS"]
            }]
        },
        "64": {
            "and": [{
                "or": ["AR", "AT", "BE", "BR", "CA", "CL", "CO", "HR", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IL", "IT", "LV", "LT", "MX", "NL", "NO", "PE", "PL", "PT", "RO", "SK", "ZA", "ES", "SE", "CH", "TR", "GB", "US"]
            }]
        },
        "65": {
            "and": [{
                "nor": ["RU", "BG", "EG", "CO", "PE", "TR", "IL", "EC", "GR", "BR", "UA", "RS"]
            }]
        },
        "80": {
            "and": [{
                "nor": ["AF", "AX", "AL", "DZ", "AS", "AI", "AG", "AM", "AW", "AZ", "BS", "BH", "BB", "BZ", "BJ", "BM", "BO", "BA", "BW", "BN", "BG", "BI", "KH", "KY", "CF", "TD", "CN", "CG", "CD", "CI", "CW", "CY", "CZ", "DM", "EG", "SV", "GQ", "EE", "FO", "FJ", "GF", "PF", "GA", "GM", "GE", "GI", "GL", "GD", "GU", "GG", "GN", "GW", "GY", "HT", "VA", "HN", "IR", "IQ", "JM", "JO", "KE", "KI", "KG", "LA", "LV", "LB", "LS", "LR", "LY", "LI", "LU", "MK", "MG", "MW", "ML", "MT", "MH", "MQ", "MR", "MU", "YT", "FM", "MD", "MN", "ME", "MS", "MZ", "MM", "NR", "NP", "NI", "NE", "NF", "MP", "PS", "QA", "RE", "BL", "KN", "LC", "MF", "PM", "VC", "WS", "SM", "SC", "SL", "SX", "SK", "SI", "SB", "SO", "SS", "LK", "SD", "SZ", "SY", "TZ", "TL", "TG", "TT", "TN", "TV", "UG", "UZ", "VU", "VE", "VG", "VI", "GH", "GP", "HU", "IS", "IM", "JE", "KW", "MO", "MV", "MC", "NC", "NU", "OM", "PA", "PG", "PY", "ST", "SR", "TJ", "TM", "TC", "YE", "ZM", "ZW", "NA", "PW", "RW", "SN", "TO", "UM", "WF", "AD", "AO", "BT", "IO", "BF", "CM", "CV", "KM", "CK", "DJ", "ER", "ET", "FK"]
            }]
        },
        "83": {
            "and": [{
                "nor": ["WF", "WS", "TL", "TK", "GU", "PW", "PF", "PG", "PN", "SB", "MH", "MP", "FJ", "FM", "VU", "NC", "NF", "NZ", "NR", "NU", "CK", "KI", "UM", "TV", "TO", "AS", "AU", "BD", "BN", "BH", "BT", "TM", "TJ", "JP", "GE", "OM", "JO", "HK", "PS", "IQ", "PK", "PH", "VN", "SA", "UZ", "MM", "MO", "MN", "MV", "MY", "IL", "IO", "NP", "CN", "CC", "CX", "SY", "KG", "KH", "KR", "KP", "KW", "KZ", "SG", "YE", "LB", "LA", "TW", "TR", "LK", "TH", "AE", "AF", "IR", "AM", "IN", "AZ", "ID", "QA"]
            }]
        },
        "84": {
            "and": [{
                "or": ["GB", "US"]
            }]
        },
        "99": {
            "and": [{
                "nor": ["AF", "AX", "AL", "DZ", "AS", "AD", "AO", "AI", "AQ", "AG", "AM", "AW", "AZ", "BS", "BH", "BD", "BB", "BZ", "BJ", "BM", "BT", "BO", "BQ", "BA", "BW", "IO", "BN", "BG", "BF", "BI", "CM", "CV", "KY", "TD", "CN", "CX", "CC", "KM", "CD", "CG", "CK", "CU", "CY", "CZ", "DJ", "DM", "EC", "EG", "SV", "GQ", "ER", "ET", "FK", "FO", "FJ", "PF", "GA", "GM", "GE", "GH", "GI", "GR", "GL", "GD", "GU", "GG", "GN", "GW", "GY", "HT", "HN", "HU", "IS", "IR", "IQ", "IM", "JM", "JE", "JO", "KI", "KP", "KW", "LA", "LB", "LS", "LR", "LY", "MO", "MG", "MW", "MY", "MV", "ML", "MT", "MH", "MR", "YT", "FM", "MN", "MS", "MZ", "MM", "NA", "NR", "NP", "NC", "NI", "NE", "NU", "NF", "MP", "PK", "PW", "PS", "PG", "PY", "PE", "PH", "PN", "QA", "RW", "SH", "KN", "LC", "MF", "PM", "VC", "WS", "SM", "ST", "SA", "RS", "SC", "SL", "SX", "SK", "SB", "SO", "GS", "SS", "LK", "SD", "SR", "SJ", "SZ", "SY", "TJ", "TZ", "TL", "TG", "TK", "TO", "TT", "TM", "TC", "TV", "UG", "UM", "VU", "VA", "VE", "VG", "WF", "EH", "YE", "ZM", "ZW", "TF", "HM", "BV"]
            }]
        }
    },
    "site": "w3schools.com",
    "version": "6537-1679996183563",
    "currencyRates": {
        "EUR": {
            "EUR": 1,
            "USD": 1.0773,
            "JPY": 141.64,
            "BGN": 1.9558,
            "CZK": 23.732,
            "DKK": 7.4515,
            "GBP": 0.87818,
            "HUF": 385.3,
            "PLN": 4.6855,
            "RON": 4.9405,
            "SEK": 11.212,
            "CHF": 0.9875,
            "ISK": 149.9,
            "NOK": 11.338,
            "TRY": 20.5701,
            "AUD": 1.6204,
            "BRL": 5.6362,
            "CAD": 1.4769,
            "CNY": 7.4131,
            "HKD": 8.4566,
            "IDR": 16319.16,
            "ILS": 3.8412,
            "INR": 88.6672,
            "KRW": 1400.23,
            "MXN": 19.8128,
            "MYR": 4.7633,
            "NZD": 1.7397,
            "PHP": 58.347,
            "SGD": 1.4351,
            "THB": 37.07,
            "ZAR": 19.7373
        },
        "USD": {
            "EUR": 0.92824654228163,
            "USD": 1,
            "JPY": 131.47684024877006,
            "BGN": 1.815464587394412,
            "CZK": 22.029146941427644,
            "DKK": 6.916829109811566,
            "GBP": 0.8151675485008818,
            "HUF": 357.65339274111204,
            "PLN": 4.349299173860578,
            "RON": 4.586002042142393,
            "SEK": 10.407500232061636,
            "CHF": 0.9166434605031096,
            "ISK": 139.14415668801632,
            "NOK": 10.524459296389121,
            "TRY": 19.09412419938736,
            "AUD": 1.5041306971131532,
            "BRL": 5.231783161607723,
            "CAD": 1.3709273182957393,
            "CNY": 6.881184442587951,
            "HKD": 7.849809709458833,
            "IDR": 15148.203842940686,
            "ILS": 3.565580618212197,
            "INR": 82.30502181379374,
            "KRW": 1299.7586558990067,
            "MXN": 18.39116309291748,
            "MYR": 4.421516754850088,
            "NZD": 1.6148705096073517,
            "PHP": 54.16040100250627,
            "SGD": 1.3321266128283673,
            "THB": 34.41009932238003,
            "ZAR": 18.321080478975215
        }
    },
    "build": "production-136",
    "id": "w3schools.com:6537-1679996183563-default",
    "environment": "production",
    "country": "IN",
    "region": "KL",
    "configGeo": "default",
    "cfwConfigHit": true,
    "cfwCoreHit": true,
    "cfwUserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36",
    "cfwUuid": "fe2a49ce-308e-4f82-82d4-d6979897fd2a"
};